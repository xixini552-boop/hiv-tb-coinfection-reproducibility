import pandas as pd
for c,f in [("South Africa","South_Africa_augmented_TB_HIV.csv"),("Kenya","Kenya_augmented_TB_HIV.csv"),("Thailand","Thailand_augmented_TB_HIV.csv"),("Portugal","Portugal_augmented_TB_HIV.csv")]:
    df=pd.read_csv(f)
    print("==",c)
    print("  tb:", df["tb_inc_100k"].tolist())
    print("  hiv:", df["hiv_prev_pct"].tolist())
    print("  ptp tb", df["tb_inc_100k"].max()-df["tb_inc_100k"].min(), "ptp hiv", df["hiv_prev_pct"].max()-df["hiv_prev_pct"].min())
