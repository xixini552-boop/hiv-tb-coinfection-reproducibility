"""Generate noisy profile-objective diagnostic figure."""
import sys, os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
RES = os.path.join(ROOT, "identifiability", "PINN", "results",
                   "identifiability_final", "noisy_profile_diagnostic.json")
FIG = os.path.join(ROOT, "identifiability", "PINN", "figures",
                   "fig_noisy_profile_m.pdf")

with open(RES) as f:
    data = json.load(f)

fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.6))

colors = ["#1f77b4", "#d62728", "#2ca02c"]
# Left: raw objective vs m (log x)
ax = axes[0]
for run, c in zip(data["runs"], colors):
    m = np.array(run["fixed"])
    o = np.array(run["objectives"])
    ax.plot(m, o, "o-", color=c, ms=4, lw=1.4,
            label=f"noise seed {run['seed']}")
true_m = data["configuration"]["true_m"]
ax.axvline(true_m, color="k", ls="--", lw=1.2, label=f"true m={true_m}")
ax.set_xscale("log")
ax.set_xlabel("fixed response-shape parameter m")
ax.set_ylabel("best relative-error objective (2x cost)")
# Panel letters are supplied by the LaTeX subfigure captions.
ax.legend(fontsize=7.5, frameon=False)
ax.grid(alpha=0.25)

# Right: normalized objective (subtract each run min) to show flatness
ax = axes[1]
for run, c in zip(data["runs"], colors):
    m = np.array(run["fixed"])
    o = np.array(run["objectives"])
    on = (o - o.min()) / o.min() * 100.0  # percent above own minimum
    ax.plot(m, on, "o-", color=c, ms=4, lw=1.4,
            label=f"seed {run['seed']}")
ax.axvline(true_m, color="k", ls="--", lw=1.2)
ax.set_xscale("log")
ax.set_xlabel("fixed response-shape parameter m")
ax.set_ylabel("% objective above run minimum")
ax.legend(fontsize=7.5, frameon=False)
ax.grid(alpha=0.25)

plt.tight_layout()
plt.savefig(FIG, bbox_inches="tight")
print(f"Saved figure: {FIG}")

# Print quantitative summary
print("\n=== Quantitative flatness summary ===")
for run in data["runs"]:
    o = np.array(run["objectives"])
    m = np.array(run["fixed"])
    rel_spread = (o.max() - o.min()) / o.min() * 100
    imin = int(np.argmin(o))
    loc = "lower bound" if imin == 0 else ("upper bound" if imin == len(o)-1 else "interior")
    obj_at_true = o[np.argmin(np.abs(m - true_m))]
    gap_true = (obj_at_true - o.min()) / o.min() * 100
    print(f"seed {run['seed']}: spread={rel_spread:.2f}%, min at {loc} "
          f"(m={m[imin]:.4f}), true-m objective {gap_true:.3f}% above min")
