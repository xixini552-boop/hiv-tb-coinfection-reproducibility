"""Conditional country PINN validation for the new identifiability branch.

This script is deliberately not a country parameter-estimation routine.  It
loads the nuisance-parameter solution saved by the isolated direct-ODE
country profile, fixes *all* physical parameters at one profile point
(including a selected value of ``m``), and trains only the state network.  The
purpose is to check whether PINN state reconstruction can reproduce the same
conditional fits without changing the shared ODE or observation operators.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np
import pandas as pd
import torch

CODE_DIR = Path(__file__).resolve().parent
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import pinn_training_paper_safe as shared  # noqa: E402


DATA_DIR = CODE_DIR.parent / "data"
PROFILE_PATH = (
    CODE_DIR.parent
    / "results"
    / "identifiability_country_profiles_with_params"
    / "identifiability_country_profiles.json"
)
OUT_DIR = CODE_DIR.parent / "results" / "pinn_country_conditional"

COUNTRY_FILES = {
    "South Africa": DATA_DIR / "South_Africa_augmented_TB_HIV.csv",
    "Kenya": DATA_DIR / "Kenya_augmented_TB_HIV.csv",
    "Thailand": DATA_DIR / "Thailand_augmented_TB_HIV.csv",
    "Portugal": DATA_DIR / "Portugal_augmented_TB_HIV.csv",
}


def load_country(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    df = pd.read_csv(path).sort_values("year").reset_index(drop=True)
    mask = df["tb_inc_100k"].notna() & df["hiv_prev_pct"].notna()
    df = df.loc[mask].copy()
    years = df["year"].to_numpy(dtype=float)
    t_eval = years - years[0]
    target = np.column_stack(
        [
            df["tb_inc_100k"].to_numpy(dtype=float),
            df["hiv_prev_pct"].to_numpy(dtype=float),
        ]
    )
    return years, t_eval, target


def nearest_profile_rows(
    profile: dict[str, Any],
    requested: list[float],
) -> list[dict[str, Any]]:
    rows = profile["m_profile"]["grid"]
    selected: list[dict[str, Any]] = []
    seen: set[float] = set()
    for value in requested:
        row = min(rows, key=lambda item: abs(float(item["fixed_m"]) - float(value)))
        fixed_m = float(row["fixed_m"])
        if fixed_m not in seen:
            selected.append(row)
            seen.add(fixed_m)
    return selected


def train_state_once(
    years: np.ndarray,
    target: np.ndarray,
    params: dict[str, float],
    seed: int,
    epochs_scale: float,
    annual_operator: bool = False,
) -> dict[str, Any]:
    shared.set_random_seed(int(seed))
    # The annual-incidence operator integrates one interval starting at each
    # reported year.  Consequently, 15 observations require a 15-year
    # forward horizon (the last interval ends one year after the final
    # reported prevalence value).
    time_horizon = float(years[-1] - years[0] + (1.0 if annual_operator else 0.0))
    time_horizon = max(time_horizon, 1e-12)
    t_norm = (years - years[0]) / time_horizon
    t_data = torch.tensor(t_norm.reshape(-1, 1), dtype=torch.float32)
    t_colloc = torch.tensor(
        np.linspace(0.0, 1.0, 300).reshape(-1, 1), dtype=torch.float32
    )
    t0 = torch.zeros((1, 1), dtype=torch.float32)
    tb_target = torch.tensor(target[:, 0], dtype=torch.float32)
    hiv_target = torch.tensor(target[:, 1], dtype=torch.float32)

    y_min, y_scale = shared.compute_country_norm(target[:, 0], target[:, 1])
    shared.set_ode_normalization(y_min, y_scale)
    x0_target = torch.tensor(
        shared.make_seed(float(params["tb_prev"]), float(params["hiv_prev"]))
        .reshape(1, -1),
        dtype=torch.float32,
    )

    param_module = shared.ParameterModule(params)
    shared.set_healthcare_trainability(param_module, ())
    beta1_net = shared.Beta1Network(
        init_beta1=float(params["beta1"]), upper=max(5.0, 2.5 * float(params["beta1"])), degree=1
    )
    beta2_net = shared.Beta2Network(
        init_beta2=float(params["beta2"]), upper=max(0.5, 2.0 * float(params["beta2"])), degree=1
    )
    for net in (beta1_net, beta2_net):
        for parameter in net.parameters():
            parameter.requires_grad_(False)

    state_net = shared.StateNetwork(hidden=32, n_hidden=2)
    parameters = [p for p in state_net.parameters() if p.requires_grad]
    optimizer = torch.optim.Adam(parameters, lr=1e-3)
    history: list[dict[str, float]] = []

    phases = [
        ("P1", int(300 * epochs_scale), 1e-3, 1.0, 0.00),
        ("P2", int(500 * epochs_scale), 5e-4, 1.0, 0.10),
        ("P3", int(700 * epochs_scale), 2e-4, 0.8, 0.50),
        ("P4", int(700 * epochs_scale), 1e-4, 0.5, 1.00),
    ]
    protocol = {
        "optimizer": "Adam",
        "gradient_clip_norm": 5.0,
        "collocation_points": 300,
        "epochs_scale": float(epochs_scale),
        "phase_schedule": [
            {
                "phase": label,
                "epochs": int(n_epochs),
                "learning_rate": float(lr),
                "data_weight": float(w_data),
                "ode_weight": float(w_ode),
                "initial_condition_weight": 1.0,
            }
            for label, n_epochs, lr, w_data, w_ode in phases
        ],
    }
    tb_scale = max(float(np.ptp(target[:, 0])), 1.0)
    hiv_scale = max(float(np.ptp(target[:, 1])), 1.0)
    y_scale_t = torch.tensor(y_scale, dtype=torch.float32)

    if annual_operator:
        n_intervals = int(len(years))
        n_quad = 9
        tau = torch.linspace(0.0, 1.0, n_quad, dtype=torch.float32)
        starts = torch.arange(n_intervals, dtype=torch.float32).reshape(-1, 1)
        t_annual_quad = ((starts + tau.reshape(1, -1)) / time_horizon).reshape(-1, 1)
        dt_quad = 1.0 / (time_horizon * float(n_quad - 1))

    def fitted_observables() -> tuple[torch.Tensor, torch.Tensor]:
        if not annual_operator:
            return shared.observables_torch(state_net(t_data))
        tb_quad, _ = shared.observables_torch(state_net(t_annual_quad))
        tb_quad = tb_quad.reshape(n_intervals, n_quad)
        tb_annual = torch.sum(
            0.5 * (tb_quad[:, :-1] + tb_quad[:, 1:]) * dt_quad,
            dim=1,
        )
        _, hiv_at_year = shared.observables_torch(state_net(t_data))
        return tb_annual, hiv_at_year

    for label, n_epochs, lr, w_data, w_ode in phases:
        for group in optimizer.param_groups:
            group["lr"] = lr
        for epoch in range(max(1, n_epochs)):
            optimizer.zero_grad()
            tb_fit, hiv_fit = fitted_observables()
            loss_data = torch.mean(((tb_fit - tb_target) / tb_scale) ** 2)
            loss_data = loss_data + torch.mean(((hiv_fit - hiv_target) / hiv_scale) ** 2)
            residual = shared.compute_ode_residual_both_nets(
                state_net,
                param_module,
                t_colloc,
                beta1_net,
                beta2_net,
                time_horizon=time_horizon,
            )
            loss_ode = torch.mean(residual ** 2)
            x0_pred = state_net(t0)
            loss_init = torch.mean(((x0_pred - x0_target) / y_scale_t) ** 2)
            loss = w_data * loss_data + w_ode * loss_ode + loss_init
            loss.backward()
            torch.nn.utils.clip_grad_norm_(parameters, 5.0)
            optimizer.step()
            if epoch == n_epochs - 1 or epoch % max(1, n_epochs // 4) == 0:
                history.append(
                    {
                        "phase": label,
                        "epoch": float(epoch),
                        "loss_total": float(loss.detach()),
                        "loss_data": float(loss_data.detach()),
                        "loss_ode": float(loss_ode.detach()),
                        "loss_init": float(loss_init.detach()),
                    }
                )

    with torch.no_grad():
        tb_fit, hiv_fit = fitted_observables()
        x0_pred = state_net(t0)
    residual = shared.compute_ode_residual_both_nets(
        state_net,
        param_module,
        t_colloc,
        beta1_net,
        beta2_net,
        time_horizon=time_horizon,
    )
    return {
        "seed": int(seed),
        "fixed_m": float(params["m"]),
        "annual_tb_incidence_operator": bool(annual_operator),
        "fixed_parameters": {key: float(value) for key, value in params.items()},
        "tb_rmse": float(torch.sqrt(torch.mean((tb_fit - tb_target) ** 2))),
        "hiv_rmse": float(torch.sqrt(torch.mean((hiv_fit - hiv_target) ** 2))),
        "tb_rmse_normalized": float(torch.sqrt(torch.mean((tb_fit - tb_target) ** 2)) / tb_scale),
        "hiv_rmse_normalized": float(torch.sqrt(torch.mean((hiv_fit - hiv_target) ** 2)) / hiv_scale),
        "ode_residual_rmse": float(torch.sqrt(torch.mean(residual ** 2))),
        "initial_state_rmse_normalized": float(
            torch.sqrt(torch.mean(((x0_pred - x0_target) / y_scale_t) ** 2))
        ),
        "final_loss": history[-1] if history else {},
        "history": history,
        "training_protocol": protocol,
        "normalization": {
            "observables": "range scaling from each country's annual TB-incidence and HIV-prevalence sequences",
            "state": "shared ODE normalization computed by compute_country_norm",
        },
        "model_modified": False,
        "time_varying_beta_used": False,
        "evidence_role": "conditional_state_reconstruction",
    }


def run_country(
    country: str,
    profile_country: dict[str, Any],
    requested_m: list[float],
    epochs_scale: float,
    seed: int,
    annual_operator: bool = False,
) -> dict[str, Any]:
    years, _, target = load_country(COUNTRY_FILES[country])
    rows = nearest_profile_rows(profile_country, requested_m)
    results = []
    for index, row in enumerate(rows):
        fixed_params = dict(row["recovered"])
        fixed_params["omega_min"] = float(shared.TRUE_VALS["omega_min"])
        print(f"{country}: conditional m={fixed_params['m']:.6g}")
        result = train_state_once(
            years,
            target,
            fixed_params,
            seed=int(seed) + index * 97,
            epochs_scale=float(epochs_scale),
            annual_operator=annual_operator,
        )
        result["direct_ode_profile_objective"] = float(row["objective"])
        result["direct_ode_profile_optimizer_success"] = bool(row["optimizer_success"])
        results.append(result)
        print(
            f"  direct_obj={row['objective']:.6g}, "
            f"TB_RMSE_norm={result['tb_rmse_normalized']:.4f}, "
            f"HIV_RMSE_norm={result['hiv_rmse_normalized']:.4f}, "
            f"ODE_RMSE={result['ode_residual_rmse']:.4e}"
        )
    return {
        "country": country,
        "years": [int(v) for v in years],
        "observations": ["tb_incidence_100k", "hiv_prevalence_pct"],
        "annual_tb_incidence_operator": bool(annual_operator),
        "requested_m": [float(v) for v in requested_m],
        "results": results,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--country", choices=[*COUNTRY_FILES, "all"], default="all")
    parser.add_argument(
        "--profile",
        type=Path,
        default=PROFILE_PATH,
        help="Profile JSON containing nuisance parameters at each fixed-m point.",
    )
    parser.add_argument(
        "--m-values",
        default="0.001001,0.05,1,20",
        help="Comma-separated requested m values; nearest profile rows are used.",
    )
    parser.add_argument("--epochs-scale", type=float, default=0.4)
    parser.add_argument(
        "--annual-operator",
        action="store_true",
        help="Use the annual TB-incidence interval-average operator.",
    )
    parser.add_argument("--seed", type=int, default=20260811)
    parser.add_argument("--out-dir", type=Path, default=OUT_DIR)
    args = parser.parse_args()
    requested_m = [float(v.strip()) for v in args.m_values.split(",") if v.strip()]
    payload_profile = json.loads(args.profile.read_text(encoding="utf-8-sig"))
    countries = list(COUNTRY_FILES) if args.country == "all" else [args.country]
    payload = {
        "analysis": "conditional country PINN state reconstruction",
        "status": "new_branch_only",
        "model_modified": False,
        "old_pinn_branch_run": False,
        "old_results_overwritten": False,
        "time_varying_beta_used": False,
        "annual_tb_incidence_operator": bool(args.annual_operator),
        "evidence_role": "conditional_state_reconstruction",
        "training_protocol": {
            "optimizer": "Adam",
            "gradient_clip_norm": 5.0,
            "collocation_points": 300,
            "epochs_scale": float(args.epochs_scale),
            "phase_epoch_bases": {"P1": 300, "P2": 500, "P3": 700, "P4": 700},
            "learning_rates": {"P1": 1e-3, "P2": 5e-4, "P3": 2e-4, "P4": 1e-4},
        },
        "normalization": {
            "observables": "range scaling from each country's annual TB-incidence and HIV-prevalence sequences",
            "state": "shared ODE normalization computed by compute_country_norm",
        },
        "conditional_parameters_loaded_from": str(args.profile.resolve()),
        "countries": {},
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    for country in countries:
        payload["countries"][country] = run_country(
            country,
            payload_profile["countries"][country],
            requested_m,
            epochs_scale=float(args.epochs_scale),
            seed=int(args.seed) + countries.index(country) * 1000,
            annual_operator=bool(args.annual_operator),
        )
    out_path = args.out_dir / "pinn_country_conditional.json"
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Saved: {out_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
