"""Generate publication-ready figures for the completed identifiability branch.

The script reads only the new JSON outputs and writes to
``PINN/figures/identifiability_final`` directory.  It does not touch the
the annual-observation country heatmaps used by the manuscript.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import numpy as np

CODE_DIR = Path(__file__).resolve().parent
ROOT = CODE_DIR.parent.parent
RESULTS = CODE_DIR.parent / "results"
OUT = CODE_DIR.parent / "figures" / "identifiability_final"

if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))
import pinn_training_paper_safe as shared  # noqa: E402


OKABE_ITO = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9"]
COUNTRY_ORDER = ["South Africa", "Kenya", "Thailand", "Portugal"]
COUNTRY_COLORS = {
    "South Africa": OKABE_ITO[0],
    "Kenya": OKABE_ITO[1],
    "Thailand": OKABE_ITO[2],
    "Portugal": OKABE_ITO[3],
}


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 8,
            "axes.labelsize": 8.5,
            "axes.titlesize": 9,
            "xtick.labelsize": 7.5,
            "ytick.labelsize": 7.5,
            "legend.fontsize": 7,
            "axes.linewidth": 0.7,
            "lines.linewidth": 1.4,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
            "ps.fonttype": 42,
            "savefig.dpi": 600,
        }
    )


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def save_figure(fig: plt.Figure, stem: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(OUT / f"{stem}.svg", bbox_inches="tight")
    fig.savefig(OUT / f"{stem}.png", dpi=600, bbox_inches="tight")
    plt.close(fig)


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.14, 1.06, label, transform=ax.transAxes, fontweight="bold", va="top")


def parameter_drift() -> None:
    paths = {
        "noise-free": RESULTS / "pinn_conditional_A_healthcare_noisefree_v2" / "pinn_conditional_A_m0.05_noise0.json",
        "5% noise": RESULTS / "pinn_conditional_A_healthcare_noise5_v2" / "pinn_conditional_A_m0.05_noise0.05.json",
    }
    true = {"a0": 0.6, "a_max": 1.5, "omega0": 0.003}
    labels = {"a0": r"$a_0$", "a_max": r"$a_{\max}$", "omega0": r"$\omega_0$"}

    # Direct-ODE (joint, m free) recovery for the same healthcare parameters:
    # noiseless recovery is exact (indistinguishable from the truth line), and
    # the 20-realization 5%-noise study gives the median +/- IQR band below.
    ode_nz = read_json(RESULTS / "identifiability_ABC_mc20" / "identifiability_ABC_noise_A.json")
    ode_nz_real = ode_nz["direct_ode_noise5pct"]["A"]["realizations"]

    fig, axes = plt.subplots(1, 3, figsize=(7.1, 2.55), sharex=True)
    x = np.arange(1, 4)
    for ax, key in zip(axes, true):
        # Direct-ODE recovery: noiseless (exact) and 5%-noise median +/- IQR.
        rec_nz = np.asarray([r["best_recovered"][key] for r in ode_nz_real])
        med, lo, hi = np.median(rec_nz), np.percentile(rec_nz, 25), np.percentile(rec_nz, 75)
        ax.axhspan(lo, hi, color=OKABE_ITO[2], alpha=0.18)
        ax.axhline(med, color=OKABE_ITO[2], lw=1.2,
                   label="direct ODE (5% noise)" if key == "a0" else None)
        # PINN conditional (m fixed) drift across network initialisations.
        for idx, (condition, path) in enumerate(paths.items()):
            data = read_json(path)
            vals = [row["recovered_params"][key] for row in data["results"]]
            ax.plot(
                x,
                vals,
                marker="o",
                markersize=3.8,
                color=OKABE_ITO[idx],
                label=f"PINN ({condition})" if key == "a0" else None,
            )
        ax.axhline(true[key], color="black", ls="--", lw=0.9,
                   label="synthetic truth" if key == "a0" else None)
        ax.set_title(labels[key])
        ax.set_xlabel("Network initialisation")
        ax.set_xticks(x)
        ax.set_xticklabels(["1", "2", "3"])
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    axes[0].set_ylabel("Recovered value")
    axes[0].legend(frameon=False, loc="upper left", fontsize=6.3)
    fig.tight_layout(w_pad=1.0)
    save_figure(fig, "fig_pinn_parameter_drift")


def mc_and_country_conditionals() -> None:
    """Write separate PINN diagnostics.

    The Monte-Carlo state-reconstruction result is a manuscript-facing
    validation figure.  The country heatmaps are retained as standalone
    supplementary diagnostics; the former four-panel composite (including a
    text-only panel) is deliberately not generated anymore.
    """
    mc = read_json(RESULTS / "pinn_mc_state_reconstruction_formal" / "pinn_mc_state_reconstruction.json")
    tb_norm, hiv_norm = [], []
    for row in mc["results"]:
        data = shared.make_partial_observation_synthetic_data(noise_fraction=0.05, seed=int(row["noise_seed"]))
        tb_norm.append(row["tb_rmse_vs_observed"] / max(float(np.ptp(data["tb_observed"])), 1.0))
        hiv_norm.append(row["hiv_rmse_vs_observed"] / max(float(np.ptp(data["hiv_observed"])), 1.0))

    # Use the corrected annual-observation operator branch for the
    # manuscript-facing country diagnostics.  The older point-matched
    # figures remain archived and are not overwritten.
    country = read_json(
        RESULTS / "pinn_country_conditional_annual_formal" / "pinn_country_conditional.json"
    )["countries"]
    m_values = []
    for row in country[COUNTRY_ORDER[0]]["results"]:
        m_values.append(row["fixed_m"])
    tb_matrix = np.asarray(
        [[row["tb_rmse_normalized"] for row in country[c]["results"]] for c in COUNTRY_ORDER],
        dtype=float,
    )
    hiv_matrix = np.asarray(
        [[row["hiv_rmse_normalized"] for row in country[c]["results"]] for c in COUNTRY_ORDER],
        dtype=float,
    )

    # Manuscript figure: 5% noise state-reconstruction Monte Carlo.
    fig, ax = plt.subplots(figsize=(3.35, 2.85))
    bp = ax.boxplot([tb_norm, hiv_norm], tick_labels=["TB", "HIV"], patch_artist=True, widths=0.55)
    for patch, color in zip(bp["boxes"], [OKABE_ITO[0], OKABE_ITO[2]]):
        patch.set_facecolor(color)
        patch.set_alpha(0.55)
    ax.scatter(np.repeat([1, 2], len(tb_norm)), np.r_[tb_norm, hiv_norm], s=8, color="black", alpha=0.45, zorder=3)
    ax.set_ylabel("Normalised observation RMSE")
    ax.text(0.03, 0.95, "n = 20", transform=ax.transAxes, va="top")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    fig.tight_layout()
    save_figure(fig, "fig_pinn_state_reconstruction_mc")

    # Standalone country diagnostics.  These are not inserted into the main
    # text because the matched profile-comparison figure already carries the
    # country-level evidence without duplicating it.
    for matrix, title, stem in [
        (tb_matrix, "Country conditional PINN: annual-operator TB observation RMSE", "fig_pinn_country_tb_conditional_annual"),
        (hiv_matrix, "Country conditional PINN: annual-operator HIV observation RMSE", "fig_pinn_country_hiv_conditional_annual"),
    ]:
        fig, ax = plt.subplots(figsize=(3.8, 2.75))
        im = ax.imshow(matrix, aspect="auto", cmap="cividis", norm=Normalize(vmin=float(matrix.min()), vmax=float(matrix.max())))
        ax.set_yticks(np.arange(len(COUNTRY_ORDER)), labels=COUNTRY_ORDER)
        m_labels = [f"{m:.6g}" if m < 0.01 else f"{m:.4g}" for m in m_values]
        ax.set_xticks(np.arange(len(m_values)), labels=m_labels, rotation=35, ha="right")
        ax.set_xlabel(r"Fixed $m$")
        cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cb.ax.tick_params(labelsize=6.5)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        fig.tight_layout()
        save_figure(fig, stem)


def country_profiles() -> None:
    direct = read_json(RESULTS / "identifiability_country_profiles_with_params" / "identifiability_country_profiles.json")["countries"]
    proxy = read_json(RESULTS / "identifiability_country_treatment_proxy_reduced" / "identifiability_country_treatment_proxy.json")["countries"]
    fig, axes = plt.subplots(2, 2, figsize=(7.1, 4.9), sharex=True)
    for ax, country in zip(axes.ravel(), COUNTRY_ORDER):
        drows = direct[country]["m_profile"]["grid"]
        prows = proxy[country]["m_profile"]["grid"]
        d_m = np.asarray([r["fixed_m"] for r in drows])
        d_obj = np.asarray([r["objective"] for r in drows])
        p_m = np.asarray([r["fixed_m"] for r in prows])
        p_obj = np.asarray([r["objective"] for r in prows])
        ax.plot(d_m, d_obj - d_obj.min(), color=COUNTRY_COLORS[country], marker="o", ms=3, label="TB + HIV")
        ax.plot(p_m, p_obj - p_obj.min(), color="black", ls="--", marker="s", ms=3, label="+ cohort proxy")
        ax.set_xscale("log")
        ax.set_title(country)
        ax.set_xlabel(r"Fixed $m$")
        ax.set_ylabel(r"Profile objective $-\min$" )
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.legend(frameon=False, fontsize=6.5, loc="best")
    fig.tight_layout(h_pad=1.2, w_pad=1.0)
    save_figure(fig, "fig_country_m_profiles")


def country_profile_pinn_comparison() -> None:
    """Compare direct-ODE m profiles with conditional PINN fits at the same m values."""
    direct = read_json(
        RESULTS / "identifiability_country_profiles_with_params" / "identifiability_country_profiles.json"
    )["countries"]
    pinn = read_json(
        RESULTS / "pinn_country_conditional_annual_formal" / "pinn_country_conditional.json"
    )["countries"]
    fig, axes = plt.subplots(2, 2, figsize=(7.1, 5.0), sharex=False)
    for ax, country in zip(axes.ravel(), COUNTRY_ORDER):
        drows = direct[country]["m_profile"]["grid"]
        prows = pinn[country]["results"]
        d_m = np.asarray([float(r["fixed_m"]) for r in drows])
        d_obj = np.asarray([float(r["objective"]) for r in drows])
        p_m = np.asarray([float(r["fixed_m"]) for r in prows])
        p_tb = np.asarray([float(r["tb_rmse_normalized"]) for r in prows])
        p_hiv = np.asarray([float(r["hiv_rmse_normalized"]) for r in prows])
        ax2 = ax.twinx()
        ax.plot(
            d_m,
            d_obj - d_obj.min(),
            color=COUNTRY_COLORS[country],
            marker="o",
            ms=3,
            lw=1.5,
            label="Direct ODE profile",
        )
        ax2.plot(p_m, p_tb, color=OKABE_ITO[1], marker="s", ms=3, ls="--", label="PINN TB RMSE")
        ax2.plot(p_m, p_hiv, color=OKABE_ITO[2], marker="^", ms=3, ls=":", label="PINN HIV RMSE")
        ax.set_xscale("log")
        ax2.set_xscale("log")
        ax.set_title(country)
        ax.set_xlabel(r"Fixed $m$")
        ax.set_ylabel(r"ODE profile objective $-\min$")
        ax2.set_ylabel("PINN normalised RMSE")
        ax.spines["top"].set_visible(False)
        ax2.spines["top"].set_visible(False)
        lines, labels = ax.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax.legend(lines + lines2, labels + labels2, frameon=False, fontsize=5.8, loc="best")
    fig.suptitle(
        "Direct-ODE profiles and conditional PINN fits at matched fixed-$m$ values",
        y=1.02,
    )
    fig.tight_layout(h_pad=1.4, w_pad=1.4)
    save_figure(fig, "fig_country_profile_pinn_comparison_annual")


def structure_screen() -> None:
    data = read_json(RESULTS / "identifiability_ABC" / "identifiability_ABC_structure.json")["structure_screen"]
    problems = ["A", "B", "C"]
    ranks = []
    n_params = []
    rel_min = []
    for p in problems:
        agg = data[p]["dense_grid"]["aggregate"]
        ranks.append(float(np.median(agg["rank_values"])))
        n_params.append(len(data[p]["dense_grid"]["unknown_parameters"]))
        rel_min.append(float(agg["median_relative_smallest_singular_value"]))
    fig_a, ax_a = plt.subplots(figsize=(3.3, 2.7))
    x = np.arange(3)
    ax_a.bar(x, ranks, color=OKABE_ITO[:3], width=0.6)
    ax_a.set_xticks(x, problems)
    ax_a.set_ylabel("Numerical sensitivity rank")
    ax_a.set_ylim(0, max(n_params) + 1.6)
    ax_a.yaxis.set_major_locator(mpl.ticker.MaxNLocator(integer=True))
    for i, (r, n) in enumerate(zip(ranks, n_params)):
        ax_a.text(i, r + 0.35, f"{int(r)}/{n}", ha="center", va="bottom",
                  fontsize=8, fontweight="bold")
    ax_a.spines["top"].set_visible(False)
    ax_a.spines["right"].set_visible(False)
    fig_a.tight_layout()
    save_figure(fig_a, "fig_ABC_conditioning_screen_rank")

    fig_b, ax_b = plt.subplots(figsize=(3.3, 2.7))
    ax_b.bar(x, rel_min, color=OKABE_ITO[:3], width=0.6)
    ax_b.set_xticks(x, problems)
    ax_b.set_yscale("log")
    ax_b.set_ylabel("Median smallest singular value / largest")
    ax_b.spines["top"].set_visible(False)
    ax_b.spines["right"].set_visible(False)
    fig_b.tight_layout()
    save_figure(fig_b, "fig_ABC_conditioning_screen_singular")


def main() -> int:
    configure_style()
    parameter_drift()
    mc_and_country_conditionals()
    country_profiles()
    # The combined direct-ODE/PINN country panel is retained as an exploratory
    # supplementary diagnostic but is not part of the JTB main-text figure set;
    # the separate TB/HIV heatmaps avoid duplicating the same matrices.
    structure_screen()
    print(f"Saved publication figures to {OUT.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
