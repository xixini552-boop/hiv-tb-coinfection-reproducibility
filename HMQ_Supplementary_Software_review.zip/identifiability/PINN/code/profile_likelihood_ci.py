"""
Noise-scale-matched profile analysis for the response-shape parameter m
and the maximum treatment response a_max (BMB revision, Major comment 4).

This upgrades the earlier profile-objective diagnostic to a
noise-scale-matched, Wilks-type calibrated profile objective.  It is not a
full heteroscedastic Gaussian likelihood because the parameter-dependent
variance term is intentionally omitted:

  * Observation model (matches the simulated data exactly):
        y_obs(t) = y_true(t) * (1 + eps),  eps ~ N(0, sigma^2), sigma = 0.05.
    The relative-error deviance used here is, up to a constant scale,
        chi2(theta) = (1/sigma^2) * sum_{t,j} [(pred_j(t;theta)-obs_j(t))
                                               / obs_j(t)]^2,
    i.e. the noise-consistent relative-error objective divided by sigma^2.
    It is used as a quasi-likelihood criterion: the fully specified
    heteroscedastic Gaussian likelihood would also contain a
    parameter-dependent variance term.

  * Global minimum-criterion fit: free fit of every Problem-A unknown (a0,
    a_max, omega0, m) from multiple starts.

  * One-dimensional profiles chi2_p(p) = min_{theta\\p} chi2(theta) for m and
    a_max, with multiple starts AND bidirectional warm starts. Using a Wilks'-
    type calibration threshold, the grid-resolved 95% calibration interval is
    {p: Delta chi2 <= chi2_{1,0.95} = 3.841}.

  * Two-dimensional joint profile chi2_j(m,a_max) = min_{a0,omega0} chi2,
    with 95%/68% contours at chi2_{2,0.95}=5.991 / chi2_{2,0.68}=2.295,
    exposing the m <-> a_max compensation ridge.

  * H2 (incidence + prevalence only) m-profile is included to show whether
    the treatment-flow channel narrows the interval.

The forward model, coordinate transform, start grid and observation operator
are imported unchanged from identifiability_ABC, so this analysis uses exactly
the same model and objective as the Monte-Carlo recovery runs.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

import numpy as np
from scipy.optimize import least_squares
from scipy.stats import chi2 as chi2_dist
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.abspath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
CODE_DIR = os.path.join(ROOT, "identifiability", "PINN", "code")
BIF_CODE = os.path.join(ROOT, "bifurcation", "code")
sys.path.insert(0, CODE_DIR)
sys.path.insert(0, BIF_CODE)

import identifiability_ABC as abc  # noqa: E402
from run_revision_experiments import get_target  # noqa: E402

RESULTS_DIR = os.path.join(
    ROOT, "identifiability", "PINN", "results", "identifiability_final")
FIG_DIR = os.path.join(ROOT, "identifiability", "PINN", "figures",
                       "identifiability_final")
os.makedirs(RESULTS_DIR, exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)

PROBLEM = "A"
NAMES = list(abc.PROBLEMS[PROBLEM]["unknown"])  # [a0, a_max, omega0, m]
SIGMA = 0.05
SEED = 42


# --------------------------------------------------------------------------
# Likelihood machinery
# --------------------------------------------------------------------------
def make_noisy(target_true, seed, sigma=SIGMA):
    rng = np.random.default_rng(seed)
    noise = rng.normal(0.0, sigma, size=target_true.shape)
    return np.maximum(target_true * (1.0 + noise), 0.0)


def select_cols(full, outputs):
    return full[:, :2] if outputs == "H2" else full


class ProfileProblem:
    """Fixed noisy dataset; chi2 over Problem-A unknowns with some fixed."""

    def __init__(self, t_eval, observed, outputs="H3", sigma=SIGMA):
        self.t_eval = t_eval
        self.observed = np.asarray(observed, dtype=float)
        self.outputs = outputs
        self.sigma = sigma
        self.rel_w = abc.relative_weights(self.observed)
        self.free_lower, self.free_upper = abc.q_bounds(NAMES)
        self.start_grid = abc._start_grid(PROBLEM)  # 3 physical starts

    # -- coordinate assembly ------------------------------------------------
    def _assemble(self, free_q, free_names, fixed_physical):
        base = abc.true_parameters()
        for key, val in fixed_physical.items():
            base[key] = float(val)
        q_full = abc.physical_to_q(base, NAMES)
        for key, qval in zip(free_names, free_q):
            q_full[NAMES.index(key)] = float(qval)
        return abc.q_to_physical(q_full, NAMES)

    def _residual_factory(self, free_names, fixed_physical):
        cols = slice(None)
        t_eval = self.t_eval
        observed = self.observed
        rel_w = self.rel_w

        def residual(free_q):
            try:
                params = self._assemble(free_q, free_names, fixed_physical)
                full_pred = abc.observations_from_states(
                    abc.integrate_states(t_eval, params), params)
                pred = full_pred if observed.shape[1] == 3 else full_pred[:, :2]
                if not np.all(np.isfinite(pred)):
                    raise RuntimeError("non-finite")
                return abc.flatten_outputs((pred - observed) * rel_w)
            except Exception:
                return np.full(observed.size, 1e6, dtype=float)
        return residual

    def _starts_q(self, free_names, fixed_physical, warm_q=None):
        """List of free-coordinate starts: grid starts + optional warm start."""
        starts = []
        for st in self.start_grid:
            merged = dict(st)
            merged.update(fixed_physical)
            q_free = np.array(
                [abc.physical_to_q(merged, NAMES)[NAMES.index(k)]
                 for k in free_names], dtype=float)
            lo, hi = abc.q_bounds(free_names)
            starts.append(np.clip(q_free, lo + 1e-6, hi - 1e-6))
        if warm_q is not None:
            lo, hi = abc.q_bounds(free_names)
            starts.append(np.clip(np.asarray(warm_q, dtype=float),
                                  lo + 1e-6, hi - 1e-6))
        return starts

    def minimize(self, fixed_physical, warm_q=None, verbose=False):
        free_names = [k for k in NAMES if k not in fixed_physical]
        lo, hi = abc.q_bounds(free_names)
        residual = self._residual_factory(free_names, fixed_physical)
        starts = self._starts_q(free_names, fixed_physical, warm_q)
        best = None
        for q0 in starts:
            fit = least_squares(
                residual, q0, bounds=(lo, hi), method="trf",
                x_scale="jac", ftol=1e-11, xtol=1e-11, gtol=1e-11,
                max_nfev=1500)
            sse = float(2.0 * fit.cost)
            if best is None or sse < best["sse"]:
                q_free_best = fit.x.copy()
                phys = self._assemble(fit.x, free_names, fixed_physical)
                best = {
                    "sse": sse,
                    "chi2": sse / self.sigma ** 2,
                    "q_free": q_free_best,
                    "free_names": free_names,
                    "physical": {k: float(phys[k]) for k in NAMES},
                    "success": bool(fit.success),
                    "status": int(fit.status),
                    "nfev": int(fit.nfev),
                }
            if verbose:
                print(f"      start sse={sse:.4f}")
        return best


def run(problem: ProfileProblem, m_grid, amax_grid, joint_m, joint_a,
        do_amax=True, do_joint=True):
    t0 = time.time()
    true_p = abc.true_parameters()

    # ---- 1. global minimum-criterion fit (all four free) -----------------
    print("[1/4] Global minimum-criterion fit (a0,a_max,omega0,m free, multi-start)...",
          flush=True)
    mle = problem.minimize({})
    chi2_min = mle["chi2"]
    n_data = problem.observed.size
    n_free = len(NAMES)
    dof = n_data - n_free
    print(f"   chi2_min={chi2_min:.3f} on {n_data} data, dof~{dof}; "
          f"minimum-criterion m={mle['physical']['m']:.5f} (true {true_p['m']}), "
          f"a_max={mle['physical']['a_max']:.5f} (true {true_p['a_max']})",
          flush=True)

    def profile_1d(param, grid, label):
        print(f"   profile {label}: {grid.size} points, multi+warm starts",
              flush=True)
        rows = []
        warm = None
        order = np.argsort(np.abs(grid - mle["physical"][param]))
        # spiral outward from the MLE so warm starts propagate both ways
        ranked = grid[order]
        cache = {}
        for val in ranked:
            fixed = {param: float(val)}
            fit = problem.minimize(fixed, warm_q=warm)
            cache[float(val)] = fit
            warm = fit["q_free"]
        for val in grid:
            fit = cache[float(val)]
            rows.append({
                "fixed": float(val),
                "chi2": float(fit["chi2"]),
                "delta_chi2": float(fit["chi2"] - chi2_min),
                "physical": fit["physical"],
                "success": fit["success"],
                "nfev": fit["nfev"],
            })
        return rows

    # ---- 2/3. one-dimensional profiles -----------------------------------
    print("[2/4] 1-D profile of m...", flush=True)
    rows_m = profile_1d("m", m_grid, "m")
    rows_a = None
    ci_a = None
    if do_amax:
        print("[3/4] 1-D profile of a_max...", flush=True)
        rows_a = profile_1d("a_max", amax_grid, "a_max")

    def wilks_interval(rows, level=0.95):
        thr = float(chi2_dist.ppf(level, 1))
        x = np.asarray([r["fixed"] for r in rows], dtype=float)
        d = np.asarray([r["delta_chi2"] for r in rows], dtype=float)
        below = x[d <= thr]
        lo = float(below.min()) if below.size else None
        hi = float(below.max()) if below.size else None
        # boundary contact flags
        lo_bound = bool(lo is not None and abs(lo - x.min()) / x.min() < 1e-6)
        hi_bound = bool(hi is not None and abs(hi - x.max()) / x.max() < 1e-6)
        return {"threshold": thr, "lower": lo, "upper": hi,
                "hits_lower_grid_edge": lo_bound,
                "hits_upper_grid_edge": hi_bound}

    ci_m = wilks_interval(rows_m)
    if do_amax:
        ci_a = wilks_interval(rows_a)
    print(f"   m 95% PL interval ~ [{ci_m['lower']}, {ci_m['upper']}] "
          f"(edge flags {ci_m['hits_lower_grid_edge']},"
          f"{ci_m['hits_upper_grid_edge']})", flush=True)
    if do_amax:
        print(f"   a_max 95% PL interval ~ [{ci_a['lower']}, {ci_a['upper']}]",
              flush=True)

    # ---- 4. joint (m, a_max) profile -------------------------------------
    Z = None
    joint_m_eff = joint_a_eff = None
    if do_joint:
        joint_m_eff, joint_a_eff = joint_m, joint_a
        print(f"[4/4] joint profile {joint_m.size}x{joint_a.size} = "
              f"{joint_m.size*joint_a.size} cells...", flush=True)
        Z = np.full((joint_a.size, joint_m.size), np.nan)
        for i, av in enumerate(joint_a):
            # warm along rows from nearest a to MLE on first pass
            warm = None
            order_m = np.argsort(np.abs(joint_m - mle["physical"]["m"]))
            ranked = joint_m[order_m]
            row_cache = {}
            for mv in ranked:
                fit = problem.minimize({"m": float(mv), "a_max": float(av)},
                                       warm_q=warm)
                row_cache[float(mv)] = fit
                warm = fit["q_free"]
            for j, mv in enumerate(joint_m):
                Z[i, j] = row_cache[float(mv)]["chi2"] - chi2_min
            if (i + 1) % 3 == 0:
                print(f"     row {i+1}/{joint_a.size}", flush=True)

    elapsed = time.time() - t0
    payload = {
        "configuration": {
            "problem": PROBLEM,
            "unknowns": NAMES,
            "outputs": problem.outputs,
            "noise": "multiplicative Gaussian, y_obs=y_true(1+eps)",
            "sigma": SIGMA,
            "noise_seed": SEED,
            "time_points": int(len(problem.t_eval)),
            "grid": "quarterly, 14 years, 57 points",
            "objective": "relative-error deviance chi2 = sum((pred-obs)/obs)^2/sigma^2",
            "n_starts": "3 grid starts + bidirectional warm start",
            "wilks_1d_95": float(chi2_dist.ppf(0.95, 1)),
            "wilks_2d_95": float(chi2_dist.ppf(0.95, 2)),
            "wilks_2d_68": float(chi2_dist.ppf(0.68, 2)),
        },
        "n_data": int(n_data),
        "residual_dof": int(dof),
        "mle": {"chi2": float(chi2_min), "physical": mle["physical"],
                "success": mle["success"], "nfev": mle["nfev"]},
        "true_parameters": {k: float(true_p[k]) for k in NAMES},
        "profile_m": rows_m,
        "ci_m_95": ci_m,
        "elapsed_seconds": float(elapsed),
    }
    if do_amax:
        payload["profile_amax"] = rows_a
        payload["ci_amax_95"] = ci_a
    if do_joint:
        payload["joint"] = {
            "m_grid": [float(v) for v in joint_m_eff],
            "amax_grid": [float(v) for v in joint_a_eff],
            "delta_chi2": Z.tolist(),
        }
    return payload


# --------------------------------------------------------------------------
# Figures
# --------------------------------------------------------------------------
def _draw_panel(ax, rows, ci, xlabel, ylabel, is_log, thr, true_v, title):
    x = np.array([r["fixed"] for r in rows])
    d = np.array([r["delta_chi2"] for r in rows])
    ax.plot(x, d, "-o", color="#1565C0", ms=4, lw=1.6,
            label=r"profile $\Delta\chi^2$")
    ax.axhline(thr, color="#C62828", ls="--", lw=1.3,
               label=fr"95% threshold $\chi^2_1={thr:.2f}$")
    ax.axvline(true_v, color="grey", ls=":", lw=1.2, label="true value")
    if ci["lower"] is not None:
        ax.axvspan(ci["lower"], ci["upper"], color="#1565C0", alpha=0.10)
    if is_log:
        ax.set_xscale("log")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_ylim(0, min(12.0, np.nanmax(d) * 1.05 + 1e-9))
    ax.legend(fontsize=7, frameon=False, loc="upper center")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    # The manuscript caption supplies the descriptive panel title and
    # interval.  Keep the artwork focused on the axes, curves and legend.


def plot_1d(payload, outbase, title_tag):
    thr = payload["configuration"]["wilks_1d_95"]
    has_amax = "profile_amax" in payload
    if has_amax:
        fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
        _draw_panel(axes[0], payload["profile_m"], payload["ci_m_95"],
                    r"response shape $m$", r"$\Delta\chi^2(m)$", True, thr,
                    payload["true_parameters"]["m"], title_tag)
        _draw_panel(axes[1], payload["profile_amax"], payload["ci_amax_95"],
                    r"maximum treatment response $a_{\max}$",
                    r"$\Delta\chi^2(a_{\max})$", False, thr,
                    payload["true_parameters"]["a_max"], title_tag)
        # Panel letters are supplied by the LaTeX subfigure captions.
    else:
        fig, ax = plt.subplots(1, 1, figsize=(5.6, 4.2))
        _draw_panel(ax, payload["profile_m"], payload["ci_m_95"],
                    r"response shape $m$", r"$\Delta\chi^2(m)$", True, thr,
                    payload["true_parameters"]["m"], title_tag)
        # Panel letters are supplied by the LaTeX subfigure caption.
    fig.tight_layout()
    fig.savefig(outbase + ".pdf", bbox_inches="tight")
    fig.savefig(outbase + ".png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def plot_joint(payload, outbase):
    j = payload["joint"]
    m_grid = np.array(j["m_grid"])
    a_grid = np.array(j["amax_grid"])
    Z = np.array(j["delta_chi2"])
    M, A = np.meshgrid(m_grid, a_grid)

    fig, ax = plt.subplots(figsize=(6.4, 5.0))
    Zc = np.clip(Z, 0, 12)
    cf = ax.contourf(M, A, Zc, levels=24, cmap="viridis", alpha=0.9)
    cs = ax.contour(M, A, Z,
                    levels=[payload["configuration"]["wilks_2d_68"],
                            payload["configuration"]["wilks_2d_95"]],
                    colors=["white", "#FFD54F"], linewidths=[1.2, 1.8])
    ax.clabel(cs, fmt={payload["configuration"]["wilks_2d_68"]: "68%",
                       payload["configuration"]["wilks_2d_95"]: "95%"},
              fontsize=9)
    ax.set_xscale("log")
    tp = payload["true_parameters"]
    ax.plot(tp["m"], tp["a_max"], marker="*", ms=16, color="red",
            label="true", zorder=5)
    mle = payload["mle"]["physical"]
    ax.plot(mle["m"], mle["a_max"], marker="o", ms=7, color="white",
            markeredgecolor="black", label="best fit", zorder=5)
    cbar = fig.colorbar(cf, ax=ax)
    cbar.set_label(r"joint profile $\Delta\chi^2(m,a_{\max})$ (clipped at 12)")
    ax.set_xlabel(r"response shape $m$")
    ax.set_ylabel(r"maximum treatment response $a_{\max}$")
    ax.legend(fontsize=8, frameon=False, loc="upper right")
    fig.tight_layout()
    fig.savefig(outbase + ".pdf", bbox_inches="tight")
    fig.savefig(outbase + ".png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def grids(quick=False):
    if quick:
        mg = np.geomspace(0.004, 0.8, 9)
        ag = np.linspace(1.05, 2.2, 7)
        jm = np.geomspace(0.006, 0.6, 7)
        ja = np.linspace(1.1, 2.1, 6)
    else:
        # m spans the physical lower bound M_LO=0.001 to beyond the 95% crossing;
        # a_max extends below the lower 95% crossing (~0.80) so neither interval
        # endpoint is clipped by the grid.
        mg = np.geomspace(0.001, 2.0, 31)
        ag = np.linspace(0.55, 2.2, 34)
        jm = np.geomspace(0.002, 1.5, 17)
        ja = np.linspace(1.0, 2.2, 17)
    return mg, ag, jm, ja


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--quick", action="store_true",
                        help="sparse grids for a smoke test")
    args = parser.parse_args()

    mg, ag, jm, ja = grids(args.quick)
    tag = "quick" if args.quick else "full"
    summaries = {}

    for outputs in ("H3", "H2"):
        print("=" * 64)
        print(f"Outputs {outputs} ({tag})")
        print("=" * 64, flush=True)
        t_eval, target_true = get_target(outputs)
        noisy = make_noisy(target_true, SEED)
        prob = ProfileProblem(t_eval, noisy, outputs=outputs)
        if outputs == "H3":
            # Full result: m and a_max 1-D profiles + joint (m,a_max) surface.
            payload = run(prob, mg, ag, jm, ja,
                          do_amax=True, do_joint=True)
        else:
            # Matched contrast: only the m 1-D profile, to test whether the
            # treatment-flow channel narrows the interval. No joint surface.
            payload = run(prob, mg, ag, None, None,
                          do_amax=False, do_joint=False)
        out_json = os.path.join(
            RESULTS_DIR, f"profile_likelihood_ci_{outputs}_{tag}.json")
        with open(out_json, "w") as fh:
            json.dump(payload, fh, indent=2)
        print(f"Saved {out_json}", flush=True)
        summaries[outputs] = {
            "chi2_min": payload["mle"]["chi2"],
            "ci_m": payload["ci_m_95"],
            "ci_amax": payload.get("ci_amax_95"),
            "elapsed": payload["elapsed_seconds"],
        }
        if outputs == "H3":
            plot_1d(payload, os.path.join(FIG_DIR,
                    "fig_profile_likelihood_ci"), "H3 (y1,y2,y3)")
            plot_joint(payload, os.path.join(FIG_DIR,
                       "fig_joint_likelihood_m_amax"))
        else:
            plot_1d(payload, os.path.join(FIG_DIR,
                    "fig_profile_likelihood_ci_H2"), "H2 (y1,y2)")

    print("\n=== SUMMARY ===")
    for out, s in summaries.items():
        line = (f"{out}: chi2_min={s['chi2_min']:.2f}, "
                f"m CI=[{s['ci_m']['lower']},{s['ci_m']['upper']}]")
        if s["ci_amax"] is not None:
            line += (f", a_max CI=[{s['ci_amax']['lower']},"
                     f"{s['ci_amax']['upper']}]")
        line += f", {s['elapsed']:.0f}s"
        print(line)


if __name__ == "__main__":
    main()
