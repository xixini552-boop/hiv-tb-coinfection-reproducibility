"""Post-process fitted parameters into local-bifurcation diagnostics.

The regression does not estimate m_c^TB directly.  For each retained fit we
evaluate the fitted centre-manifold numerator N(m), the low-burden slope
s_a=(a_max-a0)(1+m), and the corresponding threshold m_c^TB.  This makes it
possible to distinguish recovery of individual parameters from sign agreement
for the local bifurcation direction.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np


MU = 0.0143
K = 0.5
D = 0.1
LAMBDA = MU * 10000.0
TRUE_VALUES = {
    "a0": 0.6,
    "a_max": 1.5,
    "omega0": 0.003,
    "m": 0.05,
}


def centre_manifold_n(a0, a_max, omega0, m):
    term1 = 2.0 * a0 * omega0 * (
        ((MU + D + a0) / K) ** 2 + (MU + K + a0) / K
    )
    term2 = (
        2.0
        * MU
        * (MU + K + a0)
        * (MU + D + a0)
        * (MU + D + a0 + K)
        / (K * K * LAMBDA)
    )
    term3 = (
        2.0
        * MU
        * (a_max - a0)
        * (2.0 * MU + K + D + 2.0 * a0)
        * (1.0 + m)
        / (K * LAMBDA)
    )
    return float(term1 - term2 - term3)


def critical_m(a0, a_max, omega0):
    n0 = centre_manifold_n(a0, a_max, omega0, 0.0)
    denominator = (
        2.0 * MU * (a_max - a0) * (2.0 * MU + K + D + 2.0 * a0)
    )
    if denominator <= 0.0:
        return float("nan")
    return float(K * LAMBDA * n0 / denominator)


def _summary(values):
    values = np.asarray(values, dtype=float)
    return {
        "median": float(np.median(values)),
        "p05": float(np.percentile(values, 5)),
        "p95": float(np.percentile(values, 95)),
        "minimum": float(np.min(values)),
        "maximum": float(np.max(values)),
    }


def process_file(path):
    payload = json.loads(path.read_text(encoding="utf-8"))
    realizations = payload.get("realizations")
    if not isinstance(realizations, list) or not realizations:
        return None

    rows = []
    for realization in realizations:
        recovered = realization.get("best_recovered")
        if not isinstance(recovered, dict):
            return None
        required = {"a0", "a_max", "omega0", "m"}
        if not required.issubset(recovered):
            return None
        a0 = float(recovered["a0"])
        a_max = float(recovered["a_max"])
        omega0 = float(recovered["omega0"])
        m = float(recovered["m"])
        rows.append(
            {
                "realization": int(realization["realization"]),
                "m_hat": m,
                "s_a_hat": float((a_max - a0) * (1.0 + m)),
                "N_m_hat": centre_manifold_n(a0, a_max, omega0, m),
                "m_c_hat": critical_m(a0, a_max, omega0),
            }
        )

    diagnostics = {}
    for name in ("m_hat", "s_a_hat", "N_m_hat", "m_c_hat"):
        diagnostics[name] = _summary([row[name] for row in rows])

    return {
        "file": path.name,
        "n_realizations": len(rows),
        "true": {
            **TRUE_VALUES,
            "s_a": (TRUE_VALUES["a_max"] - TRUE_VALUES["a0"])
            * (1.0 + TRUE_VALUES["m"]),
            "N_m": centre_manifold_n(
                TRUE_VALUES["a0"],
                TRUE_VALUES["a_max"],
                TRUE_VALUES["omega0"],
                TRUE_VALUES["m"],
            ),
            "m_c": critical_m(
                TRUE_VALUES["a0"],
                TRUE_VALUES["a_max"],
                TRUE_VALUES["omega0"],
            ),
        },
        "diagnostics": diagnostics,
        "N_positive_count": sum(row["N_m_hat"] > 0.0 for row in rows),
        "m_below_m_c_count": sum(
            math.isfinite(row["m_c_hat"]) and row["m_hat"] < row["m_c_hat"]
            for row in rows
        ),
        "rows": rows,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=Path(__file__).resolve().parent.parent
        / "results"
        / "identifiability_final",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent.parent
        / "results"
        / "identifiability_final",
    )
    args = parser.parse_args()

    reports = []
    for path in sorted(args.input_dir.glob("*.json")):
        report = process_file(path)
        if report is not None:
            reports.append(report)

    output = {
        "description": (
            "Post-processed local-bifurcation diagnostics for direct-ODE "
            "recoveries. N(m) is evaluated from each fitted parameter vector."
        ),
        "formula": {
            "s_a": "(a_max-a0)(1+m)",
            "N_m": "Eq. (3.3) in the main text",
            "m_c_TB": "k*Lambda*N(0)/(2*mu*(a_max-a0)*(2*mu+k+d+2*a0))",
        },
        "reports": reports,
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / "bifurcation_recovery_postprocess.json"
    json_path.write_text(
        json.dumps(output, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    csv_path = args.output_dir / "bifurcation_recovery_postprocess.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "file",
                "n_realizations",
                "s_a_median",
                "s_a_p05",
                "s_a_p95",
                "N_m_median",
                "N_m_p05",
                "N_m_p95",
                "m_c_median",
                "m_c_p05",
                "m_c_p95",
                "N_positive_count",
                "m_below_m_c_count",
            ]
        )
        for report in reports:
            d = report["diagnostics"]
            writer.writerow(
                [
                    report["file"],
                    report["n_realizations"],
                    d["s_a_hat"]["median"],
                    d["s_a_hat"]["p05"],
                    d["s_a_hat"]["p95"],
                    d["N_m_hat"]["median"],
                    d["N_m_hat"]["p05"],
                    d["N_m_hat"]["p95"],
                    d["m_c_hat"]["median"],
                    d["m_c_hat"]["p05"],
                    d["m_c_hat"]["p95"],
                    report["N_positive_count"],
                    report["m_below_m_c_count"],
                ]
            )

    print(f"Saved {json_path}")
    print(f"Saved {csv_path}")


if __name__ == "__main__":
    main()
