"""Pilot recovery experiment with quarterly interval-integrated TB incidence.

This is a narrow robustness check for the practical-identifiability screen.
It keeps the non-AIDS HIV-prevalence operator and the Problem A unknown set
fixed, but replaces instantaneous TB incidence with the integral of the
annualised incidence rate over each quarter.  The output is therefore closer
to a quarterly aggregate than the instantaneous samples used in the main
screen.

The script is deliberately separate from the audited main experiment and
does not overwrite any of the six prespecified JSON result files.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

import numpy as np
from scipy.optimize import least_squares


CODE_DIR = Path(__file__).resolve().parent
ROOT_DIR = CODE_DIR.parents[2]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))
COMMON_DIR = ROOT_DIR / "bifurcation" / "code"
if str(COMMON_DIR) not in sys.path:
    sys.path.insert(0, str(COMMON_DIR))

import identifiability_ABC as abc  # noqa: E402
import pinn_training_paper_safe as shared  # noqa: E402


RESULT_DIR = ROOT_DIR / "identifiability" / "PINN" / "results" / "identifiability_final"
PROBLEM = "A"
TRUE_M = float(abc.true_parameters()["m"])


def observation_grid() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    edges = np.linspace(0.0, 14.0, 57)
    midpoints = 0.5 * (edges[:-1] + edges[1:])
    fine = np.empty(edges.size + midpoints.size, dtype=float)
    fine[0::2] = edges
    fine[1::2] = midpoints
    return edges, midpoints, fine


def interval_observations(
    fine_states: np.ndarray, edges: np.ndarray
) -> np.ndarray:
    """Return interval-integrated TB incidence and midpoint HIV prevalence."""
    fine_states = np.asarray(fine_states, dtype=float)
    tb_rate, hiv_prevalence = shared.observables_numpy(fine_states)
    left = tb_rate[0:-1:2]
    middle = tb_rate[1::2]
    right = tb_rate[2::2]
    dt = np.diff(edges)
    tb_integrated = (dt / 6.0) * (left + 4.0 * middle + right)
    hiv_midpoint = hiv_prevalence[1::2]
    return np.column_stack((tb_integrated, hiv_midpoint))


def truth() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    edges, _, fine = observation_grid()
    params = abc.true_parameters()
    states = abc.integrate_states(fine, params)
    return edges, fine, interval_observations(states, edges)


def fit_once(
    target: np.ndarray,
    start: Dict[str, float],
    objective_type: str = "relative",
) -> Dict:
    names = list(abc.PROBLEMS[PROBLEM]["unknown"])
    lower, upper = abc.q_bounds(names)
    q0 = np.clip(
        abc.physical_to_q(start, names), lower + 1.0e-6, upper - 1.0e-6
    )
    edges, _, _ = observation_grid()
    target = np.asarray(target, dtype=float)
    relative_weights = 1.0 / np.maximum(np.abs(target), 1.0e-6)
    output_scales = np.maximum(np.ptp(target, axis=0), 1.0e-12)

    def residual(q: np.ndarray) -> np.ndarray:
        try:
            params = abc.q_to_physical(q, names)
            _, _, fine = observation_grid()
            states = abc.integrate_states(fine, params)
            pred = interval_observations(states, edges)
            if not np.all(np.isfinite(pred)):
                raise RuntimeError("non-finite interval observation")
            if objective_type == "range":
                return abc.flatten_outputs((pred - target) / output_scales)
            return abc.flatten_outputs((pred - target) * relative_weights)
        except Exception:
            return np.full(target.size, 1.0e6, dtype=float)

    fit = least_squares(
        residual,
        q0,
        bounds=(lower, upper),
        method="trf",
        x_scale="jac",
        ftol=1.0e-11,
        xtol=1.0e-11,
        gtol=1.0e-11,
        max_nfev=1600,
    )
    recovered_all = abc.q_to_physical(fit.x, names)
    recovered = {name: float(recovered_all[name]) for name in names}
    true_params = abc.true_parameters()
    errors = {
        name: float(
            abs(recovered[name] - true_params[name])
            / max(abs(true_params[name]), 1.0e-12)
            * 100.0
        )
        for name in names
    }
    return {
        "initial": {name: float(start[name]) for name in names},
        "recovered": recovered,
        "relative_error_pct": errors,
        "objective": float(2.0 * fit.cost),
        "optimizer_success": bool(fit.success),
        "status": int(fit.status),
        "nfev": int(fit.nfev),
        "optimality": (
            float(np.max(np.abs(fit.grad)))
            if hasattr(fit, "grad") and fit.grad is not None else float("nan")
        ),
        "active_mask": (
            [int(v) for v in fit.active_mask]
            if hasattr(fit, "active_mask") else []
        ),
    }


def run(
    n_realizations: int,
    n_starts: int,
    seed: int,
    objective_type: str,
) -> Dict:
    edges, fine, clean_target = truth()
    starts = abc._start_grid(PROBLEM)[:n_starts]
    rng = np.random.default_rng(seed)
    realizations: List[Dict] = []

    for realization in range(1, n_realizations + 1):
        noise = rng.normal(0.0, 0.05, size=clean_target.shape)
        observed = np.maximum(clean_target * (1.0 + noise), 0.0)
        fits = [fit_once(observed, start, objective_type) for start in starts]
        best_index = min(
            range(len(fits)), key=lambda index: fits[index]["objective"]
        )
        best = fits[best_index]
        realizations.append({
            "realization": realization,
            "best_start_index": int(best_index + 1),
            "best_objective": float(best["objective"]),
            "best_recovered": best["recovered"],
            "best_relative_error_pct": best["relative_error_pct"],
            "all_starts": fits,
        })
        print(
            f"[{realization:03d}/{n_realizations:03d}] "
            f"m_hat={best['recovered']['m']:.6g}, "
            f"m_error={best['relative_error_pct']['m']:.2f}%",
            flush=True,
        )

    aggregate: Dict[str, Dict] = {}
    true_params = abc.true_parameters()
    names = list(abc.PROBLEMS[PROBLEM]["unknown"])
    for name in names:
        values = np.asarray(
            [r["best_recovered"][name] for r in realizations], dtype=float
        )
        errors = np.asarray(
            [r["best_relative_error_pct"][name] for r in realizations],
            dtype=float,
        )
        successes = int(np.sum(errors < 5.0))
        aggregate[name] = {
            "true": float(true_params[name]),
            "median_recovered": float(np.median(values)),
            "p05_recovered": float(np.percentile(values, 5)),
            "p95_recovered": float(np.percentile(values, 95)),
            "median_relative_error_pct": float(np.median(errors)),
            "p05_relative_error_pct": float(np.percentile(errors, 5)),
            "p95_relative_error_pct": float(np.percentile(errors, 95)),
            "within_5pct_count": successes,
            "within_5pct_total": int(errors.size),
        }
        if name == "m":
            from scipy.stats import beta

            n = int(errors.size)
            aggregate[name]["within_5pct_exact_95pct_ci"] = [
                0.0 if successes == 0 else float(
                    beta.ppf(0.025, successes, n - successes + 1)
                ),
                1.0 if successes == n else float(
                    beta.ppf(0.975, successes + 1, n - successes)
                ),
            ]

    payload = {
        "description": (
            "Problem A robustness pilot with quarterly interval-integrated "
            "TB incidence and midpoint non-AIDS HIV prevalence"
        ),
        "problem": PROBLEM,
        "observation_map": "H2-integrated-incidence",
        "observation_definition": {
            "y1": (
                "integral over each quarter of "
                "100000*(k*L+k_star*J2)/N dt"
            ),
            "y2": "100*(J1+J2+J3)/N at the interval midpoint",
            "interval_edges": [float(v) for v in edges],
            "n_observation_intervals": int(clean_target.shape[0]),
        },
        "noise_fraction": 0.05,
        "noise_type": "multiplicative Gaussian, clamped non-negative",
        "objective_type": objective_type,
        "parameter_bounds": {
            "m": [abc.M_FIT_LOWER, abc.M_FIT_UPPER],
            "a0": [
                float(shared.ParameterModule.A0_LO),
                float(shared.ParameterModule.A0_HI),
            ],
            "a_max": [
                float(shared.ParameterModule.A0_LO + shared.ParameterModule.EPS_A),
                float(shared.ParameterModule.AMAX_HI),
            ],
            "omega0": [
                float(shared.ParameterModule.OMEGA0_LO),
                float(shared.ParameterModule.OMEGA0_HI),
            ],
        },
        "initialization_protocol": (
            "The first n deterministic Problem A starts from _start_grid; "
            "the best objective among them is retained for each realisation."
        ),
        "seed": int(seed),
        "n_realizations": int(n_realizations),
        "n_starts_per_realization": int(n_starts),
        "aggregate": aggregate,
        "realizations": realizations,
    }
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-realizations", type=int, default=20)
    parser.add_argument("--n-starts", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20260930)
    parser.add_argument(
        "--objective", choices=("relative", "range"), default="relative"
    )
    args = parser.parse_args()

    payload = run(
        n_realizations=args.n_realizations,
        n_starts=args.n_starts,
        seed=args.seed,
        objective_type=args.objective,
    )
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    outfile = RESULT_DIR / "interval_integrated_H2_A.json"
    outfile.write_text(
        json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8"
    )
    summary = payload["aggregate"]["m"]
    print(
        f"Saved {outfile}; median m_hat={summary['median_recovered']:.6g}, "
        f"median error={summary['median_relative_error_pct']:.2f}%, "
        f"within 5%={summary['within_5pct_count']}/"
        f"{summary['within_5pct_total']}",
        flush=True,
    )


if __name__ == "__main__":
    main()
