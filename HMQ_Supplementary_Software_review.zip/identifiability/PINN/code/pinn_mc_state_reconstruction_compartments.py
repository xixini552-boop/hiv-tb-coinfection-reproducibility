"""Per-compartment Monte Carlo diagnostics for conditional PINN state reconstruction.

Companion to ``pinn_mc_state_reconstruction.py``.  That script archives the
observation-level diagnostic (normalised RMSE for the two observed outputs, TB
incidence and HIV prevalence) that is plotted in the ESM figure
``fig_pinn_state_reconstruction_mc``.  The ESM text additionally refers to
per-compartment errors for the *unobserved* compartments (latent TB ``L``,
treated TB ``T``, coinfection stages ``J2`` and ``J3``).  This script produces
and archives exactly those numbers, using the same noise seeds, network seeds,
fixed-parameter configuration and epoch schedule, so the two archives describe
the same 20 realisations.

Each compartment RMSE is normalised by the peak-to-peak range of that
compartment's true trajectory over the observation window, the direct analogue
of the range normalisation used for the observation-level RMSE.

Outputs (under ``results/pinn_mc_state_reconstruction_formal/``):
  * ``pinn_mc_state_reconstruction_compartments.json`` - full per-realisation
    records.
  * ``fig_pinn_state_reconstruction_mc_compartments.csv`` - tidy figure data
    (one row per realisation x compartment).
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np

CODE_DIR = Path(__file__).resolve().parent
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import pinn_conditional_A as conditional  # noqa: E402


OUT_DIR = CODE_DIR.parent / "results" / "pinn_mc_state_reconstruction_formal"
UNOBSERVED = ("L", "T", "J2", "J3")


def run_one(noise_seed: int, network_seed: int, epochs_scale: float) -> dict[str, Any]:
    data = conditional.synthetic_data(noise_fraction=0.05, seed=int(noise_seed))
    result = conditional.train_once(
        data=data,
        fixed_m=float(conditional.shared.TRUE_VALS["m"]),
        init_values=dict(conditional.HC_STARTS[0]),
        learnable_healthcare=(),
        seed=int(network_seed),
        epochs_scale=float(epochs_scale),
        return_state_rmse=True,
    )
    result["noise_seed"] = int(noise_seed)
    result["network_seed"] = int(network_seed)
    result["noise_fraction"] = 0.05
    return result


def summarize(results: list[dict[str, Any]]) -> dict[str, Any]:
    def pooled(key: str) -> np.ndarray:
        return np.asarray([row["per_compartment_rmse"][key]["rmse_normalized"] for row in results])

    def stats(values: np.ndarray) -> dict[str, float]:
        return {
            "median": float(np.median(values)),
            "mean": float(np.mean(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "q25": float(np.percentile(values, 25)),
            "q75": float(np.percentile(values, 75)),
        }

    tb_norm, hiv_norm = [], []
    for row in results:
        data = conditional.synthetic_data(noise_fraction=0.05, seed=int(row["noise_seed"]))
        tb_norm.append(row["tb_rmse_vs_observed"] / max(float(np.ptp(data["tb_observed"])), 1.0))
        hiv_norm.append(row["hiv_rmse_vs_observed"] / max(float(np.ptp(data["hiv_observed"])), 1.0))
    observation_level = np.r_[np.asarray(tb_norm), np.asarray(hiv_norm)]

    return {
        "n_realizations": int(len(results)),
        "noise_fraction": 0.05,
        "epochs_scale": float(results[0].get("training_protocol", {}).get("epochs_scale", float("nan")))
        if results
        else float("nan"),
        "observation_level_normalized_rmse": stats(observation_level),
        "per_compartment_normalized_rmse": {
            name: stats(pooled(name)) for name in conditional.STATE_ORDER
        },
        "unobserved_compartments": {
            name: stats(pooled(name)) for name in UNOBSERVED
        },
        "normalization": {
            "observation_level": "RMSE divided by the peak-to-peak range of the observed sequence",
            "per_compartment": (
                "RMSE divided by the peak-to-peak range of the true compartment "
                "trajectory over the observation window"
            ),
        },
    }


def write_csv(results: list[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "realization",
                "noise_seed",
                "network_seed",
                "compartment",
                "rmse_raw",
                "rmse_normalized",
                "observed",
            ]
        )
        for index, row in enumerate(results, start=1):
            for name in conditional.STATE_ORDER:
                entry = row["per_compartment_rmse"][name]
                writer.writerow(
                    [
                        index,
                        row["noise_seed"],
                        row["network_seed"],
                        name,
                        f"{entry['rmse_raw']:.10g}",
                        f"{entry['rmse_normalized']:.10g}",
                        "no" if name in UNOBSERVED else "yes",
                    ]
                )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-realizations", type=int, default=20)
    parser.add_argument("--epochs-scale", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=20260811)
    parser.add_argument("--out-dir", type=Path, default=OUT_DIR)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    results: list[dict[str, Any]] = []
    out_path = args.out_dir / "pinn_mc_state_reconstruction_compartments.json"
    csv_path = args.out_dir / "fig_pinn_state_reconstruction_mc_compartments.csv"
    for index in range(max(1, int(args.n_realizations))):
        noise_seed = int(args.seed) + index * 17
        network_seed = int(args.seed) + 10000 + index * 31
        print(f"PINN compartment MC realization {index + 1}/{args.n_realizations}", flush=True)
        result = run_one(noise_seed, network_seed, float(args.epochs_scale))
        results.append(result)
        payload = {
            "analysis": "5% noise conditional PINN per-compartment state reconstruction Monte Carlo",
            "status": "companion_to_pinn_mc_state_reconstruction",
            "model_modified": False,
            "time_varying_beta_used": False,
            "epochs_scale": float(args.epochs_scale),
            "unobserved_compartments": list(UNOBSERVED),
            "summary": summarize(results),
            "results": results,
        }
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        write_csv(results, csv_path)
        comp = result["per_compartment_rmse"]
        print(
            "  "
            + ", ".join(f"{name}={comp[name]['rmse_normalized']:.4f}" for name in UNOBSERVED),
            flush=True,
        )
    print(f"Saved: {out_path.resolve()}")
    print(f"Saved: {csv_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
