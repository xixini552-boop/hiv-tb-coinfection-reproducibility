"""Conditional PINN validation for problem A under the two-output design.

The shared ODE, response function, and TB/HIV observation operators are reused
without modification. Problem A is deliberately conditional here: m,
beta1, beta2, and the seeded initial condition are fixed, while a0, a_max,
and omega0 are learned. Constant beta networks are frozen, so this branch
does not introduce arbitrary time-varying transmission functions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch

CODE_DIR = Path(__file__).resolve().parent
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import pinn_training_paper_safe as shared  # noqa: E402


OUT_DIR = CODE_DIR.parent / "results" / "pinn_conditional_A"
HC_STARTS = [
    {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010},
    {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080},
    {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200},
]
# Component order of the state vector used by ``shared.rhs_full_np``.
STATE_ORDER = ("S", "L", "I", "T", "J1", "J2", "J3", "A")


def synthetic_data(noise_fraction: float, seed: int) -> dict[str, Any]:
    return shared.make_partial_observation_synthetic_data(
        noise_fraction=float(noise_fraction), seed=int(seed)
    )


def train_once(
    data: dict[str, Any],
    fixed_m: float,
    init_values: dict[str, float],
    learnable_healthcare: tuple[str, ...],
    seed: int,
    epochs_scale: float,
    return_state_rmse: bool = False,
) -> dict[str, Any]:
    """Run one conditional PINN fit.

    ``return_state_rmse=True`` additionally reports, for each state component,
    the raw RMSE against the synthetic truth together with the RMSE normalised
    by the peak-to-peak range of that component's true trajectory.  This is the
    per-compartment diagnostic archived for the unobserved compartments
    (latent TB ``L``, treated TB ``T``, coinfection stages ``J2`` and ``J3``);
    the default keeps the original return payload unchanged.
    """
    shared.set_random_seed(int(seed))
    t_data = torch.tensor(data["t_norm"].reshape(-1, 1), dtype=torch.float32)
    t_colloc = torch.tensor(
        np.linspace(0.0, 1.0, 300).reshape(-1, 1), dtype=torch.float32
    )
    t0 = torch.zeros((1, 1), dtype=torch.float32)
    tb_target = torch.tensor(data["tb_observed"], dtype=torch.float32)
    hiv_target = torch.tensor(data["hiv_observed"], dtype=torch.float32)
    x0_true = torch.tensor(
        shared.make_seed(0.50, 10.0).reshape(1, -1), dtype=torch.float32
    )
    y_min, y_scale = shared.compute_country_norm(
        data["tb_observed"], data["hiv_observed"]
    )
    shared.set_ode_normalization(y_min, y_scale)

    # Keep the control experiment genuinely conditional: parameters that are
    # not being learned must be fixed at the synthetic truth.  In particular,
    # ``--learn-healthcare none`` should not turn the multi-start guesses into
    # different fixed models, otherwise a poor state fit would be confounded
    # with parameter misspecification.  For a conditional estimation run,
    # only the explicitly learnable healthcare parameters receive perturbed
    # initial values; the remaining healthcare parameters stay at truth.
    initial = dict(shared.TRUE_VALS)
    for name in learnable_healthcare:
        if name in init_values:
            initial[name] = float(init_values[name])
    initial["m"] = float(fixed_m)
    param_module = shared.ParameterModule(initial)
    shared.set_healthcare_trainability(param_module, learnable_healthcare)

    state_net = shared.StateNetwork(hidden=32, n_hidden=2)
    # Degree-one networks with zero slope are constant; all beta weights are frozen.
    beta1_net = shared.Beta1Network(
        init_beta1=shared.beta1_syn, upper=5.0, degree=1
    )
    beta2_net = shared.Beta2Network(
        init_beta2=shared.beta2_syn, upper=0.5, degree=1
    )
    for net in (beta1_net, beta2_net):
        for parameter in net.parameters():
            parameter.requires_grad_(False)

    phases = [
        ("P1", int(400 * epochs_scale), 1e-3, 1.0, 0.00),
        ("P2", int(600 * epochs_scale), 5e-4, 1.0, 0.10),
        ("P3", int(800 * epochs_scale), 2e-4, 0.8, 0.50),
        ("P4", int(800 * epochs_scale), 1e-4, 0.5, 1.00),
    ]
    protocol = {
        "optimizer": "Adam",
        "gradient_clip_norm": 5.0,
        "collocation_points": 300,
        "epochs_scale": float(epochs_scale),
        "phase_schedule": [
            {
                "phase": label,
                "epochs": int(n_epochs),
                "learning_rate": float(lr),
                "data_weight": float(w_data),
                "ode_weight": float(w_ode),
                "initial_condition_weight": 1.0,
            }
            for label, n_epochs, lr, w_data, w_ode in phases
        ],
    }
    parameters = [p for p in state_net.parameters() if p.requires_grad]
    parameters += [p for p in param_module.parameters() if p.requires_grad]
    optimizer = torch.optim.Adam(parameters, lr=1e-3)
    history: list[dict[str, float]] = []

    tb_scale = max(float(np.ptp(data["tb_observed"])), 1.0)
    hiv_scale = max(float(np.ptp(data["hiv_observed"])), 1.0)
    y_scale_t = torch.tensor(y_scale, dtype=torch.float32)
    for label, n_epochs, lr, w_data, w_ode in phases:
        for group in optimizer.param_groups:
            group["lr"] = lr
        for epoch in range(max(1, n_epochs)):
            optimizer.zero_grad()
            x_data = state_net(t_data)
            tb_fit, hiv_fit = shared.observables_torch(x_data)
            loss_data = torch.mean(((tb_fit - tb_target) / tb_scale) ** 2)
            loss_data = loss_data + torch.mean(((hiv_fit - hiv_target) / hiv_scale) ** 2)

            residual = shared.compute_ode_residual_both_nets(
                state_net,
                param_module,
                t_colloc,
                beta1_net,
                beta2_net,
                time_horizon=data["time_horizon"],
            )
            loss_ode = torch.mean(residual ** 2)
            x0_pred = state_net(t0)
            loss_init = torch.mean(((x0_pred - x0_true) / y_scale_t) ** 2)
            loss = w_data * loss_data + w_ode * loss_ode + 1.0 * loss_init
            loss.backward()
            torch.nn.utils.clip_grad_norm_(parameters, 5.0)
            optimizer.step()
            if epoch == n_epochs - 1 or epoch % max(1, n_epochs // 4) == 0:
                history.append(
                    {
                        "phase": label,
                        "epoch": float(epoch),
                        "loss_total": float(loss.detach()),
                        "loss_data": float(loss_data.detach()),
                        "loss_ode": float(loss_ode.detach()),
                        "loss_init": float(loss_init.detach()),
                    }
                )

    with torch.no_grad():
        a0, a_max, omega0, omega_min, m = param_module.get_params()
        x_fit = state_net(t_data)
        tb_fit, hiv_fit = shared.observables_torch(x_fit)
        final_x0 = state_net(t0)
    recovered = {
        "a0": float(a0),
        "a_max": float(a_max),
        "omega0": float(omega0),
        "omega_min": float(omega_min),
        "m": float(m),
    }
    per_compartment: dict[str, Any] | None = None
    if return_state_rmse:
        true_states = np.asarray(data["states_true"], dtype=float)
        fit_states = x_fit.detach().cpu().numpy().astype(float)
        per_compartment = {}
        for index, name in enumerate(STATE_ORDER):
            residual_state = fit_states[:, index] - true_states[:, index]
            raw = float(np.sqrt(np.mean(residual_state ** 2)))
            span = float(np.ptp(true_states[:, index]))
            if span <= 1e-12:
                span = max(float(np.max(np.abs(true_states[:, index]))), 1.0)
            per_compartment[name] = {
                "rmse_raw": raw,
                "rmse_normalized": raw / span,
                "normalization": (
                    "RMSE divided by the peak-to-peak range of the true "
                    "compartment trajectory over the observation window"
                ),
            }
    true = shared.TRUE_VALS
    errors = {
        name: abs(recovered[name] - true[name]) / max(abs(true[name]), 1e-12) * 100.0
        for name in ("a0", "a_max", "omega0", "m")
    }
    payload: dict[str, Any] = {
        "seed": int(seed),
        "fixed_m": float(fixed_m),
        "learnable_healthcare": list(learnable_healthcare),
        "initial_values": {key: float(value) for key, value in init_values.items()},
        "recovered_params": recovered,
        "relative_errors_pct_vs_true": errors,
        "tb_rmse_vs_observed": float(torch.sqrt(torch.mean((tb_fit - tb_target) ** 2))),
        "hiv_rmse_vs_observed": float(torch.sqrt(torch.mean((hiv_fit - hiv_target) ** 2))),
        "initial_state_rmse_normalized": float(
            torch.sqrt(torch.mean(((final_x0 - x0_true) / y_scale_t) ** 2))
        ),
        "final_loss": history[-1] if history else {},
        "history": history,
        "training_protocol": protocol,
        "normalization": {
            "observables": "range scaling from the observed TB-incidence and HIV-prevalence sequences",
            "state": "shared ODE normalization computed by compute_country_norm",
        },
        "model_modified": False,
        "time_varying_beta_used": False,
        "evidence_role": (
            "conditional_state_reconstruction"
            if not learnable_healthcare
            else "parameter_drift"
        ),
    }
    if per_compartment is not None:
        payload["per_compartment_rmse"] = per_compartment
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixed-m", type=float, default=0.05)
    parser.add_argument("--noise-fraction", type=float, default=0.0)
    parser.add_argument("--n-starts", type=int, default=3)
    parser.add_argument(
        "--learn-healthcare",
        default="a0,a_max,omega0",
        help="Comma-separated learnable healthcare parameters; use 'none' for state reconstruction only.",
    )
    parser.add_argument("--epochs-scale", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=20260811)
    parser.add_argument("--out-dir", type=Path, default=OUT_DIR)
    args = parser.parse_args()
    if args.fixed_m <= 0.0:
        raise ValueError("--fixed-m must be positive")
    data = synthetic_data(args.noise_fraction, args.seed)
    if args.learn_healthcare.strip().lower() == "none":
        learnable_healthcare: tuple[str, ...] = ()
    else:
        learnable_healthcare = tuple(
            name.strip() for name in args.learn_healthcare.split(",") if name.strip()
        )
    allowed = {"a0", "a_max", "omega0"}
    invalid = sorted(set(learnable_healthcare) - allowed)
    if invalid:
        raise ValueError(f"Unsupported learnable healthcare parameters: {invalid}")
    starts = HC_STARTS[: max(1, int(args.n_starts))]
    results = []
    for index, init in enumerate(starts, start=1):
        print(f"PINN conditional A start {index}/{len(starts)} fixed m={args.fixed_m}")
        result = train_once(
            data,
            fixed_m=float(args.fixed_m),
            init_values=init,
            learnable_healthcare=learnable_healthcare,
            seed=int(args.seed) + index * 97,
            epochs_scale=float(args.epochs_scale),
        )
        result["noise_fraction"] = float(args.noise_fraction)
        results.append(result)
        print(
            f"  a0={result['recovered_params']['a0']:.6g}, "
            f"a_max={result['recovered_params']['a_max']:.6g}, "
            f"omega0={result['recovered_params']['omega0']:.6g}, "
            f"TB_RMSE={result['tb_rmse_vs_observed']:.6g}, "
            f"HIV_RMSE={result['hiv_rmse_vs_observed']:.6g}"
        )
    payload = {
        "analysis": "conditional PINN problem A",
        "status": "new_branch_only",
        "model_modified": False,
        "old_pinn_branch_run": False,
        "old_results_overwritten": False,
        "fixed": ["m", "beta1", "beta2", "seeded_initial_condition"],
        "learned": list(learnable_healthcare),
        "learnable_healthcare": list(learnable_healthcare),
        "time_varying_beta_used": False,
        "noise_fraction": float(args.noise_fraction),
        "fixed_m": float(args.fixed_m),
        "evidence_role": (
            "conditional_state_reconstruction"
            if not learnable_healthcare
            else "parameter_drift"
        ),
        "training_protocol": {
            "optimizer": "Adam",
            "gradient_clip_norm": 5.0,
            "collocation_points": 300,
            "epochs_scale": float(args.epochs_scale),
            "phase_epoch_bases": {"P1": 400, "P2": 600, "P3": 800, "P4": 800},
            "learning_rates": {"P1": 1e-3, "P2": 5e-4, "P3": 2e-4, "P4": 1e-4},
        },
        "normalization": {
            "observables": "range scaling from each observed TB-incidence and HIV-prevalence sequence",
            "state": "shared ODE normalization computed by compute_country_norm",
        },
        "results": results,
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    out_path = args.out_dir / f"pinn_conditional_A_m{args.fixed_m:g}_noise{args.noise_fraction:g}.json"
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"Saved: {out_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
