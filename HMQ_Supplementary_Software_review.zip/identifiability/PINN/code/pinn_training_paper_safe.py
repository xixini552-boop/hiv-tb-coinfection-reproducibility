"""
PINN for HIV-TB healthcare-response parameter recovery.
Synthetic validation plus paper-safe partially observed real-data fitting.

Key principles (Qian et al. 2025 observation structure; Kharazmi et al.
finite-observation validation; Miao/Wentworth parameter-subset screening):
- TB observation = flow-based incidence (kL + k*J2)/N × 10^5  (not I/N).
- No detection fraction r(t) — WHO data is estimated incidence.
- Healthcare parameter ordering enforced via hard logit constraints.
- Full-state synthetic validation is for ODE/AD debugging only and must
  NOT be described as an identifiability proof in the paper.
- Real-data identifiability is assessed through a partial-observation
  parameter-subset screen that matches the real observation design
  (15 annual points, TB incidence + HIV prevalence only).
"""
import torch
import torch.nn as nn
import numpy as np
# NumPy < 2.0 compatibility
if not hasattr(np, "trapezoid"):
    np.trapezoid = np.trapz
from scipy.integrate import solve_ivp
from scipy.optimize import minimize, least_squares
from scipy.special import expit
from pathlib import Path
import sys
import warnings
import json
import argparse
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=RuntimeWarning)

import importlib
_THIS_DIR = Path(__file__).resolve().parent
for _candidate in (
    _THIS_DIR,
    _THIS_DIR.parent.parent / "1_bifurcation" / "code",
    # Current repository layout: the shared module lives in bifurcation/code,
    # three levels up from this file (identifiability/PINN/code/).
    _THIS_DIR.parent.parent.parent / "bifurcation" / "code",
    _THIS_DIR / "hiv_tb_article_code_FIXED3" / "hiv_tb_article_code",
    Path.cwd() / "hiv_tb_article_code_FIXED3" / "hiv_tb_article_code",
):
    if _candidate.exists() and str(_candidate) not in sys.path:
        sys.path.insert(0, str(_candidate))
_common = importlib.import_module("00_common")
Params = _common.Params
beta1_from_RT = _common.beta1_from_RT
beta2_from_RH = _common.beta2_from_RH
scan_full_branch_RTH = _common.scan_full_branch_RTH

# ============================================================
# Configuration
# ============================================================
DEVICE = torch.device("cpu")
torch.manual_seed(42)
np.random.seed(42)

OUT_SYN = Path("PINN/results/synthetic")
OUT_SYN.mkdir(parents=True, exist_ok=True)

MAX_EPOCHS = 10000
TARGET_PCT = 2.0

# ============================================================
# 1. FIXED PARAMETERS
# ============================================================
N0 = 10000.0
mu = 0.0143; k_val = 0.5; d_val = 0.1
k_star = 2.5; d_star = 0.2
alpha1 = 0.1; alpha2 = 0.2; alpha3 = 0.5
f_val = 0.5; theta_val = 1.0; sigma_rel = 1.0
Lambda = mu * N0
T_MAX = 14.0

TRUE_VALS = {"a0": 0.6, "a_max": 1.5, "omega0": 0.003,
             "omega_min": 1e-5, "m": 0.05}

RT_SYN = 1.37; RH_SYN = 1.8
beta1_star_TB = (mu + k_val + TRUE_VALS["a0"]) * (mu + d_val + TRUE_VALS["a0"]) / k_val
beta1_syn = RT_SYN * beta1_star_TB
beta2_syn = RH_SYN * (alpha1 + mu)

# ============================================================
# 2. SYNTHETIC DATA — Multi-Trajectory (full-state debug)
# ============================================================

def response_np(B, a0, a_max, omega0, omega_min, m):
    B = np.asarray(B, dtype=float)
    B = np.maximum(B, 0.0)
    denom = 1.0 + m * B
    safe = np.where(denom > 0, denom, 1.0)
    z = np.where(denom > 0, (1.0 + m) * B / safe, 0.0)
    a = a0 + (a_max - a0) * z
    omega = omega0 + (omega_min - omega0) * z
    if a.ndim == 0:
        return float(a), float(omega)
    return a, omega

def rhs_full_np(t, x, beta1, beta2, a0, a_max, omega0, omega_min, m):
    S, L, I, T, J1, J2, J3, A = x
    N = S + L + I + T + J1 + J2 + J3 + A
    if N <= 1e-12: return np.ones(8) * 1e12
    R_pool = N - I - J3 - A
    if R_pool <= 1e-12: return np.ones(8) * 1e12
    B = (I + J3) / N
    a, omega = response_np(B, a0, a_max, omega0, omega_min, m)
    Jstar = J1 + J2 + J3
    treat_L = a * L / (1.0 + omega * L)
    treat_I = a * I / (1.0 + omega * I)
    treat_J2 = a * J2 / (1.0 + omega * J2)
    tb_force = beta1 * (I + J3) / N
    hiv_force = beta2 * Jstar / R_pool
    dS = Lambda - tb_force * S - hiv_force * S - mu * S
    dL = beta1*(S+T)*(I+J3)/N - sigma_rel*beta2*L*Jstar/R_pool - (mu+k_val)*L - treat_L
    dI = k_val*L - (mu+d_val)*I - treat_I
    dT = treat_L + treat_I - beta1*T*(I+J3)/N - beta2*T*Jstar/R_pool - mu*T
    dJ1 = beta2*(S+T)*Jstar/R_pool - theta_val*beta1*J1*(I+J3)/N - (alpha1+mu)*J1 + treat_J2
    dJ2 = sigma_rel*beta2*L*Jstar/R_pool + theta_val*beta1*J1*(I+J3)/N - (alpha2+mu+k_star)*J2 - treat_J2
    dJ3 = k_star*J2 - (alpha3+mu+d_star)*J3
    dA = alpha1*J1 + alpha2*J2 + alpha3*J3 - (mu+f_val)*A
    return np.array([dS, dL, dI, dT, dJ1, dJ2, dJ3, dA])

def make_seed(tb_prev_pct, hiv_prev_pct):
    """tb_prev_pct: TB prevalence per 100k / 100 (= %). hiv_prev_pct: HIV prevalence %."""
    S0 = Lambda / mu
    x = np.array([S0, 0, 0, 0, 0, 0, 0, 0])
    tb_pop = N0 * tb_prev_pct / 100.0
    hiv_pop = N0 * hiv_prev_pct / 100.0
    x[2] = tb_pop * 0.3       # I
    x[1] = x[2] * 2.0           # L
    x[3] = tb_pop * 0.2         # T
    x[4] = hiv_pop * 0.75       # J1
    x[5] = hiv_pop * 0.15       # J2
    x[6] = min(tb_pop * 0.3, hiv_pop * 0.1)  # J3
    x[7] = hiv_pop * 0.05       # A
    x[0] = max(N0 - x[1:].sum(), N0 * 0.5)
    return x

# Synthetic trajectories generated lazily.
t_data_np = None
beta1_list = [beta1_syn * r for r in [0.85, 1.0, 1.5, 3.0]]
seeds_list = None
trajectories = None
y_min = y_max = y_scale = None
Y_MIN_T = None
Y_SCALE_T = None
all_y_norm = None
all_t_norm = None

def set_random_seed(seed: int = 42):
    torch.manual_seed(seed)
    np.random.seed(seed)

def ensure_synthetic_data(verbose: bool = True):
    """Generate synthetic trajectories and normalization constants once."""
    global t_data_np, seeds_list, trajectories, y_min, y_max, y_scale
    global Y_MIN_T, Y_SCALE_T, all_y_norm, all_t_norm

    if trajectories is not None:
        return trajectories

    t_data_np = np.linspace(0, T_MAX, 100)
    seeds_list = [make_seed(10, 8), make_seed(25, 15), make_seed(40, 20), make_seed(55, 25)]

    if verbose:
        print(f"beta1_star_TB={beta1_star_TB:.4f}  beta1_syn={beta1_syn:.4f}  beta2_syn={beta2_syn:.4f}")
        print("\n=== Generating synthetic trajectories ===")

    trajectories = []
    for bi, (b1, seed) in enumerate(zip(beta1_list, seeds_list)):
        sol = solve_ivp(lambda t, y: rhs_full_np(t, y, b1, beta2_syn, **TRUE_VALS),
                        (0.0, T_MAX), seed, method="LSODA",
                        rtol=1e-8, atol=1e-10, max_step=0.5, t_eval=t_data_np)
        if sol.success:
            y = np.maximum(sol.y, 0.0)
            trajectories.append((sol.t.copy(), y))
            if verbose:
                B0 = (y[2,0] + y[6,0]) / y[:,0].sum()
                B1 = (y[2,-1] + y[6,-1]) / y[:,-1].sum()
                print(f"  Traj {bi+1} (RT≈{b1/beta1_star_TB:.2f}): B {B0:.3f}→{B1:.3f}")
        else:
            raise RuntimeError(f"Integration failed: {sol.message}")

    if verbose:
        print("\n=== Per-compartment normalization ===")
    all_y = np.concatenate([y for _, y in trajectories], axis=1)
    y_min = all_y.min(axis=1, keepdims=True)
    y_max = all_y.max(axis=1, keepdims=True)
    y_scale = y_max - y_min
    y_scale = np.where(y_scale < 1e-8, 1.0, y_scale)

    Y_MIN_T = torch.tensor(y_min.flatten(), dtype=torch.float32)
    Y_SCALE_T = torch.tensor(y_scale.flatten(), dtype=torch.float32)

    all_y_norm = [(y - y_min) / y_scale for _, y in trajectories]
    all_t_norm = [t / t[-1] for t, _ in trajectories]
    return trajectories

# ============================================================
# 3. UNIFIED OBSERVATION OPERATORS
# ============================================================

HEALTHCARE_KEYS = ("a0", "a_max", "omega0", "omega_min", "m")

RAW_PARAMETER_MAP = {
    "a0": "raw_a0",
    "a_max": "raw_amax",
    "omega0": "raw_om0",
    "omega_min": "raw_omm",
    "m": "raw_m",
}


def observables_torch(x_abs):
    """Map eight model states to the two actually observed quantities."""
    N_all = torch.clamp(x_abs.sum(dim=1), min=1e-8)

    L = x_abs[:, 1]
    J1 = x_abs[:, 4]
    J2 = x_abs[:, 5]
    J3 = x_abs[:, 6]

    tb_incidence = (
        (k_val * L + k_star * J2) / N_all * 100000.0
    )
    hiv_prevalence = (
        (J1 + J2 + J3) / N_all * 100.0
    )

    return tb_incidence, hiv_prevalence


def observables_numpy(x_abs):
    """NumPy version of the same observation operator."""
    x_abs = np.asarray(x_abs, dtype=float)
    N_all = np.maximum(x_abs.sum(axis=1), 1e-8)

    L = x_abs[:, 1]
    J1 = x_abs[:, 4]
    J2 = x_abs[:, 5]
    J3 = x_abs[:, 6]

    tb_incidence = (
        (k_val * L + k_star * J2) / N_all * 100000.0
    )
    hiv_prevalence = (
        (J1 + J2 + J3) / N_all * 100.0
    )

    return tb_incidence, hiv_prevalence

# ============================================================
# 4. NETWORK ARCHITECTURE
# ============================================================
N0_T = torch.tensor(N0, dtype=torch.float32)

class StateNetwork(nn.Module):
    """MLP: t → 8 compartments (absolute counts)."""
    def __init__(self, hidden=64, n_hidden=3, output_scale=N0):
        super().__init__()
        layers = []
        in_dim = 1
        for _ in range(int(n_hidden)):
            layers.extend([nn.Linear(in_dim, int(hidden)), nn.Tanh()])
            in_dim = int(hidden)
        layers.append(nn.Linear(in_dim, 8))
        self.net = nn.Sequential(*layers)
        self.output_scale = torch.tensor(float(output_scale), dtype=torch.float32)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, t):
        raw = self.net(t)
        return nn.functional.softplus(raw) * self.output_scale + 0.1


def _bounded_logit(value, lower, upper):
    value = float(np.clip(value, lower + 1e-8, upper - 1e-8))
    fraction = (value - lower) / (upper - lower)
    fraction = float(np.clip(fraction, 1e-6, 1.0 - 1e-6))
    return np.log(fraction / (1.0 - fraction))


class ParameterModule(nn.Module):
    """Healthcare-response parameters with hard biological ordering."""

    A0_LO = 0.01
    A0_HI = 3.0
    AMAX_HI = 5.0
    OMEGA0_LO = 1e-5
    OMEGA0_HI = 0.1
    OMEGAMIN_LO = 1e-8
    M_LO = 0.001
    M_HI = 30.0
    EPS_A = 1e-3
    EPS_OMEGA = 1e-8

    def __init__(self, init_vals):
        super().__init__()

        a0_init = float(np.clip(
            init_vals["a0"],
            self.A0_LO + 1e-6,
            self.A0_HI - 1e-6,
        ))
        amax_init = float(np.clip(
            init_vals["a_max"],
            a0_init + self.EPS_A + 1e-6,
            self.AMAX_HI - 1e-6,
        ))

        omega0_init = float(np.clip(
            init_vals["omega0"],
            self.OMEGA0_LO + 1e-8,
            self.OMEGA0_HI - 1e-8,
        ))
        omega_min_init = float(np.clip(
            init_vals["omega_min"],
            self.OMEGAMIN_LO + 1e-10,
            omega0_init - self.EPS_OMEGA - 1e-10,
        ))

        m_init = float(np.clip(
            init_vals["m"],
            self.M_LO + 1e-6,
            self.M_HI - 1e-6,
        ))

        self.raw_a0 = nn.Parameter(torch.tensor(
            _bounded_logit(a0_init, self.A0_LO, self.A0_HI),
            dtype=torch.float32,
        ))

        amax_fraction = (
            (amax_init - a0_init - self.EPS_A)
            / (self.AMAX_HI - a0_init - self.EPS_A)
        )
        amax_fraction = float(np.clip(amax_fraction, 1e-6, 1.0 - 1e-6))
        self.raw_amax = nn.Parameter(torch.tensor(
            np.log(amax_fraction / (1.0 - amax_fraction)),
            dtype=torch.float32,
        ))

        self.raw_om0 = nn.Parameter(torch.tensor(
            _bounded_logit(omega0_init, self.OMEGA0_LO, self.OMEGA0_HI),
            dtype=torch.float32,
        ))

        omega_min_upper = omega0_init - self.EPS_OMEGA
        omega_min_fraction = (
            (omega_min_init - self.OMEGAMIN_LO)
            / (omega_min_upper - self.OMEGAMIN_LO)
        )
        omega_min_fraction = float(np.clip(omega_min_fraction, 1e-6, 1.0 - 1e-6))
        self.raw_omm = nn.Parameter(torch.tensor(
            np.log(omega_min_fraction / (1.0 - omega_min_fraction)),
            dtype=torch.float32,
        ))

        self.raw_m = nn.Parameter(torch.tensor(
            _bounded_logit(m_init, self.M_LO, self.M_HI),
            dtype=torch.float32,
        ))

    def get_params(self):
        a0 = self.A0_LO + (
            self.A0_HI - self.A0_LO
        ) * torch.sigmoid(self.raw_a0)

        available_gap = self.AMAX_HI - a0 - self.EPS_A
        a_max = (
            a0
            + self.EPS_A
            + available_gap * torch.sigmoid(self.raw_amax)
        )

        omega0 = self.OMEGA0_LO + (
            self.OMEGA0_HI - self.OMEGA0_LO
        ) * torch.sigmoid(self.raw_om0)

        omega_min_upper = torch.clamp(
            omega0 - self.EPS_OMEGA,
            min=self.OMEGAMIN_LO + 1e-10,
        )
        omega_min = self.OMEGAMIN_LO + (
            omega_min_upper - self.OMEGAMIN_LO
        ) * torch.sigmoid(self.raw_omm)

        m = self.M_LO + (
            self.M_HI - self.M_LO
        ) * torch.sigmoid(self.raw_m)

        return a0, a_max, omega0, omega_min, m


def set_healthcare_trainability(param_module, learnable_names):
    """Train only the selected healthcare-response parameters."""
    learnable_names = tuple(learnable_names)

    unknown = set(learnable_names).difference(HEALTHCARE_KEYS)
    if unknown:
        raise ValueError(
            f"Unknown healthcare parameters: {sorted(unknown)}"
        )

    for name, raw_name in RAW_PARAMETER_MAP.items():
        parameter = getattr(param_module, raw_name)
        parameter.requires_grad_(name in learnable_names)


class BoundedTimeFunction(nn.Module):
    """Low-dimensional bounded polynomial time function."""
    def __init__(self, init_value, lower, upper, degree=3):
        super().__init__()
        self.lower = float(lower)
        self.upper = float(max(upper, lower + 1e-6))
        self.degree = int(degree)
        self.raw_center = nn.Parameter(
            torch.tensor(_bounded_logit(init_value, self.lower, self.upper), dtype=torch.float32)
        )
        self.raw_coeff = nn.Parameter(torch.zeros(self.degree, dtype=torch.float32))

    def _basis(self, t):
        x = 2.0 * t.squeeze(-1) - 1.0
        return torch.stack([x ** (j + 1) for j in range(self.degree)], dim=1)

    def forward(self, t):
        raw = self.raw_center + self._basis(t).matmul(self.raw_coeff)
        return self.lower + (self.upper - self.lower) * torch.sigmoid(raw)


class Beta1Network(BoundedTimeFunction):
    """Bounded low-dimensional beta1(t), TB transmission rate."""
    def __init__(self, init_beta1=2.0, lower=0.05, upper=None, degree=3):
        upper = max(float(upper or 0.0), 2.5 * float(init_beta1), 5.0)
        super().__init__(init_beta1, lower, upper, degree=degree)


class Beta2Network(BoundedTimeFunction):
    """Bounded low-dimensional beta2(t), HIV transmission rate."""
    def __init__(self, init_beta2=0.2, lower=0.01, upper=None, degree=2):
        upper = max(float(upper or 0.0), 2.0 * float(init_beta2), 0.5)
        super().__init__(init_beta2, lower, upper, degree=degree)


# ============================================================
# 5. ODE RESIDUAL (normalized space)
# ============================================================
LAMBDA_T = torch.tensor(Lambda, dtype=torch.float32)
MU_T = torch.tensor(mu, dtype=torch.float32)
K_T = torch.tensor(k_val, dtype=torch.float32)
D_T = torch.tensor(d_val, dtype=torch.float32)
K_STAR_T = torch.tensor(k_star, dtype=torch.float32)
D_STAR_T = torch.tensor(d_star, dtype=torch.float32)
ALPHA1_T = torch.tensor(alpha1, dtype=torch.float32)
ALPHA2_T = torch.tensor(alpha2, dtype=torch.float32)
ALPHA3_T = torch.tensor(alpha3, dtype=torch.float32)
F_T = torch.tensor(f_val, dtype=torch.float32)
THETA_T = torch.tensor(theta_val, dtype=torch.float32)
SIGMA_T = torch.tensor(sigma_rel, dtype=torch.float32)

ODE_Y_MIN = None
ODE_Y_SCALE = None


def set_ode_normalization(y_min_arr, y_scale_arr):
    global ODE_Y_MIN, ODE_Y_SCALE
    ODE_Y_MIN = torch.tensor(y_min_arr, dtype=torch.float32)
    ODE_Y_SCALE = torch.tensor(y_scale_arr, dtype=torch.float32)


def _get_ode_norm():
    global ODE_Y_MIN, ODE_Y_SCALE
    if ODE_Y_MIN is None or ODE_Y_SCALE is None:
        ensure_synthetic_data(verbose=False)
        ODE_Y_MIN = Y_MIN_T
        ODE_Y_SCALE = Y_SCALE_T
    return ODE_Y_MIN, ODE_Y_SCALE


def compute_country_norm(tb_inc, hiv_prev):
    """Estimate per-compartment normalization ranges from country observables."""
    tb_inc = np.asarray(tb_inc, dtype=float)
    hiv_prev = np.asarray(hiv_prev, dtype=float)
    r_bar = 0.6
    N0_est = N0

    I_lo = tb_inc.min() / 100000.0 * N0_est / r_bar * 0.5
    I_hi = tb_inc.max() / 100000.0 * N0_est / r_bar * 2.0
    Jstar_lo = hiv_prev.min() / 100.0 * N0_est * 0.8
    Jstar_hi = hiv_prev.max() / 100.0 * N0_est * 1.2

    dur_I = 1.0 / (mu + d_val + TRUE_VALS["a0"])
    L_mult = 1.0 / (k_val * dur_I)
    L_lo = I_lo * L_mult * 0.5
    L_hi = I_hi * L_mult * 2.0

    S_lo = N0_est * 0.3
    S_hi = N0_est * 1.0
    T_lo, T_hi = 0.0, N0_est * 0.3
    J1_lo, J1_hi = Jstar_lo * 0.3, Jstar_hi * 0.9
    J2_lo, J2_hi = Jstar_lo * 0.05, Jstar_hi * 0.3
    J3_lo, J3_hi = I_lo * 0.1, I_hi * 0.5
    A_lo, A_hi = 0.0, N0_est * 0.1

    y_min = np.array([S_lo, L_lo, I_lo, T_lo, J1_lo, J2_lo, J3_lo, A_lo])
    y_max = np.array([S_hi, L_hi, I_hi, T_hi, J1_hi, J2_hi, J3_hi, A_hi])
    y_scale = y_max - y_min
    y_scale = np.where(y_scale < 1e-8, 1.0, y_scale)

    return y_min, y_scale


def response_torch(B, a0, a_max, omega0, omega_min, m):
    B = torch.clamp(B, min=0.0)
    z = (1.0 + m) * B / (1.0 + m * B + 1e-12)
    return a0 + (a_max - a0) * z, omega0 + (omega_min - omega0) * z


def rhs_full_torch_normalized(x_norm, beta1, beta2, a0, a_max, omega0, omega_min, m):
    ym, ys = _get_ode_norm()
    x_abs = x_norm * ys + ym
    S, L, I, T, J1, J2, J3, A = x_abs[:,0], x_abs[:,1], x_abs[:,2], x_abs[:,3], x_abs[:,4], x_abs[:,5], x_abs[:,6], x_abs[:,7]
    N_all = S + L + I + T + J1 + J2 + J3 + A
    R_pool = N_all - I - J3 - A
    Jstar = J1 + J2 + J3
    N_s = torch.clamp(N_all, min=1e-8)
    R_s = torch.clamp(R_pool, min=1e-8)
    B = (I + J3) / N_s
    a, omega = response_torch(B, a0, a_max, omega0, omega_min, m)
    treat_L = a * L / (1.0 + omega * L)
    treat_I = a * I / (1.0 + omega * I)
    treat_J2 = a * J2 / (1.0 + omega * J2)
    tb_f = beta1 * (I + J3) / N_s
    hiv_f = beta2 * Jstar / R_s
    dS = LAMBDA_T - tb_f*S - hiv_f*S - MU_T*S
    dL = beta1*(S+T)*(I+J3)/N_s - SIGMA_T*beta2*L*Jstar/R_s - (MU_T+K_T)*L - treat_L
    dI = K_T*L - (MU_T+D_T)*I - treat_I
    dT = treat_L+treat_I - beta1*T*(I+J3)/N_s - beta2*T*Jstar/R_s - MU_T*T
    dJ1 = beta2*(S+T)*Jstar/R_s - THETA_T*beta1*J1*(I+J3)/N_s - (ALPHA1_T+MU_T)*J1 + treat_J2
    dJ2 = SIGMA_T*beta2*L*Jstar/R_s + THETA_T*beta1*J1*(I+J3)/N_s - (ALPHA2_T+MU_T+K_STAR_T)*J2 - treat_J2
    dJ3 = K_STAR_T*J2 - (ALPHA3_T+MU_T+D_STAR_T)*J3
    dA = ALPHA1_T*J1 + ALPHA2_T*J2 + ALPHA3_T*J3 - (MU_T+F_T)*A
    d_abs = torch.stack([dS, dL, dI, dT, dJ1, dJ2, dJ3, dA], dim=1)
    _, ys = _get_ode_norm()
    return d_abs / ys


def _componentwise_time_derivative(y, t):
    grads = []
    for j in range(y.shape[1]):
        grad_j = torch.autograd.grad(
            y[:, j].sum(),
            t,
            create_graph=True,
            retain_graph=True,
        )[0]
        grads.append(grad_j)
    return torch.cat(grads, dim=1)


def _squared_time_derivative_mean(y, t):
    dy = torch.autograd.grad(y.sum(), t, create_graph=True, retain_graph=True)[0]
    return torch.mean(dy ** 2)


def rate_regularization(beta1_net, beta2_net, t):
    """Smoothness regularization without parameter-value leakage."""
    t_reg = t.clone().detach().requires_grad_(True)

    beta1_t = beta1_net(t_reg)
    beta2_t = beta2_net(t_reg)

    return (
        _squared_time_derivative_mean(beta1_t, t_reg)
        + _squared_time_derivative_mean(beta2_t, t_reg)
    )


def count_trainable_params(*modules):
    return int(sum(p.numel() for module in modules for p in module.parameters() if p.requires_grad))


def compute_ode_residual(state_net, param_module, t, beta1, beta2, time_horizon=T_MAX):
    t_in = t.clone().detach().requires_grad_(True)
    x_abs = state_net(t_in)
    ym, ys = _get_ode_norm()
    x_norm = (x_abs - ym) / ys
    dx_dtn = _componentwise_time_derivative(x_norm, t_in)
    dx_dtr = dx_dtn / max(float(time_horizon), 1e-12)
    a0, a_max, omega0, omega_min, m = param_module.get_params()
    rhs = rhs_full_torch_normalized(x_norm, beta1, beta2, a0, a_max, omega0, omega_min, m)
    return dx_dtr - rhs


def compute_ode_residual_both_nets(state_net, param_module, t, beta1_net, beta2_net, time_horizon=T_MAX):
    t_in = t.clone().detach().requires_grad_(True)
    x_abs = state_net(t_in)
    ym, ys = _get_ode_norm()
    x_norm = (x_abs - ym) / ys
    dx_dtn = _componentwise_time_derivative(x_norm, t_in)
    dx_dtr = dx_dtn / max(float(time_horizon), 1e-12)
    a0, a_max, omega0, omega_min, m = param_module.get_params()
    beta1_t = beta1_net(t_in).squeeze(-1)
    beta2_t = beta2_net(t_in).squeeze(-1)
    rhs = rhs_full_torch_normalized(x_norm, beta1_t, beta2_t, a0, a_max, omega0, omega_min, m)
    return dx_dtr - rhs

# ============================================================
# 6. FULL-STATE SYNTHETIC TRAINING (ODE/AD debugging only)
# ============================================================

def run_training(lr_init=1e-3):
    """Single full-state training run. For ODE/AD verification, not identifiability."""
    ensure_synthetic_data(verbose=True)
    print(f"\n{'='*60}")
    print(f"Training run: lr={lr_init:.0e}, w_data=1.0, w_ode=0.5, max_epochs={MAX_EPOCHS}")
    print(f"{'='*60}")

    n_traj = len(trajectories)
    t_data = [torch.tensor(tn.reshape(-1,1), dtype=torch.float32) for tn in all_t_norm]
    y_data = [torch.tensor(yn.T.astype(np.float32)) for yn in all_y_norm]
    t_colloc = [torch.tensor(np.linspace(0,1,500).reshape(-1,1), dtype=torch.float32) for _ in range(n_traj)]

    state_nets = [StateNetwork() for _ in range(n_traj)]
    param_module = ParameterModule({"a0":0.65, "a_max":1.55, "omega0":0.0028,
                                     "omega_min":1e-5, "m":0.055})

    all_params = []
    for sn in state_nets:
        all_params.extend(sn.parameters())
    all_params.extend(param_module.parameters())

    PHASE1_EPOCHS = 3000
    PHASE2_LR = 2e-4

    optimizer = torch.optim.Adam([{"params": all_params, "lr": lr_init}])

    loss_hist, param_hist = [], []
    best_max_err = float("inf")
    best_params = None
    best_epoch = 0
    prior_log10 = -5.0

    for epoch in range(MAX_EPOCHS):
        if epoch == PHASE1_EPOCHS:
            for g in optimizer.param_groups:
                g["lr"] = PHASE2_LR
            print(f"  --- Phase 2: LR -> {PHASE2_LR:.0e} at epoch {epoch} ---")

        optimizer.zero_grad()

        loss_data = sum(
            nn.functional.mse_loss(
                (state_nets[k](t_data[k]) - Y_MIN_T) / Y_SCALE_T,
                y_data[k])
            for k in range(n_traj)) / n_traj

        loss_ode = sum(
            torch.mean(compute_ode_residual(
                state_nets[k], param_module, t_colloc[k],
                torch.as_tensor(beta1_list[k], dtype=torch.float32),
                torch.tensor(beta2_syn, dtype=torch.float32))**2)
            for k in range(n_traj)) / n_traj

        _, _, _, omega_min, _ = param_module.get_params()
        loss_reg = (torch.log10(omega_min + 1e-12) - prior_log10)**2

        loss = 1.0 * loss_data + 0.5 * loss_ode + 0.01 * loss_reg
        loss.backward()

        grads = [p.grad for p in all_params if p.grad is not None]
        if grads:
            torch.nn.utils.clip_grad_norm_(grads, 5.0)

        optimizer.step()

        with torch.no_grad():
            a0, a_max, omega0, omega_min, m = param_module.get_params()
            pd = {"a0":a0.item(), "a_max":a_max.item(), "omega0":omega0.item(),
                  "omega_min":omega_min.item(), "m":m.item()}

        loss_hist.append({"epoch":epoch, "loss_total":loss.item(),
                          "loss_data":loss_data.item(), "loss_ode":loss_ode.item()})
        param_hist.append(pd)

        max_err = max(abs(pd[k]-TRUE_VALS[k])/max(abs(TRUE_VALS[k]),1e-8)*100
                      for k in TRUE_VALS)
        if max_err < best_max_err:
            best_max_err = max_err
            best_params = dict(pd)
            best_epoch = epoch

        if max_err < TARGET_PCT:
            print(f"  *** CONVERGED at epoch {epoch}: max error {max_err:.2f}% < {TARGET_PCT}% ***")
            break

        if epoch % 500 == 0:
            lr_now = optimizer.param_groups[0]["lr"]
            errs = " | ".join(f"{k}={pd[k]:.4g}({abs(pd[k]-TRUE_VALS[k])/max(abs(TRUE_VALS[k]),1e-8)*100:.1f}%)"
                              for k in TRUE_VALS)
            print(f"  ep {epoch:5d} lr={lr_now:.2e} | total={loss.item():.4e} data={loss_data.item():.4e} ode={loss_ode.item():.4e}")
            print(f"        {errs}")

    with torch.no_grad():
        a0, a_max, omega0, omega_min, m = param_module.get_params()
        recovered = {"a0":a0.item(), "a_max":a_max.item(), "omega0":omega0.item(),
                     "omega_min":omega_min.item(), "m":m.item()}
    errors = {k: abs(recovered[k]-TRUE_VALS[k])/max(abs(TRUE_VALS[k]),1e-8)*100 for k in TRUE_VALS}
    max_err = max(errors.values())

    print(f"\n  Best epoch: {best_epoch} (max_err={best_max_err:.2f}%)")
    print(f"  Final: max_err={max_err:.2f}%")
    for k in TRUE_VALS:
        print(f"    {k}: true={TRUE_VALS[k]:.6g} recovered={recovered[k]:.6g} err={errors[k]:.2f}%")

    return recovered, errors, max_err, loss_hist, param_hist, state_nets, param_module


def plot_results(loss_hist, param_hist, recovered, errors, run_id):
    epochs = np.arange(len(loss_hist))
    param_keys = ["a0", "a_max", "omega0", "omega_min", "m"]
    colors_p = ["#C62828", "#E65100", "#1565C0", "#2E7D32", "#6A1B9A"]

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    ax = axes[0]
    ax.semilogy(epochs, [h["loss_total"] for h in loss_hist], "k-", lw=1.0, label="Total")
    ax.semilogy(epochs, [h["loss_data"] for h in loss_hist], "#C62828", lw=0.7, alpha=0.7, label="Data")
    ax.semilogy(epochs, [h["loss_ode"] for h in loss_hist], "#1565C0", lw=0.7, alpha=0.7, label="ODE")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Loss"); ax.set_title("Loss")
    ax.legend(fontsize=7); ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    ax = axes[1]
    for i, key in enumerate(param_keys):
        vals = [p[key] for p in param_hist]
        ax.semilogy(epochs, vals, color=colors_p[i], lw=0.8, label=key)
        ax.axhline(y=TRUE_VALS[key], color=colors_p[i], lw=0.6, ls="--", alpha=0.5)
    ax.set_xlabel("Epoch"); ax.set_ylabel("Value"); ax.set_title("Parameter Convergence")
    ax.legend(fontsize=6, ncol=3); ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    ax = axes[2]
    errs_list = [errors[k] for k in param_keys]
    bars = ax.bar(param_keys, errs_list, color=colors_p, edgecolor="k", linewidth=0.5)
    ax.axhline(y=TARGET_PCT, color="red", lw=1.0, ls="--")
    ax.text(-0.35, TARGET_PCT + 0.08, f"{TARGET_PCT}% threshold",
            fontsize=7, color="red", va="bottom", fontstyle="italic")
    for bar, ev in zip(bars, errs_list):
        ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.10,
                f"{ev:.1f}%", ha="center", fontsize=8, fontweight="bold")
    ax.set_ylabel("Relative Error (%)"); ax.set_title("Parameter Errors")
    ax.set_ylim(0, max(errs_list) * 1.4 + 0.5)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)

    fig.suptitle(f"Synthetic Full-State Validation — Run {run_id}", fontweight="bold")
    fig.tight_layout()
    fig.savefig(str(OUT_SYN / f"diagnostics_run{run_id}.pdf"), dpi=300)
    fig.savefig(str(OUT_SYN / f"diagnostics_run{run_id}.png"), dpi=300)
    plt.close(fig)


def plot_trajectory_comparison(state_nets, param_module, run_id):
    ensure_synthetic_data(verbose=False)
    n_traj = len(trajectories)
    comp_names = ["S", "L", "I", "T", "J1", "J2", "J3", "A"]
    colors = ["#1565C0", "#C62828", "#2E7D32", "#E65100"]
    rt_approx = [f"{beta1_list[k]/beta1_star_TB:.2f}" for k in range(n_traj)]

    fig, axes = plt.subplots(3, 3, figsize=(20, 16))
    axes_flat = axes.flatten()

    for k in range(n_traj):
        t_k = torch.tensor(all_t_norm[k].reshape(-1, 1), dtype=torch.float32)
        with torch.no_grad():
            pred_abs = state_nets[k](t_k).numpy()
        true_abs = trajectories[k][1].T

        for c in range(8):
            ax = axes_flat[c]
            ax.plot(t_data_np, true_abs[:, c], color=colors[k], lw=1.5,
                    label=f"True (RT≈{rt_approx[k]})")
            ax.plot(t_data_np, pred_abs[:, c], color=colors[k], lw=1.0, ls="--",
                    label=f"Pred (RT≈{rt_approx[k]})" if c == 0 else "")
            ax.set_title(comp_names[c], fontweight="bold", fontsize=11)
            ax.set_xlabel("t (years)")
            ax.set_ylabel("Count")
            ax.spines["top"].set_visible(False)
            ax.spines["right"].set_visible(False)

    handles, labels = axes_flat[0].get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    axes_flat[0].legend(by_label.values(), by_label.keys(), fontsize=6, loc="upper right",
                        ncol=2, framealpha=0.8)

    ax_res = axes_flat[8]
    all_residuals = []
    t_fine = torch.tensor(np.linspace(0, 1, 200).reshape(-1, 1), dtype=torch.float32)
    beta1_b = [torch.tensor(b1, dtype=torch.float32) for b1 in beta1_list]
    for k in range(n_traj):
        res = compute_ode_residual(state_nets[k], param_module, t_fine,
                                   beta1_b[k], torch.tensor(beta2_syn, dtype=torch.float32))
        all_residuals.append(res.detach().numpy().flatten())
    all_residuals = np.concatenate(all_residuals)
    cutoff = np.percentile(np.abs(all_residuals), 99)
    clipped = all_residuals[np.abs(all_residuals) <= cutoff]
    if clipped.size == 0:
        clipped = all_residuals
    all_residuals = clipped
    ax_res.hist(all_residuals, bins=80, color="#616161", edgecolor="white", alpha=0.8, density=True)
    ax_res.axvline(x=0, color="#C62828", lw=1.0, ls="--")
    ax_res.set_xlabel("ODE residual")
    ax_res.set_ylabel("Density")
    ax_res.set_title(f"ODE Residual Distribution\n(μ={np.mean(all_residuals):.2e}, σ={np.std(all_residuals):.2e})",
                     fontsize=10)
    ax_res.spines["top"].set_visible(False)
    ax_res.spines["right"].set_visible(False)

    fig.suptitle(f"4-Trajectory Full State Comparison — Run {run_id}", fontweight="bold", fontsize=14)
    fig.tight_layout()
    fig.savefig(str(OUT_SYN / f"trajectory_comparison_run{run_id}.pdf"), dpi=300)
    fig.savefig(str(OUT_SYN / f"trajectory_comparison_run{run_id}.png"), dpi=300)
    plt.close(fig)
    print(f"  Trajectory comparison saved → {OUT_SYN}")

# ============================================================
# 7. TRAINING WITH PARTIAL OBSERVATIONS + PARAMETER FREEZING
# ============================================================

def train_real(
    state_net,
    param_module,
    beta1_net,
    beta2_net,
    t_data,
    tb_raw_target,
    hiv_prev_raw_target,
    t_colloc,
    n_epochs,
    lr,
    w_data,
    w_ode,
    w_reg,
    label,
    y_min=None,
    y_scale=None,
    time_horizon=T_MAX,
    learnable_healthcare=HEALTHCARE_KEYS,
    train_beta1=True,
    train_beta2=True,
    healthcare_lr_factor=1.0,
):
    """Partially observed training with parameter-subset freezing.

    The data loss uses two observables via observables_torch():
    1. WHO estimated TB incidence:  (k*L + k_star*J2)/N * 100000
    2. UNAIDS all-age HIV prevalence:  (J1 + J2 + J3)/N * 100

    The ODE residual is imposed on all eight state variables.
    """
    set_healthcare_trainability(param_module, learnable_healthcare)

    if y_min is not None and y_scale is not None:
        set_ode_normalization(y_min, y_scale)
    else:
        ensure_synthetic_data(verbose=False)

    for parameter in beta1_net.parameters():
        parameter.requires_grad_(train_beta1)

    for parameter in beta2_net.parameters():
        parameter.requires_grad_(train_beta2)

    optimizer_groups = [
        {
            "params": [
                p for p in state_net.parameters()
                if p.requires_grad
            ],
            "lr": lr,
        }
    ]

    beta1_parameters = [
        p for p in beta1_net.parameters()
        if p.requires_grad
    ]
    if beta1_parameters:
        optimizer_groups.append({
            "params": beta1_parameters,
            "lr": lr,
        })

    beta2_parameters = [
        p for p in beta2_net.parameters()
        if p.requires_grad
    ]
    if beta2_parameters:
        optimizer_groups.append({
            "params": beta2_parameters,
            "lr": lr,
        })

    healthcare_parameters = [
        p for p in param_module.parameters()
        if p.requires_grad
    ]
    if healthcare_parameters:
        optimizer_groups.append({
            "params": healthcare_parameters,
            "lr": lr * healthcare_lr_factor,
        })

    optimizer = torch.optim.Adam(optimizer_groups)

    opt_params = [
        p for group in optimizer_groups for p in group["params"]
        if p.requires_grad
    ]

    loss_hist, param_hist = [], []

    for epoch in range(n_epochs):
        optimizer.zero_grad()

        x_abs = state_net(t_data)
        tb_observed, hiv_prev_model = observables_torch(x_abs)

        tb_scale = torch.clamp(tb_raw_target.max() - tb_raw_target.min(), min=1.0)
        hiv_scale = torch.clamp(hiv_prev_raw_target.max() - hiv_prev_raw_target.min(), min=1.0)
        loss_tb = nn.functional.mse_loss((tb_observed - tb_raw_target) / tb_scale,
                                         torch.zeros_like(tb_raw_target))
        loss_hiv = nn.functional.mse_loss((hiv_prev_model - hiv_prev_raw_target) / hiv_scale,
                                          torch.zeros_like(hiv_prev_raw_target))
        loss_data = loss_tb + loss_hiv

        residual = compute_ode_residual_both_nets(
            state_net, param_module, t_colloc, beta1_net, beta2_net,
            time_horizon=time_horizon,
        )
        loss_ode = torch.mean(residual ** 2)

        loss_rates = rate_regularization(beta1_net, beta2_net, t_colloc)
        loss_reg = 0.05 * loss_rates

        loss = w_data * loss_data + w_ode * loss_ode + w_reg * loss_reg
        loss.backward()

        grads = [p.grad for p in opt_params if p.grad is not None]
        if grads:
            torch.nn.utils.clip_grad_norm_(grads, 5.0)
        optimizer.step()

        with torch.no_grad():
            a0, a_max, omega0, omega_min, m = param_module.get_params()
            b1_sample = beta1_net(t_data).squeeze(-1)
            b2_sample = beta2_net(t_data).squeeze(-1)
            pd = {"a0": a0.item(), "a_max": a_max.item(), "omega0": omega0.item(),
                  "omega_min": omega_min.item(), "m": m.item(),
                  "beta1_0": b1_sample[0].item(), "beta1_end": b1_sample[-1].item(),
                  "beta2_0": b2_sample[0].item(), "beta2_end": b2_sample[-1].item()}

        loss_hist.append({"epoch": epoch, "loss_total": loss.item(),
                          "loss_data": loss_data.item(), "loss_ode": loss_ode.item()})
        param_hist.append(pd)

        if epoch % max(1, n_epochs // 5) == 0:
            print(f"  [{label}] ep {epoch:5d} | total={loss.item():.4e} "
                  f"data={loss_data.item():.4e} ode={loss_ode.item():.4e} "
                  f"b1_0={pd['beta1_0']:.3f} b1_e={pd['beta1_end']:.3f} "
                  f"b2_0={pd['beta2_0']:.3f}")

    return loss_hist, param_hist

# ============================================================
# 8. PARTIAL-OBSERVATION SYNTHETIC VALIDATION
# ============================================================

def make_partial_observation_synthetic_data(
    noise_fraction=0.0,
    seed=2026,
):
    """Generate 15 annual synthetic observations using only TB incidence
    and HIV prevalence, matching the real-data observation design.
    """
    rng = np.random.default_rng(seed)

    years = np.arange(2010, 2025)
    t_real = years - years[0]
    time_horizon = float(t_real[-1])

    x0 = make_seed(
        tb_prev_pct=0.50,
        hiv_prev_pct=10.0,
    )

    solution = solve_ivp(
        lambda t, x: rhs_full_np(
            t,
            x,
            beta1_syn,
            beta2_syn,
            **TRUE_VALS,
        ),
        (0.0, time_horizon),
        x0,
        t_eval=t_real.astype(float),
        method="LSODA",
        rtol=1e-9,
        atol=1e-11,
    )

    if not solution.success:
        raise RuntimeError(
            f"Synthetic ODE integration failed: {solution.message}"
        )

    states_true = solution.y.T
    tb_true, hiv_true = observables_numpy(states_true)

    if noise_fraction > 0:
        tb_observed = tb_true * (
            1.0
            + rng.normal(
                0.0,
                noise_fraction,
                size=tb_true.shape,
            )
        )
        hiv_observed = hiv_true * (
            1.0
            + rng.normal(
                0.0,
                noise_fraction,
                size=hiv_true.shape,
            )
        )
    else:
        tb_observed = tb_true.copy()
        hiv_observed = hiv_true.copy()

    tb_observed = np.maximum(tb_observed, 0.0)
    hiv_observed = np.clip(hiv_observed, 0.0, 100.0)

    return {
        "years": years,
        "t_norm": t_real / time_horizon,
        "time_horizon": time_horizon,
        "states_true": states_true,
        "tb_true": tb_true,
        "hiv_true": hiv_true,
        "tb_observed": tb_observed,
        "hiv_observed": hiv_observed,
    }


def run_partial_recovery_once(
    learnable_healthcare,
    init_values,
    seed,
    noise_fraction=0.0,
    collocation_points=300,
):
    """One observation-matched synthetic recovery run."""
    set_random_seed(seed)

    dataset = make_partial_observation_synthetic_data(
        noise_fraction=noise_fraction,
        seed=seed,
    )

    t_data = torch.tensor(
        dataset["t_norm"].reshape(-1, 1),
        dtype=torch.float32,
    )
    tb_target = torch.tensor(
        dataset["tb_observed"],
        dtype=torch.float32,
    )
    hiv_target = torch.tensor(
        dataset["hiv_observed"],
        dtype=torch.float32,
    )
    t_colloc = torch.tensor(
        np.linspace(0.0, 1.0, collocation_points).reshape(-1, 1),
        dtype=torch.float32,
    )

    y_min, y_scale = compute_country_norm(
        dataset["tb_observed"],
        dataset["hiv_observed"],
    )

    # Parameters not under examination are fixed at their true values.
    parameter_initialization = dict(TRUE_VALS)
    for name in learnable_healthcare:
        parameter_initialization[name] = init_values[name]

    state_net = StateNetwork(hidden=32, n_hidden=2)
    param_module = ParameterModule(parameter_initialization)

    beta1_net = Beta1Network(init_beta1=0.8 * beta1_syn, degree=3)
    beta2_net = Beta2Network(init_beta2=1.2 * beta2_syn, degree=2)

    phases = [
        ("PV1", 1000, 1e-3, 1.0, 0.00, 0.01),
        ("PV2", 2000, 5e-4, 1.0, 0.10, 0.02),
        ("PV3", 2500, 2e-4, 0.8, 0.50, 0.05),
        ("PV4", 2500, 1e-4, 0.5, 1.00, 0.10),
    ]

    for label, n_epochs, lr, w_data, w_ode, w_reg in phases:
        train_real(
            state_net,
            param_module,
            beta1_net,
            beta2_net,
            t_data,
            tb_target,
            hiv_target,
            t_colloc,
            n_epochs=n_epochs,
            lr=lr,
            w_data=w_data,
            w_ode=w_ode,
            w_reg=w_reg,
            label=label,
            y_min=y_min,
            y_scale=y_scale,
            time_horizon=dataset["time_horizon"],
            learnable_healthcare=learnable_healthcare,
        )

    with torch.no_grad():
        values = param_module.get_params()
        recovered = dict(zip(
            HEALTHCARE_KEYS,
            [float(v.item()) for v in values],
        ))

        predicted_states = state_net(t_data)
        tb_fit, hiv_fit = observables_torch(predicted_states)

    relative_errors = {
        name: (
            abs(recovered[name] - TRUE_VALS[name])
            / max(abs(TRUE_VALS[name]), 1e-12)
            * 100.0
        )
        for name in learnable_healthcare
    }

    return {
        "seed": int(seed),
        "noise_fraction": float(noise_fraction),
        "learnable_healthcare": list(learnable_healthcare),
        "initial_values": {
            name: float(init_values[name])
            for name in learnable_healthcare
        },
        "recovered_params": recovered,
        "relative_errors_pct": relative_errors,
        "tb_rmse": float(np.sqrt(np.mean(
            (tb_fit.detach().cpu().numpy() - dataset["tb_true"]) ** 2
        ))),
        "hiv_rmse": float(np.sqrt(np.mean(
            (hiv_fit.detach().cpu().numpy() - dataset["hiv_true"]) ** 2
        ))),
    }


PARTIAL_VALIDATION_STARTS = [
    {
        "a0": 0.30,
        "a_max": 0.90,
        "omega0": 0.0010,
        "omega_min": 3e-6,
        "m": 0.015,
    },
    {
        "a0": 0.90,
        "a_max": 2.20,
        "omega0": 0.0080,
        "omega_min": 3e-5,
        "m": 0.20,
    },
    {
        "a0": 1.30,
        "a_max": 3.50,
        "omega0": 0.0200,
        "omega_min": 1e-4,
        "m": 1.00,
    },
]

CANDIDATE_PARAMETER_SETS = [
    ("a0",),
    ("a0", "a_max"),
    ("a0", "a_max", "m"),
    ("a0", "a_max", "omega0", "omega_min", "m"),
]


def run_partial_observation_screen(
    noise_fraction=0.0,
):
    """Empirical practical-recovery screen under the real observation design.

    This is not a proof of structural identifiability.
    """
    results = []

    for parameter_set in CANDIDATE_PARAMETER_SETS:
        print("\n" + "=" * 70)
        print(
            "PARTIAL-OBSERVATION SCREEN:",
            ", ".join(parameter_set),
        )
        print("=" * 70)

        for index, start in enumerate(PARTIAL_VALIDATION_STARTS):
            result = run_partial_recovery_once(
                learnable_healthcare=parameter_set,
                init_values=start,
                seed=2000 + index,
                noise_fraction=noise_fraction,
            )
            results.append(result)

            print(
                f"start {index + 1}: "
                f"errors={result['relative_errors_pct']}"
            )

    payload = {
        "analysis": "practical recovery screen",
        "structural_identifiability_proved": False,
        "observation_design": (
            "15 annual TB-incidence and HIV-prevalence values"
        ),
        "noise_fraction": float(noise_fraction),
        "candidate_parameter_sets": [
            list(x) for x in CANDIDATE_PARAMETER_SETS
        ],
        "individual_runs": results,
    }

    output_path = OUT_SYN / "partial_observation_recovery_screen.json"
    output_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    print(f"\nSaved: {output_path}")
    return payload


# ============================================================
# 9. CONTROLLED IDENTIFIABILITY DIAGNOSTICS
# ============================================================

CONTROL_PHASES = [
    ("C1", 1000, 1e-3, 1.0, 0.00, 0.01),
    ("C2", 2000, 5e-4, 1.0, 0.10, 0.02),
    ("C3", 2500, 2e-4, 0.8, 0.50, 0.05),
    ("C4", 2500, 1e-4, 0.5, 1.00, 0.10),
]


def _control_inputs():
    dataset = make_partial_observation_synthetic_data(
        noise_fraction=0.0,
        seed=2026,
    )

    t_data = torch.tensor(
        dataset["t_norm"].reshape(-1, 1),
        dtype=torch.float32,
    )
    tb_target = torch.tensor(
        dataset["tb_observed"],
        dtype=torch.float32,
    )
    hiv_target = torch.tensor(
        dataset["hiv_observed"],
        dtype=torch.float32,
    )
    t_colloc = torch.tensor(
        np.linspace(0.0, 1.0, 300).reshape(-1, 1),
        dtype=torch.float32,
    )

    y_min_control, y_scale_control = compute_country_norm(
        dataset["tb_observed"],
        dataset["hiv_observed"],
    )

    return (
        dataset,
        t_data,
        tb_target,
        hiv_target,
        t_colloc,
        y_min_control,
        y_scale_control,
    )


def _observation_errors(state_net, t_data, dataset):
    with torch.no_grad():
        states = state_net(t_data)
        tb_fit, hiv_fit = observables_torch(states)

    tb_fit = tb_fit.detach().cpu().numpy()
    hiv_fit = hiv_fit.detach().cpu().numpy()

    return {
        "tb_rmse": float(np.sqrt(np.mean(
            (tb_fit - dataset["tb_true"]) ** 2
        ))),
        "hiv_rmse": float(np.sqrt(np.mean(
            (hiv_fit - dataset["hiv_true"]) ** 2
        ))),
    }


def run_beta_only_control_once(
    beta1_factor,
    beta2_factor,
    start_index,
):
    """Control A: healthcare fixed at TRUE_VALS, recover beta1, beta2 only."""
    set_random_seed(3100)

    (
        dataset,
        t_data,
        tb_target,
        hiv_target,
        t_colloc,
        y_min_control,
        y_scale_control,
    ) = _control_inputs()

    state_net = StateNetwork(hidden=32, n_hidden=2)
    param_module = ParameterModule(dict(TRUE_VALS))

    beta1_net = Beta1Network(
        init_beta1=beta1_factor * beta1_syn,
        upper=5.0,
        degree=3,
    )
    beta2_net = Beta2Network(
        init_beta2=beta2_factor * beta2_syn,
        upper=0.5,
        degree=2,
    )

    for label, epochs, lr, wd, wo, wr in CONTROL_PHASES:
        train_real(
            state_net,
            param_module,
            beta1_net,
            beta2_net,
            t_data,
            tb_target,
            hiv_target,
            t_colloc,
            n_epochs=epochs,
            lr=lr,
            w_data=wd,
            w_ode=wo,
            w_reg=wr,
            label=f"BETA-{start_index}-{label}",
            y_min=y_min_control,
            y_scale=y_scale_control,
            time_horizon=dataset["time_horizon"],
            learnable_healthcare=(),
            train_beta1=True,
            train_beta2=True,
        )

    t_dense = torch.tensor(
        np.linspace(0.0, 1.0, 201).reshape(-1, 1),
        dtype=torch.float32,
    )

    with torch.no_grad():
        beta1_est = beta1_net(t_dense).squeeze(-1).cpu().numpy()
        beta2_est = beta2_net(t_dense).squeeze(-1).cpu().numpy()

    result = {
        "start_index": int(start_index),
        "initial_beta1": float(beta1_factor * beta1_syn),
        "initial_beta2": float(beta2_factor * beta2_syn),
        "beta1_true": float(beta1_syn),
        "beta2_true": float(beta2_syn),
        "beta1_relative_rmse_pct": float(
            np.sqrt(np.mean((beta1_est - beta1_syn) ** 2))
            / beta1_syn * 100.0
        ),
        "beta2_relative_rmse_pct": float(
            np.sqrt(np.mean((beta2_est - beta2_syn) ** 2))
            / beta2_syn * 100.0
        ),
        "beta1_mean": float(beta1_est.mean()),
        "beta2_mean": float(beta2_est.mean()),
        "beta1_range": [
            float(beta1_est.min()),
            float(beta1_est.max()),
        ],
        "beta2_range": [
            float(beta2_est.min()),
            float(beta2_est.max()),
        ],
    }

    result.update(
        _observation_errors(state_net, t_data, dataset)
    )
    return result


def run_oracle_beta_healthcare_once(
    initial_values,
    start_index,
):
    """Control B: beta1, beta2 fixed at true values, recover all healthcare params."""
    set_random_seed(3100)

    (
        dataset,
        t_data,
        tb_target,
        hiv_target,
        t_colloc,
        y_min_control,
        y_scale_control,
    ) = _control_inputs()

    state_net = StateNetwork(hidden=32, n_hidden=2)
    param_module = ParameterModule(dict(initial_values))

    beta1_net = Beta1Network(
        init_beta1=beta1_syn,
        upper=5.0,
        degree=3,
    )
    beta2_net = Beta2Network(
        init_beta2=beta2_syn,
        upper=0.5,
        degree=2,
    )

    for label, epochs, lr, wd, wo, wr in CONTROL_PHASES:
        train_real(
            state_net,
            param_module,
            beta1_net,
            beta2_net,
            t_data,
            tb_target,
            hiv_target,
            t_colloc,
            n_epochs=epochs,
            lr=lr,
            w_data=wd,
            w_ode=wo,
            w_reg=wr,
            label=f"ORACLE-{start_index}-{label}",
            y_min=y_min_control,
            y_scale=y_scale_control,
            time_horizon=dataset["time_horizon"],
            learnable_healthcare=HEALTHCARE_KEYS,
            train_beta1=False,
            train_beta2=False,
            healthcare_lr_factor=1.0,
        )

    with torch.no_grad():
        values = param_module.get_params()

    recovered = dict(zip(
        HEALTHCARE_KEYS,
        [float(value.item()) for value in values],
    ))

    result = {
        "start_index": int(start_index),
        "initial_values": {
            key: float(initial_values[key])
            for key in HEALTHCARE_KEYS
        },
        "recovered_params": recovered,
        "relative_errors_pct": {
            key: float(
                abs(recovered[key] - TRUE_VALS[key])
                / abs(TRUE_VALS[key]) * 100.0
            )
            for key in HEALTHCARE_KEYS
        },
        "log10_errors": {
            key: float(abs(np.log10(
                recovered[key] / TRUE_VALS[key]
            )))
            for key in ("omega0", "omega_min", "m")
        },
    }

    result.update(
        _observation_errors(state_net, t_data, dataset)
    )
    return result


def run_identifiability_controls():
    beta_starts = [
        (0.50, 0.50),
        (0.80, 1.20),
        (1.50, 1.80),
    ]

    print("\n" + "=" * 70)
    print("CONTROL A: healthcare fixed at TRUE, recover beta1, beta2")
    print("=" * 70)

    beta_results = []
    for index, (factor1, factor2) in enumerate(
        beta_starts,
        start=1,
    ):
        r = run_beta_only_control_once(
            factor1,
            factor2,
            index,
        )
        beta_results.append(r)
        print(
            f"  start {index}: "
            f"beta1_rmse={r['beta1_relative_rmse_pct']:.2f}%  "
            f"beta2_rmse={r['beta2_relative_rmse_pct']:.2f}%  "
            f"tb_rmse={r['tb_rmse']:.2f}  hiv_rmse={r['hiv_rmse']:.4f}"
        )

    print("\n" + "=" * 70)
    print("CONTROL B: beta fixed at TRUE, recover all healthcare")
    print("=" * 70)

    healthcare_results = []
    for index, initial_values in enumerate(
        PARTIAL_VALIDATION_STARTS,
        start=1,
    ):
        r = run_oracle_beta_healthcare_once(
            initial_values,
            index,
        )
        healthcare_results.append(r)
        print(
            f"  start {index}: "
            f"errors={r['relative_errors_pct']}  "
            f"log10_errors={r['log10_errors']}"
        )

    payload = {
        "analysis": "controlled practical-recovery diagnostics",
        "structural_identifiability_proved": False,
        "noise_fraction": 0.0,
        "same_network_seed_across_starts": True,
        "beta_only_recovery": beta_results,
        "oracle_beta_healthcare_recovery": healthcare_results,
    }

    output_path = (
        OUT_SYN / "identifiability_controls.json"
    )
    output_path.write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )

    print(f"\nSaved: {output_path}")
    return payload


# ============================================================
# 11. DIRECT ODE IDENTIFIABILITY DIAGNOSTICS
# ============================================================
# Distinguish between (a) PINN optimisation failure and (b) genuine
# information-theoretic non-identifiability under two annual observables.
# If direct ODE fitting (no state network, no AD) also cannot recover the
# five healthcare parameters from the same synthetic observations, the
# observation design itself is insufficient.  If ODE fitting succeeds
# where the PINN fails, the problem is the PINN optimisation, not the data.

ODE_DIAG_OUT = OUT_SYN


def _ode_predict_observables(t_eval, a0, a_max, omega0, omega_min, m,
                              beta1, beta2, x0):
    """Forward-solve ODE; return (tb, hiv, states) or (None, None, msg)."""
    sol = solve_ivp(
        lambda t, x: rhs_full_np(t, x, beta1, beta2, a0, a_max,
                                  omega0, omega_min, m),
        (0.0, float(t_eval[-1])),
        np.asarray(x0, dtype=float),
        t_eval=np.asarray(t_eval, dtype=float),
        method="LSODA",
        rtol=1e-8, atol=1e-10, max_step=0.5,
    )
    if not sol.success:
        return None, None, sol.message
    states = sol.y.T
    tb, hiv = observables_numpy(states)
    return tb, hiv, states


# ── Bound constants (mirror ParameterModule) ──────────────────────
_A0_LO, _A0_HI = 0.01, 3.0
_AMAX_HI = 5.0
_OMEGA0_LO, _OMEGA0_HI = 1e-5, 0.1
_OMEGAMIN_LO = 1e-8
_M_LO, _M_HI = 0.001, 30.0
_EPS_A = 1e-3
_EPS_OMEGA = 1e-8


def _healthcare_to_theta(a0, a_max, omega0, omega_min, m):
    """Map physical params → unconstrained ℝ⁵ (matching ParameterModule).

    Uses the same logit / fraction-of-gap transforms as the PINN's
    ParameterModule so that L-BFGS-B bounds inherit the identical
    biological hard constraints.
    """
    # a0  ── logit within [A0_LO, A0_HI]
    a0_c = float(np.clip(a0, _A0_LO + 1e-8, _A0_HI - 1e-8))
    raw_a0 = float(np.log((a0_c - _A0_LO) / (_A0_HI - a0_c)))

    # a_max  ── fraction of remaining gap above a0, then logit
    gap_amax = max(_AMAX_HI - a0_c - _EPS_A, 1e-12)
    amax_c = float(np.clip(a_max, a0_c + _EPS_A + 1e-10,
                           _AMAX_HI - 1e-10))
    frac_amax = float(np.clip((amax_c - a0_c - _EPS_A) / gap_amax,
                              1e-6, 1.0 - 1e-6))
    raw_amax = float(np.log(frac_amax / (1.0 - frac_amax)))

    # omega0  ── logit within [OMEGA0_LO, OMEGA0_HI]
    om0_c = float(np.clip(omega0, _OMEGA0_LO + 1e-10,
                          _OMEGA0_HI - 1e-10))
    raw_om0 = float(np.log((om0_c - _OMEGA0_LO)
                           / (_OMEGA0_HI - om0_c)))

    # omega_min  ── fraction of gap [OMEGAMIN_LO, omega0 - EPS_OMEGA], then logit
    ommin_upper = om0_c - _EPS_OMEGA
    if ommin_upper <= _OMEGAMIN_LO + 1e-12:
        ommin_upper = _OMEGAMIN_LO + 1e-8
    ommin_c = float(np.clip(omega_min, _OMEGAMIN_LO + 1e-12,
                            ommin_upper - 1e-12))
    frac_ommin = float(np.clip(
        (ommin_c - _OMEGAMIN_LO) / (ommin_upper - _OMEGAMIN_LO),
        1e-6, 1.0 - 1e-6))
    raw_ommin = float(np.log(frac_ommin / (1.0 - frac_ommin)))

    # m  ── logit within [M_LO, M_HI]
    m_c = float(np.clip(m, _M_LO + 1e-8, _M_HI - 1e-8))
    raw_m = float(np.log((m_c - _M_LO) / (_M_HI - m_c)))

    return np.array([raw_a0, raw_amax, raw_om0, raw_ommin, raw_m])


def _theta_to_healthcare(theta):
    """Inverse of _healthcare_to_theta — matches ParameterModule.get_params()."""
    raw_a0, raw_amax, raw_om0, raw_ommin, raw_m = [float(t) for t in theta]

    a0 = _A0_LO + (_A0_HI - _A0_LO) * float(expit(raw_a0))

    available_gap = max(_AMAX_HI - a0 - _EPS_A, 1e-12)
    a_max = a0 + _EPS_A + available_gap * float(expit(raw_amax))

    omega0 = _OMEGA0_LO + (_OMEGA0_HI - _OMEGA0_LO) * float(expit(raw_om0))

    omega_min_upper = max(omega0 - _EPS_OMEGA, _OMEGAMIN_LO + 1e-10)
    omega_min = (_OMEGAMIN_LO
                 + (omega_min_upper - _OMEGAMIN_LO) * float(expit(raw_ommin)))

    m = _M_LO + (_M_HI - _M_LO) * float(expit(raw_m))

    return a0, a_max, omega0, omega_min, m


def _ode_healthcare_objective(theta, t_eval, tb_true, hiv_true,
                               beta1, beta2, x0):
    """MSE for 5 healthcare params (beta, x0 fixed at truth)."""
    a0, a_max, omega0, omega_min, m = _theta_to_healthcare(theta)
    tb_pred, hiv_pred, info = _ode_predict_observables(
        t_eval, a0, a_max, omega0, omega_min, m, beta1, beta2, x0)
    if tb_pred is None:
        return 1e10
    tb_scale = max(float(np.ptp(tb_true)), 1.0)
    hiv_scale = max(float(np.ptp(hiv_true)), 1.0)
    return float(np.mean(((tb_pred - tb_true) / tb_scale) ** 2)
                 + np.mean(((hiv_pred - hiv_true) / hiv_scale) ** 2))


def _ode_healthcare_x0_objective(theta, t_eval, tb_true, hiv_true,
                                  beta1, beta2):
    """MSE for 5 healthcare params + 2 initial-state params (beta fixed)."""
    a0, a_max, omega0, omega_min, m = _theta_to_healthcare(theta[:5])
    tb_prev = 10.0 ** float(theta[5])
    hiv_prev = 10.0 ** float(theta[6])
    x0 = make_seed(float(tb_prev), float(hiv_prev))
    tb_pred, hiv_pred, info = _ode_predict_observables(
        t_eval, a0, a_max, omega0, omega_min, m, beta1, beta2, x0)
    if tb_pred is None:
        return 1e10
    tb_scale = max(float(np.ptp(tb_true)), 1.0)
    hiv_scale = max(float(np.ptp(hiv_true)), 1.0)
    return float(np.mean(((tb_pred - tb_true) / tb_scale) ** 2)
                 + np.mean(((hiv_pred - hiv_true) / hiv_scale) ** 2))


def _ode_beta_objective(theta, t_eval, tb_true, hiv_true, x0):
    """MSE for β₁,β₂ only — healthcare params and x0 fixed at TRUE_VALS."""
    beta1 = 10.0 ** float(theta[0])
    beta2 = 10.0 ** float(theta[1])
    tb_pred, hiv_pred, info = _ode_predict_observables(
        t_eval, TRUE_VALS["a0"], TRUE_VALS["a_max"],
        TRUE_VALS["omega0"], TRUE_VALS["omega_min"], TRUE_VALS["m"],
        beta1, beta2, x0)
    if tb_pred is None:
        return 1e10
    tb_scale = max(float(np.ptp(tb_true)), 1.0)
    hiv_scale = max(float(np.ptp(hiv_true)), 1.0)
    return float(np.mean(((tb_pred - tb_true) / tb_scale) ** 2)
                 + np.mean(((hiv_pred - hiv_true) / hiv_scale) ** 2))


def _get_ode_diag_data():
    dataset = make_partial_observation_synthetic_data(
        noise_fraction=0.0, seed=2026)
    t_eval = (dataset["years"] - dataset["years"][0]).astype(float)
    tb_true = dataset["tb_true"]
    hiv_true = dataset["hiv_true"]
    x0_true = make_seed(tb_prev_pct=0.50, hiv_prev_pct=10.0)
    return dataset, t_eval, tb_true, hiv_true, x0_true


def run_direct_ode_recovery_known_beta_x0():
    """Experiment 1: ODE recovery — beta and x0 fixed at TRUE_VALS."""
    print("\n" + "=" * 70)
    print("ODE DIAGNOSTIC 1: known beta + known x0, recover healthcare")
    print("=" * 70)

    _, t_eval, tb_true, hiv_true, x0_true = _get_ode_diag_data()

    starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010,
         "omega_min": 3e-6, "m": 0.015},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080,
         "omega_min": 3e-5, "m": 0.20},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200,
         "omega_min": 1e-4, "m": 1.00},
    ]

    results = []
    for idx, init in enumerate(starts, start=1):
        theta0 = _healthcare_to_theta(**init)
        # logit-space: each raw parameter in [-12, 12] — wide enough
        # that the sigmoid saturates before hitting the bound
        bounds = [(-12.0, 12.0)] * 5

        res = minimize(
            _ode_healthcare_objective,
            theta0,
            args=(t_eval, tb_true, hiv_true, beta1_syn, beta2_syn, x0_true),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 5000, "ftol": 1e-12, "gtol": 1e-8},
        )

        a0_r, a_max_r, omega0_r, omega_min_r, m_r = _theta_to_healthcare(res.x)
        recovered = dict(zip(HEALTHCARE_KEYS, [a0_r, a_max_r, omega0_r,
                                                omega_min_r, m_r]))
        errors = {k: abs(recovered[k] - TRUE_VALS[k])
                       / max(abs(TRUE_VALS[k]), 1e-12) * 100
                  for k in HEALTHCARE_KEYS}

        tb_pred, hiv_pred, _ = _ode_predict_observables(
            t_eval, a0_r, a_max_r, omega0_r, omega_min_r, m_r,
            beta1_syn, beta2_syn, x0_true)

        results.append({
            "start_index": idx,
            "initial_values": init,
            "recovered_params": {k: float(v) for k, v in recovered.items()},
            "relative_errors_pct": {k: float(v) for k, v in errors.items()},
            "objective": float(res.fun),
            "success": bool(res.success),
            "message": str(res.message),
            "tb_rmse": float(np.sqrt(np.mean((tb_pred - tb_true) ** 2))),
            "hiv_rmse": float(np.sqrt(np.mean((hiv_pred - hiv_true) ** 2))),
            "n_iter": int(res.nit),
            "n_fev": int(res.nfev),
        })

        print(f"  start {idx}: obj={res.fun:.2e}  nfev={res.nfev}  "
              f"success={res.success}")
        print(f"    errors: {{{', '.join(f'{k}: {v:.1f}%' for k, v in errors.items())}}}")

    return results


def run_direct_ode_recovery_known_beta_two_parameter_seeded_x0():
    """Experiment 2: beta fixed; two-parameter seeded initial condition varied."""
    print("\n" + "=" * 70)
    print("ODE DIAGNOSTIC 2: beta fixed; two-parameter seeded x0 varied")
    print("=" * 70)

    _, t_eval, tb_true, hiv_true, _x0_true = _get_ode_diag_data()

    true_tb_prev = 0.50
    true_hiv_prev = 10.0

    starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010, "omega_min": 3e-6,
         "m": 0.015, "tb_prev_pct": 0.20, "hiv_prev_pct": 5.0},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080, "omega_min": 3e-5,
         "m": 0.20, "tb_prev_pct": 0.80, "hiv_prev_pct": 15.0},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200, "omega_min": 1e-4,
         "m": 1.00, "tb_prev_pct": 1.50, "hiv_prev_pct": 20.0},
    ]

    results = []
    for idx, init in enumerate(starts, start=1):
        theta_hc = _healthcare_to_theta(
            init["a0"], init["a_max"], init["omega0"],
            init["omega_min"], init["m"])
        theta_x0 = np.array([np.log10(init["tb_prev_pct"]),
                             np.log10(init["hiv_prev_pct"])])
        theta0 = np.concatenate([theta_hc, theta_x0])

        # healthcare (5 × logit) + 2 × log10 prevalence seeds
        bounds = [(-12.0, 12.0)] * 5 + [
            (-2.0, 2.0),     # log10(tb_prev_pct)  [0.01, 100]
            (-1.0, 1.7),     # log10(hiv_prev_pct) [0.1, 50]
        ]

        res = minimize(
            _ode_healthcare_x0_objective,
            theta0,
            args=(t_eval, tb_true, hiv_true, beta1_syn, beta2_syn),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 5000, "ftol": 1e-12, "gtol": 1e-8},
        )

        a0_r, a_max_r, omega0_r, omega_min_r, m_r = \
            _theta_to_healthcare(res.x[:5])
        tb_prev_r = 10.0 ** float(res.x[5])
        hiv_prev_r = 10.0 ** float(res.x[6])

        recovered = dict(zip(HEALTHCARE_KEYS, [a0_r, a_max_r, omega0_r,
                                                omega_min_r, m_r]))
        errors = {k: abs(recovered[k] - TRUE_VALS[k])
                       / max(abs(TRUE_VALS[k]), 1e-12) * 100
                  for k in HEALTHCARE_KEYS}

        x0_r = make_seed(float(tb_prev_r), float(hiv_prev_r))
        tb_pred, hiv_pred, _ = _ode_predict_observables(
            t_eval, a0_r, a_max_r, omega0_r, omega_min_r, m_r,
            beta1_syn, beta2_syn, x0_r)

        results.append({
            "start_index": idx,
            "recovered_params": {k: float(v) for k, v in recovered.items()},
            "relative_errors_pct": {k: float(v) for k, v in errors.items()},
            "recovered_tb_prev_pct": float(tb_prev_r),
            "recovered_hiv_prev_pct": float(hiv_prev_r),
            "true_tb_prev_pct": true_tb_prev,
            "true_hiv_prev_pct": true_hiv_prev,
            "objective": float(res.fun),
            "success": bool(res.success),
            "tb_rmse": float(np.sqrt(np.mean((tb_pred - tb_true) ** 2))),
            "hiv_rmse": float(np.sqrt(np.mean((hiv_pred - hiv_true) ** 2))),
            "n_iter": int(res.nit),
            "n_fev": int(res.nfev),
        })

        print(f"  start {idx}: obj={res.fun:.2e}  nfev={res.nfev}  "
              f"success={res.success}")
        print(f"    errors: {{{', '.join(f'{k}: {v:.1f}%' for k, v in errors.items())}}}")
        print(f"    x0: tb_prev={tb_prev_r:.3f} (true={true_tb_prev})  "
              f"hiv_prev={hiv_prev_r:.2f} (true={true_hiv_prev})")

    return results


def run_direct_ode_recovery_known_healthcare_x0():
    """Experiment 3: ODE recovery — healthcare + x0 fixed, recover β₁,β₂ only.

    Mirrors Control A (§9) but replaces the PINN with direct ODE integration
    so we can distinguish PINN-optimisation failure from information-theoretic
    limits of the observation design.
    """
    print("\n" + "=" * 70)
    print("ODE DIAGNOSTIC 3: known healthcare + known x0, recover beta1, beta2")
    print("=" * 70)

    _, t_eval, tb_true, hiv_true, x0_true = _get_ode_diag_data()

    # Three starting points spanning the Control A initialisation range
    starts = [
        {"beta1": beta1_syn * 0.50, "beta2": beta2_syn * 0.50},
        {"beta1": beta1_syn * 0.80, "beta2": beta2_syn * 1.20},
        {"beta1": beta1_syn * 1.50, "beta2": beta2_syn * 1.50},
    ]

    results = []
    for idx, init in enumerate(starts, start=1):
        theta0 = np.array([np.log10(init["beta1"]),
                           np.log10(init["beta2"])])
        # β₁ ∈ [0.1, 20], β₂ ∈ [0.01, 5]  (wide log10 bounds)
        bounds = [(-1.0, np.log10(20.0)),
                  (-2.0, np.log10(5.0))]

        res = minimize(
            _ode_beta_objective,
            theta0,
            args=(t_eval, tb_true, hiv_true, x0_true),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 5000, "ftol": 1e-12, "gtol": 1e-8},
        )

        beta1_r = 10.0 ** float(res.x[0])
        beta2_r = 10.0 ** float(res.x[1])
        errors = {
            "beta1": abs(beta1_r - beta1_syn) / beta1_syn * 100,
            "beta2": abs(beta2_r - beta2_syn) / beta2_syn * 100,
        }

        tb_pred, hiv_pred, _ = _ode_predict_observables(
            t_eval, TRUE_VALS["a0"], TRUE_VALS["a_max"],
            TRUE_VALS["omega0"], TRUE_VALS["omega_min"], TRUE_VALS["m"],
            beta1_r, beta2_r, x0_true)

        results.append({
            "start_index": idx,
            "initial_beta1": float(init["beta1"]),
            "initial_beta2": float(init["beta2"]),
            "beta1_true": float(beta1_syn),
            "beta2_true": float(beta2_syn),
            "recovered_beta1": float(beta1_r),
            "recovered_beta2": float(beta2_r),
            "relative_errors_pct": {k: float(v) for k, v in errors.items()},
            "objective": float(res.fun),
            "success": bool(res.success),
            "message": str(res.message),
            "tb_rmse": float(np.sqrt(np.mean((tb_pred - tb_true) ** 2))),
            "hiv_rmse": float(np.sqrt(np.mean((hiv_pred - hiv_true) ** 2))),
            "n_iter": int(res.nit),
            "n_fev": int(res.nfev),
        })

        print(f"  start {idx}: obj={res.fun:.2e}  nfev={res.nfev}  "
              f"success={res.success}")
        print(f"    beta1={beta1_r:.4f} (true={beta1_syn:.4f}, "
              f"err={errors['beta1']:.1f}%)  "
              f"beta2={beta2_r:.4f} (true={beta2_syn:.4f}, "
              f"err={errors['beta2']:.1f}%)")

    return results


# ── Ideal treatment-flow observable ──────────────────────────────
# Annual per-100k treatment initiation rate:
#   10^5 × ∫_y^{y+1} τ_I(t) dt / ∫_y^{y+1} N(t) dt
# where τ_I(t) = a(B(t))·I(t) / (1 + ω(B(t))·I(t)).
# This is evaluated at fine ODE resolution then integrated to annual
# idealized annual active-TB treatment-initiation rate


def _compute_treatment_flow_integral(t_fine, states, a0, a_max,
                                      omega0, omega_min, m):
    """idealized annual active-TB treatment-initiation rate

    Returns array of shape (n_years,) where each entry is:
      1e5 * ∫_y^{y+1} a·I/(1+ω·I) dt / ∫_y^{y+1} N dt
    """
    I = states[:, 2]
    N_total = np.maximum(states.sum(axis=1), 1e-12)
    B = (states[:, 2] + states[:, 6]) / N_total
    a_vals, omega_vals = response_np(B, a0, a_max, omega0, omega_min, m)
    treat_flow = a_vals * I / (1.0 + omega_vals * I)  # absolute rate

    n_years = int(np.floor(float(t_fine[-1])))
    annual_rates = []

    for year in range(n_years):
        left = float(year)
        right = left + 1.0

        interior = (
            (t_fine > left)
            & (t_fine < right)
        )

        t_year = np.concatenate((
            [left],
            t_fine[interior],
            [right],
        ))

        treatment_year = np.interp(
            t_year,
            t_fine,
            treat_flow,
        )

        population_year = np.interp(
            t_year,
            t_fine,
            N_total,
        )

        annual_treated = np.trapezoid(
            treatment_year,
            x=t_year,
        )

        population_time = np.trapezoid(
            population_year,
            x=t_year,
        )

        annual_rates.append(
            1e5
            * annual_treated
            / max(population_time, 1e-12)
        )

    return np.asarray(annual_rates, dtype=float)


def _get_ode_diag_data_3obs():
    """Generate 3-observable synthetic data: TB incidence, HIV prevalence,
    and treatment-flow integral, 2012–2023 window (12 annual points)."""
    dataset, t_eval, tb_true, hiv_true, x0_true = _get_ode_diag_data()

    # Generate fine-resolution solution for treatment-flow integration
    t_fine = np.linspace(0.0, T_MAX, int(T_MAX * 100) + 1)
    sol = solve_ivp(
        lambda t, x: rhs_full_np(t, x, beta1_syn, beta2_syn, **TRUE_VALS),
        (0.0, T_MAX),
        np.asarray(x0_true, dtype=float),
        t_eval=t_fine,
        method="LSODA", rtol=1e-8, atol=1e-10, max_step=0.5,
    )
    if not sol.success:
        raise RuntimeError(f"Fine-grid integration failed: {sol.message}")
    states_fine = sol.y.T

    tx_flow_all = _compute_treatment_flow_integral(
        t_fine, states_fine, **TRUE_VALS)

    # Restrict to 2012–2023: t ∈ [2, 14), indices 2..13
    idx_start, idx_end = 2, 14  # 12 annual points
    t_window = t_eval[idx_start:idx_end]
    tb_window = tb_true[idx_start:idx_end]
    hiv_window = hiv_true[idx_start:idx_end]
    tx_window = tx_flow_all[idx_start:idx_end]

    return (t_window, tb_window, hiv_window, tx_window,
            x0_true, t_fine, states_fine)


def _ode_predict_3obs(t_eval_annual, a0, a_max, omega0, omega_min, m,
                       beta1, beta2, x0):
    """Forward-solve ODE at fine resolution; return (tb, hiv, tx_flow) or Nones.

    t_eval_annual: annual sample times for TB/HIV.
    Integration is always done on [0, T_MAX] for accurate tx-flow quadrature
    across all years.
    """
    t_fine = np.linspace(0.0, T_MAX, int(T_MAX * 100) + 1)
    sol = solve_ivp(
        lambda t, x: rhs_full_np(t, x, beta1, beta2, a0, a_max,
                                  omega0, omega_min, m),
        (0.0, T_MAX),
        np.asarray(x0, dtype=float),
        t_eval=t_fine,
        method="LSODA", rtol=1e-8, atol=1e-10, max_step=0.5,
    )
    if not sol.success:
        return None, None, None, sol.message
    states_fine = sol.y.T
    tb_all, hiv_all = observables_numpy(states_fine)
    # TB / HIV at the requested annual points
    n_annual = len(t_eval_annual)
    tb = np.array([tb_all[int(np.argmin(np.abs(t_fine - float(t_eval_annual[i]))))]
                    for i in range(n_annual)])
    hiv = np.array([hiv_all[int(np.argmin(np.abs(t_fine - float(t_eval_annual[i]))))]
                     for i in range(n_annual)])
    # All annual treatment-flow integrals (years 0..13)
    tx_flow_all = _compute_treatment_flow_integral(
        t_fine, states_fine, a0, a_max, omega0, omega_min, m)
    # Return integrals matching t_eval_annual index range
    idx0 = int(np.floor(float(t_eval_annual[0])))
    idx1 = idx0 + n_annual
    tx_flow = tx_flow_all[idx0:idx1]
    return tb, hiv, tx_flow, states_fine


def _ode_healthcare_3obs_objective(theta, t_eval, tb_true, hiv_true,
                                    tx_true, beta1, beta2, x0):
    """MSE for 5 healthcare params with 3 observables (TB+HIV+tx_flow)."""
    a0, a_max, omega0, omega_min, m = _theta_to_healthcare(theta)
    tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
        t_eval, a0, a_max, omega0, omega_min, m, beta1, beta2, x0)
    if tb_pred is None:
        return 1e10
    n = min(len(tx_pred), len(tx_true))
    tx_pred_a = np.asarray(tx_pred[:n], dtype=float)
    tx_true_a = np.asarray(tx_true[:n], dtype=float)
    tb_scale = max(float(np.ptp(tb_true[:n])), 1.0)
    hiv_scale = max(float(np.ptp(hiv_true[:n])), 1.0)
    tx_scale = max(float(np.ptp(tx_true_a)), 1.0)
    return float(
        np.mean(((tb_pred[:n] - tb_true[:n]) / tb_scale) ** 2)
        + np.mean(((hiv_pred[:n] - hiv_true[:n]) / hiv_scale) ** 2)
        + np.mean(((tx_pred_a - tx_true_a) / tx_scale) ** 2)
    )


def _ode_healthcare_x0_3obs_objective(theta, t_eval, tb_true, hiv_true,
                                       tx_true, beta1, beta2):
    """MSE for 5 healthcare + 2 x0 params, 3 observables."""
    a0, a_max, omega0, omega_min, m = _theta_to_healthcare(theta[:5])
    tb_prev = 10.0 ** float(theta[5])
    hiv_prev = 10.0 ** float(theta[6])
    x0 = make_seed(float(tb_prev), float(hiv_prev))
    tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
        t_eval, a0, a_max, omega0, omega_min, m, beta1, beta2, x0)
    if tb_pred is None:
        return 1e10
    n = min(len(tx_pred), len(tx_true))
    tx_pred_a = np.asarray(tx_pred[:n], dtype=float)
    tx_true_a = np.asarray(tx_true[:n], dtype=float)
    tb_scale = max(float(np.ptp(tb_true[:n])), 1.0)
    hiv_scale = max(float(np.ptp(hiv_true[:n])), 1.0)
    tx_scale = max(float(np.ptp(tx_true_a)), 1.0)
    return float(
        np.mean(((tb_pred[:n] - tb_true[:n]) / tb_scale) ** 2)
        + np.mean(((hiv_pred[:n] - hiv_true[:n]) / hiv_scale) ** 2)
        + np.mean(((tx_pred_a - tx_true_a) / tx_scale) ** 2)
    )


def run_ideal_treatment_flow_known_beta_x0():
    """Expt A: known β + known full x₀, 3-obs, recover 5 healthcare params."""
    print("\n" + "=" * 70)
    print("IDEAL TX-FLOW A: known β, known full x₀, 3 observables (12 years)")
    print("=" * 70)

    (t_eval, tb_true, hiv_true, tx_true,
     x0_true, _, _) = _get_ode_diag_data_3obs()

    starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010,
         "omega_min": 3e-6, "m": 0.015},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080,
         "omega_min": 3e-5, "m": 0.20},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200,
         "omega_min": 1e-4, "m": 1.00},
    ]

    results = []
    for idx, init in enumerate(starts, start=1):
        theta0 = _healthcare_to_theta(**init)
        bounds = [(-12.0, 12.0)] * 5

        res = minimize(
            _ode_healthcare_3obs_objective,
            theta0,
            args=(t_eval, tb_true, hiv_true, tx_true,
                  beta1_syn, beta2_syn, x0_true),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 5000, "ftol": 1e-12, "gtol": 1e-8},
        )

        a0_r, a_max_r, omega0_r, omega_min_r, m_r = _theta_to_healthcare(res.x)
        recovered = dict(zip(HEALTHCARE_KEYS, [a0_r, a_max_r, omega0_r,
                                                omega_min_r, m_r]))
        errors = {k: abs(recovered[k] - TRUE_VALS[k])
                       / max(abs(TRUE_VALS[k]), 1e-12) * 100
                  for k in HEALTHCARE_KEYS}

        tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
            t_eval, a0_r, a_max_r, omega0_r, omega_min_r, m_r,
            beta1_syn, beta2_syn, x0_true)
        if tb_pred is None:
            tx_pred = np.zeros_like(tx_true)
            tb_pred = np.zeros_like(tb_true)
            hiv_pred = np.zeros_like(hiv_true)

        results.append({
            "start_index": idx,
            "initial_values": init,
            "recovered_params": {k: float(v) for k, v in recovered.items()},
            "relative_errors_pct": {k: float(v) for k, v in errors.items()},
            "objective": float(res.fun),
            "success": bool(res.success),
            "message": str(res.message),
            "tb_rmse": float(np.sqrt(np.mean((tb_pred - tb_true) ** 2))),
            "hiv_rmse": float(np.sqrt(np.mean((hiv_pred - hiv_true) ** 2))),
            "tx_rmse": float(np.sqrt(np.mean((tx_pred - tx_true) ** 2))),
            "n_iter": int(res.nit),
            "n_fev": int(res.nfev),
        })

        print(f"  start {idx}: obj={res.fun:.2e}  nfev={res.nfev}  "
              f"success={res.success}")
        print(f"    errors: {{{', '.join(f'{k}: {v:.1f}%' for k, v in errors.items())}}}")

    return results


def run_ideal_treatment_flow_known_beta_seeded_x0():
    """Expt B: known β, two-parameter seeded x₀, 3-obs, recover 7 params.

    Only tb_prev_pct and hiv_prev_pct are estimated; the remaining six
    initial states follow the fixed make_seed() proportions.
    """
    print("\n" + "=" * 70)
    print("IDEAL TX-FLOW B: known β, two-parameter seeded x₀, 3 observables (12 years)")
    print("=" * 70)

    (t_eval, tb_true, hiv_true, tx_true,
     _, _, _) = _get_ode_diag_data_3obs()

    true_tb_prev = 0.50
    true_hiv_prev = 10.0

    starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010, "omega_min": 3e-6,
         "m": 0.015, "tb_prev_pct": 0.20, "hiv_prev_pct": 5.0},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080, "omega_min": 3e-5,
         "m": 0.20, "tb_prev_pct": 0.80, "hiv_prev_pct": 15.0},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200, "omega_min": 1e-4,
         "m": 1.00, "tb_prev_pct": 1.50, "hiv_prev_pct": 20.0},
    ]

    results = []
    for idx, init in enumerate(starts, start=1):
        theta_hc = _healthcare_to_theta(
            init["a0"], init["a_max"], init["omega0"],
            init["omega_min"], init["m"])
        theta_x0 = np.array([np.log10(init["tb_prev_pct"]),
                             np.log10(init["hiv_prev_pct"])])
        theta0 = np.concatenate([theta_hc, theta_x0])

        bounds = [(-12.0, 12.0)] * 5 + [
            (-2.0, 2.0), (-1.0, 1.7),
        ]

        res = minimize(
            _ode_healthcare_x0_3obs_objective,
            theta0,
            args=(t_eval, tb_true, hiv_true, tx_true,
                  beta1_syn, beta2_syn),
            method="L-BFGS-B",
            bounds=bounds,
            options={"maxiter": 5000, "ftol": 1e-12, "gtol": 1e-8},
        )

        a0_r, a_max_r, omega0_r, omega_min_r, m_r = \
            _theta_to_healthcare(res.x[:5])
        tb_prev_r = 10.0 ** float(res.x[5])
        hiv_prev_r = 10.0 ** float(res.x[6])

        recovered = dict(zip(HEALTHCARE_KEYS, [a0_r, a_max_r, omega0_r,
                                                omega_min_r, m_r]))
        errors = {k: abs(recovered[k] - TRUE_VALS[k])
                       / max(abs(TRUE_VALS[k]), 1e-12) * 100
                  for k in HEALTHCARE_KEYS}

        x0_r = make_seed(float(tb_prev_r), float(hiv_prev_r))
        tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
            t_eval, a0_r, a_max_r, omega0_r, omega_min_r, m_r,
            beta1_syn, beta2_syn, x0_r)
        if tb_pred is None:
            tx_pred = np.zeros_like(tx_true)
            tb_pred = np.zeros_like(tb_true)
            hiv_pred = np.zeros_like(hiv_true)

        results.append({
            "start_index": idx,
            "recovered_params": {k: float(v) for k, v in recovered.items()},
            "relative_errors_pct": {k: float(v) for k, v in errors.items()},
            "recovered_tb_prev_pct": float(tb_prev_r),
            "recovered_hiv_prev_pct": float(hiv_prev_r),
            "true_tb_prev_pct": true_tb_prev,
            "true_hiv_prev_pct": true_hiv_prev,
            "objective": float(res.fun),
            "success": bool(res.success),
            "tb_rmse": float(np.sqrt(np.mean((tb_pred - tb_true) ** 2))),
            "hiv_rmse": float(np.sqrt(np.mean((hiv_pred - hiv_true) ** 2))),
            "tx_rmse": float(np.sqrt(np.mean((tx_pred - tx_true) ** 2))),
            "n_iter": int(res.nit),
            "n_fev": int(res.nfev),
        })

        print(f"  start {idx}: obj={res.fun:.2e}  nfev={res.nfev}  "
              f"success={res.success}")
        print(f"    errors: {{{', '.join(f'{k}: {v:.1f}%' for k, v in errors.items())}}}")
        if tb_prev_r is not None:
            print(f"    x0: tb_prev={tb_prev_r:.3f} (true={true_tb_prev})  "
                  f"hiv_prev={hiv_prev_r:.2f} (true={true_hiv_prev})")

    return results


def run_ideal_treatment_flow_diagnostics():
    """Ideal treatment-flow identifiability experiments.

    Returns dict with keys:
      - ideal_tx_flow_known_beta_x0       (Expt A: known full x₀)
      - ideal_tx_flow_known_beta_seeded_x0 (Expt B: two-parameter seeded x₀)
    """
    results = {}
    results["ideal_tx_flow_known_beta_x0"] = \
        run_ideal_treatment_flow_known_beta_x0()
    results["ideal_tx_flow_known_beta_seeded_x0"] = \
        run_ideal_treatment_flow_known_beta_seeded_x0()
    return results


# ── Experiment C1: 3-param healthcare, unknown β, unknown x₀ ─────
# Recovers a₀, a_max, ω₀, β₁, β₂, tb_prev, hiv_prev  (7 params)
# with m, ω_min fixed at true values.
# 27-start grid: 3 healthcare × 3 beta × 3 prevalence.

_EXPC_M_FIXED = 0.05
_EXPC_OMEGAMIN_FIXED = 1e-5


def _expC_pack(theta):
    """Unpack 7-vector → physical parameters (all constraints built-in)."""
    a0 = float(_A0_LO + (_A0_HI - _A0_LO) * expit(float(theta[0])))
    available_gap = max(
        _AMAX_HI - a0 - _EPS_A,
        1e-12,
    )
    a_max = float(
        a0
        + _EPS_A
        + available_gap * expit(float(theta[1]))
    )
    omega0 = float(_OMEGA0_LO + (_OMEGA0_HI - _OMEGA0_LO) * expit(float(theta[2])))
    beta1 = float(10.0 ** float(theta[3]))
    beta2 = float(10.0 ** float(theta[4]))
    tb_prev = float(10.0 ** float(theta[5]))
    hiv_prev = float(10.0 ** float(theta[6]))
    return a0, a_max, omega0, beta1, beta2, tb_prev, hiv_prev


def _expC_unpack(a0, a_max, omega0, beta1, beta2, tb_prev, hiv_prev):
    """Physical parameters → 7-vector (inverse of _expC_pack)."""
    t0 = float(np.log(max((a0 - _A0_LO) / (_A0_HI - _A0_LO), 1e-15)
               / max(1.0 - (a0 - _A0_LO) / (_A0_HI - _A0_LO), 1e-15)))
    available_gap = max(
        _AMAX_HI - a0 - _EPS_A,
        1e-12,
    )

    fraction = np.clip(
        (a_max - a0 - _EPS_A) / available_gap,
        1e-8,
        1.0 - 1e-8,
    )

    t1 = float(
        np.log(fraction / (1.0 - fraction))
    )
    t2 = float(np.log(max((omega0 - _OMEGA0_LO) / (_OMEGA0_HI - _OMEGA0_LO), 1e-15)
               / max(1.0 - (omega0 - _OMEGA0_LO) / (_OMEGA0_HI - _OMEGA0_LO), 1e-15)))
    t3 = float(np.log10(max(beta1, 1e-12)))
    t4 = float(np.log10(max(beta2, 1e-12)))
    t5 = float(np.log10(max(tb_prev, 1e-12)))
    t6 = float(np.log10(max(hiv_prev, 1e-12)))
    return np.array([t0, t1, t2, t3, t4, t5, t6], dtype=float)


def _ode_expC_residual(
        theta,
        t_eval,
        tb_target,
        hiv_target,
        tx_target,
):
    """Residual vector for Experiment C."""

    (
        a0,
        a_max,
        omega0,
        beta1,
        beta2,
        tb_prev,
        hiv_prev,
    ) = _expC_pack(theta)

    x0 = make_seed(tb_prev, hiv_prev)

    tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
        t_eval,
        a0,
        a_max,
        omega0,
        _EXPC_OMEGAMIN_FIXED,
        _EXPC_M_FIXED,
        beta1,
        beta2,
        x0,
    )

    n_obs = len(t_eval)

    if (
        tb_pred is None
        or len(tb_pred) != n_obs
        or len(hiv_pred) != n_obs
        or len(tx_pred) != n_obs
        or not np.all(np.isfinite(tb_pred))
        or not np.all(np.isfinite(hiv_pred))
        or not np.all(np.isfinite(tx_pred))
    ):
        return np.full(3 * n_obs, 1e5, dtype=float)

    tb_scale = max(float(np.ptp(tb_target)), 1.0)
    hiv_scale = max(float(np.ptp(hiv_target)), 1.0)
    tx_scale = max(float(np.ptp(tx_target)), 1.0)

    return np.concatenate((
        (np.asarray(tb_pred) - tb_target) / tb_scale,
        (np.asarray(hiv_pred) - hiv_target) / hiv_scale,
        (np.asarray(tx_pred) - tx_target) / tx_scale,
    ))


def run_experiment_C1():
    """Experiment C1: Direct ODE, no noise, 27-start grid.

    Recovers {a₀, a_max, ω₀, β₁, β₂, tb_prev, hiv_prev} with
    m, ω_min fixed.  3 healthcare × 3 beta × 3 prevalence starts.

    Returns dict with per-start results and summary statistics.
    """
    print("\n" + "=" * 70)
    print("EXPERIMENT C1: 3-param healthcare + unknown β + seeded x₀")
    print("Direct ODE, no noise, 27-start grid")
    print("=" * 70)

    (t_eval, tb_true, hiv_true, tx_true,
     _, _, _) = _get_ode_diag_data_3obs()

    # ── Initial-value grid ──────────────────────────────────────
    hc_starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010,
         "label": "HC-low"},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080,
         "label": "HC-mid"},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200,
         "label": "HC-high"},
    ]
    beta_starts = [
        {"beta1": beta1_syn * 0.50, "beta2": beta2_syn * 0.50,
         "label": "β-low"},
        {"beta1": beta1_syn * 0.80, "beta2": beta2_syn * 1.20,
         "label": "β-mid"},
        {"beta1": beta1_syn * 1.50, "beta2": beta2_syn * 1.50,
         "label": "β-high"},
    ]
    prev_starts = [
        {"tb_prev": 0.20, "hiv_prev": 5.0,  "label": "prev-low"},
        {"tb_prev": 0.80, "hiv_prev": 15.0, "label": "prev-mid"},
        {"tb_prev": 1.50, "hiv_prev": 20.0, "label": "prev-high"},
    ]

    true_params = {
        "a0": TRUE_VALS["a0"], "a_max": TRUE_VALS["a_max"],
        "omega0": TRUE_VALS["omega0"],
        "beta1": beta1_syn, "beta2": beta2_syn,
        "tb_prev": 0.50, "hiv_prev": 10.0,
    }

    bounds = [(-12.0, 12.0),     # logit(a₀)
              (-12.0, 12.0),     # logit(a_max fraction)
              (-12.0, 12.0),     # logit(ω₀)
              (-2.0, 3.0),       # log10(β₁)
              (-2.0, 3.0),       # log10(β₂)
              (-3.0, 3.0),       # log10(tb_prev)
              (-3.0, 3.0)]       # log10(hiv_prev)

    all_results = []
    idx = 0
    for hc in hc_starts:
        for bt in beta_starts:
            for pv in prev_starts:
                idx += 1
                init_label = f"{hc['label']}/{bt['label']}/{pv['label']}"
                theta0 = _expC_unpack(
                    hc["a0"], hc["a_max"], hc["omega0"],
                    bt["beta1"], bt["beta2"],
                    pv["tb_prev"], pv["hiv_prev"])

                lower = np.array([b[0] for b in bounds], dtype=float)
                upper = np.array([b[1] for b in bounds], dtype=float)

                res = least_squares(
                    _ode_expC_residual,
                    theta0,
                    bounds=(lower, upper),
                    args=(
                        t_eval,
                        tb_true,
                        hiv_true,
                        tx_true,
                    ),
                    method="trf",
                    x_scale="jac",
                    loss="linear",
                    ftol=1e-12,
                    xtol=1e-12,
                    gtol=1e-12,
                    max_nfev=5000,
                )

                a0_r, a_max_r, omega0_r, beta1_r, beta2_r, \
                    tb_prev_r, hiv_prev_r = _expC_pack(res.x)
                x0_r = make_seed(tb_prev_r, hiv_prev_r)
                tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
                    t_eval, a0_r, a_max_r, omega0_r,
                    _EXPC_OMEGAMIN_FIXED, _EXPC_M_FIXED,
                    beta1_r, beta2_r, x0_r)
                if tb_pred is None:
                    tb_pred = np.zeros_like(tb_true)
                    hiv_pred = np.zeros_like(hiv_true)
                    tx_pred = np.zeros_like(tx_true)

                recovered = {
                    "a0": a0_r, "a_max": a_max_r, "omega0": omega0_r,
                    "beta1": beta1_r, "beta2": beta2_r,
                    "tb_prev": tb_prev_r, "hiv_prev": hiv_prev_r,
                }
                rel_errors = {
                    k: abs(recovered[k] - true_params[k])
                       / max(abs(true_params[k]), 1e-12) * 100
                    for k in true_params
                }

                optimizer_success = bool(res.success)
                recovery_success = bool(
                    optimizer_success
                    and max(rel_errors.values()) < 5.0
                )

                entry = {
                    "index": idx,
                    "label": init_label,
                    "initial": {
                        "a0": hc["a0"], "a_max": hc["a_max"],
                        "omega0": hc["omega0"],
                        "beta1": bt["beta1"], "beta2": bt["beta2"],
                        "tb_prev": pv["tb_prev"], "hiv_prev": pv["hiv_prev"],
                    },
                    "recovered": {k: float(v) for k, v in recovered.items()},
                    "rel_error_pct": {k: float(v) for k, v in rel_errors.items()},
                    "objective": float(2.0 * res.cost),
                    "optimizer_success": optimizer_success,
                    "recovery_success": recovery_success,
                    "tb_rmse": float(np.sqrt(np.mean((tb_pred - tb_true) ** 2))),
                    "hiv_rmse": float(np.sqrt(np.mean((hiv_pred - hiv_true) ** 2))),
                    "tx_rmse": float(np.sqrt(np.mean((tx_pred - tx_true) ** 2))),
                    "n_fev": int(res.nfev),
                    "n_jev": (
                        int(res.njev)
                        if res.njev is not None
                        else None
                    ),
                }
                all_results.append(entry)

                hc_errs = ", ".join(
                    f"{k}={rel_errors[k]:.1f}%"
                    for k in ["a0", "a_max", "omega0"])
                bt_errs = f"β₁={rel_errors['beta1']:.1f}% β₂={rel_errors['beta2']:.1f}%"
                pv_errs = (f"tb_prev={rel_errors['tb_prev']:.1f}% "
                           f"hiv_prev={rel_errors['hiv_prev']:.1f}%")
                obj_val = float(2.0 * res.cost)
                print(f"  [{idx:2d}] {init_label:30s}  obj={obj_val:.2e}  "
                      f"nfev={res.nfev:4d}  opt_succ={optimizer_success}  "
                      f"rec_succ={recovery_success}")
                print(f"       HC: {{{hc_errs}}}  |  {bt_errs}  |  {pv_errs}")

    # ── Summary statistics ──────────────────────────────────────────
    param_names = list(true_params.keys())
    summaries = {}
    for k in param_names:
        errs = np.array([r["rel_error_pct"][k] for r in all_results])
        vals = np.array([r["recovered"][k] for r in all_results])
        summaries[k] = {
            "true": float(true_params[k]),
            "median_recovered": float(np.median(vals)),
            "median_rel_error_pct": float(np.median(errs)),
            "mean_rel_error_pct": float(np.mean(errs)),
            "max_rel_error_pct": float(np.max(errs)),
            "cv_pct": float(np.std(vals) / max(np.mean(vals), 1e-12) * 100),
            "success_rate_pct": float(np.mean(errs < 5.0) * 100),
        }

    # Flag low-loss but poorly recovered cases
    obj_threshold = np.median([r["objective"] for r in all_results]) * 100
    flagged = []
    for r in all_results:
        if r["objective"] < obj_threshold:
            max_err = max(r["rel_error_pct"].values())
            if max_err > 10.0:
                flagged.append(r["index"])

    print(f"\n{'─' * 70}")
    print("SUMMARY: Experiment C1")
    print(f"{'─' * 70}")
    print(f"{'Param':<12s} {'True':>10s} {'MedRec':>10s} {'MedErr':>8s} "
          f"{'MaxErr':>8s} {'CV':>8s} {'Succ%':>7s}")
    print(f"{'─' * 70}")
    for k in param_names:
        s = summaries[k]
        print(f"{k:<12s} {s['true']:10.4f} {s['median_recovered']:10.4f} "
              f"{s['median_rel_error_pct']:7.1f}% {s['max_rel_error_pct']:7.1f}% "
              f"{s['cv_pct']:7.1f}% {s['success_rate_pct']:6.0f}%")
    if flagged:
        print(f"\n  ⚠ Low-loss but poorly recovered starts (obj < {obj_threshold:.1e}, "
              f"max_err > 10%): {flagged}")

    # Determine pass/fail for the three healthcare params
    hc_pass = all(
        summaries[k]["max_rel_error_pct"] < 5.0
        and summaries[k]["cv_pct"] < 5.0
        for k in ["a0", "a_max", "omega0"]
    )
    print(f"\n  Healthcare-param pass (max_err<5% & CV<5%): {hc_pass}")

    return {
        "experiment": "C1",
        "description": "3-param healthcare + unknown beta + two-parameter seeded x0, direct ODE, no noise",
        "fixed_params": {"m": _EXPC_M_FIXED, "omega_min": _EXPC_OMEGAMIN_FIXED},
        "true_params": {k: float(v) for k, v in true_params.items()},
        "n_starts": len(all_results),
        "results": all_results,
        "summary": summaries,
        "healthcare_pass": hc_pass,
        "flagged_starts": flagged,
        "notes": [
            "a_max = a0 + EPS_A + available_gap * expit(theta) <= AMAX_HI",
            "least_squares with trf, 3-observable residual vector",
            "optimizer_success = optimizer converged; recovery_success = max_err < 5%",
        ],
    }


def run_experiment_C2(n_realizations=20, n_starts_per_noise=3):
    """Experiment C2: Direct ODE, 5% multiplicative noise.

    Same 7-param recovery as C1.  For each independent noise realisation,
    runs n_starts_per_noise (HC-low/mid/high with mid-β and mid-prev),
    reports parameter error distributions, success rate, and flags any
    poorly recovered cases (healthcare-param error > 20%).
    """
    print("\n" + "=" * 70)
    print(f"EXPERIMENT C2: 3-param HC + unknown β + seeded x₀, 5% noise")
    print(f"{n_realizations} noise realisations × {n_starts_per_noise} starts")
    print("=" * 70)

    (t_eval, tb_true, hiv_true, tx_true,
     _, _, _) = _get_ode_diag_data_3obs()

    true_params = {
        "a0": TRUE_VALS["a0"], "a_max": TRUE_VALS["a_max"],
        "omega0": TRUE_VALS["omega0"],
        "beta1": beta1_syn, "beta2": beta2_syn,
        "tb_prev": 0.50, "hiv_prev": 10.0,
    }

    # Representative starts: vary HC, keep β and prev at mid values
    hc_starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010, "label": "HC-low"},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080, "label": "HC-mid"},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200, "label": "HC-high"},
    ]
    bt0 = {"beta1": beta1_syn * 0.80, "beta2": beta2_syn * 1.20}
    pv0 = {"tb_prev": 0.80, "hiv_prev": 15.0}
    starts = hc_starts[:n_starts_per_noise]

    bounds = [(-12.0, 12.0), (-12.0, 12.0), (-12.0, 12.0),
              (-2.0, 3.0), (-2.0, 3.0), (-3.0, 3.0), (-3.0, 3.0)]

    param_names = list(true_params.keys())
    all_realizations = []

    rng = np.random.RandomState(4242)
    noise_level = 0.05

    for irep in range(1, n_realizations + 1):
        # Generate independent noise for each observable sequence
        eps_tb = rng.randn(len(tb_true))
        eps_hiv = rng.randn(len(hiv_true))
        eps_tx = rng.randn(len(tx_true))
        tb_obs = np.maximum(tb_true * (1.0 + noise_level * eps_tb), 0.0)
        hiv_obs = np.maximum(hiv_true * (1.0 + noise_level * eps_hiv), 0.0)
        tx_obs = np.maximum(tx_true * (1.0 + noise_level * eps_tx), 0.0)

        rep_results = []
        best_obj = np.inf

        for si, hc in enumerate(starts):
            theta0 = _expC_unpack(
                hc["a0"], hc["a_max"], hc["omega0"],
                bt0["beta1"], bt0["beta2"],
                pv0["tb_prev"], pv0["hiv_prev"])

            lower = np.array([b[0] for b in bounds], dtype=float)
            upper = np.array([b[1] for b in bounds], dtype=float)

            res = least_squares(
                _ode_expC_residual,
                theta0,
                bounds=(lower, upper),
                args=(
                    t_eval,
                    tb_obs,
                    hiv_obs,
                    tx_obs,
                ),
                method="trf",
                x_scale="jac",
                loss="linear",
                ftol=1e-12,
                xtol=1e-12,
                gtol=1e-12,
                max_nfev=5000,
            )

            a0_r, a_max_r, omega0_r, beta1_r, beta2_r, \
                tb_prev_r, hiv_prev_r = _expC_pack(res.x)
            recovered = {
                "a0": a0_r, "a_max": a_max_r, "omega0": omega0_r,
                "beta1": beta1_r, "beta2": beta2_r,
                "tb_prev": tb_prev_r, "hiv_prev": hiv_prev_r,
            }
            rel_errors = {
                k: abs(recovered[k] - true_params[k])
                   / max(abs(true_params[k]), 1e-12) * 100
                for k in true_params
            }

            x0_r = make_seed(tb_prev_r, hiv_prev_r)
            tb_pred, hiv_pred, tx_pred, _ = _ode_predict_3obs(
                t_eval, a0_r, a_max_r, omega0_r,
                _EXPC_OMEGAMIN_FIXED, _EXPC_M_FIXED,
                beta1_r, beta2_r, x0_r)

            optimizer_success = bool(res.success)
            recovery_success = bool(
                optimizer_success
                and max(rel_errors.values()) < 5.0
            )

            entry = {
                "start_label": hc["label"],
                "recovered": {k: float(v) for k, v in recovered.items()},
                "rel_error_pct": {k: float(v) for k, v in rel_errors.items()},
                "objective": float(2.0 * res.cost),
                "optimizer_success": optimizer_success,
                "recovery_success": recovery_success,
                "n_fev": int(res.nfev),
                "n_jev": (
                    int(res.njev)
                    if res.njev is not None
                    else None
                ),
            }
            if tb_pred is not None:
                entry["tb_rmse"] = float(np.sqrt(np.mean((tb_pred - tb_obs) ** 2)))
                entry["hiv_rmse"] = float(np.sqrt(np.mean((hiv_pred - hiv_obs) ** 2)))
                entry["tx_rmse"] = float(np.sqrt(np.mean((tx_pred - tx_obs) ** 2)))
            rep_results.append(entry)

            if (2.0 * res.cost) < best_obj:
                best_obj = (2.0 * res.cost)

        # Per-realisation: pick best start, check for poor recovery
        best = min(rep_results, key=lambda r: r["objective"])
        best_errs = best["rel_error_pct"]
        poor_flag = (
            max(
                best_errs["a0"],
                best_errs["a_max"],
                best_errs["omega0"],
            ) > 20.0
        )

        all_realizations.append({
            "realization": irep,
            "best_start": best["start_label"],
            "best_objective": best["objective"],
            "best_rel_errors": best_errs,
            "all_starts": rep_results,
            "poor_recovery_flag": poor_flag,
        })

        hc_str = ", ".join(
            f"{k}={best_errs[k]:.1f}%" for k in ["a0", "a_max", "omega0"])
        bt_str = (f"β₁={best_errs['beta1']:.1f}% "
                  f"β₂={best_errs['beta2']:.1f}%")
        flag = " ⚠POOR" if poor_flag else ""
        print(f"  rep {irep:2d}/{n_realizations}: best={best['start_label']:7s} "
              f"obj={best['objective']:.2e}  HC: {{{hc_str}}}  {bt_str}{flag}")

    # ── Aggregate across realisations ────────────────────────────
    agg = {}
    for k in param_names:
        errs = np.array([r["best_rel_errors"][k] for r in all_realizations])
        agg[k] = {
            "true": float(true_params[k]),
            "median_rel_error_pct": float(np.median(errs)),
            "mean_rel_error_pct": float(np.mean(errs)),
            "p5_rel_error_pct": float(np.percentile(errs, 5)),
            "p95_rel_error_pct": float(np.percentile(errs, 95)),
            "success_rate_pct": float(np.mean(errs < 5.0) * 100),
        }

    n_poor_recovery = sum(1 for r in all_realizations if r["poor_recovery_flag"])

    print(f"\n{'─' * 70}")
    print("SUMMARY: Experiment C2  (per-realisation best-start results)")
    print(f"{'─' * 70}")
    print(f"{'Param':<12s} {'True':>10s} {'MedErr':>8s} {'P5':>8s} "
          f"{'P95':>8s} {'Succ%':>7s}")
    print(f"{'─' * 70}")
    for k in param_names:
        s = agg[k]
        print(f"{k:<12s} {s['true']:10.4f} {s['median_rel_error_pct']:7.1f}% "
              f"{s['p5_rel_error_pct']:7.1f}% {s['p95_rel_error_pct']:7.1f}% "
              f"{s['success_rate_pct']:6.0f}%")
    print(f"\n  Poorly recovered realisations (healthcare-param error > 20%): "
          f"{n_poor_recovery}/{n_realizations}")

    hc_pass = all(agg[k]["p95_rel_error_pct"] < 20.0 for k in
                  ["a0", "a_max", "omega0"])
    print(f"  HC-param pass (P95 < 20% under 5% noise): {hc_pass}")

    return {
        "experiment": "C2",
        "noise_level": noise_level,
        "noise_type": "multiplicative Gaussian, clamped non-negative",
        "n_realizations": n_realizations,
        "n_starts_per_noise": n_starts_per_noise,
        "true_params": {k: float(v) for k, v in true_params.items()},
        "aggregate": agg,
        "n_poor_recovery": n_poor_recovery,
        "healthcare_pass": hc_pass,
        "realizations": all_realizations,
    }


def run_ode_identifiability_diagnostics():
    ode_results = {}

    ode_results["known_beta_known_x0"] = \
        run_direct_ode_recovery_known_beta_x0()

    ode_results["known_beta_two_parameter_seeded_x0"] = \
        run_direct_ode_recovery_known_beta_two_parameter_seeded_x0()

    ode_results["known_healthcare_known_x0"] = \
        run_direct_ode_recovery_known_healthcare_x0()

    # Sanitise numpy types for JSON
    def _sanitise(obj):
        if isinstance(obj, dict):
            return {str(k): _sanitise(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_sanitise(v) for v in obj]
        if isinstance(obj, (np.floating, np.integer)):
            return float(obj) if isinstance(obj, np.floating) else int(obj)
        return obj

    payload = {
        "analysis": "direct-ODE identifiability diagnostics",
        "structural_identifiability_proved": False,
        "method": "scipy L-BFGS-B, multi-start",
        "observation_design":
            "15 annual TB-incidence + HIV-prevalence, noise-free",
        **_sanitise(ode_results),
    }

    output_path = ODE_DIAG_OUT / "ode_identifiability_diagnostics.json"
    output_path.write_text(
        json.dumps(payload, indent=2, default=str),
        encoding="utf-8",
    )

    print(f"\nSaved: {output_path}")
    return payload


# ============================================================
# 12. REAL DATA APPLICATION
# ============================================================
OUT_REAL = Path("PINN/results/south_africa/real_unfrozen")
OUT_REAL.mkdir(parents=True, exist_ok=True)

def load_real_data(csv_path=None):
    import pandas as pd
    csv_path = Path(csv_path or "PINN/data/merged_TB_HIV.csv")
    if not csv_path.exists():
        raise FileNotFoundError(f"{csv_path} not found. Run process_merge_data.py first.")
    return pd.read_csv(csv_path)

def prepare_observable_data(real_df):
    cols_lower = {c.lower(): c for c in real_df.columns}
    year_col = cols_lower.get("year", "Year")
    required_cols = [year_col, "TB_incidence_per_100k", "HIV_prevalence_all_ages_pct"]
    missing = [c for c in required_cols if c not in real_df.columns]
    if missing:
        raise KeyError(f"Missing required column(s): {missing}")

    real_df = real_df.sort_values(year_col).reset_index(drop=True)
    years = real_df[year_col].values
    if len(years) < 2 or years[-1] <= years[0]:
        raise ValueError("Real-data training requires at least two increasing years.")
    t_real = (years - years[0]).astype(float)
    t_norm = t_real / t_real[-1]

    tb_inc = real_df["TB_incidence_per_100k"].values.astype(np.float32)
    hiv_prev = real_df["HIV_prevalence_all_ages_pct"].values.astype(np.float32)

    tb_min, tb_max = tb_inc.min(), tb_inc.max()
    hiv_prev_min, hiv_prev_max = hiv_prev.min(), hiv_prev.max()

    tb_scale = tb_max - tb_min if tb_max > tb_min else 1.0
    hiv_prev_scale = hiv_prev_max - hiv_prev_min if hiv_prev_max > hiv_prev_min else 1.0

    tb_norm = (tb_inc - tb_min) / tb_scale
    hiv_prev_norm = (hiv_prev - hiv_prev_min) / hiv_prev_scale

    obs_meta = {"tb_min": tb_min, "tb_scale": tb_scale,
                "hiv_prev_min": hiv_prev_min, "hiv_prev_scale": hiv_prev_scale}

    print(f"  TB incidence: [{tb_min:.0f}, {tb_max:.0f}] per 100k")
    print(f"  HIV prevalence: [{hiv_prev_min:.1f}, {hiv_prev_max:.1f}]%")
    return t_norm, years, tb_inc, hiv_prev, tb_norm, hiv_prev_norm, obs_meta


def run_real_application(recovered_synth, data_path=None, collocation_points=500):
    """Partial-observation PINN with bounded beta1(t) and beta2(t).

    Country-specific m_c^F estimation is deferred to independent bifurcation
    validation and is not run as part of PINN training.
    """
    print("\n" + "=" * 60)
    print("PART B: REAL SA DATA — bounded beta1(t), beta2(t)  [r(t) removed; m_c^F deferred]")
    print("=" * 60)

    df = load_real_data(data_path)
    t_norm_v, years, tb_inc_raw, hiv_prev_raw, tb_norm, hiv_prev_norm, obs_meta = \
        prepare_observable_data(df)

    time_horizon = float(years[-1] - years[0])
    print(f"  ODE time horizon: {time_horizon:.1f} years")

    t_data = torch.tensor(t_norm_v.reshape(-1, 1), dtype=torch.float32)
    tb_raw_target = torch.tensor(tb_inc_raw.reshape(-1, 1), dtype=torch.float32).squeeze(-1)
    hiv_prev_raw_target = torch.tensor(hiv_prev_raw.reshape(-1, 1), dtype=torch.float32).squeeze(-1)
    t_col = torch.tensor(np.linspace(0, 1, collocation_points).reshape(-1, 1), dtype=torch.float32)

    c_y_min, c_y_scale = compute_country_norm(tb_inc_raw, hiv_prev_raw)
    print(f"  ODE norm: I ∈ [{c_y_min[2]:.0f}, {c_y_min[2]+c_y_scale[2]:.0f}], "
          f"J* ∈ [{c_y_min[4]:.0f}, {c_y_min[4]+c_y_scale[4]:.0f}]")

    state_net = StateNetwork(hidden=32, n_hidden=2)
    param_module = ParameterModule(recovered_synth)
    beta1_net = Beta1Network(init_beta1=beta1_syn, degree=3)
    beta2_net = Beta2Network(init_beta2=beta2_syn, degree=2)

    n_free = count_trainable_params(state_net, param_module, beta1_net, beta2_net)
    n_data = int(2 * len(years))
    print(f"  beta1(t), beta2(t) ← bounded low-dimensional functions")
    print(f"  No r(t): WHO data is estimated TB incidence, not notifications")
    print(f"  Trainable parameters: {n_free} vs observed data values: {n_data}")
    print(f"  Targets: RAW TB inc [{tb_inc_raw[0]:.0f}-{tb_inc_raw[-1]:.0f}]/100k, "
          f"HIV prev [{hiv_prev_raw[0]:.1f}-{hiv_prev_raw[-1]:.1f}]%")
    print(f"  Healthcare (LEARNABLE): "
          f"{', '.join(f'{k}={v:.4g}' for k,v in recovered_synth.items())}")

    all_loss, all_param = [], []

    print("\n  --- Pre-training: data-only ---")
    lh, ph = train_real(state_net, param_module, beta1_net, beta2_net,
                        t_data, tb_raw_target, hiv_prev_raw_target, t_col,
                        n_epochs=1000, lr=1e-3, w_data=1.0, w_ode=0.0, w_reg=0.02, label="PRE",
                        y_min=c_y_min, y_scale=c_y_scale, time_horizon=time_horizon)
    all_loss.extend(lh); all_param.extend(ph)

    phases = [
        ("R1", 2000, 1e-3, 1.0, 0.00, 0.02),
        ("R2", 3000, 5e-4, 1.0, 0.01, 0.05),
        ("R3", 3000, 2e-4, 0.8, 0.10, 0.10),
        ("R4", 3000, 1e-4, 0.5, 0.50, 0.15),
        ("R5", 3000, 5e-5, 0.3, 1.00, 0.20),
    ]
    for label, n_ep, lr, wd, wo, wr in phases:
        lh, ph = train_real(state_net, param_module, beta1_net, beta2_net,
                            t_data, tb_raw_target, hiv_prev_raw_target, t_col,
                            n_epochs=n_ep, lr=lr, w_data=wd, w_ode=wo, w_reg=wr, label=label,
                            y_min=c_y_min, y_scale=c_y_scale, time_horizon=time_horizon)
        all_loss.extend(lh); all_param.extend(ph)

    with torch.no_grad():
        a0, a_max, omega0, omega_min, m = param_module.get_params()

    recovered_real = {"a0": a0.item(), "a_max": a_max.item(), "omega0": omega0.item(),
                      "omega_min": omega_min.item(), "m": m.item()}

    print(f"\n  Final healthcare parameters:")
    for k, v in recovered_real.items():
        print(f"    {k} = {v:.6g}")

    mf_diagnostic = {
        "status": "not_evaluated",
        "critical_mF_estimate": None,
        "reason": (
            "Full-system fold continuation must be independently "
            "validated before estimating m_c^F."
        ),
    }
    print(f"  m_c^F status: {mf_diagnostic['status']} — {mf_diagnostic['reason']}")

    t_eval = torch.tensor(t_norm_v.reshape(-1, 1), dtype=torch.float32)
    with torch.no_grad():
        states_pred = state_net(t_eval).numpy()
        beta1_pred = beta1_net(t_eval).squeeze(-1).numpy()
        beta2_pred = beta2_net(t_eval).squeeze(-1).numpy()

    print(f"  beta1(t) range: [{beta1_pred.min():.4f}, {beta1_pred.max():.4f}]")
    print(f"  beta2(t) range: [{beta2_pred.min():.4f}, {beta2_pred.max():.4f}]")

    RT_vals, TB_burden, a_vals = [], [], []
    for i in range(len(years)):
        N_i = max(states_pred[i].sum(), 1.0)
        B_i = (states_pred[i, 2] + states_pred[i, 6]) / N_i
        TB_burden.append(B_i * 100)
        z_i = (1.0 + recovered_real["m"]) * B_i / (1.0 + recovered_real["m"] * B_i + 1e-12)
        a_i = recovered_real["a0"] + (recovered_real["a_max"] - recovered_real["a0"]) * z_i
        a_vals.append(a_i)
        beta1_i = beta1_pred[i]
        beta1_star_i = (mu + k_val + a_i) * (mu + d_val + a_i) / k_val
        RT_vals.append(beta1_i / max(beta1_star_i, 1e-12))

    RT_vals = np.array(RT_vals); TB_burden = np.array(TB_burden)

    print(f"  RT(t) range: [{RT_vals.min():.4f}, {RT_vals.max():.4f}]")
    print(f"  TB prevalence (true): [{TB_burden.min():.2f}%, {TB_burden.max():.2f}%]")

    with torch.no_grad():
        y_data_pts = state_net(t_data).numpy()
    N_data = y_data_pts.sum(axis=1)
    Jstar_data = y_data_pts[:, 4] + y_data_pts[:, 5] + y_data_pts[:, 6]
    tb_model_data = (k_val * y_data_pts[:, 1] + k_star * y_data_pts[:, 5]) / (N_data + 1e-8) * 100000
    tb_obs_data = tb_model_data
    hiv_model_data = Jstar_data / (N_data + 1e-8) * 100

    def _rmse(a, b):
        return float(np.sqrt(np.mean((np.asarray(a) - np.asarray(b)) ** 2)))
    def _mae(a, b):
        return float(np.mean(np.abs(np.asarray(a) - np.asarray(b))))

    tb_rmse = _rmse(tb_inc_raw, tb_obs_data)
    tb_mae = _mae(tb_inc_raw, tb_obs_data)
    hiv_rmse = _rmse(hiv_prev_raw, hiv_model_data)
    hiv_mae = _mae(hiv_prev_raw, hiv_model_data)
    print(f"  TB fit:  RMSE={tb_rmse:.1f}/100k, MAE={tb_mae:.1f}/100k")
    print(f"  HIV fit: RMSE={hiv_rmse:.2f}%,  MAE={hiv_mae:.2f}%")

    print("\n  Generating observation fit plot (TB + HIV)...")
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 14))

    t_dense = np.linspace(0, 1, 200)
    t_t_dense = torch.tensor(t_dense.reshape(-1, 1), dtype=torch.float32)
    with torch.no_grad():
        y_dense = state_net(t_t_dense).numpy()
        beta1_dense = beta1_net(t_t_dense).squeeze(-1).numpy()
        beta2_dense = beta2_net(t_t_dense).squeeze(-1).numpy()
    tb_model_dense, hiv_prev_model_dense = observables_numpy(y_dense)
    t_years_dense = np.linspace(years[0], years[-1], 200)

    ax1.plot(years, tb_inc_raw, "ko-", markersize=8, linewidth=2.0, label="WHO data")
    ax1.plot(t_years_dense, tb_model_dense, "#C62828", lw=2.0,
             label=r"PINN: $(kL+k^*J_2)/N \times 10^5$")
    ax1.set_ylabel("TB incidence per 100 000", fontsize=12)
    ax1.set_title("South Africa TB incidence", fontsize=12, fontweight="bold")
    ax1.legend(fontsize=9, loc="upper right")
    ax1.spines["top"].set_visible(False); ax1.spines["right"].set_visible(False)
    ax1.text(0.03, 0.93, f"RMSE={tb_rmse:.1f}  MAE={tb_mae:.1f}", transform=ax1.transAxes,
             fontsize=8, va="top", family="monospace",
             bbox={"boxstyle": "round,pad=0.3", "facecolor": "white", "alpha": 0.85})

    ax2.plot(years, hiv_prev_raw, "ko-", markersize=8, linewidth=2.0, label="UNAIDS data")
    ax2.plot(t_years_dense, hiv_prev_model_dense, "#2E7D32", lw=2.0,
             label=r"PINN: $J^*/N \times 100$")
    ax2.set_ylabel("HIV prevalence (%)", fontsize=12)
    ax2.set_title("South Africa HIV prevalence (all ages)", fontsize=12, fontweight="bold")
    ax2.legend(fontsize=9, loc="upper right")
    ax2.spines["top"].set_visible(False); ax2.spines["right"].set_visible(False)
    ax2.text(0.03, 0.93, f"RMSE={hiv_rmse:.2f}  MAE={hiv_mae:.2f}", transform=ax2.transAxes,
             fontsize=8, va="top", family="monospace",
             bbox={"boxstyle": "round,pad=0.3", "facecolor": "white", "alpha": 0.85})

    ax3.plot(t_years_dense, beta1_dense, "#1565C0", lw=2.0, label=r"$\beta_1(t)$")
    ax3.plot(t_years_dense, beta2_dense, "#2E7D32", lw=2.0, ls="--", label=r"$\beta_2(t)$")
    ax3.set_xlabel("Year", fontsize=12)
    ax3.set_ylabel(r"Transmission rate (year$^{-1}$)", fontsize=12)
    ax3.set_title("Time-varying transmission rates", fontsize=12)
    ax3.legend(fontsize=9)

    fig.tight_layout()
    fig.savefig(str(OUT_REAL / "observation_fit.pdf"), dpi=300)
    fig.savefig(str(OUT_REAL / "observation_fit.png"), dpi=300)
    plt.close(fig)

    model_path = OUT_REAL / "best_model.pt"
    torch.save({
        "state_net": state_net.state_dict(),
        "param_module": param_module.state_dict(),
        "beta1_net": beta1_net.state_dict(),
        "beta2_net": beta2_net.state_dict(),
        "recovered_params": recovered_real,
    }, model_path)
    print(f"  Saved model weights → {model_path}")

    real_results = {
        "recovered_params": {k: float(v) for k, v in recovered_real.items()},
        "RH": float(RH_SYN),
        "fit_metrics": {
            "tb_rmse_per_100k": tb_rmse,
            "tb_mae_per_100k": tb_mae,
            "hiv_rmse_pct": hiv_rmse,
            "hiv_mae_pct": hiv_mae,
        },
        "RT_range": [float(RT_vals.min()), float(RT_vals.max())],
        "RT_trajectory": [float(v) for v in RT_vals],
        "beta1_trajectory": [float(v) for v in beta1_pred],
        "beta2_trajectory": [float(v) for v in beta2_pred],
        "TB_burden_trajectory": [float(v) for v in TB_burden],
        "a_trajectory": [float(v) for v in a_vals],
        "country_specific_mF_diagnostic": mf_diagnostic,
        "interpretation_flags": {
            "uses_flow_based_tb_incidence_observation": True,
            "no_detection_fraction_applied": True,
            "universal_mF_assumption_used": False,
            "beta2_is_bounded_and_regularized": True,
            "real_data_fit_is_partially_observed": True,
            "mF_diagnostic_deferred_to_independent_validation": True,
        },
    }
    with open(OUT_REAL / "recovered_params.json", "w") as f:
        json.dump(real_results, f, indent=2)

    print(f"  Saved → {OUT_REAL}")
    return real_results, tb_inc_raw, tb_obs_data, years

# ============================================================
# 10. MAIN
# ============================================================

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="PINN training for HIV-TB parameter recovery.")
    parser.add_argument(
        "--mode",
        choices=["partial-validation", "identifiability-controls", "expc1", "expc2", "full-state-debug", "real"],
        default="partial-validation",
    )
    parser.add_argument("--validation-noise", type=float, default=0.0)
    parser.add_argument("--max-epochs", type=int, default=MAX_EPOCHS)
    parser.add_argument("--target-pct", type=float, default=TARGET_PCT)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--data", default="PINN/data/merged_TB_HIV.csv")
    parser.add_argument("--collocation", type=int, default=500)
    parser.add_argument("--real-init-json", default=None)
    parser.add_argument("--out-syn", default=str(OUT_SYN))
    parser.add_argument("--out-real", default=str(OUT_REAL))
    return parser.parse_args(argv)


def _load_initial_params(path):
    candidate = Path(path) if path else OUT_SYN / "validation_results.json"
    if candidate.exists():
        payload = json.loads(candidate.read_text(encoding="utf-8"))
        if "recovered_params" in payload:
            return payload["recovered_params"]
    print("  No synthetic validation JSON found; using TRUE_VALS as initial healthcare parameters.")
    return dict(TRUE_VALS)


def _run_synthetic_then_real(args):
    """Full-state synthetic training — for ODE/AD debugging, NOT identifiability proof."""
    lr_attempts = [1e-3, 5e-4, 2e-4]
    for attempt, lr in enumerate(lr_attempts):
        recovered, errors, max_err, loss_hist, param_hist, state_nets, param_module = run_training(lr_init=lr)
        plot_results(loss_hist, param_hist, recovered, errors, attempt + 1)

        if max_err < TARGET_PCT:
            print(f"\n{'='*60}")
            print(f"*** FULL-STATE DEBUG PASSED (attempt {attempt+1}, lr={lr:.0e}) ***")
            print(f"Max error: {max_err:.2f}% < {TARGET_PCT}%")
            for k in TRUE_VALS:
                print(f"  {k}: true={TRUE_VALS[k]:.6g} recovered={recovered[k]:.6g} err={errors[k]:.2f}%")
            print(f"  CAUTION: this is full-state, not partial-observation recovery.")
            print(f"{'='*60}")

            results = {
                "true_params": TRUE_VALS,
                "recovered_params": recovered,
                "errors_pct": errors,
                "max_error_pct": max_err,
                "attempt": attempt + 1,
                "lr": lr,
                "total_epochs": len(loss_hist),
            }
            with open(OUT_SYN / "validation_results.json", "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2)

            torch.save({
                "state_nets": [sn.state_dict() for sn in state_nets],
                "param_module": param_module.state_dict(),
                "recovered": recovered,
                "errors": errors,
            }, OUT_SYN / "best_model.pt")

            plot_trajectory_comparison(state_nets, param_module, attempt + 1)

            print(f"\n  Synthetic full-state outputs: {OUT_SYN.resolve()}")
            return True

    print(f"\n{'='*60}")
    print(f"*** Full-state debug failed after {MAX_EPOCHS} epochs per attempt. ***")
    print(f"{'='*60}")
    return False


def main(argv=None):
    global MAX_EPOCHS, TARGET_PCT, OUT_SYN, OUT_REAL
    args = parse_args(argv)
    MAX_EPOCHS = args.max_epochs
    TARGET_PCT = args.target_pct
    OUT_SYN = Path(args.out_syn); OUT_SYN.mkdir(parents=True, exist_ok=True)
    OUT_REAL = Path(args.out_real); OUT_REAL.mkdir(parents=True, exist_ok=True)
    set_random_seed(args.seed)

    print("=" * 60)
    print("PINN HIV-TB TRAINING")
    print(f"Mode: {args.mode} | Target: < {TARGET_PCT}% | Max epochs: {MAX_EPOCHS}")
    print("=" * 60)

    if args.mode == "partial-validation":
        run_partial_observation_screen(noise_fraction=args.validation_noise)
        return True

    if args.mode == "identifiability-controls":
        run_identifiability_controls()
        return True

    if args.mode == "expc1":
        results = run_experiment_C1()
        out_path = OUT_SYN / "experiment_C1_direct_ode_noise0.json"
        out_path.write_text(
            json.dumps(results, indent=2, default=str),
            encoding="utf-8",
        )
        print(f"\nExperiment C1 results saved: {out_path.resolve()}")
        return True

    if args.mode == "expc2":
        results = run_experiment_C2()
        out_path = OUT_SYN / "experiment_C2_direct_ode_noise5pct.json"
        out_path.write_text(
            json.dumps(results, indent=2, default=str),
            encoding="utf-8",
        )
        print(f"\nExperiment C2 results saved: {out_path.resolve()}")
        return True

    if args.mode == "full-state-debug":
        return _run_synthetic_then_real(args)

    if args.mode == "real":
        init_params = _load_initial_params(args.real_init_json)
        run_real_application(
            init_params,
            data_path=args.data,
            collocation_points=args.collocation,
        )
        return True

    return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
