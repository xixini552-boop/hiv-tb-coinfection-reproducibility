# Full-system LOCAL structural identifiability of the HIV-TB model.
#
# Correctness-first: this mirrors the Python RHS in pinn_training_paper_safe.py
# (rhs_full_np) and the observation operator in identifiability_ABC.py
# (observations_from_states). Any deviation here would make the result about a
# different model.
#
# This is the STANDARD local structural identifiability test (Xia--Moog /
# generic initial condition), the "structurally identifiable" definition used
# in Miao et al. 2011. It answers: are the parameters uniquely determined by
# the ideal outputs under exact, noise-free, continuous measurement?
#
# NOTE: v0.5.27 has a bug — the `known_ic` branch of assess_local_identifiability
# calls the undefined `_assess_local_identifiability_kic`. So the known-IC
# variant is not included here; no known-IC run is archived in this repository.
using StructuralIdentifiability
using ModelingToolkit
using Symbolics
using Logging
using Dates
using Random

# ---- minimal JSON serializer (no JSON.jl dependency) ------------------------
function _json_escape(s::String)
    out = IOBuffer()
    write(out, UInt8('"'))
    for c in s
        if c == '"' || c == '\\'
            write(out, UInt8('\\'), UInt8(c))
        elseif c == '\n'
            write(out, UInt8('\\'), UInt8('n'))
        elseif c == '\t'
            write(out, UInt8('\\'), UInt8('t'))
        else
            write(out, c)
        end
    end
    write(out, UInt8('"'))
    return String(take!(out))
end
to_json(x::Bool)                       = x ? "true" : "false"
to_json(x::String)                     = _json_escape(x)
to_json(x::AbstractFloat)              = string(x)
to_json(x::Integer)                    = string(x)
function to_json(x::AbstractDict)
    parts = String["$(_json_escape(string(k))): $(to_json(v))" for (k, v) in x]
    return "{" * join(parts, ", ") * "}"
end
function to_json(x::AbstractVector)
    return "[" * join([to_json(v) for v in x], ", ") * "]"
end

const _RESULTS_DIR = joinpath(@__DIR__, "..", "results", "identifiability_ABC")
const _OUT_PATH    = joinpath(_RESULTS_DIR, "structural_identifiability_jl_output.json")

# The local-identifiability routine draws random parameter values and initial
# conditions over a finite field. The seed is fixed so that the archived run is
# reproducible; the packaged correctness bound (prob_threshold) still applies.
const RANDOM_SEED = 20261016

# ---- numeric constants (must match pinn_training_paper_safe.py) ------------
const mu        = 0.0143
const k_val     = 0.5
const d_val     = 0.1
const k_star    = 2.5
const d_star    = 0.2
const alpha1    = 0.1
const alpha2    = 0.2
const alpha3    = 0.5
const f_val     = 0.5
const theta_val = 1.0
const sigma_rel = 1.0
const N0        = 10000.0
const Lambda    = mu * N0
const omega_min = 1e-5   # fixed throughout

const a0_t      = 0.6
const b1_star   = (mu + k_val + a0_t) * (mu + d_val + a0_t) / k_val
const beta1_syn = 1.37 * b1_star          # RT_SYN = 1.37
const beta2_syn = 1.8  * (alpha1 + mu)    # RH_SYN = 1.8

# ---- symbolic unknown parameters -------------------------------------------
@parameters a0 a_max omega0 m beta1 beta2
@independent_variables t
@variables S(t) L(t) I(t) T(t) J1(t) J2(t) J3(t) A(t)
D = Differential(t)

N      = S + L + I + T + J1 + J2 + J3 + A
R_pool = N - I - J3 - A
B      = (I + J3) / N
gm     = (1 + m) * B / (1 + m * B)
aB     = a0 + (a_max - a0) * gm
omB    = omega0 + (omega_min - omega0) * gm
Jstar  = J1 + J2 + J3
tL     = aB * L / (1 + omB * L)
tI     = aB * I / (1 + omB * I)
tJ2    = aB * J2 / (1 + omB * J2)

# ---- full 8-state equations (symbolic beta1, beta2) ------------------------
eqs_full = [
    D(S)  ~ Lambda - beta1*(I+J3)/N*S - beta2*Jstar/R_pool*S - mu*S,
    D(L)  ~ beta1*(S+T)*(I+J3)/N - sigma_rel*beta2*L*Jstar/R_pool - (mu+k_val)*L - tL,
    D(I)  ~ k_val*L - (mu+d_val)*I - tI,
    D(T)  ~ tL + tI - beta1*T*(I+J3)/N - beta2*T*Jstar/R_pool - mu*T,
    D(J1) ~ beta2*(S+T)*Jstar/R_pool - theta_val*beta1*J1*(I+J3)/N - (alpha1+mu)*J1 + tJ2,
    D(J2) ~ sigma_rel*beta2*L*Jstar/R_pool + theta_val*beta1*J1*(I+J3)/N - (alpha2+mu+k_star)*J2 - tJ2,
    D(J3) ~ k_star*J2 - (alpha3+mu+d_star)*J3,
    D(A)  ~ alpha1*J1 + alpha2*J2 + alpha3*J3 - (mu+f_val)*A,
]

# ---- outputs (scalar factors 1e5 / 100 dropped; they are invertible) ------
@variables y1(t) y2(t) y3(t)
measured_ideal   = [y1 ~ (k_val*L + k_star*J2)/N, y2 ~ Jstar/N, y3 ~ aB*I/(1 + omB*I)]
measured_routine = [y1 ~ (k_val*L + k_star*J2)/N, y2 ~ Jstar/N]

# ---- Problem A: beta fixed at synthetic values -----------------------------
subs_A = Dict(beta1 => beta1_syn, beta2 => beta2_syn)
eqs_A  = [Symbolics.substitute(eq, subs_A) for eq in eqs_full]
ode_A  = ODESystem(eqs_A, t, name=:HIVTB_A)
params_A = [a0, a_max, omega0, m]

# ---- Problem B: beta free --------------------------------------------------
ode_B = ODESystem(eqs_full, t, name=:HIVTB_B)
params_B = [a0, a_max, omega0, m, beta1, beta2]

function run_local(ode, measured, params, label; problem="", measured_labels=String[])
    println("="^70); flush(stdout)
    println("LOCAL structural identifiability — ", label); flush(stdout)
    println("="^70); flush(stdout)
    res = assess_local_identifiability(
        ode,
        measured_quantities = measured,
        funcs_to_check = params,
        prob_threshold = 0.99,
        loglevel = Logging.Warn,
    )
    result_bool = Dict{String,Bool}()
    for (p, v) in res
        result_bool[string(p)] = v
        println("  ", string(p), "  =>  ", v); flush(stdout)
    end
    all_id = all(values(result_bool))
    println(); flush(stdout)
    return Dict(
        "label" => label,
        "problem" => problem,
        "measured_outputs" => measured_labels,
        "unknown_parameters" => string.(params),
        "result" => result_bool,
        "all_identifiable" => all_id,
    )
end

Random.seed!(RANDOM_SEED)
println("START"); flush(stdout)
configs = Dict{String,Any}[]
push!(configs, run_local(ode_A, measured_ideal,   params_A, "A  ideal (y1,y2,y3), generic x0"; problem="A", measured_labels=["y1","y2","y3"]))
push!(configs, run_local(ode_A, measured_routine, params_A, "A  routine (y1,y2), generic x0"; problem="A", measured_labels=["y1","y2"]))
push!(configs, run_local(ode_B, measured_ideal,   params_B, "B  ideal (y1,y2,y3), generic x0"; problem="B", measured_labels=["y1","y2","y3"]))
push!(configs, run_local(ode_B, measured_routine, params_B, "B  routine (y1,y2), generic x0"; problem="B", measured_labels=["y1","y2"]))

si_version = try
    string(pkgversion(StructuralIdentifiability))
catch
    "0.5.27"
end

output = Dict{String,Any}(
    "tool" => "StructuralIdentifiability.jl",
    "julia_version" => string(VERSION),
    "structural_identifiability_version" => si_version,
    "method" => "Xia-Moog local structural identifiability, generic initial condition (assess_local_identifiability, type=:SE, prob_threshold=0.99)",
    "random_seed" => RANDOM_SEED,
    "known_ic_note" => "known_ic variant omitted: v0.5.27 calls undefined _assess_local_identifiability_kic (bug); only generic-IC run archived.",
    "generated_at" => string(now()),
    "configurations" => configs,
)
mkpath(_RESULTS_DIR)
open(_OUT_PATH, "w") do io
    write(io, to_json(output))
end
println("WROTE ", _OUT_PATH); flush(stdout)
println("DONE"); flush(stdout)
