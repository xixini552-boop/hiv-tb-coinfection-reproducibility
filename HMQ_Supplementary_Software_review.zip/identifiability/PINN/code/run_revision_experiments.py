"""
Run noise-consistent identifiability experiments for BMB revision.

Experiments:
1. Relative-error objective x multiplicative noise x 20 MC (Problems A/B/C, H2/H3)
2. Multi-start profile for m (Problem A, 3 starts, relative objective)
3. Log-space objective x multiplicative noise x 20 MC (Problem B, H2) - optional对照

Results saved to PINN/results/identifiability_final/
"""
import sys
import os
import json
import time
import numpy as np

# Add code directory to path
CODE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CODE_DIR)
ROOT_DIR = os.path.abspath(os.path.join(CODE_DIR, "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT_DIR, "bifurcation", "code"))

from identifiability_ABC import (
    true_parameters,
    integrate_states,
    observations_from_states,
    run_noise_monte_carlo,
    profile_likelihood,
)

RESULTS_DIR = os.path.join(CODE_DIR, "..", "results", "identifiability_final")
os.makedirs(RESULTS_DIR, exist_ok=True)

# Force re-run even if output files exist (use --force flag)
FORCE = "--force" in sys.argv
RELATIVE_ONLY = "--relative-only" in sys.argv


def _option_value(flag, default=None):
    """Return the value following a simple ``--flag value`` CLI option."""
    if flag not in sys.argv:
        return default
    index = sys.argv.index(flag)
    if index + 1 >= len(sys.argv):
        raise ValueError(f"{flag} requires a value")
    return sys.argv[index + 1]


def get_target(outputs="H3"):
    """Generate synthetic target from true parameters."""
    t_eval = np.linspace(0, 14, 57)  # 14 years, quarterly
    true_p = true_parameters()
    states = integrate_states(t_eval, true_p)
    full_target = observations_from_states(states, true_p)
    if outputs == "H2":
        return t_eval, full_target[:, :2]
    return t_eval, full_target


def run_mc_experiment(problem, outputs, objective_type, noise_type="multiplicative",
                      n_realizations=20, n_starts=3, seed=42):
    """Run one MC experiment and save results."""
    tag = f"{objective_type}_{noise_type}_{outputs}_{problem}"
    outfile = os.path.join(RESULTS_DIR, f"{tag}.json")
    
    # Skip if already done (unless --force)
    if os.path.exists(outfile) and not FORCE:
        print(f"  [SKIP] {tag} already exists (use --force to re-run)")
        with open(outfile) as f:
            return json.load(f)
    
    print(f"  [RUN] {tag}...", flush=True)
    t0 = time.time()
    t_eval, target = get_target(outputs)
    
    result = run_noise_monte_carlo(
        problem=problem,
        t_eval=t_eval,
        target=target,
        n_realizations=n_realizations,
        n_starts=n_starts,
        noise_fraction=0.05,
        seed=seed,
        objective_type=objective_type,
        noise_type=noise_type,
    )
    
    elapsed = time.time() - t0
    result["elapsed_seconds"] = elapsed
    
    with open(outfile, "w") as f:
        json.dump(result, f, indent=2)
    
    m_med = result["aggregate"]["m"]["median_relative_error_pct"]
    print(f"  [DONE] {tag}: m median error = {m_med:.1f}% ({elapsed:.0f}s)", flush=True)
    return result


def run_profile_experiment(problem="A", n_starts=3, objective_type="relative"):
    """Run multi-start profile for m."""
    tag = f"profile_{objective_type}_{problem}_m_nstarts{n_starts}"
    outfile = os.path.join(RESULTS_DIR, f"{tag}.json")
    
    if os.path.exists(outfile) and not FORCE:
        print(f"  [SKIP] {tag} already exists (use --force to re-run)")
        return
    
    print(f"  [RUN] {tag}...", flush=True)
    t0 = time.time()
    t_eval, target = get_target("H3")
    
    result = profile_likelihood(
        problem=problem,
        t_eval=t_eval,
        target=target,
        n_points=9,
        parameters=["m"],
        n_starts=n_starts,
        objective_type=objective_type,
    )
    
    elapsed = time.time() - t0
    result["elapsed_seconds"] = elapsed
    
    with open(outfile, "w") as f:
        json.dump(result, f, indent=2)
    
    print(f"  [DONE] {tag} ({elapsed:.0f}s)", flush=True)


def main():
    print("=" * 60)
    print("BMB Revision - Noise-Consistent Identifiability Experiments")
    print("=" * 60)
    
    # Verify imports work
    print("\n[1/5] Verifying model...")
    t_eval, target = get_target("H3")
    print(f"  Time points: {len(t_eval)}, Target shape: {target.shape}")
    print(f"  True m: {true_parameters()['m']}")

    one_problem = _option_value("--problem")
    one_outputs = _option_value("--outputs")
    if one_problem or one_outputs:
        if one_problem not in {"A", "B", "C"} or one_outputs not in {"H2", "H3"}:
            raise ValueError("Single-case runs require --problem {A,B,C} and --outputs {H2,H3}")
        run_mc_experiment(one_problem, one_outputs, "relative", "multiplicative")
        return
    
    # Experiment 1: Relative-error objective (most critical)
    print("\n[2/5] Relative-error objective x multiplicative noise (CRITICAL)")
    for problem in ["A", "B", "C"]:
        for outputs in ["H2", "H3"]:
            run_mc_experiment(problem, outputs, "relative", "multiplicative")

    if RELATIVE_ONLY:
        print("\nRelative-noise experiments complete.")
        return

    # Experiment 2: Original range objective for comparison (if not already present)
    print("\n[3/5] Range-normalized objective (original, for comparison)")
    for problem in ["A", "B", "C"]:
        for outputs in ["H2", "H3"]:
            run_mc_experiment(problem, outputs, "range", "multiplicative")
    
    # Experiment 3: Additive-noise robustness (range objective, H3 only)
    print("\n[4/5] Additive-noise robustness (range x H3)")
    for problem in ["A", "B", "C"]:
        run_mc_experiment(problem, "H3", "range", "additive")
    
    # Experiment 4: Multi-start profile
    print("\n[5/5] Multi-start profile for m")
    run_profile_experiment("A", n_starts=3, objective_type="relative")
    run_profile_experiment("A", n_starts=3, objective_type="range")
    
    print("\n" + "=" * 60)
    print("ALL EXPERIMENTS COMPLETE")
    print(f"Results saved to: {RESULTS_DIR}")
    print("=" * 60)
    
    # Print summary comparison
    print("\n=== Summary: m median relative error (%) ===")
    print(f"{'Problem':<8} {'Outputs':<8} {'Range':<10} {'Relative':<10} {'Change':<10}")
    for problem in ["A", "B", "C"]:
        for outputs in ["H2", "H3"]:
            range_file = os.path.join(RESULTS_DIR, f"range_multiplicative_{outputs}_{problem}.json")
            rel_file = os.path.join(RESULTS_DIR, f"relative_multiplicative_{outputs}_{problem}.json")
            range_err = "N/A"
            rel_err = "N/A"
            change = "N/A"
            if os.path.exists(range_file):
                with open(range_file) as f:
                    range_err = f"{json.load(f)['aggregate']['m']['median_relative_error_pct']:.1f}"
            if os.path.exists(rel_file):
                with open(rel_file) as f:
                    rel_err = f"{json.load(f)['aggregate']['m']['median_relative_error_pct']:.1f}"
            if range_err != "N/A" and rel_err != "N/A":
                try:
                    change = f"{float(rel_err)-float(range_err):+.1f}"
                except:
                    pass
            print(f"{problem:<8} {outputs:<8} {range_err:<10} {rel_err:<10} {change:<10}")


if __name__ == "__main__":
    main()
