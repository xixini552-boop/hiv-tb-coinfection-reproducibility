"""
High-burden TB basin recovery experiment at Q=0.80 (inside bistability window).

Uses initial conditions that converge to the HIV-free TB-endemic attractor,
in contrast to the existing window pilot which converges to the TB-free
HIV-endemic attractor. 20 noise realisations, 5% multiplicative noise,
Problem A/H2 (theta_A unknown set).

Output:
  ../../identifiability/PINN/results/identifiability_final/window_Q080_H2_A_highburden.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

CODE = Path(__file__).resolve().parent
ROOT = CODE.parents[2]
COMMON_DIR = ROOT / "bifurcation" / "code"
if str(CODE) not in sys.path:
    sys.path.insert(0, str(CODE))
if str(COMMON_DIR) not in sys.path:
    sys.path.insert(0, str(COMMON_DIR))

import identifiability_ABC as abc

# Window coordinate Q=0.80 -> beta1 (same as existing pilot)
WINDOW_Q = 0.80
WINDOW_BETA1 = 1.0391942198578614

# High-burden TB basin initial conditions
HIGH_TB_PREV = 15.0   # percent
HIGH_HIV_PREV = 1.0   # percent


def test_convergence():
    """Verify that the high-burden seed converges to HIV-free TB-endemic."""
    abc.shared.beta1_syn = WINDOW_BETA1
    abc.TRUE_TB_PREV = HIGH_TB_PREV
    abc.TRUE_HIV_PREV = HIGH_HIV_PREV

    params = abc.true_parameters()
    x0 = abc.x0_from_parameters(params)
    print(f"Initial state: S={x0[0]:.0f}, L={x0[1]:.0f}, I={x0[2]:.0f}, "
          f"T={x0[3]:.0f}, J1={x0[4]:.0f}, J2={x0[5]:.0f}, J3={x0[6]:.0f}, A={x0[7]:.0f}",
          flush=True)
    print(f"Initial TB burden = {(x0[2]+x0[6])/np.sum(x0):.4f}", flush=True)
    print(f"Initial HIV burden = {(x0[4]+x0[5]+x0[6])/np.sum(x0):.4f}", flush=True)

    # Integrate to long time to find attractor
    t_long = np.linspace(0, 200, 201)
    states = abc.integrate_states(t_long, params)
    final = states[-1]
    N = np.sum(final)
    tb_burden = (final[2] + final[6]) / N
    hiv_burden = (final[4] + final[5] + final[6]) / N
    print(f"\nFinal state (t=200): S={final[0]:.1f}, L={final[1]:.1f}, I={final[2]:.1f}, "
          f"T={final[3]:.1f}, J1={final[4]:.1f}, J2={final[5]:.1f}, J3={final[6]:.1f}, A={final[7]:.1f}",
          flush=True)
    print(f"Final TB burden = {tb_burden:.6f}", flush=True)
    print(f"Final HIV burden = {hiv_burden:.6f}", flush=True)

    if tb_burden > 0.01 and hiv_burden < 1e-4:
        print("\n>>> CONFIRMED: converges to HIV-free TB-endemic (high-burden basin)", flush=True)
        return True
    else:
        print(f"\n>>> WARNING: not clearly in high-burden TB basin "
              f"(TB={tb_burden:.4f}, HIV={hiv_burden:.6f})", flush=True)
        return False


def run_experiment(n_realizations=20, n_starts=3, seed=42):
    """Run the high-burden basin recovery Monte Carlo."""
    abc.shared.beta1_syn = WINDOW_BETA1
    abc.TRUE_TB_PREV = HIGH_TB_PREV
    abc.TRUE_HIV_PREV = HIGH_HIV_PREV

    t_eval = np.linspace(0.0, 14.0, 57)
    params = abc.true_parameters()
    states = abc.integrate_states(t_eval, params)
    target = abc.observations_from_states(states, params)[:, :2]

    # Check data-generating trajectory basin
    final = states[-1]
    N = np.sum(final)
    tb_burden = (final[2] + final[6]) / N
    hiv_burden = (final[4] + final[5] + final[6]) / N
    print(f"\nData trajectory (t=14): TB burden={tb_burden:.6f}, HIV burden={hiv_burden:.6f}",
          flush=True)

    result = abc.run_noise_monte_carlo(
        problem="A",
        t_eval=t_eval,
        target=target,
        n_realizations=n_realizations,
        n_starts=n_starts,
        noise_fraction=0.05,
        seed=seed,
        objective_type="relative",
        noise_type="multiplicative",
    )

    # Add metadata
    result.update({
        "description": (
            "Restricted Problem A/H2 pilot at Q=0.80 inside the bistability "
            "window, with initial conditions in the HIV-free TB-endemic "
            "(high-burden) basin."
        ),
        "window_coordinate": "Q=R_TB|E2",
        "Q": WINDOW_Q,
        "beta1": WINDOW_BETA1,
        "beta2": float(params["beta2"]),
        "m_true": float(params["m"]),
        "observation_map": "H2",
        "sampling": "57 quarterly instantaneous points over 14 years",
        "noise_fraction": 0.05,
        "noise_type": "multiplicative Gaussian, clamped non-negative",
        "objective_type": "relative",
        "basin": "HIV-free TB-endemic (high-burden)",
        "initial_tb_prev_pct": HIGH_TB_PREV,
        "initial_hiv_prev_pct": HIGH_HIV_PREV,
        "data_trajectory_tb_burden": float(tb_burden),
        "data_trajectory_hiv_burden": float(hiv_burden),
        "seed": int(seed),
        "n_realizations": int(n_realizations),
        "n_starts_per_realization": int(n_starts),
    })

    # Summary stats
    m_hats = np.array([r["best_recovered"]["m"] for r in result["realizations"]])
    m_true = float(params["m"])
    rel_errors = np.abs(m_hats - m_true) / m_true
    median_rel_err = float(np.median(rel_errors))
    p05 = float(np.percentile(m_hats, 5))
    p95 = float(np.percentile(m_hats, 95))
    n_pass_5pct = int(np.sum(rel_errors < 0.05))
    n_at_bound = int(np.sum(m_hats <= abc.M_AT_LOWER_BAND))

    result["summary"] = {
        "m_true": m_true,
        "median_m_hat": float(np.median(m_hats)),
        "m_hat_p05": p05,
        "m_hat_p95": p95,
        "median_relative_error": median_rel_err,
        "median_relative_error_pct": median_rel_err * 100,
        "n_pass_5pct_screen": n_pass_5pct,
        "n_at_lower_bound_band": n_at_bound,
    }

    print(f"\n=== HIGH-BURDEN BASIN RESULTS ===", flush=True)
    print(f"m_true = {m_true}", flush=True)
    print(f"median m_hat = {np.median(m_hats):.4f}", flush=True)
    print(f"m_hat 5th-95th = [{p05:.4f}, {p95:.4f}]", flush=True)
    print(f"median relative error = {median_rel_err*100:.1f}%", flush=True)
    print(f"pass 5% screen: {n_pass_5pct}/{n_realizations}", flush=True)
    print(f"at lower bound band (m_hat <= 0.006): {n_at_bound}/{n_realizations}", flush=True)

    return result


if __name__ == "__main__":
    print("=== Step 1: Convergence test ===", flush=True)
    ok = test_convergence()
    if not ok:
        print("\nConvergence test failed. Adjust initial conditions.", flush=True)
        sys.exit(1)

    print("\n=== Step 2: Running recovery experiment (20 realizations) ===", flush=True)
    result = run_experiment(n_realizations=20, n_starts=3, seed=42)

    outdir = CODE.parent / "results" / "identifiability_final"
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / "window_Q080_H2_A_highburden.json"
    with open(outpath, "w") as f:
        json.dump(result, f, indent=2, default=str)
    print(f"\nSaved: {outpath}", flush=True)
