"""Restricted recovery pilot at a point inside the full-system window.

The six principal recovery experiments use the identifiability preset with
beta1=2.181, which corresponds to Q=R_TB|E2 approximately 1.68 and therefore
lies above the reported boundary-bistability window.  This pilot keeps the
same Problem A/H2 protocol but sets beta1 to the branch value at Q=0.80,
where the bistable window is reported in the bifurcation analysis.

The pilot is deliberately separate from the six prespecified experiments and
does not overwrite their JSON files.
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
from pathlib import Path

import numpy as np


CODE_DIR = Path(__file__).resolve().parent
ROOT_DIR = CODE_DIR.parents[2]
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))
COMMON_DIR = ROOT_DIR / "bifurcation" / "code"
if str(COMMON_DIR) not in sys.path:
    sys.path.insert(0, str(COMMON_DIR))

import identifiability_ABC as abc  # noqa: E402

common = importlib.import_module("00_common")


RESULT_DIR = ROOT_DIR / "identifiability" / "PINN" / "results" / "identifiability_final"
WINDOW_Q = 0.80
WINDOW_BETA1 = 1.0391942198578614


def _derive_bifurcation_diagnostics(realizations):
    """Evaluate the fitted local-direction quantities without refitting."""
    mu = float(common.P.mu)
    k = float(common.P.k)
    d = float(common.P.d)
    Lam = float(common.P.Lambda)

    def n_of_m(a0, a_max, omega0, m):
        term1 = 2.0 * a0 * omega0 * (
            ((mu + d + a0) / k) ** 2 + (mu + k + a0) / k
        )
        term2 = (
            2.0
            * mu
            * (mu + k + a0)
            * (mu + d + a0)
            * (mu + d + a0 + k)
            / (k * k * Lam)
        )
        term3 = (
            2.0
            * mu
            * (a_max - a0)
            * (2.0 * mu + k + d + 2.0 * a0)
            * (1.0 + m)
            / (k * Lam)
        )
        return float(term1 - term2 - term3)

    def m_critical(a0, a_max, omega0):
        n0 = n_of_m(a0, a_max, omega0, 0.0)
        denominator = (
            2.0
            * mu
            * (a_max - a0)
            * (2.0 * mu + k + d + 2.0 * a0)
        )
        if denominator <= 0.0:
            return float("nan")
        return float(k * Lam * n0 / denominator)

    for realization in realizations:
        recovered = realization["best_recovered"]
        a0 = float(recovered["a0"])
        a_max = float(recovered["a_max"])
        omega0 = float(recovered["omega0"])
        m = float(recovered["m"])
        realization["derived_bifurcation_diagnostics"] = {
            "s_a": float((a_max - a0) * (1.0 + m)),
            "N_m": n_of_m(a0, a_max, omega0, m),
            "m_c_TB": m_critical(a0, a_max, omega0),
        }


def _aggregate_derived(realizations):
    names = ("s_a", "N_m", "m_c_TB")
    aggregate = {}
    for name in names:
        values = np.asarray(
            [r["derived_bifurcation_diagnostics"][name] for r in realizations],
            dtype=float,
        )
        aggregate[name] = {
            "median": float(np.median(values)),
            "p05": float(np.percentile(values, 5)),
            "p95": float(np.percentile(values, 95)),
            "minimum": float(np.min(values)),
            "maximum": float(np.max(values)),
            "positive_count": int(np.sum(values > 0.0)),
            "total": int(values.size),
        }
    return aggregate


def run(n_realizations, n_starts, seed):
    abc.shared.beta1_syn = WINDOW_BETA1
    t_eval = np.linspace(0.0, 14.0, 57)
    params = abc.true_parameters()
    states = abc.integrate_states(t_eval, params)
    target = abc.observations_from_states(states, params)[:, :2]

    result = abc.run_noise_monte_carlo(
        problem="A",
        t_eval=t_eval,
        target=target,
        n_realizations=n_realizations,
        n_starts=n_starts,
        noise_fraction=0.05,
        seed=seed,
        objective_type="relative",
        noise_type="multiplicative",
    )
    _derive_bifurcation_diagnostics(result["realizations"])
    result.update(
        {
            "description": (
                "Restricted Problem A/H2 pilot at an interior point of the "
                "reported boundary-bistability window"
            ),
            "window_coordinate": "Q=R_TB|E2",
            "Q": WINDOW_Q,
            "beta1": WINDOW_BETA1,
            "beta2": float(params["beta2"]),
            "m_true": float(params["m"]),
            "observation_map": "H2",
            "sampling": "57 quarterly instantaneous points over 14 years",
            "noise_fraction": 0.05,
            "noise_type": "multiplicative Gaussian, clamped non-negative",
            "objective_type": "relative",
            "parameter_bounds": {
                "m": [abc.M_FIT_LOWER, abc.M_FIT_UPPER],
            },
            "initialization_protocol": (
                "First three deterministic Problem A starts in the audited "
                "experiment; the best objective is retained per realisation."
            ),
            "seed": int(seed),
            "n_realizations": int(n_realizations),
            "n_starts_per_realization": int(n_starts),
            "derived_bifurcation_aggregate": _aggregate_derived(
                result["realizations"]
            ),
            "scope": (
                "Single point inside the reported window; not a scan over the "
                "full window and not a cross-switch classification experiment."
            ),
        }
    )
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-realizations", type=int, default=20)
    parser.add_argument("--n-starts", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20260930)
    args = parser.parse_args()

    payload = run(
        n_realizations=args.n_realizations,
        n_starts=args.n_starts,
        seed=args.seed,
    )
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    outfile = RESULT_DIR / "window_Q080_H2_A.json"
    outfile.write_text(
        json.dumps(payload, indent=2, allow_nan=False),
        encoding="utf-8",
    )
    summary = payload["aggregate"]["m"]
    print(
        f"Saved {outfile}; median m_hat={summary['median_recovered']:.6g}, "
        f"median error={summary['median_relative_error_pct']:.2f}%, "
        f"within 5%={summary['within_5pct_count']}/"
        f"{summary['within_5pct_total']}",
        flush=True,
    )


if __name__ == "__main__":
    main()
