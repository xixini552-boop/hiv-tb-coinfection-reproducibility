"""
Identifiability branch for the three candidate inverse problems A/B/C.

This module deliberately imports the shared ODE and observation code from
``pinn_training_paper_safe.py`` instead of copying or changing the model.
The old PINN-C branch is not imported and no old result file is overwritten.

The default ``structure`` mode performs a generic local-rank screen with the
ideal instantaneous treatment-flow output requested for the new experiment:

    y1 = TB incidence = (k L + k* J2) / N * 1e5
    y2 = HIV prevalence = (J1 + J2 + J3) / N * 100
    y3 = a(B) I / (1 + omega(B) I)

The numerical rank screen is evidence about the sampled input-output map; it
is not claimed to be a formal differential-algebra proof.  The JSON output
also records a tool-ready structural-identifiability specification and the
external tools selected for independent verification.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares


# ---------------------------------------------------------------------------
# Shared model: this is the only source of the ODE and existing observations.
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[2]
CODE_DIR = ROOT / "PINN" / "code"
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import pinn_training_paper_safe as shared  # noqa: E402


OUT_DIR = ROOT / "PINN" / "results" / "identifiability_ABC"
OMEGA_MIN_FIXED = float(shared.TRUE_VALS["omega_min"])
TRUE_TB_PREV = 0.50
TRUE_HIV_PREV = 10.0
TRUE_M_OVERRIDE: float | None = None

# These optimizer-coordinate limits approximate the physical fit bounds.
Q_COORD_LOWER = -20.0
Q_COORD_UPPER = 20.0
M_FIT_LOWER = 0.001
M_FIT_UPPER = 10.0
# Bound-hit bands as reported in the manuscript (ESM Table 7): the lower
# edge is m_hat <= 0.006 and the upper edge is m_hat >= 9.9, i.e. about 1%
# of the prior range [0.001, 10]. Both basin pilots inherit these constants
# through the shared aggregate below.
M_AT_LOWER_BAND = 0.006
M_AT_UPPER_BAND = 9.9

PARAM_ORDER = (
    "a0",
    "a_max",
    "omega0",
    "m",
    "beta1",
    "beta2",
    "tb_prev",
    "hiv_prev",
)

PROBLEMS: dict[str, dict[str, Any]] = {
    "A": {
        "unknown": ["a0", "a_max", "omega0", "m"],
        "fixed": ["omega_min", "beta1", "beta2", "tb_prev", "hiv_prev"],
        "description": (
            "Ideal observations y1/y2/y3; healthcare response plus m unknown; "
            "transmission rates and seeded initial condition fixed."
        ),
    },
    "B": {
        "unknown": ["a0", "a_max", "omega0", "m", "beta1", "beta2"],
        "fixed": ["omega_min", "tb_prev", "hiv_prev"],
        "description": (
            "Ideal observations y1/y2/y3; healthcare response and constant "
            "transmission rates unknown; seeded initial condition fixed."
        ),
    },
    "C": {
        "unknown": [
            "a0",
            "a_max",
            "omega0",
            "m",
            "beta1",
            "beta2",
            "tb_prev",
            "hiv_prev",
        ],
        "fixed": ["omega_min"],
        "description": (
            "Ideal observations y1/y2/y3; healthcare response, constant "
            "transmission rates and two seeded initial-condition descriptors "
            "unknown."
        ),
    },
}


def _sigmoid(x: float | np.ndarray) -> float | np.ndarray:
    x_arr = np.asarray(x, dtype=float)
    out = np.empty_like(x_arr)
    pos = x_arr >= 0.0
    out[pos] = 1.0 / (1.0 + np.exp(-x_arr[pos]))
    exp_x = np.exp(x_arr[~pos])
    out[~pos] = exp_x / (1.0 + exp_x)
    if np.ndim(x) == 0:
        return float(out)
    return out


def _logit_fraction(fraction: float) -> float:
    f = float(np.clip(fraction, 1e-10, 1.0 - 1e-10))
    return float(np.log(f / (1.0 - f)))


def true_parameters() -> dict[str, float]:
    return {
        "a0": float(shared.TRUE_VALS["a0"]),
        "a_max": float(shared.TRUE_VALS["a_max"]),
        "omega0": float(shared.TRUE_VALS["omega0"]),
        "m": float(
            shared.TRUE_VALS["m"] if TRUE_M_OVERRIDE is None else TRUE_M_OVERRIDE
        ),
        "beta1": float(shared.beta1_syn),
        "beta2": float(shared.beta2_syn),
        "tb_prev": TRUE_TB_PREV,
        "hiv_prev": TRUE_HIV_PREV,
        "omega_min": OMEGA_MIN_FIXED,
    }


def q_bounds(names: Iterable[str]) -> tuple[np.ndarray, np.ndarray]:
    lower: list[float] = []
    upper: list[float] = []
    for name in names:
        if name in {"a0", "a_max", "omega0", "m"}:
            lower.append(float(Q_COORD_LOWER))
            upper.append(float(Q_COORD_UPPER))
        elif name in {"beta1", "beta2"}:
            lower.append(-2.0)
            upper.append(3.0)
        elif name in {"tb_prev", "hiv_prev"}:
            lower.append(-3.0)
            upper.append(3.0)
        else:
            raise KeyError(f"No transform bounds for {name!r}")
    return np.asarray(lower, dtype=float), np.asarray(upper, dtype=float)


def physical_to_q(params: dict[str, float], names: Iterable[str]) -> np.ndarray:
    """Map physical positive parameters to the bounded optimizer coordinates."""
    p = {k: float(v) for k, v in params.items()}
    result: list[float] = []
    for name in names:
        if name == "a0":
            f = (p[name] - shared.ParameterModule.A0_LO) / (
                shared.ParameterModule.A0_HI - shared.ParameterModule.A0_LO
            )
            result.append(_logit_fraction(f))
        elif name == "a_max":
            gap = shared.ParameterModule.AMAX_HI - p["a0"] - shared.ParameterModule.EPS_A
            f = (p[name] - p["a0"] - shared.ParameterModule.EPS_A) / max(gap, 1e-12)
            result.append(_logit_fraction(f))
        elif name == "omega0":
            f = (p[name] - shared.ParameterModule.OMEGA0_LO) / (
                shared.ParameterModule.OMEGA0_HI - shared.ParameterModule.OMEGA0_LO
            )
            result.append(_logit_fraction(f))
        elif name == "m":
            f = (p[name] - M_FIT_LOWER) / (M_FIT_UPPER - M_FIT_LOWER)
            result.append(_logit_fraction(f))
        elif name in {"beta1", "beta2", "tb_prev", "hiv_prev"}:
            result.append(float(np.log10(max(p[name], 1e-12))))
        else:
            raise KeyError(f"Unknown parameter {name!r}")
    return np.asarray(result, dtype=float)


def q_to_physical(q: Iterable[float], names: Iterable[str]) -> dict[str, float]:
    """Map optimizer coordinates to the physical parameter dictionary."""
    q_arr = np.asarray(list(q), dtype=float)
    names_list = list(names)
    if q_arr.size != len(names_list):
        raise ValueError("Coordinate length does not match parameter names")

    p = true_parameters()
    for value, name in zip(q_arr, names_list):
        if name == "a0":
            p[name] = float(
                shared.ParameterModule.A0_LO
                + (shared.ParameterModule.A0_HI - shared.ParameterModule.A0_LO)
                * _sigmoid(value)
            )
        elif name == "a_max":
            gap = max(
                shared.ParameterModule.AMAX_HI
                - p["a0"]
                - shared.ParameterModule.EPS_A,
                1e-12,
            )
            p[name] = float(
                p["a0"]
                + shared.ParameterModule.EPS_A
                + gap * _sigmoid(value)
            )
        elif name == "omega0":
            p[name] = float(
                shared.ParameterModule.OMEGA0_LO
                + (shared.ParameterModule.OMEGA0_HI - shared.ParameterModule.OMEGA0_LO)
                * _sigmoid(value)
            )
        elif name == "m":
            p[name] = float(
                M_FIT_LOWER + (M_FIT_UPPER - M_FIT_LOWER) * _sigmoid(value)
            )
        elif name in {"beta1", "beta2", "tb_prev", "hiv_prev"}:
            p[name] = float(10.0 ** value)
        else:
            raise KeyError(f"Unknown parameter {name!r}")
    return p


def x0_from_parameters(params: dict[str, float]) -> np.ndarray:
    return np.asarray(
        shared.make_seed(float(params["tb_prev"]), float(params["hiv_prev"])),
        dtype=float,
    )


def integrate_states(
    t_eval: np.ndarray,
    params: dict[str, float],
    x0: np.ndarray | None = None,
) -> np.ndarray:
    """Forward solve using the locked shared RHS."""
    t_values = np.asarray(t_eval, dtype=float).reshape(-1)
    if t_values.size == 0 or np.any(np.diff(t_values) < 0.0):
        raise ValueError("t_eval must be a non-empty sorted time grid")
    x_initial = x0_from_parameters(params) if x0 is None else np.asarray(x0, dtype=float)
    t_end = float(t_values[-1])
    sol = solve_ivp(
        lambda t, x: shared.rhs_full_np(
            t,
            x,
            float(params["beta1"]),
            float(params["beta2"]),
            float(params["a0"]),
            float(params["a_max"]),
            float(params["omega0"]),
            float(params["omega_min"]),
            float(params["m"]),
        ),
        (0.0, t_end),
        x_initial,
        t_eval=t_values,
        method="LSODA",
        rtol=1e-9,
        atol=1e-11,
        max_step=0.25,
    )
    if not sol.success or sol.y.shape[1] != t_values.size:
        raise RuntimeError(f"ODE integration failed: {sol.message}")
    states = sol.y.T
    if not np.all(np.isfinite(states)):
        raise RuntimeError("ODE integration returned non-finite states")
    return states


def treatment_flow(states: np.ndarray, params: dict[str, float]) -> np.ndarray:
    states = np.asarray(states, dtype=float)
    n_total = np.maximum(states.sum(axis=1), 1e-12)
    burden = (states[:, 2] + states[:, 6]) / n_total
    a_values, omega_values = shared.response_np(
        burden,
        float(params["a0"]),
        float(params["a_max"]),
        float(params["omega0"]),
        float(params["omega_min"]),
        float(params["m"]),
    )
    return a_values * states[:, 2] / (1.0 + omega_values * states[:, 2] + 1e-12)


def observations_from_states(states: np.ndarray, params: dict[str, float]) -> np.ndarray:
    """Return columns [TB incidence, HIV prevalence, instantaneous treatment flow]."""
    tb, hiv = shared.observables_numpy(np.asarray(states, dtype=float))
    y3 = treatment_flow(states, params)
    return np.column_stack((tb, hiv, y3))


def synthetic_truth(t_eval: np.ndarray) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
    params = true_parameters()
    states = integrate_states(np.asarray(t_eval, dtype=float), params)
    return states, observations_from_states(states, params), params


def output_scales(outputs: np.ndarray) -> np.ndarray:
    spread = np.ptp(np.asarray(outputs, dtype=float), axis=0)
    return np.maximum(spread, 1e-12)


def relative_weights(target: np.ndarray) -> np.ndarray:
    """Pointwise relative-error weights: 1/max(|y|, eps).

    Consistent with multiplicative Gaussian noise y_obs = y_true*(1+eps),
    for which Var(y_obs) ∝ y_true^2 and the Gaussian likelihood weights
    residuals by 1/y_true.
    """
    return 1.0 / np.maximum(np.abs(np.asarray(target, dtype=float)), 1e-6)


def log_residual(pred: np.ndarray, target: np.ndarray) -> np.ndarray:
    """Log-space residual: log(pred+eps) - log(target+eps).

    Exact for log-normal observation model; approximate for multiplicative
    Gaussian when the noise fraction is small.
    """
    eps = 1e-8
    return np.log(np.maximum(pred, eps)) - np.log(np.maximum(target, eps))


def flatten_outputs(outputs: np.ndarray) -> np.ndarray:
    # Match the order used in the sensitivity report: y1(t), y2(t), y3(t).
    return np.asarray(outputs, dtype=float).T.reshape(-1)


def normalized_sensitivity(
    t_eval: np.ndarray,
    params: dict[str, float],
    names: list[str],
    rel_step: float = 2e-5,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute S_(j,k),i = theta_i / y_j * dy_j/dtheta_i."""
    base_states = integrate_states(t_eval, params)
    base_output = observations_from_states(base_states, params)
    columns: list[np.ndarray] = []
    for name in names:
        theta = float(params[name])
        step = max(abs(theta) * rel_step, 1e-8)
        p_plus = dict(params)
        p_minus = dict(params)
        p_plus[name] = theta + step
        p_minus[name] = max(theta - step, 1e-12)
        # Keep a_max > a0 in the finite-difference pair.
        if name == "a0":
            p_plus["a0"] = min(p_plus["a0"], p_plus["a_max"] - 2e-3)
            p_minus["a0"] = min(p_minus["a0"], p_minus["a_max"] - 2e-3)
        if name == "a_max":
            p_plus["a_max"] = max(p_plus["a_max"], p_plus["a0"] + 2e-3)
            p_minus["a_max"] = max(p_minus["a_max"], p_minus["a0"] + 2e-3)
        y_plus = observations_from_states(integrate_states(t_eval, p_plus), p_plus)
        y_minus = observations_from_states(integrate_states(t_eval, p_minus), p_minus)
        derivative = (y_plus - y_minus) / (p_plus[name] - p_minus[name])
        scaled = derivative * theta / np.maximum(np.abs(base_output), 1e-12)
        columns.append(flatten_outputs(scaled))
    return np.column_stack(columns), base_output


def sensitivity_report(sensitivity: np.ndarray, names: list[str], rtol: float = 1e-8) -> dict[str, Any]:
    matrix = np.asarray(sensitivity, dtype=float)
    u, singular_values, vt = np.linalg.svd(matrix, full_matrices=False)
    del u
    s0 = float(singular_values[0]) if singular_values.size else 0.0
    tolerance = float(max(matrix.shape, default=1) * np.finfo(float).eps * max(s0, 1.0))
    rank = int(np.sum(singular_values > max(tolerance, rtol * max(s0, 1e-30))))
    if singular_values.size and singular_values[-1] > 0.0:
        condition = float(singular_values[0] / singular_values[-1])
        relative_min = float(singular_values[-1] / max(singular_values[0], 1e-30))
        min_vector = vt[-1]
    else:
        condition = float("inf")
        relative_min = 0.0
        min_vector = np.zeros(len(names), dtype=float)

    norms = np.linalg.norm(matrix, axis=0)
    corr = np.zeros((len(names), len(names)), dtype=float)
    for i in range(len(names)):
        for j in range(len(names)):
            if norms[i] > 0.0 and norms[j] > 0.0:
                corr[i, j] = float(np.dot(matrix[:, i], matrix[:, j]) / (norms[i] * norms[j]))
            else:
                corr[i, j] = np.nan

    return {
        "shape": [int(v) for v in matrix.shape],
        "parameter_names": list(names),
        "rank": rank,
        "n_parameters": len(names),
        "rank_tolerance": float(max(tolerance, rtol * max(s0, 1e-30))),
        "singular_values": [float(v) for v in singular_values],
        "condition_number": condition,
        "relative_smallest_singular_value": relative_min,
        "column_norms": {name: float(norms[i]) for i, name in enumerate(names)},
        "column_correlation": corr.tolist(),
        "minimum_singular_vector": {
            name: float(min_vector[i]) for i, name in enumerate(names)
        },
        "full_column_rank": bool(rank == len(names)),
    }


def _generic_parameter_draw(problem: str, rng: np.random.Generator) -> dict[str, float]:
    names = list(PROBLEMS[problem]["unknown"])
    q0 = physical_to_q(true_parameters(), names)
    lo, hi = q_bounds(names)
    q_draw = np.clip(q0 + rng.normal(0.0, 0.65, size=q0.size), lo + 1e-5, hi - 1e-5)
    return q_to_physical(q_draw, names)


def run_structure_screen(
    problem: str,
    t_eval: np.ndarray,
    n_draws: int,
    seed: int,
    rtol: float,
) -> dict[str, Any]:
    names = list(PROBLEMS[problem]["unknown"])
    rng = np.random.default_rng(seed)
    draw_reports: list[dict[str, Any]] = []
    for draw_index in range(n_draws):
        params = true_parameters() if draw_index == 0 else _generic_parameter_draw(problem, rng)
        sensitivity, outputs = normalized_sensitivity(t_eval, params, names)
        report = sensitivity_report(sensitivity, names, rtol=rtol)
        report.update(
            {
                "draw_index": draw_index,
                "parameter_values": {name: float(params[name]) for name in names},
                "output_ranges": {
                    f"y{j + 1}": [
                        float(np.min(outputs[:, j])),
                        float(np.max(outputs[:, j])),
                    ]
                    for j in range(outputs.shape[1])
                },
            }
        )
        draw_reports.append(report)

    n_params = len(names)
    ranks = [r["rank"] for r in draw_reports]
    relative_min = [r["relative_smallest_singular_value"] for r in draw_reports]
    m_idx = names.index("m") if "m" in names else None
    m_norms = [r["column_norms"]["m"] for r in draw_reports] if m_idx is not None else []
    if all(rank < n_params for rank in ranks):
        classification = "numerically_rank_deficient"
    elif min(relative_min) < 1e-6:
        classification = "numerically_full_rank_but_severely_ill_conditioned"
    else:
        classification = "numerically_locally_full_rank"

    return {
        "problem": problem,
        "description": PROBLEMS[problem]["description"],
        "unknown_parameters": names,
        "fixed_parameters": list(PROBLEMS[problem]["fixed"]),
        "time_grid": [float(v) for v in t_eval],
        "n_draws": int(n_draws),
        "draws": draw_reports,
        "aggregate": {
            "rank_values": ranks,
            "full_rank_count": int(sum(rank == n_params for rank in ranks)),
            "min_relative_smallest_singular_value": float(min(relative_min)),
            "median_relative_smallest_singular_value": float(np.median(relative_min)),
            "m_column_norm_values": [float(v) for v in m_norms],
            "classification": classification,
        },
        "interpretation": (
            "Generic finite-time sensitivity rank screen only; this does not "
            "constitute a formal structural-identifiability proof."
        ),
    }


def _start_grid(problem: str) -> list[dict[str, float]]:
    hc_starts = [
        {"a0": 0.30, "a_max": 0.90, "omega0": 0.0010, "m": 0.01},
        {"a0": 0.90, "a_max": 2.20, "omega0": 0.0080, "m": 0.05},
        {"a0": 1.30, "a_max": 3.50, "omega0": 0.0200, "m": 1.00},
    ]
    beta_starts = [
        {"beta1": shared.beta1_syn * 0.50, "beta2": shared.beta2_syn * 0.50},
        {"beta1": shared.beta1_syn * 0.80, "beta2": shared.beta2_syn * 1.20},
        {"beta1": shared.beta1_syn * 1.50, "beta2": shared.beta2_syn * 1.50},
    ]
    prev_starts = [
        {"tb_prev": 0.20, "hiv_prev": 5.0},
        {"tb_prev": 0.80, "hiv_prev": 15.0},
        {"tb_prev": 1.50, "hiv_prev": 20.0},
    ]
    starts: list[dict[str, float]] = []
    for hc in hc_starts:
        for bt in (beta_starts if problem in {"B", "C"} else [beta_starts[1]]):
            for pv in (prev_starts if problem == "C" else [prev_starts[1]]):
                p = true_parameters()
                p.update(hc)
                p.update(bt)
                p.update(pv)
                starts.append(p)
    return starts


def direct_fit(
    problem: str,
    t_eval: np.ndarray,
    target: np.ndarray,
    max_starts: int | None = None,
    objective_type: str = "range",
) -> dict[str, Any]:
    """Direct-ODE least-squares fit.

    objective_type:
      - "range": peak-to-peak range normalised residuals (original, homoscedastic)
      - "relative": pointwise relative-error residuals (consistent with multiplicative noise)
      - "log": log-space residuals (log-normal observation model)
    """
    names = list(PROBLEMS[problem]["unknown"])
    starts = _start_grid(problem)
    if max_starts is not None:
        starts = starts[: max(1, int(max_starts))]
    scales = output_scales(target)
    rel_w = relative_weights(target)
    lower, upper = q_bounds(names)
    true_p = true_parameters()
    results: list[dict[str, Any]] = []

    def residual(q: np.ndarray) -> np.ndarray:
        try:
            p = q_to_physical(q, names)
            pred_full = observations_from_states(integrate_states(t_eval, p), p)
            if target.ndim != 2 or target.shape[1] > pred_full.shape[1]:
                raise ValueError("Target output dimension exceeds model outputs")
            pred = pred_full[:, : target.shape[1]]
            if not np.all(np.isfinite(pred)):
                raise RuntimeError("non-finite output")
            if objective_type == "relative":
                return flatten_outputs((pred - target) * rel_w)
            elif objective_type == "log":
                return flatten_outputs(log_residual(pred, target))
            else:
                return flatten_outputs((pred - target) / scales)
        except Exception:
            return np.full(target.size, 1e6, dtype=float)

    for index, start in enumerate(starts, start=1):
        q0 = np.clip(physical_to_q(start, names), lower + 1e-6, upper - 1e-6)
        fit = least_squares(
            residual,
            q0,
            bounds=(lower, upper),
            method="trf",
            x_scale="jac",
            ftol=1e-11,
            xtol=1e-11,
            gtol=1e-11,
            max_nfev=1200,
        )
        recovered_all = q_to_physical(fit.x, names)
        recovered = {name: float(recovered_all[name]) for name in names}
        errors = {
            name: float(
                abs(recovered[name] - true_p[name])
                / max(abs(true_p[name]), 1e-12)
                * 100.0
            )
            for name in names
        }
        objective = float(2.0 * fit.cost)
        optimality = float(np.max(np.abs(fit.grad))) if hasattr(fit, "grad") and fit.grad is not None else float("nan")
        active_mask = [bool(x) for x in fit.active_mask] if hasattr(fit, "active_mask") else []
        results.append(
            {
                "start_index": index,
                "initial": {name: float(start[name]) for name in names},
                "recovered": recovered,
                "relative_error_pct": errors,
                "objective": objective,
                "optimizer_success": bool(fit.success),
                "recovery_success": bool(fit.success and max(errors.values()) < 5.0),
                "nfev": int(fit.nfev),
                "njev": int(fit.njev) if hasattr(fit, "njev") else -1,
                "status": int(fit.status) if hasattr(fit, "status") else -1,
                "optimality": optimality,
                "active_mask": active_mask,
                "active_lower_count": int(sum(1 for x in active_mask if x < 0)),
                "active_upper_count": int(sum(1 for x in active_mask if x > 0)),
                "message": str(fit.message),
            }
        )

    summary: dict[str, Any] = {}
    for name in names:
        values = np.asarray([r["recovered"][name] for r in results], dtype=float)
        errors = np.asarray([r["relative_error_pct"][name] for r in results], dtype=float)
        summary[name] = {
            "true": float(true_p[name]),
            "median_recovered": float(np.median(values)),
            "median_relative_error_pct": float(np.median(errors)),
            "max_relative_error_pct": float(np.max(errors)),
            "cv_pct": float(np.std(values) / max(abs(np.mean(values)), 1e-12) * 100.0),
            "success_rate_pct": float(np.mean(errors < 5.0) * 100.0),
        }
    return {
        "problem": problem,
        "unknown_parameters": names,
        "n_starts": len(results),
        "results": results,
        "summary": summary,
        "all_parameters_pass_5pct": bool(
            all(summary[name]["max_relative_error_pct"] < 5.0 for name in names)
        ),
    }


def noisy_outputs(
    outputs: np.ndarray,
    noise_fraction: float,
    rng: np.random.Generator,
) -> np.ndarray:
    noise = rng.normal(0.0, float(noise_fraction), size=np.asarray(outputs).shape)
    return np.maximum(np.asarray(outputs, dtype=float) * (1.0 + noise), 0.0)


def additive_noise_outputs(
    outputs: np.ndarray,
    noise_fraction: float,
    rng: np.random.Generator,
) -> np.ndarray:
    """Additive Gaussian noise with std = noise_fraction * channel mean."""
    out = np.asarray(outputs, dtype=float)
    channel_std = noise_fraction * np.maximum(np.mean(out, axis=0), 1e-6)
    noise = rng.normal(0.0, 1.0, size=out.shape) * channel_std[np.newaxis, :]
    return np.maximum(out + noise, 0.0)


def run_noise_monte_carlo(
    problem: str,
    t_eval: np.ndarray,
    target: np.ndarray,
    n_realizations: int,
    n_starts: int | None,
    noise_fraction: float,
    seed: int,
    objective_type: str = "range",
    noise_type: str = "multiplicative",
) -> dict[str, Any]:
    """Direct-ODE practical-identifiability screen under noise.

    noise_type: "multiplicative" (y*(1+eps)) or "additive" (y + eps*mean).
    objective_type: "range", "relative", or "log" (see direct_fit).
    """
    rng = np.random.default_rng(seed)
    names = list(PROBLEMS[problem]["unknown"])
    realizations: list[dict[str, Any]] = []
    for realization in range(1, int(n_realizations) + 1):
        if noise_type == "additive":
            observed = additive_noise_outputs(target, noise_fraction, rng)
        else:
            observed = noisy_outputs(target, noise_fraction, rng)
        fit = direct_fit(problem, t_eval, observed, max_starts=n_starts, objective_type=objective_type)
        best = min(fit["results"], key=lambda entry: entry["objective"])
        realizations.append(
            {
                "realization": realization,
                "best_start_index": best["start_index"],
                "best_objective": best["objective"],
                "best_recovered": best["recovered"],
                "best_relative_error_pct": best["relative_error_pct"],
                "best_recovery_success": best["recovery_success"],
                "all_starts": fit["results"],
            }
        )

    aggregate: dict[str, Any] = {}
    for name in names:
        errors = np.asarray(
            [entry["best_relative_error_pct"][name] for entry in realizations],
            dtype=float,
        )
        values = np.asarray(
            [entry["best_recovered"][name] for entry in realizations],
            dtype=float,
        )
        aggregate[name] = {
            "true": float(true_parameters()[name]),
            "median_recovered": float(np.median(values)),
            "p05_recovered": float(np.percentile(values, 5)),
            "p95_recovered": float(np.percentile(values, 95)),
            "min_recovered": float(np.min(values)),
            "max_recovered": float(np.max(values)),
            "median_relative_error_pct": float(np.median(errors)),
            "p05_relative_error_pct": float(np.percentile(errors, 5)),
            "p95_relative_error_pct": float(np.percentile(errors, 95)),
            "max_relative_error_pct": float(np.max(errors)),
            "cv_pct": float(np.std(values) / max(abs(np.mean(values)), 1e-12) * 100.0),
            "success_rate_pct": float(np.mean(errors < 5.0) * 100.0),
            "within_5pct_count": int(np.sum(errors < 5.0)),
            "within_5pct_total": int(errors.size),
        }
        if name == "m":
            from scipy.stats import beta

            successes = int(np.sum(errors < 5.0))
            n = int(errors.size)
            aggregate[name]["within_5pct_exact_95pct_ci"] = [
                0.0 if successes == 0 else float(beta.ppf(0.025, successes, n - successes + 1)),
                1.0 if successes == n else float(beta.ppf(0.975, successes + 1, n - successes)),
            ]
            # Bound-hit counts on the manuscript bands, so that both basin
            # pilots report the same criterion.
            aggregate[name]["n_at_lower_bound_band"] = int(
                np.sum(values <= M_AT_LOWER_BAND)
            )
            aggregate[name]["n_at_upper_bound_band"] = int(
                np.sum(values >= M_AT_UPPER_BAND)
            )
            aggregate[name]["n_at_bound_bands_total"] = int(values.size)
    return {
        "problem": problem,
        "noise_fraction": float(noise_fraction),
        "noise_type": f"{noise_type} Gaussian, clamped non-negative",
        "objective_type": objective_type,
        "n_realizations": int(n_realizations),
        "n_starts_per_realization": int(n_starts) if n_starts is not None else None,
        "initialization_protocol": (
            "Deterministic start grid from _start_grid; the best objective among "
            "the requested starts is retained for each noise realization."
        ),
        "aggregate": aggregate,
        "realizations": realizations,
    }


def _profile_grid(problem: str, parameter: str, n_points: int) -> np.ndarray:
    p = true_parameters()
    n = max(3, int(n_points))
    if parameter == "a0":
        lo = shared.ParameterModule.A0_LO + 2e-3
        hi = min(shared.ParameterModule.A0_HI - 2e-3, p["a_max"] - 2e-3)
        return np.linspace(lo, hi, n)
    if parameter == "a_max":
        lo = p["a0"] + shared.ParameterModule.EPS_A + 2e-3
        hi = shared.ParameterModule.AMAX_HI - 2e-3
        return np.linspace(lo, hi, n)
    if parameter == "omega0":
        lo = max(shared.ParameterModule.OMEGA0_LO * 1.01, p["omega0"] * 0.2)
        hi = min(shared.ParameterModule.OMEGA0_HI * 0.95, p["omega0"] * 5.0)
        return np.geomspace(lo, hi, n)
    if parameter == "m":
        lo = max(shared.ParameterModule.M_LO * 1.01, p["m"] * 0.1)
        hi = min(shared.ParameterModule.M_HI * 0.95, p["m"] * 10.0)
        return np.geomspace(lo, hi, n)
    if parameter in {"beta1", "beta2", "tb_prev", "hiv_prev"}:
        lo = p[parameter] * 0.1
        hi = p[parameter] * 10.0
        return np.geomspace(lo, hi, n)
    raise KeyError(parameter)


def _q_to_physical_with_fixed(
    q_free: np.ndarray,
    problem_names: list[str],
    free_names: list[str],
    fixed_name: str,
    fixed_value: float,
) -> dict[str, float]:
    fixed_base = true_parameters()
    fixed_base[fixed_name] = float(fixed_value)
    q_full = physical_to_q(fixed_base, problem_names)
    free_positions = {name: i for i, name in enumerate(free_names)}
    full_positions = {name: i for i, name in enumerate(problem_names)}
    for name, free_index in free_positions.items():
        q_full[full_positions[name]] = float(q_free[free_index])
    return q_to_physical(q_full, problem_names)


def profile_likelihood(
    problem: str,
    t_eval: np.ndarray,
    target: np.ndarray,
    n_points: int = 9,
    parameters: Iterable[str] | None = None,
    n_starts: int = 3,
    objective_type: str = "range",
) -> dict[str, Any]:
    """One-dimensional least-squares profiles for selected unknown parameters.

    ``parameters`` is an optional subset used to make high-resolution profiles
    practical (for example, profiling only ``m``).  The model and objective
    are unchanged; omitting it preserves the original all-parameter behavior.

    Each profile point uses ``n_starts`` optimizer starts and retains the best
    objective. This is a profile-objective diagnostic, not a likelihood-calibrated
    confidence interval.
    """
    names = list(PROBLEMS[problem]["unknown"])
    if parameters is None:
        profile_names = names
    else:
        profile_names = list(parameters)
        unknown_set = set(names)
        invalid = [name for name in profile_names if name not in unknown_set]
        if invalid:
            raise ValueError(
                f"Profile parameters {invalid!r} are not unknown in problem {problem}"
            )
        if not profile_names:
            raise ValueError("At least one profile parameter is required")
    scales = output_scales(target)
    rel_w = relative_weights(target)
    true_p = true_parameters()
    profiles: dict[str, Any] = {}

    for fixed_name in profile_names:
        free_names = [name for name in names if name != fixed_name]
        lower, upper = q_bounds(free_names)
        values = _profile_grid(problem, fixed_name, n_points)
        rows: list[dict[str, Any]] = []
        # Multi-start grid: draw n_starts starting points with profile param fixed
        base_starts = _start_grid(problem)[: max(1, int(n_starts))]
        for fixed_value in values:
            best_obj = float("inf")
            best_fit = None
            best_start_idx = 0
            for start_idx, start in enumerate(base_starts, start=1):
                p0 = dict(start)
                p0[fixed_name] = float(fixed_value)
                q0 = np.clip(
                    physical_to_q(p0, free_names),
                    lower + 1e-6,
                    upper - 1e-6,
                )

                def residual(q: np.ndarray) -> np.ndarray:
                    try:
                        p_fit = _q_to_physical_with_fixed(
                            q, names, free_names, fixed_name, float(fixed_value)
                        )
                        pred_full = observations_from_states(
                            integrate_states(t_eval, p_fit), p_fit
                        )
                        if target.ndim != 2 or target.shape[1] > pred_full.shape[1]:
                            raise ValueError("Target output dimension exceeds model outputs")
                        pred = pred_full[:, : target.shape[1]]
                        if not np.all(np.isfinite(pred)):
                            raise RuntimeError("non-finite output")
                        if objective_type == "relative":
                            return flatten_outputs((pred - target) * rel_w)
                        elif objective_type == "log":
                            return flatten_outputs(log_residual(pred, target))
                        else:
                            return flatten_outputs((pred - target) / scales)
                    except Exception:
                        return np.full(target.size, 1e6, dtype=float)

                fit = least_squares(
                    residual,
                    q0,
                    bounds=(lower, upper),
                    method="trf",
                    x_scale="jac",
                    ftol=1e-10,
                    xtol=1e-10,
                    gtol=1e-10,
                    max_nfev=1000,
                )
                obj = float(2.0 * fit.cost)
                if obj < best_obj:
                    best_obj = obj
                    best_fit = fit
                    best_start_idx = start_idx
            rows.append(
                {
                    "fixed_value": float(fixed_value),
                    "objective": best_obj,
                    "optimizer_success": bool(best_fit.success),
                    "nfev": int(best_fit.nfev),
                    "best_start_index": best_start_idx,
                    "n_starts_tried": len(base_starts),
                }
            )
        objectives = np.asarray([row["objective"] for row in rows], dtype=float)
        min_index = int(np.argmin(objectives))
        profiles[fixed_name] = {
            "true_value": float(true_p[fixed_name]),
            "rows": rows,
            "minimum": rows[min_index],
            "objective_at_true_interpolated": float(
                min(
                    rows,
                    key=lambda row: abs(row["fixed_value"] - true_p[fixed_name]),
                )["objective"]
            ),
            "finite_minimum_inside_grid": bool(
                0 < min_index < len(rows) - 1
            ),
        }

    return {
        "problem": problem,
        "unknown_parameters": names,
        "profile_parameters": profile_names,
        "time_points": int(len(t_eval)),
        "n_profile_points": int(n_points),
        "profiles": profiles,
        "interpretation": (
            "A finite interior minimum supports practical information about a "
            "parameter; a boundary minimum or a flat profile is evidence of "
            "practical non-identifiability, not a structural proof."
        ),
    }


def structural_input_spec() -> dict[str, Any]:
    return {
        "model_source": str((CODE_DIR / "pinn_training_paper_safe.py").resolve()),
        "model_source_sha256": hashlib.sha256(
            (CODE_DIR / "pinn_training_paper_safe.py").read_bytes()
        ).hexdigest(),
        "state_order": ["S", "L", "I", "T", "J1", "J2", "J3", "A"],
        "outputs": {
            "y1": "(k*L + k_star*J2)/N*100000",
            "y2": "(J1 + J2 + J3)/N*100",
            "y3": "a(B)*I/(1 + omega(B)*I)",
            "B": "(I + J3)/N",
            "a(B)": "a0 + (a_max-a0)*(1+m)*B/(1+m*B)",
            "omega(B)": "omega0 + (omega_min-omega0)*(1+m)*B/(1+m*B)",
        },
        "problems": PROBLEMS,
        "fixed_values": {
            "omega_min": OMEGA_MIN_FIXED,
            "beta1": float(shared.beta1_syn),
            "beta2": float(shared.beta2_syn),
            "tb_prev": TRUE_TB_PREV,
            "hiv_prev": TRUE_HIV_PREV,
        },
        "external_verification": [
            {
                "name": "StructuralIdentifiability.jl",
                "url": "https://github.com/SciML/StructuralIdentifiability.jl",
                "license": "MIT",
                "role": "formal local/global structural identifiability for ODE outputs",
            },
            {
                "name": "STRIKE-GOLDD",
                "url": "https://github.com/afvillaverde/strike-goldd",
                "license": "GPL-3.0",
                "role": "independent MATLAB symbolic observability/identifiability check",
            },
        ],
        "code_reuse_candidates": [
            {
                "name": "PINN-COVID",
                "url": "https://github.com/ehsankharazmi/PINN-COVID",
                "license": "MIT",
                "decision": "reference_only",
                "reason": (
                    "The paper's released TensorFlow PINN code uses a different "
                    "COVID compartment model and time-varying neural functions; "
                    "it is not a drop-in A/B/C inverse solver."
                ),
            },
            {
                "name": "pyPESTO",
                "url": "https://github.com/ICB-DCM/pyPESTO",
                "license": "BSD-3-Clause",
                "decision": "later_optional_reference",
                "reason": (
                    "Useful for profile likelihood and uncertainty workflows, "
                    "but adding it now would obscure the locked-model structural "
                    "screen; the current branch keeps the direct ODE objective "
                    "self-contained."
                ),
            },
        ],
        "caveat": (
            "C includes two unknown seeded initial-condition descriptors. "
            "The Python generic-rank screen handles them directly; an exact "
            "external structural tool must represent their initial-state map "
            "explicitly rather than silently treating all eight initial states "
            "as independent parameters."
        ),
    }


def consistency_checks() -> dict[str, Any]:
    t_fine = np.linspace(0.0, float(shared.T_MAX), int(shared.T_MAX * 100) + 1)
    _, _, _, _, x0_ref, t_ref, states_ref = shared._get_ode_diag_data_3obs()
    params = true_parameters()
    states_new = integrate_states(t_ref, params, x0=x0_ref)
    output_new = observations_from_states(states_new, params)
    tb_ref, hiv_ref = shared.observables_numpy(states_ref)
    output_ref = np.column_stack((tb_ref, hiv_ref, treatment_flow(states_ref, params)))
    state_abs = np.max(np.abs(states_new - states_ref))
    state_scale = np.maximum(np.abs(states_ref), 1.0)
    output_diff = np.abs(output_new - output_ref)
    output_scale = np.maximum(np.abs(output_ref), 1.0)
    state_rel = float(np.max(np.abs(states_new - states_ref) / state_scale))
    output_rel = float(np.max(output_diff / output_scale))
    return {
        "shared_model_path": str(Path(shared.__file__).resolve()),
        "shared_model_sha256": hashlib.sha256(Path(shared.__file__).read_bytes()).hexdigest(),
        "reference_grid_points": int(len(t_ref)),
        "state_max_abs_difference": float(state_abs),
        "state_max_relative_difference": state_rel,
        "output_max_abs_difference": float(np.max(output_diff)),
        "output_max_relative_difference": output_rel,
        "output_columns": ["tb_incidence", "hiv_prevalence", "instantaneous_treatment_flow"],
        "instantaneous_flow_min": float(np.min(output_new[:, 2])),
        "instantaneous_flow_max": float(np.max(output_new[:, 2])),
        "passed": bool(state_rel < 1e-6 and output_rel < 1e-6),
        "note": "The new branch calls the locked shared RHS and output operator; no model equation was edited.",
    }


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return [_jsonable(v) for v in value.tolist()]
    if isinstance(value, (np.floating, np.integer, np.bool_)):
        return value.item()
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mode",
        choices=["consistency", "structure", "fit", "noise", "profile", "all"],
        default="structure",
    )
    parser.add_argument("--out-dir", type=Path, default=OUT_DIR)
    parser.add_argument("--n-draws", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260811)
    parser.add_argument("--sensitivity-rtol", type=float, default=1e-8)
    parser.add_argument("--max-starts", type=int, default=None)
    parser.add_argument("--n-realizations", type=int, default=20)
    parser.add_argument("--noise-fraction", type=float, default=0.05)
    parser.add_argument(
        "--true-m",
        type=float,
        default=None,
        help="Synthetic generating value of m for fit/noise/profile modes.",
    )
    parser.add_argument("--profile-points", type=int, default=9)
    parser.add_argument(
        "--profile-parameter",
        choices=["all", *PARAM_ORDER],
        default="all",
        help="Profile one unknown parameter or all parameters (default).",
    )
    parser.add_argument(
        "--q-lower",
        type=float,
        default=-20.0,
        help=(
            "Lower bound for transformed healthcare parameters; -20 closely "
            "approximates the physical lower bounds."
        ),
    )
    parser.add_argument("--problem", choices=["A", "B", "C", "all"], default="all")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    global Q_COORD_LOWER, TRUE_M_OVERRIDE
    if not np.isfinite(args.q_lower) or args.q_lower >= Q_COORD_UPPER:
        raise ValueError("--q-lower must be finite and smaller than the upper bound")
    Q_COORD_LOWER = float(args.q_lower)
    if args.true_m is not None:
        if not np.isfinite(args.true_m) or args.true_m <= 0.0:
            raise ValueError("--true-m must be a finite positive value")
        TRUE_M_OVERRIDE = float(args.true_m)
    args.out_dir.mkdir(parents=True, exist_ok=True)
    selected_problems = (
        (args.problem,) if args.problem in {"A", "B", "C"} else ("A", "B", "C")
    )
    payload: dict[str, Any] = {
        "analysis": "A/B/C identifiability branch",
        "status": "new_branch_only",
        "model_modified": False,
        "old_pinn_branch_run": False,
        "old_results_overwritten": False,
        "optimizer_coordinates": {
            "q_lower": float(Q_COORD_LOWER),
            "q_upper": float(Q_COORD_UPPER),
            "m_fit_bounds": [M_FIT_LOWER, M_FIT_UPPER],
            "m_effective_bounds": [
                M_FIT_LOWER
                + (M_FIT_UPPER - M_FIT_LOWER) * _sigmoid(Q_COORD_LOWER),
                M_FIT_LOWER
                + (M_FIT_UPPER - M_FIT_LOWER) * _sigmoid(Q_COORD_UPPER),
            ],
            "note": "transformed-coordinate bounds approximate the stated physical fit bounds",
        },
        "synthetic_truth_override": {
            "m": None if TRUE_M_OVERRIDE is None else float(TRUE_M_OVERRIDE),
        },
        "structural_input": structural_input_spec(),
    }

    if args.mode in {"consistency", "structure", "all"}:
        payload["consistency"] = consistency_checks()

    if args.mode in {"structure", "all"}:
        t_dense = np.linspace(0.0, float(shared.T_MAX), int(shared.T_MAX * 10) + 1)
        t_annual = np.arange(0.0, float(shared.T_MAX) + 1.0, 1.0)
        structure: dict[str, Any] = {}
        for offset, problem in enumerate(selected_problems):
            structure[problem] = {
                "dense_grid": run_structure_screen(
                    problem,
                    t_dense,
                    max(1, int(args.n_draws)),
                    int(args.seed) + offset * 101,
                    float(args.sensitivity_rtol),
                ),
                "annual_grid": run_structure_screen(
                    problem,
                    t_annual,
                    max(1, int(args.n_draws)),
                    int(args.seed) + offset * 101 + 33,
                    float(args.sensitivity_rtol),
                ),
            }
        payload["structure_screen"] = structure

    if args.mode in {"fit", "all"}:
        t_annual = np.arange(0.0, float(shared.T_MAX) + 1.0, 1.0)
        _, target, _ = synthetic_truth(t_annual)
        payload["direct_ode_noise0"] = {
            problem: direct_fit(problem, t_annual, target, args.max_starts)
            for problem in selected_problems
        }

    if args.mode == "noise":
        t_annual = np.arange(0.0, float(shared.T_MAX) + 1.0, 1.0)
        _, target, _ = synthetic_truth(t_annual)
        payload["direct_ode_noise5pct"] = {
            problem: run_noise_monte_carlo(
                problem,
                t_annual,
                target,
                n_realizations=max(1, int(args.n_realizations)),
                n_starts=args.max_starts,
                noise_fraction=float(args.noise_fraction),
                seed=int(args.seed) + i * 1009,
            )
            for i, problem in enumerate(selected_problems)
        }

    if args.mode == "profile":
        t_annual = np.arange(0.0, float(shared.T_MAX) + 1.0, 1.0)
        _, target, _ = synthetic_truth(t_annual)
        profile_parameters = (
            None if args.profile_parameter == "all" else [args.profile_parameter]
        )
        payload["direct_ode_profiles"] = {
            problem: profile_likelihood(
                problem,
                t_annual,
                target,
                n_points=max(3, int(args.profile_points)),
                parameters=profile_parameters,
            )
            for problem in selected_problems
        }

    problem_suffix = "" if args.problem == "all" else f"_{args.problem}"
    out_path = args.out_dir / f"identifiability_ABC_{args.mode}{problem_suffix}.json"
    out_path.write_text(json.dumps(_jsonable(payload), indent=2), encoding="utf-8")
    print(f"Saved: {out_path.resolve()}")
    if "consistency" in payload:
        print(f"Consistency passed: {payload['consistency']['passed']}")
    if "structure_screen" in payload:
        for problem in selected_problems:
            dense = payload["structure_screen"][problem]["dense_grid"]["aggregate"]
            annual = payload["structure_screen"][problem]["annual_grid"]["aggregate"]
            print(
                f"{problem}: dense ranks={dense['rank_values']} "
                f"classification={dense['classification']}; "
                f"annual ranks={annual['rank_values']} "
                f"classification={annual['classification']}"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
