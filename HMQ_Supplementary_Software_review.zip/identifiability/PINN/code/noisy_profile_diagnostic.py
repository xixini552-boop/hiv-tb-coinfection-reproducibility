"""
Noisy profile-objective diagnostic for m.

Runs profile_likelihood on REPRESENTATIVE NOISY datasets (multiplicative 5%)
with the relative-error objective (noise-consistent). For each of several
noise seeds, fixes m at 9 log-spaced values, re-optimizes remaining unknowns
with 3 starts, and records the objective profile.

A flat objective across a wide m range indicates poor practical recovery.
Output: identifiability/PINN/results/identifiability_final/noisy_profile_diagnostic.json
"""
import sys, os, json
import numpy as np

ROOT = os.path.abspath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "identifiability", "PINN", "code"))
sys.path.insert(0, os.path.join(ROOT, "bifurcation", "code"))

import identifiability_ABC as abc
from run_revision_experiments import get_target

OUT = os.path.join(ROOT, "identifiability", "PINN", "results",
                   "identifiability_final", "noisy_profile_diagnostic.json")


def run_one(seed, t_eval, target_true, n_points=9, n_starts=3):
    rng = np.random.default_rng(seed)
    noisy = target_true * (1 + 0.05 * rng.standard_normal(target_true.shape))
    res = abc.profile_likelihood(
        "A", t_eval, noisy, n_points=n_points, parameters=["m"],
        n_starts=n_starts, objective_type="relative",
    )
    rows = res["profiles"]["m"]["rows"]
    fixed = [r["fixed_value"] for r in rows]
    objs = [r["objective"] for r in rows]
    return fixed, objs


def main():
    print("=" * 64)
    print("Noisy profile-objective diagnostic (Problem A, H3, relative)")
    print("=" * 64)

    t_eval, target = get_target("H3")
    true_m = abc.true_parameters()["m"]
    print(f"time points={len(t_eval)}, true m={true_m}")

    seeds = [42, 123, 7]
    all_runs = []
    for seed in seeds:
        print(f"\n--- noise seed {seed} (9 points x 3 starts) ---", flush=True)
        fixed, objs = run_one(seed, t_eval, target)
        finite = [(m, o) for m, o in zip(fixed, objs) if np.isfinite(o) and o < 1e12]
        print(f"{'m':>9} {'objective':>16}")
        for m, o in zip(fixed, objs):
            mark = " *" if abs(m - true_m) / true_m < 0.15 else ""
            print(f"{m:>9.4f} {o:>16.6g}{mark}")
        if finite:
            omin = min(o for _, o in finite)
            omax = max(o for _, o in finite)
            # flat region: within 10% of min
            tol = omin + 0.10 * (omax - omin)
            flat = [m for m, o in finite if o <= tol]
            print(f"finite range: m in [{min(m for m,_ in finite):.4f},"
                  f"{max(m for m,_ in finite):.4f}], "
                  f"flat(10%) span [{min(flat):.4f},{max(flat):.4f}]")
            all_runs.append({"seed": seed, "fixed": fixed, "objectives": objs,
                             "flat_range": [min(flat), max(flat)]})

    # Aggregate: how wide is the flat region relative to true m
    summary = []
    for run in all_runs:
        lo, hi = run["flat_range"]
        summary.append({
            "seed": run["seed"],
            "flat_lower": float(lo), "flat_upper": float(hi),
            "true_m_in_flat": bool(lo <= true_m <= hi),
            "flat_width_ratio": float(hi / lo) if lo > 0 else None,
        })
    print("\n=== Summary ===")
    for s in summary:
        print(f"  seed {s['seed']}: flat [{s['flat_lower']:.4f},"
              f"{s['flat_upper']:.4f}], true m in flat: {s['true_m_in_flat']}")

    out = {
        "configuration": {
            "problem": "A", "outputs": "H3", "objective": "relative",
            "noise": "multiplicative 5%", "n_points": 9, "n_starts": 3,
            "seeds": seeds, "true_m": float(true_m),
            "note": "Profile-objective diagnostic on noisy realizations; "
                    "not a likelihood-calibrated confidence interval.",
        },
        "runs": all_runs,
        "summary": summary,
    }
    with open(OUT, "w") as f:
        json.dump(out, f, indent=2)
    print(f"\nSaved: {OUT}")


if __name__ == "__main__":
    main()
