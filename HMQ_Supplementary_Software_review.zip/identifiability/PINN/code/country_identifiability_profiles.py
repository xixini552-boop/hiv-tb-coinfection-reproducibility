"""Reproduce the archived country observation-design profiles.

Two exploratory branches are written, both of which are diagnostics of
observation design rather than calibration studies:

1. ``identifiability_country_profiles_with_params``
   Eight-parameter country fit (``a0, a_max, omega0, m, beta1, beta2,
   tb_prev, hiv_prev``) to the two archived outputs (WHO TB incidence and
   UNAIDS HIV prevalence, 2010-2024), followed by a 15-point profile of the
   response slope ``m``.

2. ``identifiability_country_treatment_proxy_reduced``
   The same fit with the country-reported annual treatment-cohort record
   added as a shape-only proxy observation (``newrel_coh`` normalised by its
   own country mean over 2012-2023), followed by a seven-point profile of
   ``m``. This branch is the archived *reduced* variant: it keeps only the
   first Control-A transmission start crossed with the three initial-prevalence
   seeds (three starts), whereas the direct branch uses the full 3 x 3 grid
   (nine starts).

Both branches are exploratory.  Every unconstrained fit terminates at a
parameter bound, including the bound of ``m`` or ``a_max``, and no result
reported in the manuscript or supplementary information is derived from these
fits.  The script is deterministic: it uses the archived start grid, the
locked shared ODE (``pinn_training_paper_safe.rhs_full_np``), and the same
observation operator as the synthetic identifiability branch.

By default each start receives a single trust-region pass, which is the
protocol that produced the archived files.  Pass ``--polish`` to add a second
pass from each solution to the same objective; the archived numbers do not use
it.

Reproduction fidelity.  The direct branch is exact at the level of the
objective: evaluating this script's residual at the archived best-fit
parameters returns the archived objective to machine precision, and the
refitted values agree with the archive to about 1e-7 relative (up to 1e-3 for
individual profile points, because that surface is extremely flat and a point
can settle on a marginally different local optimum).

The treatment-proxy branch could not be reconstructed to the same precision.
Its producer script is absent from the archived tree and from the earlier
working copies, so the branch was rebuilt from the archived JSON itself (start
grid, bounds, parameterisation, proxy window and observed-proxy
normalisation).  The schema, the protocol and the qualitative result match,
but the archived best-fit parameters do not evaluate to the archived objective
under this residual definition, so a detail of the original proxy residual is
unrecoverable; the objectives agree to within about 6e-2 relative.  In both
branches every unconstrained fit terminates at a parameter bound and the ``m``
profile minimum sits on the edge of the grid, which is the reading the
manuscript uses.  No reported result depends on either file.

One field is not reproduced literally: the archived ``data_file`` values
recorded ``D:\\TB-HIV\\PINN\\data\\...``, a path that no longer exists.  The
script writes the archive-relative path instead, namely
``identifiability/PINN/data/...``.

Usage (from the archive root holding ``identifiability/``):

    python identifiability/PINN/code/country_identifiability_profiles.py
    python identifiability/PINN/code/country_identifiability_profiles.py --countries Kenya Portugal
    python identifiability/PINN/code/country_identifiability_profiles.py --polish
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

CODE_DIR = Path(__file__).resolve().parent
PINN_DIR = CODE_DIR.parent
ROOT = PINN_DIR.parent.parent
DATA_DIR = PINN_DIR / "data"
DIRECT_DIR = PINN_DIR / "results" / "identifiability_country_profiles_with_params"
PROXY_DIR = PINN_DIR / "results" / "identifiability_country_treatment_proxy_reduced"

if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import pinn_training_paper_safe as shared  # noqa: E402

COUNTRIES = {
    "South Africa": "South_Africa_augmented_TB_HIV.csv",
    "Kenya": "Kenya_augmented_TB_HIV.csv",
    "Thailand": "Thailand_augmented_TB_HIV.csv",
    "Portugal": "Portugal_augmented_TB_HIV.csv",
}

# Observation window of the archived country tables.
YEARS = tuple(range(2010, 2025))
T_GRID = np.arange(float(len(YEARS)))

# Treatment-cohort proxy window (``newrel_coh`` is reported for 2012-2023).
PROXY_YEARS = tuple(range(2012, 2024))
PROXY_T_INDEX = tuple(y - YEARS[0] for y in PROXY_YEARS)

PARAM_ORDER = (
    "a0",
    "a_max",
    "omega0",
    "m",
    "beta1",
    "beta2",
    "tb_prev",
    "hiv_prev",
)

# Hard biological bounds, mirrored from the PINN ParameterModule.
A0_LO, A0_HI = 0.01, 3.0
AMAX_HI = 5.0
OMEGA0_LO, OMEGA0_HI = 1e-5, 0.1
EPS_A = 1e-3
M_LO, M_HI = 0.001, 30.0
OMEGA_MIN = float(shared.TRUE_VALS["omega_min"])

# Optimiser-coordinate limits for the four transformed healthcare parameters.
Q_COORD_LOWER, Q_COORD_UPPER = -20.0, 20.0
LOG_COORD_LOWER, LOG_COORD_UPPER = -2.0, 3.0
INIT_COORD_LOWER, INIT_COORD_UPPER = -3.0, 3.0

# Seeded initial-condition descriptors are anchored to the first archived
# year of each country; the TB seed is floored at 0.05 %.
SEED_MULTIPLIERS = (0.5, 1.0, 2.0)
TB_SEED_FLOOR = 0.05

# The three transmission-rate starts reuse the Control-A grid of the shared
# synthetic experiments: beta1_syn * {0.5, 0.8, 1.5} and beta2_syn * {0.5, 1.2, 1.5}.
RT_MULTIPLIERS = (0.5, 0.8, 1.5)
RH_MULTIPLIERS = (0.5, 1.2, 1.5)

M_GRID_DIRECT = np.geomspace(0.001001, 20.0, 15)
M_GRID_PROXY = np.geomspace(0.001001, 20.0, 7)

# The archived files were produced with a single trust-region pass per start.
POLISH_DEFAULT = False

DEFAULT_PROFILE_INTERPRETATION = (
    "This is a two-observation country profile. It is a practical diagnostic, "
    "not a structural-identifiability proof."
)

SOLVER_OPTIONS = {
    "method": "trf",
    "x_scale": "jac",
    "ftol": 1e-11,
    "xtol": 1e-11,
    "gtol": 1e-11,
    "max_nfev": 1200,
}
ODE_OPTIONS = {"method": "LSODA", "rtol": 1e-9, "atol": 1e-11, "max_step": 0.25}


# ---------------------------------------------------------------------------
# Parameter transforms (identical to the synthetic identifiability branch)
# ---------------------------------------------------------------------------
def _sigmoid(x):
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    pos = x >= 0.0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    exp_x = np.exp(x[~pos])
    out[~pos] = exp_x / (1.0 + exp_x)
    return float(out) if x.ndim == 0 else out


def _logit(fraction: float) -> float:
    f = float(np.clip(fraction, 1e-10, 1.0 - 1e-10))
    return float(np.log(f / (1.0 - f)))


def coordinate_bounds(names) -> tuple[np.ndarray, np.ndarray]:
    lower, upper = [], []
    for name in names:
        if name in {"a0", "a_max", "omega0", "m"}:
            lower.append(Q_COORD_LOWER)
            upper.append(Q_COORD_UPPER)
        elif name in {"beta1", "beta2"}:
            lower.append(LOG_COORD_LOWER)
            upper.append(LOG_COORD_UPPER)
        elif name in {"tb_prev", "hiv_prev"}:
            lower.append(INIT_COORD_LOWER)
            upper.append(INIT_COORD_UPPER)
        else:
            raise KeyError(f"no coordinate bounds for {name!r}")
    return np.asarray(lower, dtype=float), np.asarray(upper, dtype=float)


def physical_to_coordinate(params: dict, names) -> np.ndarray:
    out = []
    for name in names:
        value = float(params[name])
        if name == "a0":
            out.append(_logit((value - A0_LO) / (A0_HI - A0_LO)))
        elif name == "a_max":
            gap = AMAX_HI - float(params["a0"]) - EPS_A
            out.append(_logit((value - float(params["a0"]) - EPS_A) / max(gap, 1e-12)))
        elif name == "omega0":
            out.append(_logit((value - OMEGA0_LO) / (OMEGA0_HI - OMEGA0_LO)))
        elif name == "m":
            out.append(_logit((value - M_LO) / (M_HI - M_LO)))
        elif name in {"beta1", "beta2", "tb_prev", "hiv_prev"}:
            out.append(float(np.log10(max(value, 1e-12))))
        else:
            raise KeyError(f"unknown parameter {name!r}")
    return np.asarray(out, dtype=float)


def coordinate_to_physical(q, names) -> dict:
    q = np.asarray(q, dtype=float)
    params = {name: float(q[i]) for i, name in enumerate(names)}
    for name, value in params.items():
        if name == "a0":
            params[name] = A0_LO + (A0_HI - A0_LO) * _sigmoid(value)
        elif name == "a_max":
            gap = max(AMAX_HI - params["a0"] - EPS_A, 1e-12)
            params[name] = params["a0"] + EPS_A + gap * _sigmoid(value)
        elif name == "omega0":
            params[name] = OMEGA0_LO + (OMEGA0_HI - OMEGA0_LO) * _sigmoid(value)
        elif name == "m":
            params[name] = M_LO + (M_HI - M_LO) * _sigmoid(value)
        elif name in {"beta1", "beta2", "tb_prev", "hiv_prev"}:
            params[name] = 10.0 ** value
        else:
            raise KeyError(f"unknown parameter {name!r}")
    return params


# ---------------------------------------------------------------------------
# Forward model and observation operators
# ---------------------------------------------------------------------------
def integrate_states(params: dict, t_eval: np.ndarray) -> np.ndarray:
    """Solve the locked eight-compartment model from the seeded initial state."""
    x0 = np.asarray(shared.make_seed(float(params["tb_prev"]), float(params["hiv_prev"])), dtype=float)
    sol = solve_ivp(
        lambda t, x: shared.rhs_full_np(
            t,
            x,
            float(params["beta1"]),
            float(params["beta2"]),
            float(params["a0"]),
            float(params["a_max"]),
            float(params["omega0"]),
            OMEGA_MIN,
            float(params["m"]),
        ),
        (0.0, float(np.max(t_eval))),
        x0,
        t_eval=t_eval,
        **ODE_OPTIONS,
    )
    if not sol.success or sol.y.shape[1] != np.asarray(t_eval).size:
        raise RuntimeError(f"ODE integration failed: {sol.message}")
    return sol.y.T


def observable_matrix(states: np.ndarray) -> np.ndarray:
    """Columns: TB incidence per 100k and non-AIDS HIV prevalence in percent."""
    tb_incidence, hiv_prevalence = shared.observables_numpy(np.asarray(states, dtype=float))
    return np.column_stack((tb_incidence, hiv_prevalence))


def annual_treatment_initiations(params: dict, years_index) -> np.ndarray:
    """Annual integrals of the instantaneous treatment flow ``a(B)I/(1+omega(B)I)``."""
    fine = np.linspace(0.0, float(len(YEARS) - 1), 2801)
    states = integrate_states(params, fine)
    infected = states[:, 2]
    total = np.maximum(states.sum(axis=1), 1e-8)
    burden = (infected + states[:, 6]) / total
    response, saturation = shared.response_np(
        burden,
        float(params["a0"]),
        float(params["a_max"]),
        float(params["omega0"]),
        OMEGA_MIN,
        float(params["m"]),
    )
    flow = response * infected / (1.0 + saturation * infected)
    out = []
    for index in years_index:
        window = (fine >= index) & (fine <= index + 1)
        out.append(float(np.trapz(flow[window], fine[window])))
    return np.asarray(out, dtype=float)


def normalize(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    mean = float(np.mean(values))
    if not np.isfinite(mean) or abs(mean) < 1e-30:
        raise RuntimeError("proxy normalisation failed")
    return values / mean


# ---------------------------------------------------------------------------
# Country data and start grid
# ---------------------------------------------------------------------------
def load_country(country: str) -> dict:
    frame = pd.read_csv(DATA_DIR / COUNTRIES[country])
    frame = frame[frame["year"].between(YEARS[0], YEARS[-1])]
    if len(frame) != len(YEARS):
        raise RuntimeError(f"{country}: expected {len(YEARS)} annual rows, found {len(frame)}")
    tb = frame["tb_inc_100k"].to_numpy(dtype=float)
    hiv = frame["hiv_prev_pct"].to_numpy(dtype=float)
    cohort = frame["newrel_coh"].to_numpy(dtype=float)
    proxy_mask = frame["year"].between(PROXY_YEARS[0], PROXY_YEARS[-1]).to_numpy()
    if np.any(~np.isfinite(cohort[proxy_mask])):
        raise RuntimeError(f"{country}: missing treatment-cohort record inside the proxy window")
    return {
        "targets": np.column_stack((tb, hiv)),
        "observation_scales": np.ptp(np.column_stack((tb, hiv)), axis=0),
        "proxy_observed": normalize(cohort[proxy_mask]),
    }


def start_grid(country: str, data: dict, reduced: bool = False) -> list[dict]:
    """Archived deterministic start grid.

    The direct branch uses three transmission starts crossed with three
    initial-prevalence seeds (nine starts).  The archived treatment-proxy
    branch is the *reduced* variant and keeps only the first transmission
    start, giving three starts.
    """
    tb0 = float(data["targets"][0, 0]) / 1000.0
    hiv0 = float(data["targets"][0, 1])
    tb_base = max(tb0, TB_SEED_FLOOR)
    tb_seeds = [max(TB_SEED_FLOOR, multiplier * tb_base) for multiplier in SEED_MULTIPLIERS]
    hiv_seeds = [multiplier * hiv0 for multiplier in SEED_MULTIPLIERS]
    transmission = [
        (rt * float(shared.beta1_syn), rh * float(shared.beta2_syn))
        for rt, rh in zip(RT_MULTIPLIERS, RH_MULTIPLIERS)
    ]
    if reduced:
        transmission = transmission[:1]
    starts = []
    for beta1, beta2 in transmission:
        for tb_seed, hiv_seed in zip(tb_seeds, hiv_seeds):
            starts.append(
                {
                    "a0": 0.3,
                    "a_max": 0.9,
                    "omega0": 0.001,
                    "m": 0.01,
                    "beta1": beta1,
                    "beta2": beta2,
                    "tb_prev": tb_seed,
                    "hiv_prev": hiv_seed,
                }
            )
    return starts


# ---------------------------------------------------------------------------
# Fitting
# ---------------------------------------------------------------------------
def _residual_function(names, data, use_proxy: bool, fixed_m: float | None = None):
    targets = data["targets"]
    scales = data["observation_scales"]
    proxy_observed = data["proxy_observed"]
    proxy_scale = float(np.ptp(proxy_observed))

    def residual(q):
        try:
            params = coordinate_to_physical(q, names)
            if fixed_m is not None:
                params["m"] = float(fixed_m)
            prediction = observable_matrix(integrate_states(params, T_GRID))
            if not np.all(np.isfinite(prediction)):
                raise RuntimeError("non-finite output")
            parts = [((prediction - targets) / scales).ravel()]
            if use_proxy:
                proxy = normalize(annual_treatment_initiations(params, PROXY_T_INDEX))
                parts.append((proxy - proxy_observed) / proxy_scale)
            return np.concatenate(parts)
        except Exception:
            return np.full(targets.size + (len(PROXY_T_INDEX) if use_proxy else 0), 1e6)

    return residual


def fit_country(
    country: str,
    data: dict,
    use_proxy: bool,
    fixed_m: float | None = None,
    start: dict | None = None,
    polish: bool = POLISH_DEFAULT,
) -> dict:
    """One multistart (or single-start) bounded least-squares fit.

    ``polish=False`` is the protocol that produced the archived files: one
    trust-region pass per start.  ``polish=True`` adds an optional second pass
    from each solution to the same objective; the surface is extremely flat
    along the ``(a0, a_max, m, tb_prev)`` ridge, so that pass can move the
    optimum slightly below the archived value.
    """
    if fixed_m is None:
        names = list(PARAM_ORDER)
        starts = start_grid(country, data, reduced=use_proxy)
        if start is not None:
            starts = [start]
    else:
        names = [name for name in PARAM_ORDER if name != "m"]
        base = start if start is not None else start_grid(country, data)[0]
        starts = [{k: v for k, v in base.items() if k != "m"}]

    residual = _residual_function(names, data, use_proxy, fixed_m=fixed_m)
    lower, upper = coordinate_bounds(names)
    results = []
    for index, entry in enumerate(starts, start=1):
        q0 = np.clip(physical_to_coordinate(entry, names), lower + 1e-6, upper - 1e-6)
        fit = least_squares(residual, q0, bounds=(lower, upper), **SOLVER_OPTIONS)
        if polish:
            second = least_squares(residual, fit.x, bounds=(lower, upper), **SOLVER_OPTIONS)
            if second.cost <= fit.cost:
                fit = second
        recovered = coordinate_to_physical(fit.x, names)
        if fixed_m is not None:
            recovered["m"] = float(fixed_m)
        results.append(
            {
                "start_index": index,
                "initial": {name: float(entry[name]) for name in names},
                "recovered": {name: float(recovered[name]) for name in PARAM_ORDER},
                "objective": float(2.0 * fit.cost),
                "optimizer_success": bool(fit.success),
                "nfev": int(fit.nfev),
                "message": str(fit.message),
            }
        )
    best = min(results, key=lambda row: row["objective"])
    return {"n_starts": len(results), "best": best, "all_starts": results}


def profile_country(
    data: dict, use_proxy: bool, best: dict, grid: np.ndarray, polish: bool = POLISH_DEFAULT
) -> dict:
    """Fix ``m`` on a geometric grid and refit the remaining seven parameters."""
    rows = []
    for fixed_m in grid:
        fit = fit_country(
            "",
            data,
            use_proxy,
            fixed_m=float(fixed_m),
            start=best["recovered"],
            polish=polish,
        )
        row = fit["best"]
        rows.append(
            {
                "fixed_m": float(fixed_m),
                "objective": row["objective"],
                "optimizer_success": row["optimizer_success"],
                "nfev": row["nfev"],
                "recovered": row["recovered"],
            }
        )
    objectives = [row["objective"] for row in rows]
    minimum = min(rows, key=lambda row: row["objective"])
    payload = {
        "grid": rows,
        "minimum": minimum,
        "finite_minimum_inside_grid": bool(0 < rows.index(minimum) < len(rows) - 1),
        "objective_range": [float(min(objectives)), float(max(objectives))],
    }
    if not use_proxy:
        payload["interpretation"] = DEFAULT_PROFILE_INTERPRETATION
    return payload


def country_block(country: str, data: dict, use_proxy: bool, polish: bool = POLISH_DEFAULT) -> dict:
    fit = fit_country(country, data, use_proxy, polish=polish)
    best = fit["best"]
    block = {
        "country": country,
        "data_file": str((DATA_DIR / COUNTRIES[country]).relative_to(ROOT)).replace("\\", "/"),
        "years": list(YEARS),
        "n_observations": len(YEARS),
        "observations": ["tb_incidence_100k", "hiv_prevalence_pct"],
        "time_varying_beta_used": False,
        "fit": {
            "n_starts": fit["n_starts"],
            "best": best,
            "all_starts": fit["all_starts"],
            "observation_scales": [float(v) for v in data["observation_scales"]],
        },
    }
    if use_proxy:
        block["proxy_years"] = list(PROXY_YEARS)
        block["n_proxy_observations"] = len(PROXY_YEARS)
        block["proxy"] = "newrel_coh normalized by country-specific mean; exploratory only"
        block["fit"]["proxy_scale"] = float(np.ptp(data["proxy_observed"]))
    block["m_profile"] = profile_country(
        data, use_proxy, best, M_GRID_PROXY if use_proxy else M_GRID_DIRECT, polish=polish
    )
    return block


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=1), encoding="utf-8")
    print(f"wrote {path}")


def build_payload(countries: list[str], use_proxy: bool, polish: bool = POLISH_DEFAULT) -> dict:
    operator = {
        "y1": "(k*L + k_star*J2)/N*100000",
        "y2": "(J1 + J2 + J3)/N*100",
    }
    if use_proxy:
        operator["proxy"] = "newrel_coh / mean(newrel_coh), years 2012-2023"
        operator["proxy_is_instantaneous_flow"] = False
    else:
        operator["y3_used"] = False
    return {
        "analysis": (
            "exploratory country annual treatment-cohort proxy profiles"
            if use_proxy
            else "country two-observation m profiles"
        ),
        "status": "new_branch_only",
        "model_modified": False,
        "old_pinn_branch_run": False,
        "old_results_overwritten": False,
        "q_lower": Q_COORD_LOWER,
        "observation_operator": operator,
        "countries": {
            country: country_block(country, load_country(country), use_proxy, polish=polish)
            for country in countries
        },
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--countries", nargs="+", choices=list(COUNTRIES), default=list(COUNTRIES))
    parser.add_argument("--branch", choices=("direct", "proxy", "both"), default="both")
    parser.add_argument(
        "--polish",
        action="store_true",
        help="add a second trust-region pass per start (not used for the archived values)",
    )
    args = parser.parse_args(argv)

    if args.branch in {"direct", "both"}:
        write_json(
            DIRECT_DIR / "identifiability_country_profiles.json",
            build_payload(args.countries, use_proxy=False, polish=args.polish),
        )
    if args.branch in {"proxy", "both"}:
        write_json(
            PROXY_DIR / "identifiability_country_treatment_proxy.json",
            build_payload(args.countries, use_proxy=True, polish=args.polish),
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
