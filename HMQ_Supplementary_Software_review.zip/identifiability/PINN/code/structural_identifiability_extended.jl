# EXPANDED-SET local structural identifiability (reviewer Major 6).
#
# Baseline structural_identifiability.jl fixes all natural-history parameters
# and omega_min. A reviewer asked to test at least one expanded set that
# releases biologically uncertain quantities. Here we additionally release
#   * omega_min (the asymptotic saturation coefficient), and
#   * k         (the latent->active TB progression rate, a natural-history par)
# for BOTH Problem A (transmission fixed) and Problem B (transmission free),
# under both the ideal (y1,y2,y3) and routine (y1,y2) observation operators.
#
# In Problem A the transmission coefficients are fixed to NUMERIC constants
# evaluated at the nominal k=0.5 (they no longer depend on the symbolic k).
using StructuralIdentifiability
using ModelingToolkit
using Symbolics
using Logging
using Dates
using Random

const _RESULTS_DIR = joinpath(@__DIR__, "..", "results", "identifiability_ABC")
const _OUT_PATH    = joinpath(_RESULTS_DIR, "structural_identifiability_extended_jl_output.json")

# Same fixed random draw as the primary run, so that this expanded set is
# reproducible; the packaged correctness bound (prob_threshold) still applies.
const RANDOM_SEED = 20261016

# ---- minimal JSON serializer (no JSON.jl dependency) ------------------------
function _json_escape(s::String)
    out = IOBuffer()
    write(out, UInt8('"'))
    for c in s
        if c == '"' || c == '\\'
            write(out, UInt8('\\'), UInt8(c))
        elseif c == '\n'
            write(out, UInt8('\\'), UInt8('n'))
        elseif c == '\t'
            write(out, UInt8('\\'), UInt8('t'))
        else
            write(out, c)
        end
    end
    write(out, UInt8('"'))
    return String(take!(out))
end
to_json(x::Bool)          = x ? "true" : "false"
to_json(x::String)        = _json_escape(x)
to_json(x::AbstractFloat) = string(x)
to_json(x::Integer)       = string(x)
function to_json(x::AbstractDict)
    parts = String["$(_json_escape(string(k))): $(to_json(v))" for (k, v) in x]
    return "{" * join(parts, ", ") * "}"
end
function to_json(x::AbstractVector)
    return "[" * join([to_json(v) for v in x], ", ") * "]"
end

# ---- numeric constants kept fixed (match pinn_training_paper_safe.py) ------
const mu        = 0.0143
const d_val     = 0.1
const k_star    = 2.5
const d_star    = 0.2
const alpha1    = 0.1
const alpha2    = 0.2
const alpha3    = 0.5
const f_val     = 0.5
const theta_val = 1.0
const sigma_rel = 1.0
const N0        = 10000.0
const Lambda    = mu * N0

# fixed numeric transmission values for Problem A (nominal k=0.5)
const beta1_fix = 2.1808879026
const beta2_fix = 0.20574

# ---- symbolic unknowns: omega_min and k are now FREE -----------------------
@parameters a0 a_max omega0 omega_min k m beta1 beta2
@independent_variables t
@variables S(t) L(t) I(t) T(t) J1(t) J2(t) J3(t) A(t)
D = Differential(t)

N      = S + L + I + T + J1 + J2 + J3 + A
R_pool = N - I - J3 - A
B      = (I + J3) / N
gm     = (1 + m) * B / (1 + m * B)
aB     = a0 + (a_max - a0) * gm
omB    = omega0 + (omega_min - omega0) * gm
Jstar  = J1 + J2 + J3
tL     = aB * L / (1 + omB * L)
tI     = aB * I / (1 + omB * I)
tJ2    = aB * J2 / (1 + omB * J2)

# ---- full 8-state equations; k is now symbolic ------------------------------
eqs_full = [
    D(S)  ~ Lambda - beta1*(I+J3)/N*S - beta2*Jstar/R_pool*S - mu*S,
    D(L)  ~ beta1*(S+T)*(I+J3)/N - sigma_rel*beta2*L*Jstar/R_pool - (mu+k)*L - tL,
    D(I)  ~ k*L - (mu+d_val)*I - tI,
    D(T)  ~ tL + tI - beta1*T*(I+J3)/N - beta2*T*Jstar/R_pool - mu*T,
    D(J1) ~ beta2*(S+T)*Jstar/R_pool - theta_val*beta1*J1*(I+J3)/N - (alpha1+mu)*J1 + tJ2,
    D(J2) ~ sigma_rel*beta2*L*Jstar/R_pool + theta_val*beta1*J1*(I+J3)/N - (alpha2+mu+k_star)*J2 - tJ2,
    D(J3) ~ k_star*J2 - (alpha3+mu+d_star)*J3,
    D(A)  ~ alpha1*J1 + alpha2*J2 + alpha3*J3 - (mu+f_val)*A,
]

# ---- outputs (k now symbolic in y1) -----------------------------------------
@variables y1(t) y2(t) y3(t)
measured_ideal   = [y1 ~ (k*L + k_star*J2)/N, y2 ~ Jstar/N, y3 ~ aB*I/(1 + omB*I)]
measured_routine = [y1 ~ (k*L + k_star*J2)/N, y2 ~ Jstar/N]

# ---- Problem A-ext: transmission fixed to numeric constants ----------------
subs_A = Dict(beta1 => beta1_fix, beta2 => beta2_fix)
eqs_A  = [Symbolics.substitute(eq, subs_A) for eq in eqs_full]
ode_A  = ODESystem(eqs_A, t, name=:HIVTB_Aext)
params_Aext = [a0, a_max, omega0, omega_min, k, m]

# ---- Problem B-ext: transmission free ---------------------------------------
ode_B = ODESystem(eqs_full, t, name=:HIVTB_Bext)
params_Bext = [a0, a_max, omega0, omega_min, k, m, beta1, beta2]

function run_local(ode, measured, params, label; problem="", measured_labels=String[])
    println("="^70); flush(stdout)
    println("EXPANDED local structural identifiability — ", label); flush(stdout)
    println("="^70); flush(stdout)
    res = assess_local_identifiability(
        ode,
        measured_quantities = measured,
        funcs_to_check = params,
        prob_threshold = 0.99,
        loglevel = Logging.Warn,
    )
    result_bool = Dict{String,Bool}()
    for (p, v) in res
        result_bool[string(p)] = v
        println("  ", string(p), "  =>  ", v); flush(stdout)
    end
    println(); flush(stdout)
    return Dict(
        "label" => label,
        "problem" => problem,
        "measured_outputs" => measured_labels,
        "unknown_parameters" => string.(params),
        "result" => result_bool,
        "all_identifiable" => all(values(result_bool)),
    )
end

Random.seed!(RANDOM_SEED)
println("START_EXTENDED"); flush(stdout)
configs = Dict{String,Any}[]
push!(configs, run_local(ode_A, measured_ideal,   params_Aext, "A-ext ideal (y1,y2,y3): +omega_min,+k"; problem="A-ext", measured_labels=["y1","y2","y3"]))
push!(configs, run_local(ode_A, measured_routine, params_Aext, "A-ext routine (y1,y2): +omega_min,+k"; problem="A-ext", measured_labels=["y1","y2"]))
push!(configs, run_local(ode_B, measured_ideal,   params_Bext, "B-ext ideal (y1,y2,y3): +omega_min,+k"; problem="B-ext", measured_labels=["y1","y2","y3"]))
push!(configs, run_local(ode_B, measured_routine, params_Bext, "B-ext routine (y1,y2): +omega_min,+k"; problem="B-ext", measured_labels=["y1","y2"]))

si_version_ext = "0.5.27"
try
    global si_version_ext = string(pkgversion(StructuralIdentifiability))
catch
end

output = Dict{String,Any}(
    "tool" => "StructuralIdentifiability.jl",
    "julia_version" => string(VERSION),
    "structural_identifiability_version" => si_version_ext,
    "method" => "Xia-Moog local structural identifiability, generic initial condition (assess_local_identifiability, type=:SE, prob_threshold=0.99)",
    "random_seed" => RANDOM_SEED,
    "released_parameters" => ["omega_min", "k"],
    "known_ic_note" => "known_ic variant omitted: v0.5.27 calls undefined _assess_local_identifiability_kic (bug); only generic-IC run archived.",
    "generated_at" => string(now()),
    "configurations" => configs,
)
mkpath(_RESULTS_DIR)
open(_OUT_PATH, "w") do io
    write(io, to_json(output))
end
println("WROTE ", _OUT_PATH); flush(stdout)
println("DONE_EXTENDED"); flush(stdout)
