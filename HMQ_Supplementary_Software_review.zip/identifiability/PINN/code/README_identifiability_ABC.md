﻿# A/B/C identifiability branch

`identifiability_ABC.py` is the new, isolated experiment branch. It imports
the locked ODE and existing TB/HIV observation operators from
`pinn_training_paper_safe.py`; it does not edit those equations, run the old
PINN branch, or overwrite the archived C1/C2 JSON files.

The three problems are encoded exactly as follows:

- A: `a0, a_max, omega0, m` unknown; `omega_min, beta1, beta2` and both
  seeded initial-condition descriptors fixed.
- B: A's four parameters plus constant `beta1, beta2` unknown; seeded initial
  condition fixed.
- C: B's six parameters plus `tb_prev, hiv_prev` unknown; only
  `omega_min=1e-5` fixed.

The ideal third output is the instantaneous treatment flow
`a(B) I / (1 + omega(B) I)`. The `structure` mode reports finite-time
standardized sensitivities, rank, singular values, condition number, column
correlations and the minimum right singular vector for dense and annual time
grids. This is a generic numerical local-rank screen, not a formal proof; the
JSON records the symbolic verification specification and the available
StructuralIdentifiability.jl / STRIKE-GOLDD tool routes. In the completed
branch, the symbolic log verifies A and B; C remains covered by the Python
finite-time numerical screen because its seeded initial-condition map was not
passed to the symbolic script.

Examples from the project root:

```powershell
python identifiability/PINN/code/identifiability_ABC.py --mode consistency
python identifiability/PINN/code/identifiability_ABC.py --mode structure --n-draws 5
python identifiability/PINN/code/identifiability_ABC.py --mode fit --max-starts 3
# High-resolution profile of m only (avoids profiling unrelated parameters)
python identifiability/PINN/code/identifiability_ABC.py --mode profile --problem all --profile-parameter m --profile-points 41
# Formal 5% Monte Carlo run with near-physical transformed-coordinate coverage
python identifiability/PINN/code/identifiability_ABC.py --mode noise --problem all --n-realizations 20 --max-starts 3 --q-lower -20
```

Outputs are written only under `PINN/results/identifiability_ABC/`.

## Deterministic window-pilot archive

The trajectory quantities quoted for the Q = 0.80 window pilots are properties
of the data-generating trajectory rather than of the fits, so they are archived
separately from the Monte Carlo runs.  From the archive root (the directory
holding `bifurcation/`, `data_files/`, `figures/` and `identifiability/`):

```powershell
python identifiability/PINN/code/window_pilot_diagnostics.py
```

The script recomputes them from the locked model, initial conditions and branch
value without refitting anything, and writes
`identifiability/PINN/results/identifiability_final/window_pilot_diagnostics.json`,
holding the low- and high-burden deterministic trajectories, the `t = 4000`
attractor reached from each seed, and the `corr(m_hat, a_max_hat)` of the three
archived Q = 0.80 pilots.

## Country observation-design profiles

`country_identifiability_profiles.py` regenerates the two archived country
profile files that document the exploratory observation-design fits. The
direct branch is reproduced from its archived protocol; the treatment-proxy
branch is a protocol-matched reconstruction because its historical producer
is unavailable, as described in the script docstring:

```powershell
python identifiability/PINN/code/country_identifiability_profiles.py
# single branch or country subset
python identifiability/PINN/code/country_identifiability_profiles.py --branch direct --countries Kenya Portugal
```

Outputs (overwritten in place):

- `identifiability/PINN/results/identifiability_country_profiles_with_params/identifiability_country_profiles.json`:
  eight-parameter fits to the two archived outputs (WHO TB incidence and UNAIDS
  HIV prevalence, 2010-2024) and a 15-point profile of the response slope `m`.
- `identifiability/PINN/results/identifiability_country_treatment_proxy_reduced/identifiability_country_treatment_proxy.json`:
  the same fits with the country-reported annual treatment-cohort record added
  as a shape-only proxy observation (2012-2023) and a seven-point `m` profile.

Both branches are exploratory diagnostics of observation design, not
calibrations. Every unconstrained fit terminates at a parameter bound,
including the bound of `m` or `a_max`, and no value recovered from these fits
enters any reported result. The script is deterministic: it reuses the locked
`pinn_training_paper_safe.rhs_full_np` and the same bounded logit/log10
parameterisation as the synthetic identifiability branch. The direct branch
uses the full archived start grid (three Control-A transmission-rate starts
crossed with three initial-prevalence seeds, nine starts); the archived
treatment-proxy branch is the *reduced* variant and keeps only the first
transmission start, giving three starts. Each start receives a single
trust-region pass, which is the protocol that produced the archived files;
`--polish` adds a second pass to the same objective and is not used for the
archived values.

Reproduction fidelity. The direct branch reproduces the archived objective
exactly: evaluating the script's residual at the archived best-fit parameters
returns the archived value to machine precision, and the refitted values agree
to about `1e-7` relative (up to `1e-3` for individual profile points, whose
surface is extremely flat). The treatment-proxy branch does not reach that
precision. Its original producer script is absent from the archive and from
the earlier working copies, so the branch was rebuilt from the archived JSON.
Schema, protocol and qualitative result match, but the archived proxy
parameters do not evaluate to the archived objective under this residual
definition, so one detail of the original proxy residual is unrecoverable;
objectives agree to within about `6e-2` relative. Both branches still give the
same reading used in the manuscript: every unconstrained fit terminates at a
parameter bound and the `m` profile minimum lies on the grid edge. No reported
result depends on either file.

One archived field is deliberately not reproduced literally: the original
`data_file` values recorded the absolute path `D:\TB-HIV\PINN\data\...`, which
does not exist in the archive. The script writes the archive-relative path
`identifiability/PINN/data/...` instead.
