"""5% noise Monte Carlo for conditional PINN state reconstruction.

The experiment fixes the synthetic healthcare parameters, constant beta rates,
and seeded initial condition.  Only the state network is trained.  It is a
robustness control for PINN trajectory reconstruction, not a claim that the
healthcare parameters (or m) are identifiable.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

import numpy as np

CODE_DIR = Path(__file__).resolve().parent
if str(CODE_DIR) not in sys.path:
    sys.path.insert(0, str(CODE_DIR))

import pinn_conditional_A as conditional  # noqa: E402


OUT_DIR = CODE_DIR.parent / "results" / "pinn_mc_state_reconstruction"


def run_one(noise_seed: int, network_seed: int, epochs_scale: float) -> dict[str, Any]:
    data = conditional.synthetic_data(noise_fraction=0.05, seed=int(noise_seed))
    result = conditional.train_once(
        data=data,
        fixed_m=float(conditional.shared.TRUE_VALS["m"]),
        init_values=dict(conditional.HC_STARTS[0]),
        learnable_healthcare=(),
        seed=int(network_seed),
        epochs_scale=float(epochs_scale),
    )
    result["noise_seed"] = int(noise_seed)
    result["network_seed"] = int(network_seed)
    result["noise_fraction"] = 0.05
    return result


def summarize(results: list[dict[str, Any]]) -> dict[str, Any]:
    tb = np.asarray([row["tb_rmse_vs_observed"] for row in results], dtype=float)
    hiv = np.asarray([row["hiv_rmse_vs_observed"] for row in results], dtype=float)
    tb_norm = []
    hiv_norm = []
    for row in results:
        data = conditional.synthetic_data(noise_fraction=0.05, seed=int(row["noise_seed"]))
        tb_norm.append(row["tb_rmse_vs_observed"] / max(float(np.ptp(data["tb_observed"])), 1.0))
        hiv_norm.append(row["hiv_rmse_vs_observed"] / max(float(np.ptp(data["hiv_observed"])), 1.0))
    tb_norm = np.asarray(tb_norm, dtype=float)
    hiv_norm = np.asarray(hiv_norm, dtype=float)
    return {
        "n_realizations": int(len(results)),
        "noise_fraction": 0.05,
        "tb_rmse_raw_mean": float(np.mean(tb)),
        "tb_rmse_raw_sd": float(np.std(tb, ddof=1)) if len(tb) > 1 else 0.0,
        "tb_rmse_raw_p95": float(np.quantile(tb, 0.95)),
        "hiv_rmse_raw_mean": float(np.mean(hiv)),
        "hiv_rmse_raw_sd": float(np.std(hiv, ddof=1)) if len(hiv) > 1 else 0.0,
        "hiv_rmse_raw_p95": float(np.quantile(hiv, 0.95)),
        "tb_rmse_normalized_mean": float(np.mean(tb_norm)),
        "tb_rmse_normalized_sd": float(np.std(tb_norm, ddof=1)) if len(tb_norm) > 1 else 0.0,
        "hiv_rmse_normalized_mean": float(np.mean(hiv_norm)),
        "hiv_rmse_normalized_sd": float(np.std(hiv_norm, ddof=1)) if len(hiv_norm) > 1 else 0.0,
        "parameter_mode": "m, beta1, beta2, healthcare parameters and seeded initial condition fixed",
        "interpretation": "state-reconstruction robustness only; no parameter-identifiability claim",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-realizations", type=int, default=20)
    parser.add_argument("--epochs-scale", type=float, default=0.5)
    parser.add_argument("--seed", type=int, default=20260811)
    parser.add_argument("--out-dir", type=Path, default=OUT_DIR)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    results: list[dict[str, Any]] = []
    out_path = args.out_dir / "pinn_mc_state_reconstruction.json"
    for index in range(max(1, int(args.n_realizations))):
        noise_seed = int(args.seed) + index * 17
        network_seed = int(args.seed) + 10000 + index * 31
        print(f"PINN MC realization {index + 1}/{args.n_realizations}")
        result = run_one(noise_seed, network_seed, float(args.epochs_scale))
        results.append(result)
        payload = {
            "analysis": "5% noise conditional PINN state reconstruction Monte Carlo",
            "status": "new_branch_only",
            "model_modified": False,
            "old_pinn_branch_run": False,
            "old_results_overwritten": False,
            "time_varying_beta_used": False,
            "epochs_scale": float(args.epochs_scale),
            "summary": summarize(results),
            "results": results,
        }
        out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(
            f"  TB_RMSE={result['tb_rmse_vs_observed']:.4g}, "
            f"HIV_RMSE={result['hiv_rmse_vs_observed']:.4g}, "
            f"ODE_RMSE={result['final_loss'].get('loss_ode', float('nan')):.4g}"
        )
    print(f"Saved: {out_path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
