"""Archive the deterministic diagnostics quoted for the Q=0.80 window pilots.

The two window pilots (`run_window_recovery_pilot.py` and
`run_window_highburden_pilot.py`) archive the recovery statistics of their 20
noise realizations, but the trajectory quantities in the supplementary
window-diagnostics table are properties of the data-generating trajectory
rather than of the fits.  This script recomputes those quantities from the
same model, initial conditions and branch value, together with the
correlation between the recovered `m` and `a_max` in each archived pilot, and
writes them to

  identifiability/PINN/results/identifiability_final/window_pilot_diagnostics.json

No fitting is performed here, so the file is cheap to regenerate and can be
checked against the reported table independently of the Monte Carlo runs.
"""
from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

import numpy as np

CODE = Path(__file__).resolve().parent
ROOT = CODE.parents[2]
COMMON_DIR = ROOT / "bifurcation" / "code"
if str(CODE) not in sys.path:
    sys.path.insert(0, str(CODE))
if str(COMMON_DIR) not in sys.path:
    sys.path.insert(0, str(COMMON_DIR))

import identifiability_ABC as abc  # noqa: E402

common = importlib.import_module("00_common")

RESULT_DIR = ROOT / "identifiability" / "PINN" / "results" / "identifiability_final"
WINDOW_Q = 0.80
WINDOW_BETA1 = 1.0391942198578614
RH = 1.8
LOW_TB_PREV, LOW_HIV_PREV = 0.50, 10.0
HIGH_TB_PREV, HIGH_HIV_PREV = 15.0, 1.0


def _burden(states):
    """Active-TB burden (I + J3)/N in percent."""
    states = np.atleast_2d(np.asarray(states, dtype=float))
    total = np.sum(states, axis=1)
    return 100.0 * (states[:, 2] + states[:, 6]) / total


def _hiv_fraction(states, aids_inclusive=False):
    states = np.atleast_2d(np.asarray(states, dtype=float))
    total = np.sum(states, axis=1)
    numerator = states[:, 4] + states[:, 5] + states[:, 6]
    if aids_inclusive:
        numerator = numerator + states[:, 7]
    return 100.0 * numerator / total


def _trajectory_block(tb_prev, hiv_prev, label):
    abc.shared.beta1_syn = WINDOW_BETA1
    abc.TRUE_TB_PREV = float(tb_prev)
    abc.TRUE_HIV_PREV = float(hiv_prev)
    params = abc.true_parameters()

    t_eval = np.linspace(0.0, 14.0, 57)
    states = abc.integrate_states(t_eval, params)
    observed = abc.observations_from_states(states, params)
    burden = _burden(states)
    hiv = _hiv_fraction(states)

    block = {
        "basin": label,
        "seeded_initial_tb_prevalence_pct": float(tb_prev),
        "seeded_initial_hiv_prevalence_pct": float(hiv_prev),
        "sampling": "57 quarterly points over 14 years (instantaneous)",
        "initial_active_tb_burden_pct": float(burden[0]),
        "initial_non_aids_hiv_prevalence_pct": float(hiv[0]),
        "active_tb_burden_pct_range": [float(burden.min()), float(burden.max())],
        "active_tb_burden_pct_terminal": float(burden[-1]),
        "tb_incidence_per_100k_range": [float(observed[:, 0].min()),
                                        float(observed[:, 0].max())],
        "tb_incidence_per_100k_terminal": float(observed[-1, 0]),
        "non_aids_hiv_prevalence_pct_range": [float(hiv.min()), float(hiv.max())],
        "non_aids_hiv_prevalence_pct_terminal": float(hiv[-1]),
    }

    # Long-run attractor from the same initial state.
    t_long = np.linspace(0.0, 4000.0, 401)
    long_states = abc.integrate_states(t_long, params)
    final = long_states[-1]
    block["long_run_t4000"] = {
        "active_tb_burden_pct": float(_burden(final)[0]),
        "non_aids_hiv_prevalence_pct": float(_hiv_fraction(final)[0]),
        "aids_inclusive_hiv_prevalence_pct": float(_hiv_fraction(final, True)[0]),
    }
    return block


def _recovery_correlation(name):
    path = RESULT_DIR / name
    payload = json.loads(path.read_text(encoding="utf-8"))
    m_hat = np.array([r["best_recovered"]["m"] for r in payload["realizations"]],
                     dtype=float)
    a_hat = np.array([r["best_recovered"]["a_max"] for r in payload["realizations"]],
                     dtype=float)
    return {
        "file": name,
        "n_realizations": int(m_hat.size),
        "corr_m_hat_a_max_hat": float(np.corrcoef(m_hat, a_hat)[0, 1]),
    }


def main():
    print("=== window pilot diagnostics (Q=0.80) ===", flush=True)
    common_P = getattr(common, "P")
    e2 = common.full_tb_free_equilibrium(RH, common_P)
    e2_total = float(np.sum(e2))

    payload = {
        "description": (
            "Deterministic trajectory and attractor diagnostics for the Q=0.80 "
            "window pilots, recomputed from the locked model without refitting; "
            "plus the recovered-parameter correlations of the archived pilots."
        ),
        "Q": WINDOW_Q,
        "beta1": WINDOW_BETA1,
        "RH": RH,
        "m_true": 0.05,
        "observation_map": "H2",
        "integrated_trajectory": _trajectory_block(LOW_TB_PREV, LOW_HIV_PREV,
                                                  "TB-free HIV-endemic (low-burden)"),
        "integrated_trajectory_high_burden": _trajectory_block(
            HIGH_TB_PREV, HIGH_HIV_PREV, "HIV-free TB-endemic (high-burden)"),
        "analytic_e2_fractions_pct": {
            "non_aids_hiv_prevalence": float(100.0 * (e2[4] + e2[5] + e2[6]) / e2_total),
            "aids_inclusive_hiv_prevalence": float(
                100.0 * (e2[4] + e2[5] + e2[6] + e2[7]) / e2_total),
        },
        "recovery_correlations": [
            _recovery_correlation("interval_integrated_H2_A.json"),
            _recovery_correlation("window_Q080_H2_A.json"),
            _recovery_correlation("window_Q080_H2_A_highburden.json"),
        ],
    }
    out = RESULT_DIR / "window_pilot_diagnostics.json"
    out.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    traj = payload["integrated_trajectory"]
    print(f"low-burden initial burden={traj['initial_active_tb_burden_pct']:.4f}% "
          f"hiv={traj['initial_non_aids_hiv_prevalence_pct']:.4f}%", flush=True)
    print(f"low-burden 14y burden range={traj['active_tb_burden_pct_range']} "
          f"terminal={traj['active_tb_burden_pct_terminal']:.4f}%", flush=True)
    print(f"low-burden y1 range={traj['tb_incidence_per_100k_range']} "
          f"y2 range={traj['non_aids_hiv_prevalence_pct_range']}", flush=True)
    print(f"low-burden t=4000 attractor: {traj['long_run_t4000']}", flush=True)
    for corr in payload["recovery_correlations"]:
        print(f"  corr {corr['file']}: {corr['corr_m_hat_a_max_hat']:.6f}", flush=True)
    print(f"Saved: {out}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
