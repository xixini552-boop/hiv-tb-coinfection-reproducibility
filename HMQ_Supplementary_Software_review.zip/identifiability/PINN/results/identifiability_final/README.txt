Current manuscript results
==========================

The six files named

    relative_multiplicative_H2_A.json
    relative_multiplicative_H2_B.json
    relative_multiplicative_H2_C.json
    relative_multiplicative_H3_A.json
    relative_multiplicative_H3_B.json
    relative_multiplicative_H3_C.json

are the audited direct-ODE experiments reported in the revised manuscript and
Supplementary Methods. Each contains 20 multiplicative-noise realisations,
three deterministic starts per realisation, all fitted parameters, the
per-realisation relative errors, and aggregate statistics including the exact
binomial 95% confidence interval for the marginal m-recovery count.

Legacy file
-----------

The legacy file range_multiplicative_H2_A.json predates the H2
target-dimensionality fix. Its H2 objective compared three predicted columns
with a two-column target and is not valid for the revised results. It has been
moved to ../legacy_invalid/ for traceability and must not be used.
