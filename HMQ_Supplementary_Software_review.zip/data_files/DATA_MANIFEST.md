# Reproducibility manifest: archived external data files

Country-profile files and derived series below are retained in the
reproducibility archive only as exploratory observation-design material
for South Africa, Kenya, Thailand and Portugal. The `who_augmented/*`
entries are global WHO country-year source tables; four-country slices
from them were used only for the exploratory material. No exploratory
fit to these records is used in a reported result, and no reported
result depends on them.

`saved` is the file's save date on the working system. `sha256` is the
SHA-256 digest of the archived file. `content_summary` records the row
count, column count, year span and blank-cell fraction computed
directly from each file, together with the series it holds.

| file | bytes | saved | source | indicator | sha256 | content |
| --- | --- | --- | --- | --- | --- | --- |
| `HIV_estimates_from_1990-to-2025.xlsx` | 5888570 | 2026-04-27 | UNAIDS 2025 estimates workbook | annual country estimates | `ecdba947ff1589663348350f01b16b289bbef8f0a2f47914da9e43712c507be9` | UNAIDS 2025 estimates workbook (1990-2024; the filename retains the release-year label). 4 worksheets; header states 1990-2024; source: UNAIDS 2025 estimates; valid XLSX workbook, parsed for manifest metadata |
| `unaids_hiv_prevalence_all_ages.csv` | 1385 | 2026-08-09 | UNAIDS AIDSinfo | prevalence, all ages, both sexes | `90280652db8b4af932efae98bf30c4b67c49a98628fc3b8664f4e2a95a57ad48` | UNAIDS AIDSinfo: HIV prevalence, all ages (%). 60 data rows, 3 columns, year span 2010-2024, 0/180 blank cells (0.00%) |
| `un_wpp_population_2010_2024.csv` | 3420 | 2026-08-09 | World Bank World Development Indicators | SP.POP.TOTL | `ac7b914ab262738ec5daea3b21aff0d1c82e2d359b0fee1212a127aa277b9ed4` | World Bank WDI total population (indicator SP.POP.TOTL); the filename retains a legacy 'un_wpp' label, but every row carries 'World Bank WDI (SP.POP.TOTL)' in its Source column. 60 data rows, 5 columns, year span 2010-2024, 0/300 blank cells (0.00%) |
| `Kenya-1.csv` | 602 | 2026-05-26 | WHO Global Tuberculosis Programme | estimated TB incidence per 100000; new and relapse TB cases notified per 100000 | `aa1dc4127edd696dd88a37f5f1ecac8a613b33ff977605c9531ebf1d1001b81a` | WHO TB country profile series for Kenya. 15 data rows, 5 columns, year span 2010-2024, 0/75 blank cells (0.00%) |
| `Thailand-1.csv` | 596 | 2026-05-26 | WHO Global Tuberculosis Programme | estimated TB incidence per 100000; new and relapse TB cases notified per 100000 | `cd871a894c44fb4e14fa69c3c8016e3ab895912b87f088aa71538c9e46fa0614` | WHO TB country profile series for Thailand. 15 data rows, 5 columns, year span 2010-2024, 0/75 blank cells (0.00%) |
| `Portugal-1.csv` | 534 | 2026-05-26 | WHO Global Tuberculosis Programme | estimated TB incidence per 100000; new and relapse TB cases notified per 100000 | `b409e0de80d6dee4ba30f358093e919ac86b15b43d82c3657a7cf1b594d3fefd` | WHO TB country profile series for Portugal. 15 data rows, 5 columns, year span 2010-2024, 0/75 blank cells (0.00%) |
| `south african-1.xls` | 3758 | 2026-04-27 | WHO Global Tuberculosis Programme | estimated TB incidence per 100000; new and relapse TB cases notified per 100000 | `7a582cbb4ebf463ac85e10144c043a2918e2ba1754e2c869458d057b73f79d21` | WHO TB country profile series for South Africa (saved as an HTML-table 'xls'). HTML-table workbook saved with an .xls extension; not parsed |
| `who_augmented/estimates.csv` | 1053778 | 2026-08-11 | WHO Global Tuberculosis Programme | e_inc_100k, e_inc_num, e_tbhiv_prct, e_mort_* and related estimates | `6849d50d91579eaefa5833aa46d19d34e68dd6408a3768875991013f05586c30` | WHO global TB estimates (country-year table). 5347 data rows, 50 columns, year span 2000-2024, 33228/267350 blank cells (12.43%) |
| `who_augmented/notifications.csv` | 3005322 | 2026-08-11 | WHO Global Tuberculosis Programme | case notifications and case-finding variables | `edd2e53898d078e1ada0b0552031035318439013840ac47273aa8afd3965e1a5` | WHO TB notifications (country-year table). 9567 data rows, 216 columns, year span 1980-2024, 1740559/2066472 blank cells (84.23%) |
| `who_augmented/outcomes.csv` | 957609 | 2026-08-11 | WHO Global Tuberculosis Programme | treatment-cohort outcome variables (new_sp_*, new_snep_*) | `8195082c2425a7255103f9b3634bc1b6fa8892b82dea245cb3feea03865aa422` | WHO TB treatment outcomes (country-year table). 6399 data rows, 73 columns, year span 1994-2023, 298239/467127 blank cells (63.85%) |
| `who_augmented/contact_tpt.csv` | 183185 | 2026-08-11 | WHO Global Tuberculosis Programme | contact investigation and TPT variables | `ef96ad86e574bd83276f6833e4ed022ac0f8b3f0f8aa4eec79f9fa77101678ce` | WHO TB contact screening and preventive treatment (country-year table). 2150 data rows, 36 columns, year span 2015-2024, 52199/77400 blank cells (67.44%) |
| `who_augmented/dictionary.csv` | 108122 | 2026-08-11 | WHO Global Tuberculosis Programme | variable_name, dataset, code_list, definition | `2b0aecd442bffabf2f313d2eaa478ffaea48d09fe78670a136a1956c042011bf` | WHO augmented-dataset variable dictionary. 698 data rows, 4 columns, year span n/a, 606/2792 blank cells (21.70%) |

## Transformations

- `unaids_hiv_prevalence_all_ages.csv`: the UNAIDS all-ages HIV
  prevalence series was screened to the four countries and to the
  years 2010-2024. The all-ages indicator includes AIDS, whereas the
  manuscript's `y_2` observation excludes AIDS.
- `un_wpp_population_2010_2024.csv`: total population screened to the
  four countries and 2010-2024; values are World Bank WDI
  `SP.POP.TOTL`.
- `Kenya-1.csv`, `Thailand-1.csv`, `Portugal-1.csv`,
  `south african-1.xls`: WHO estimated TB incidence per 100 000 with
  its uncertainty interval, and new and relapse TB cases notified per
  100 000, screened to 2010-2024. These country-profile notification
  series are annual reported quantities, not the instantaneous
  treatment flow of the model.
- `who_augmented/*`: the augmented WHO country-year tables are retained
  as global country-year source tables. The estimates table covers
  2000-2024, notifications 1980-2024, outcomes 1994-2023, and
  contact/TPT 2015-2024; four-country slices are used only in the
  exploratory observation-design material. The `newrel_coh`
  treatment-cohort proxy used by that material is non-missing for
  the four countries over 2012-2023, not for every year of the
  broader 2010-2024 observation window.

## Missingness

Blank-cell fractions are reported per file in `content_summary` above
and in `DATA_MANIFEST.csv`. No value was imputed.

## Key archived computational outputs and seeds

`bifurcation/output/representative_diagnostics.json` stores the
representative Q = 0.80 equilibria and the BP1/LP2 diagnostics used
for the supplementary window-diagnostics table. The high-burden window
pilot uses seed 42 (high-burden window pilot 42); the window-coordinate
and interval-integrated pilots 20260930 use seed 20260930. The phrase
`interval-integrated pilots 20260930` identifies the two pilots that
share that seed. The seed assignments are also listed in `HMQ_ESM.tex`.

## Software environment

The archived outputs were produced with CPython 3.9.7 (NumPy 1.26.4,
SciPy 1.13.1, Matplotlib 3.9.0) and PyTorch 2.8.0 (CPU); the local
structural-identifiability runs used Julia 1.10.4 with
StructuralIdentifiability.jl v0.5.27. Fixed seeds: Latin-hypercube
scan 20260912; direct-ODE identifiability experiments 42; sensitivity
calculations 20260811; PRCC 20261016; robustness and window-coordinate
pilots 20260930; PINN Monte Carlo 20260811 (noise seed offsets 17 per
realization, network seed offsets 31 plus 10000).

## Parameter ranges

Latin-hypercube and PRCC bounds: natural mortality mu 0.010-0.020;
TB progression k 0.20-0.60, k* 1.0-3.0; TB mortality d 0.05-0.20,
d* 0.10-0.40; AIDS progression alpha1 0.05-0.15, alpha2 0.10-0.30,
alpha3 0.25-0.75; AIDS mortality f 0.25-0.75; TB-acquisition modifier
in J1 theta 0.9-1.1; HIV-acquisition modifier in L sigma_rel 0.9-1.1;
treatment a0 0.30-0.90, a_max 0.80-2.00; dimensionless saturation
omega0_tilde 20-1000 and omega_min_tilde 20-400 (both log-uniform);
shape parameter m 0.001-10. Samples violating a_max > a0 + 0.05 or
omega_min_tilde < 0.95 * omega0_tilde are rejected and redrawn.
Baseline preset: a0 = 0.6, a_max = 1.5, omega0 = 0.003,
omega_min = 1e-5, m = 0.05, R2 = 1.8.

## Noise, observation and objective specification

Synthetic observations use multiplicative Gaussian noise with 5%
standard deviation (sigma = 0.05; noise seed 42 unless stated). The
observation map is y1 = (k L + k* J2) / N x 1e5 (TB incidence per
100 000) and y2 = non-AIDS HIV prevalence; the extended map y3 is the
instantaneous treatment flow. The record is quarterly over 14 years
(57 time points); H2 uses 2 outputs x 57 points = 114 observations and
4 free parameters (110 residual degrees of freedom). The fitting
objective is the relative-error deviance
chi2 = sum((pred - obs)/obs)^2 / sigma^2.

## Initialization and optimizer settings

Direct-ODE fits start from a deterministic start grid with 3 starts
per realization, and the best objective is retained. All nonlinear
solves use scipy.optimize.least_squares with parameter bounds
(xtol = ftol = gtol = 1e-13 for the dedicated fold and branch-point
solves, 1e-10 for the general equilibrium solves; max_nfev 6000 for
the fold solve and 1800 for the window-audit root solves). Continuation
uses a custom pseudo-arclength predictor-corrector with adaptive step;
steps are accepted when the scaled equilibrium residual is below
8e-6 and the arclength constraint is satisfied to 5e-4. Retained
equilibria satisfy the scaled residual cutoff 1e-7, and folds satisfy
|lambda_0| < 1e-7.

## Training schedule (conditional PINN)

Adam optimizer with gradient clipping at norm 5.0; state network with
two hidden layers of 32 units and tanh activation; 300 collocation
points. Four phases: 400 epochs at lr 1e-3 with data weight 1.0 and
ODE weight 0.00; 600 epochs at lr 5e-4 with weights 1.0 / 0.10; 800
epochs at lr 2e-4 with weights 0.8 / 0.50; 800 epochs at lr 1e-4 with
weights 0.5 / 1.00. Total 2600 epochs; the initial-condition weight is
1.0 throughout.

## Normalization and figure-specific grids

Reported reconstruction errors are RMSEs divided by the peak-to-peak
range of the true trajectory over the observation window. TB-only
scans use 220 points on R1 in [0.40, 1.35]; the plotted equilibrium
curves are rebuilt on 350 log-spaced values of I (plus the fold
state). The below-branch non-principal-root census uses 80 evenly
spaced slices in Q in [0.55, 0.6632535]; the full-window audit uses 80
slices in Q in [0.6643535, 0.999]. Basin classification uses a 25 x 25
seed grid integrated to t = 1500, with a finite-time cutoff of 0.005
on the terminal TB or HIV fraction; trajectory panels are plotted from
t = 30.
