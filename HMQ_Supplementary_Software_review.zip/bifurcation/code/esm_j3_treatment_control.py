"""ESM structural sensitivity: treatment destination for the J3 compartment.

Reviewer concern (manuscript 5.1(1))
-----------------------------------
The main model assigns no explicit treatment term to the HIV-active-TB
compartment J3 (Roeger et al. destination structure).  The natural minimal
control is to give J3 the same saturated treatment form as L, I and J2,

    h(J3; t) = a(B) * J3 / (1 + omega(B) * J3),

with treated J3 individuals clearing TB and returning to the HIV-only
compartment J1 (mirroring the existing J2 -> J1 flow).  The audited baseline
calculation distinguishes the TB-only/HIV boundary branch point from a
genuine interior saddle-node, so the comparison tests the sensitivity of
that branch structure rather than assuming that every zero eigenvalue is LP1.

Implementation
--------------
This script imports the audited full-system branch solver
(05_full_backward_bifurcation_v4_verified.py) and the shared model
(00_common.py), then repeats the branch-point / interior-fold checks twice:

    baseline     : the published model (no J3 treatment);
    J3 treatment : dJ3 -= treat_J3,  dJ1 += treat_J3.

At the TB-free states B = 0 the J3 treatment linearises to a0 * J3, so the
invasion map R1^2 gains a0 in the J3 diagonal of the removal matrix V.
Everything else (parameters, RH = 1.8, m = 0.05) is identical to the
verified publication figure.
"""

import importlib.util
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent

# Faster local regeneration for the control (same default behaviour as the
# verified script; the env vars are read at import time below).
os.environ.setdefault("FULL_BIF_N_BRANCH", "240")
os.environ.setdefault("FULL_BIF_SEED_STEPS", "400")

# --- load shared model -----------------------------------------------------
_spec_c = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(_spec_c)
sys.modules["common"] = common
_spec_c.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

# --- load the verified full-system fold solver as a module -----------------
_spec_v = importlib.util.spec_from_file_location(
    "verifier", str(HERE / "05_full_backward_bifurcation_v4_verified.py")
)
verifier = importlib.util.module_from_spec(_spec_v)
sys.modules["verifier"] = verifier
_spec_v.loader.exec_module(verifier)

# Emit this control's figure beside the other publication figures.
# Allow a writable output directory during sandboxed/reproducibility runs;
# publication runs can leave this unset to write beside the code.
common.OUTPUT_DIR = os.environ.get("ESM_OUTPUT_DIR", str(HERE / ".." / "figures"))
OUTPUT_DIR = common.OUTPUT_DIR

# ===========================================================================
# J3-treatment variant of the RHS and of the invasion map
# ===========================================================================

TREAT_J3 = False  # module-level toggle; set before each fold computation


def rhs_full(x, beta1, beta2, m, p=P):
    """Full-model RHS, optionally including the J3 treatment term.

    Identical to 00_common.rhs_full except that, when TREAT_J3 is True, the
    saturated term h(J3) = a(B) J3 / (1 + omega(B) J3) removes TB from J3 and
    returns those individuals to J1 (the Roeger destination, mirroring
    J2 -> J1).
    """
    S, L, I, T, J1, J2, J3, A = x
    N = S + L + I + T + J1 + J2 + J3 + A
    R = N - I - J3 - A
    Jstar = J1 + J2 + J3

    if N <= 1e-12 or R <= 1e-12:
        return np.ones(8) * 1e12

    B = (I + J3) / N
    a, omega = response_from_burden(B, m, p)

    denom_L = 1.0 + omega * L
    denom_I = 1.0 + omega * I
    denom_J2 = 1.0 + omega * J2
    denom_J3 = 1.0 + omega * J3
    if denom_L <= 0 or denom_I <= 0 or denom_J2 <= 0 or denom_J3 <= 0:
        return np.ones(8) * 1e12

    treat_L = a * L / denom_L
    treat_I = a * I / denom_I
    treat_J2 = a * J2 / denom_J2
    treat_J3 = a * J3 / denom_J3 if TREAT_J3 else 0.0

    tb_force = beta1 * (I + J3) / N
    hiv_force = beta2 * Jstar / R

    dS = p.Lambda - tb_force * S - hiv_force * S - p.mu * S

    dL = (
        beta1 * (S + T) * (I + J3) / N
        - p.sigma_rel * beta2 * L * Jstar / R
        - (p.mu + p.k) * L
        - treat_L
    )

    dI = p.k * L - (p.mu + p.d) * I - treat_I

    dT = (
        treat_L + treat_I
        - beta1 * T * (I + J3) / N
        - beta2 * T * Jstar / R
        - p.mu * T
    )

    dJ1 = (
        beta2 * (S + T) * Jstar / R
        - p.theta * beta1 * J1 * (I + J3) / N
        - (p.alpha1 + p.mu) * J1
        + treat_J2
        + treat_J3
    )

    dJ2 = (
        p.sigma_rel * beta2 * L * Jstar / R
        + p.theta * beta1 * J1 * (I + J3) / N
        - (p.alpha2 + p.mu + p.k_star) * J2
        - treat_J2
    )

    dJ3 = p.k_star * J2 - (p.alpha3 + p.mu + p.d_star) * J3 - treat_J3

    dA = p.alpha1 * J1 + p.alpha2 * J2 + p.alpha3 * J3 - (p.mu + p.f) * A

    return np.array([dS, dL, dI, dT, dJ1, dJ2, dJ3, dA], dtype=float)


def RTH_for_beta1(beta1, RH, p=P):
    """TB-invasion number R1^2, with the J3 treatment folded into V.

    Identical to 00_common.RTH_for_beta1 except that, when TREAT_J3 is True,
    the J3 diagonal of the removal matrix V gains a0 (the linearised J3
    treatment rate at the TB-free state B = 0).
    """
    beta2 = beta2_from_RH(RH, p)
    EH = full_tb_free_equilibrium(RH, p)
    S, J1 = EH[0], EH[4]
    N = np.sum(EH)
    R = S + J1

    if N <= 0 or R <= 0:
        return np.nan

    h = p.sigma_rel * beta2 * J1 / R

    F = np.zeros((4, 4))
    # x_T = (L, I, J2, J3)
    F[0, 1] = beta1 * S / N
    F[0, 3] = beta1 * S / N
    F[2, 1] = p.theta * beta1 * J1 / N
    F[2, 3] = p.theta * beta1 * J1 / N

    j3_removal = p.alpha3 + p.mu + p.d_star + (p.a0 if TREAT_J3 else 0.0)

    V = np.array([
        [p.mu + p.k + p.a0 + h, 0.0, 0.0, 0.0],
        [-p.k, p.mu + p.d + p.a0, 0.0, 0.0],
        [-h, 0.0, p.alpha2 + p.mu + p.k_star + p.a0, 0.0],
        [0.0, 0.0, -p.k_star, j3_removal],
    ], dtype=float)

    K = F @ np.linalg.inv(V)
    return float(np.max(np.abs(eigvals(K))))


def _apply_patch():
    """Route every model call through the variant RHS / invasion map.

    The verified solver calls rhs_full both directly (fold_residual,
    solve_fold) and indirectly through common's full_residual_scaled /
    find_full_equilibria / full_stability.  Patching both namespaces makes
    all of them resolve to the TREAT_J3-aware variant.

    The verifier re-instantiates its OWN copy of 00_common on import (via
    spec_from_file_location); its equilibrium solvers bind rhs_full in that
    inner namespace, which must also be patched. Otherwise the root-finder
    would silently keep using the untreated model while the Jacobian used
    the treated one -- an inconsistent hybrid.
    """
    inner = verifier.find_full_equilibria.__globals__
    for ns in (common.__dict__, verifier.__dict__, inner):
        ns["rhs_full"] = rhs_full
        ns["RTH_for_beta1"] = RTH_for_beta1


_apply_patch()


def set_variant(treat_j3):
    global TREAT_J3
    TREAT_J3 = bool(treat_j3)


# ===========================================================================
# Boundary branch-point locator and branch comparison
# ===========================================================================

FOLD_LO, FOLD_HI = 0.45, verifier.Q_MAX  # Q_MAX = 1.55


def locate_bp1():
    """Locate the TB-only/HIV boundary point for the active model variant.

    The control can shift the crossing far to the right of the baseline
    value, so the search interval must cover the full reported sensitivity
    range rather than the narrow baseline bracket.
    """
    try:
        return verifier.locate_tb_hiv_branch_point(
            q_lower=max(FOLD_LO, 0.60), q_upper=1.08
        )
    except RuntimeError:
        # The control may remove the transverse crossing from the reported
        # interval.  This is an informative no-crossing result, not a fold.
        return None


def scan_variant(q_values):
    """Collect validated equilibria for a variant on a prescribed Q grid."""
    records = []
    previous = []
    for q in q_values:
        current = verifier.equilibrium_records(float(q), previous=previous)
        records.extend(current)
        previous = [r["state"] for r in current]
    return records


def collapse_scan_by_q(records, stable, choose="max"):
    """Keep one branch representative per Q to avoid connecting roots."""
    grouped = {}
    for rec in records:
        if bool(rec["stable"]) != bool(stable):
            continue
        grouped.setdefault(round(float(rec["Q"]), 10), []).append(rec)
    out = []
    for q in sorted(grouped):
        vals = grouped[q]
        key = (lambda r: r["burden"]) if choose == "max" else (lambda r: -r["burden"])
        out.append(max(vals, key=key))
    return out


def collapse_class_scan_by_q(records, eq_class, stable, choose="max"):
    """Collapse a scan after enforcing both disease support and stability."""
    return collapse_scan_by_q(
        [r for r in records if r.get("eq_class") == eq_class],
        stable=stable, choose=choose,
    )


def follow_branch_partial(Q_values, initial_record, stable, eq_class=None):
    """Like verifier.follow_branch, but returns the partial branch on loss."""
    branch = [initial_record]
    previous = initial_record["state"]
    for Q in Q_values[1:]:
        records = verifier.equilibrium_records(Q, previous=[previous])
        candidate = verifier.nearest_record(
            records, previous, stable=stable, eq_class=eq_class
        )
        if candidate is None:
            break
        branch.append(candidate)
        previous = candidate["state"]
    return branch


def collect_branches(lp1, q_stop=1.08):
    """Follow the boundary and strict interior branches from the branch point.

    The control model may have its interior fold above BP1, so the unstable
    branch is initialized from a dedicated validated scan rather than by
    assuming a root exists immediately at BP1 + EPS.
    """
    q1_in = lp1["Q"] + verifier.EPS_FOLD
    q_values = np.linspace(q1_in, q_stop, verifier.N_BRANCH)
    roots = verifier.equilibrium_records(q1_in, previous=[lp1["state"]])
    upper0 = verifier.nearest_record(
        roots, lp1["state"], stable=True, eq_class="tb_only"
    )
    upper = (
        follow_branch_partial(q_values, upper0, True, eq_class="tb_only")
        if upper0 is not None else []
    )

    # Search a finite interval for the unstable strict co-endemic branch.
    middle0 = None
    q_middle_start = None
    q_probe = np.linspace(q1_in, q_stop, 60)
    previous = [lp1["state"]]
    for q in q_probe:
        records = verifier.equilibrium_records(float(q), previous=previous)
        candidate = verifier.nearest_record(
            records, lp1["state"], stable=False, eq_class="co_endemic"
        )
        if candidate is not None:
            middle0, q_middle_start = candidate, float(q)
            break
        previous = [r["state"] for r in records]
    middle = []
    if middle0 is not None:
        middle_values = np.linspace(q_middle_start, q_stop, verifier.N_BRANCH)
        middle = follow_branch_partial(
            middle_values, middle0, False, eq_class="co_endemic"
        )
    return upper, middle


# ===========================================================================
# Run both variants and produce the comparison figure
# ===========================================================================

def main():
    set_publication_style()

    set_variant(False)
    print("Computing baseline boundary point (no J3 treatment) ...", flush=True)
    bp1_base = locate_bp1()
    if bp1_base is None:
        raise RuntimeError("Baseline TB-only/HIV boundary point could not be located")
    print(
        f"Baseline BP1: Q={bp1_base['Q']:.8f}, "
        f"B={bp1_base['burden']:.8f}, "
        f"transverse growth={bp1_base.get('transverse_growth', 0.0):.2e}"
    )

    set_variant(True)
    print("Computing J3-treatment boundary point (J3 -> J1) ...", flush=True)
    bp1_j3 = locate_bp1()
    if bp1_j3 is not None:
        print(
            f"J3-treated BP1: Q={bp1_j3['Q']:.8f}, "
            f"B={bp1_j3['burden']:.8f}, "
            f"transverse growth={bp1_j3.get('transverse_growth', 0.0):.2e}"
        )

    # Collect each variant's branches under its own model.  A direct scan is
    # retained as a fallback only if a crossing cannot be bracketed.
    set_variant(False)
    base_upper, base_middle = collect_branches(bp1_base)
    set_variant(True)
    if bp1_j3 is not None:
        j3_upper, j3_middle = collect_branches(bp1_j3)
    else:
        q_scan = np.linspace(max(FOLD_LO, 0.60), 1.08, 25)
        j3_scan = scan_variant(q_scan)
        # The fallback is deliberately class-aware: a stable TB-only boundary
        # root must not be relabelled as a co-endemic branch, and an unstable
        # HIV-only/TB-free root must not enter the burden plot.
        j3_upper = collapse_class_scan_by_q(j3_scan, "co_endemic", True, "max")
        j3_middle = collapse_class_scan_by_q(j3_scan, "co_endemic", False, "max")
        # Keep the boundary branch separately for diagnostics, but never draw
        # it as if it were a strict co-endemic branch.
        j3_tb_boundary = collapse_class_scan_by_q(j3_scan, "tb_only", True, "max")
        j3_upper = [r for r in j3_upper if r["burden"] > verifier.POSITIVE_BURDEN]
        j3_middle = [r for r in j3_middle if r["burden"] > verifier.POSITIVE_BURDEN]

    # ---- headline answer -------------------------------------------------
    headline = []
    headline.append("=" * 72)
    headline.append("ESM structural sensitivity: explicit J3 treatment term")
    headline.append("=" * 72)
    headline.append(
        f"baseline (no J3 treatment):  BP1 = R1^2 = {bp1_base['Q']:.6f}   "
        "boundary point, not an interior fold"
    )
    if bp1_j3 is not None:
        headline.append(
            f"J3 treatment (J3 -> J1):     BP1 = R1^2 = {bp1_j3['Q']:.6f}   "
            "boundary point, not an interior fold"
        )
        shift = bp1_j3["Q"] - bp1_base["Q"]
        headline.append(f"BP1 shift from adding J3 treatment: {shift:+.6f}")
    else:
        headline.append(
            "J3 treatment (J3 -> J1):     no TB-only/HIV boundary point found "
            "for 0.60 <= R1^2 <= 1.08"
        )
        headline.append(
            "=> No comparable boundary crossing was detected on the selected scan; "
            "the control is retained as a finite-range structural-sensitivity result."
        )
    headline.append("=" * 72)
    summary = "\n".join(headline)
    print(summary)

    # Persist the headline result beside the figure.
    summary_path = Path(OUTPUT_DIR) / "esm_j3_treatment_control_summary.txt"
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(summary + "\n", encoding="utf-8")
    print(f"saved: {summary_path}", flush=True)

    # ---- comparison figure ----------------------------------------------
    if bp1_j3 is None:
        # Fallback case: plot the validated baseline branches together with the
        # J3-treatment scan and the forward threshold.
        fig, ax = plt.subplots(figsize=(6.6, 4.3))
        ax.plot(np.linspace(verifier.Q_MIN, 1.0, 250), np.zeros(250),
                color=verifier.TB_FREE_COLOR, linewidth=1.65)
        ax.axvline(1.0, color="#6E6E6E", linestyle="--", linewidth=0.9)
        if base_upper:
            ax.plot([bp1_base["Q"]] + [r["Q"] for r in base_upper],
                    [bp1_base["burden"]] + [r["burden"] for r in base_upper],
                    color="#0B3C5D", linewidth=2.2, label="baseline: stable TB-only boundary")
        if base_middle:
            ax.plot([bp1_base["Q"]] + [r["Q"] for r in base_middle],
                    [bp1_base["burden"]] + [r["burden"] for r in base_middle],
                    color="#B2182B", linestyle=(0, (4.2, 2.2)), linewidth=2.0,
                    label="baseline: unstable strict co-endemic")
        if j3_upper:
            ax.scatter([r["Q"] for r in j3_upper], [r["burden"] for r in j3_upper],
                       color="#2E7D32", s=18, zorder=6,
                       label="J3-treated: stable equilibria")
        if j3_middle:
            ax.scatter([r["Q"] for r in j3_middle], [r["burden"] for r in j3_middle],
                       facecolors="none", edgecolors="#E65100", s=22, zorder=6,
                       label="J3-treated: unstable equilibria")
        ax.plot(bp1_base["Q"], bp1_base["burden"], marker="^", markersize=7.5,
                 markerfacecolor="#6A3D9A", markeredgecolor="#3B1F5A",
                 markeredgewidth=1.2, label="BP1 (baseline)")
        ax.text(0.62, 0.92, "J3-treated: no bracketed boundary crossing\n"
                "or subthreshold interior fold in fallback scan",
                transform=ax.transAxes, ha="center", va="top", fontsize=7.2,
                bbox=white_box(alpha=0.85))
        ax.set_xlim(verifier.Q_MIN, 1.08)
        ax.set_ylim(bottom=-0.01)
        ax.set_xlabel(r"TB invasion reproduction number, $\mathcal{R}_1^2$")
        ax.set_ylabel(r"Full active TB burden, $(I^*+J_3^*)/N^*$")
        ax.grid(True, color="#E8E8E8", linewidth=0.45, alpha=0.72)
        ax.legend(frameon=False, fontsize=7.5, loc="best")
        fig.tight_layout()
        save_fig(fig, "fig_ESM_j3_treatment_control")
        plt.close(fig)
        summary_path = Path(OUTPUT_DIR) / "esm_j3_treatment_control_summary.txt"
        summary_path.parent.mkdir(parents=True, exist_ok=True)
        summary_path.write_text(summary + "\n", encoding="utf-8")
        print(f"saved: {summary_path}", flush=True)
        return

    fig, ax = plt.subplots(figsize=(7.0, 4.9))

    def qs(branch):
        return [r["Q"] for r in branch]

    def bs(branch):
        return [r["burden"] for r in branch]

    base_c = "#0B3C5D"   # dark blue
    base_u = "#B2182B"   # red
    j3_c = "#2E7D32"     # green
    j3_u = "#E65100"     # orange
    point_base = "#6A3D9A"
    point_j3 = "#3E2723"

    # TB-free branch and the threshold line.
    ax.plot(np.linspace(verifier.Q_MIN, 1.0, 250), np.zeros(250),
            color=verifier.TB_FREE_COLOR, linewidth=1.65)
    ax.plot(np.linspace(1.0, 1.08, 250), np.zeros(250),
            color=verifier.TB_FREE_COLOR, linestyle=(0, (4.2, 2.2)), linewidth=1.55)
    ax.axvline(1.0, color="#6E6E6E", linestyle="--", linewidth=0.9)

    def draw(branch, color, linestyle):
        if not branch:
            return
        ax.plot(qs(branch), bs(branch), color=color, linestyle=linestyle,
                linewidth=2.2, zorder=5)

    # baseline
    lp1b_rec = {"Q": bp1_base["Q"], "burden": bp1_base["burden"]}
    draw([lp1b_rec] + base_upper, base_c, "-")
    draw([lp1b_rec] + base_middle, base_u, (0, (4.2, 2.2)))
    # J3 treatment
    lp1j_rec = {"Q": bp1_j3["Q"], "burden": bp1_j3["burden"]}
    draw([lp1j_rec] + j3_upper, j3_c, "-")
    draw([lp1j_rec] + j3_middle, j3_u, (0, (4.2, 2.2)))

    ax.plot(bp1_base["Q"], bp1_base["burden"], marker="^", markersize=7.5,
            markerfacecolor=point_base, markeredgecolor="#3B1F5A",
            markeredgewidth=1.2, zorder=10)
    ax.plot(bp1_j3["Q"], bp1_j3["burden"], marker="^", markersize=7.5,
            markerfacecolor=point_j3, markeredgecolor="#1B0F0C",
            markeredgewidth=1.2, zorder=10)
    ax.annotate(rf"baseline BP1: $\mathcal{{R}}_1^2\approx{bp1_base['Q']:.4f}$",
                xy=(bp1_base["Q"], bp1_base["burden"]),
                xytext=(bp1_base["Q"] + 0.05, bp1_base["burden"] - 0.085),
                fontsize=8, arrowprops=dict(arrowstyle="->", color=point_base,
                linewidth=0.9), bbox=white_box(alpha=0.85))
    ax.annotate(rf"J3-treated BP1: $\mathcal{{R}}_1^2\approx{bp1_j3['Q']:.4f}$",
                xy=(bp1_j3["Q"], bp1_j3["burden"]),
                xytext=(bp1_j3["Q"] + 0.10, bp1_j3["burden"] + 0.075),
                fontsize=8, arrowprops=dict(arrowstyle="->", color=point_j3,
                linewidth=0.9), bbox=white_box(alpha=0.85))

    all_burdens = [r["burden"] for r in
                   [lp1b_rec] + base_upper + base_middle +
                   [lp1j_rec] + j3_upper + j3_middle if r["burden"] > 0]
    ymax = 1.14 * max(all_burdens)

    ax.text(1.065, 0.55 * ymax,
            rf"$\mathcal{{R}}_2={verifier.RH:g}$" + "\n" + rf"$m={verifier.M:g}$",
            fontsize=8.2, ha="right", bbox=white_box(alpha=0.85))
    ax.set_xlim(0.55, 1.08)
    ax.set_ylim(-0.03 * ymax, ymax)
    ax.set_xlabel(r"TB invasion reproduction number, $\mathcal{R}_1^2$")
    ax.set_ylabel(r"Full active TB burden, $(I^*+J_3^*)/N^*$")
    ax.grid(True, color="#E8E8E8", linewidth=0.45, alpha=0.72)
    ax.legend(handles=[
        Line2D([0], [0], color=base_c, linewidth=2.2, label="baseline: stable TB-only boundary"),
        Line2D([0], [0], color=base_u, linestyle=(0, (4.2, 2.2)), linewidth=2.0,
               label="baseline: unstable strict co-endemic"),
        Line2D([0], [0], color=j3_c, linewidth=2.2, label="J3-treated: stable TB-only boundary"),
        Line2D([0], [0], color=j3_u, linestyle=(0, (4.2, 2.2)), linewidth=2.0,
               label="J3-treated: unstable strict co-endemic"),
        Line2D([0], [0], color=verifier.TB_FREE_COLOR, linewidth=1.65, label="TB-free branch"),
        Line2D([0], [0], color="#6E6E6E", linestyle="--", linewidth=0.9,
               label=r"$\mathcal{R}_1^2=1$"),
        Line2D([0], [0], marker="^", color=point_base, markeredgecolor="#3B1F5A",
               linewidth=0, markersize=7.5, label="BP1 (baseline)"),
        Line2D([0], [0], marker="^", color=point_j3, markeredgecolor="#1B0F0C",
               linewidth=0, markersize=7.5, label="BP1 (J3-treated)"),
    ], frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.095),
       handlelength=2.6, ncol=2, fontsize=8, columnspacing=1.4)
    fig.tight_layout()
    save_fig(fig, "fig_ESM_j3_treatment_control")
    plt.close(fig)


if __name__ == "__main__":
    main()
