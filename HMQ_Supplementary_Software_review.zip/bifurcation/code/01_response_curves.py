import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location("common", str(Path(__file__).with_name("00_common.py")))
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({name: getattr(common, name) for name in dir(common) if not name.startswith("_")})

def main():
    set_publication_style()
    write_parameter_summary()

    B = np.linspace(0, 0.25, 420)
    m_values = [0.05, 0.5, 2.0, 5.0, 10.0]

    cmap = plt.get_cmap("viridis")

    # =========================
    # Fig. 01a
    # =========================
    fig, ax = plt.subplots(figsize=(4.4, 3.6))

    for idx, m in enumerate(m_values):
        color = cmap(idx / (len(m_values) - 1))
        a_values = []
        for b in B:
            a, omega = response_from_burden(b, m, P)
            a_values.append(a)

        ax.plot(B, a_values, color=color, linewidth=2.0, label=rf"$m={m:g}$")

    ax.set_xlabel(r"Active-TB prevalence, $B=(I+J_3)/N$")
    ax.set_ylabel(r"Treatment-intensity coefficient, $a(B)$ (yr$^{-1}$)")
    ax.grid(True, color="#E4E4E4", linewidth=0.45, alpha=0.75)
    ax.legend(frameon=False, loc="best")

    fig.tight_layout()
    save_fig(fig, "fig_01a_treatment_scale_up")


    # =========================
    # Fig. 01b
    # =========================
    fig, ax = plt.subplots(figsize=(4.4, 3.6))

    for idx, m in enumerate(m_values):
        color = cmap(idx / (len(m_values) - 1))
        omega_values = []
        for b in B:
            a, omega = response_from_burden(b, m, P)
            omega_values.append(omega)

        ax.plot(B, omega_values, color=color, linewidth=2.0, label=rf"$m={m:g}$")

    ax.set_xlabel(r"Active-TB prevalence, $B=(I+J_3)/N$")
    ax.set_ylabel(r"Resource-limitation coefficient, $\omega(B)$ (individual$^{-1}$)")
    ax.grid(True, color="#E4E4E4", linewidth=0.45, alpha=0.75)
    ax.legend(frameon=False, loc="best")

    fig.tight_layout()
    save_fig(fig, "fig_01b_resource_limitation")


if __name__ == "__main__":
    main()
