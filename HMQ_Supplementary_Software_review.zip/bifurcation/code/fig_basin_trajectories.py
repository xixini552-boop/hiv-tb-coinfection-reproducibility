"""Representative trajectory overlay for the full-system boundary bistability.

At Q=R_1^2=0.8 (inside the bistability window), several strictly-positive
initial conditions are integrated forward in time.  Each trajectory is plotted
in the (active-TB burden, HIV fraction) plane with an arrow indicating the time
direction; green trajectories converge to the HIV-free TB boundary (T) and
purple trajectories to the TB-free HIV-endemic boundary (H).  The two boundary
attractors are marked with stars.  This conveys the dynamic convergence process
rather than a static classification grid.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "audited_full", str(HERE / "05_full_backward_bifurcation_v4_verified.py")
)
mod = importlib.util.module_from_spec(spec)
sys.modules["audited_full"] = mod
spec.loader.exec_module(mod)

Q = 0.80
N0 = mod.P.N0
EPS = 1.0e-6
T_END = 400.0
N_REC = 500
beta1 = mod.beta1_from_RTH(Q, mod.RH, mod.P)

T_COLOR = "#1B7837"
H_COLOR = "#762A83"

# Representative initial conditions (I(0)/N, J1(0)/N).  Spanning the T basin,
# the separatrix neighbourhood, and the H basin.  The final classification is
# computed below (not hard-coded) so the colours are data-driven.
SEEDS = [
    (0.22, 0.05),
    (0.15, 0.10),
    (0.12, 0.15),
    (0.10, 0.18),
    (0.16, 0.32),
]


def make_x0(p_tb: float, p_hiv: float) -> np.ndarray:
    x0 = np.full(8, EPS * N0, dtype=float)
    x0[2] = p_tb * N0
    x0[4] = p_hiv * N0
    remainder = (1.0 - p_tb - p_hiv - 6.0 * EPS) * N0
    x0[0] = max(remainder, EPS * N0)
    return x0


def rhs(t: float, x: np.ndarray) -> np.ndarray:
    return mod.rhs_full(np.maximum(x, 0.0), beta1, mod.BETA2, mod.M, mod.P)


def burden_hiv(x: np.ndarray) -> tuple[float, float]:
    n = max(float(x.sum()), 1e-12)
    tb = float((x[2] + x[6]) / n)
    hiv = float((x[4] + x[5] + x[6] + x[7]) / n)
    return tb, hiv


def classify(x_end: np.ndarray) -> str:
    tb, hiv = burden_hiv(x_end)
    return "T" if (tb > 0.10 and hiv < 0.05) else "H"


# Integrate each seed and record the (TB burden, HIV fraction) trajectory.
trajectories = []
for (p_tb, p_hiv) in SEEDS:
    x0 = make_x0(p_tb, p_hiv)
    t_eval = np.linspace(0.0, T_END, N_REC)
    sol = solve_ivp(rhs, (0.0, T_END), x0, method="LSODA", t_eval=t_eval,
                    rtol=2e-7, atol=2e-9, max_step=4.0)
    ys = np.maximum(sol.y, 0.0)
    tb_t = np.array([burden_hiv(ys[:, k])[0] for k in range(ys.shape[1])])
    hiv_t = np.array([burden_hiv(ys[:, k])[1] for k in range(ys.shape[1])])
    cls = classify(ys[:, -1])
    # Plot only the convergence segment: start after the initial overshoot (t>=30)
    # and truncate at the first entry into the attractor neighbourhood.
    t_arr = sol.t
    start_idx = int(np.searchsorted(t_arr, 30.0))
    tb_att, hiv_att = (0.2199, 0.0) if cls == "T" else (0.0, 0.4886)
    tol = 0.015
    in_nbhd = (np.abs(tb_t - tb_att) < tol) & (np.abs(hiv_t - hiv_att) < tol)
    cut_idx = len(tb_t) - 1
    for k in range(start_idx, len(tb_t) - 25):
        if in_nbhd[k] and bool(np.all(in_nbhd[k:k + 25])):
            cut_idx = k
            break
    trajectories.append({
        "seed": (p_tb, p_hiv), "tb": tb_t[start_idx:cut_idx + 1],
        "hiv": hiv_t[start_idx:cut_idx + 1], "end": burden_hiv(ys[:, -1]),
        "class": cls,
    })
    print(f"seed (I0={p_tb:.2f}, J1_0={p_hiv:.2f}) -> {cls}; "
          f"end (TB={burden_hiv(ys[:, -1])[0]:.4f}, HIV={burden_hiv(ys[:, -1])[1]:.4f})")

# ------------------------------------------------------------------
# Plot.
# ------------------------------------------------------------------
mod.set_publication_style()
fig, ax = plt.subplots(figsize=(5.8, 4.6))

for tr in trajectories:
    color = T_COLOR if tr["class"] == "T" else H_COLOR
    hiv, tb = tr["hiv"], tr["tb"]
    ax.plot(hiv, tb, color=color, linewidth=1.6, alpha=0.92, zorder=3)
    # start point (open circle)
    ax.plot(hiv[0], tb[0], marker="o", markersize=6.0, markerfacecolor="white",
            markeredgecolor=color, markeredgewidth=1.3, zorder=5)
    # arrow at ~55% of the trajectory
    k = int(0.55 * (len(hiv) - 1))
    k2 = min(k + 5, len(hiv) - 1)
    ax.annotate("", xy=(hiv[k2], tb[k2]), xytext=(hiv[k], tb[k]),
                arrowprops=dict(arrowstyle="->", color=color, lw=1.7,
                                shrinkA=0, shrinkB=0), zorder=4)
    # end point (filled circle)
    ax.plot(hiv[-1], tb[-1], marker="o", markersize=6.0, markerfacecolor=color,
            markeredgecolor="white", markeredgewidth=0.8, zorder=5)

# Mark the two boundary attractors with stars (use mean endpoint of each class).
for cls, color, marker, label in [
    ("T", T_COLOR, "*", "HIV-free TB boundary attractor"),
    ("H", H_COLOR, "*", "TB-free HIV-endemic attractor"),
]:
    pts = [tr["end"] for tr in trajectories if tr["class"] == cls]
    if pts:
        mean_tb = float(np.mean([p[0] for p in pts]))
        mean_hiv = float(np.mean([p[1] for p in pts]))
        ax.plot(mean_hiv, mean_tb, marker=marker, markersize=15, color=color,
                markeredgecolor="white", markeredgewidth=1.0, zorder=6)

ax.set_xlabel(r"HIV fraction, $(J_1+J_2+J_3+A)/N$")
ax.set_ylabel(r"Active TB burden, $(I+J_3)/N$")
all_tb = np.concatenate([tr["tb"] for tr in trajectories])
all_hiv = np.concatenate([tr["hiv"] for tr in trajectories])
ax.set_xlim(-0.01, float(np.max(all_hiv)) * 1.06)
ax.set_ylim(-0.01, max(0.30, float(np.max(all_tb)) * 1.08))
ax.grid(True, color="#E8E8E8", linewidth=0.45, alpha=0.7)

from matplotlib.lines import Line2D
handles = [
    Line2D([], [], color=T_COLOR, linewidth=2.0, marker="o", markersize=6,
           markerfacecolor="white", markeredgecolor=T_COLOR, label="trajectory converging to T"),
    Line2D([], [], color=H_COLOR, linewidth=2.0, marker="o", markersize=6,
           markerfacecolor="white", markeredgecolor=H_COLOR, label="trajectory converging to H"),
    Line2D([], [], color=T_COLOR, marker="*", linestyle="None", markersize=11,
           label="T attractor"),
    Line2D([], [], color=H_COLOR, marker="*", linestyle="None", markersize=11,
           label="H attractor"),
]
ax.legend(handles=handles, frameon=False, loc="upper right", fontsize=7.4,
          handlelength=1.6, labelspacing=0.4, borderpad=0.3)
fig.tight_layout(pad=0.4)

out = HERE.parent / "figures" / "fig_basin_trajectories_Q08.pdf"
out.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(out, bbox_inches="tight")
fig.savefig(out.with_suffix(".png"), bbox_inches="tight", dpi=200)
plt.close(fig)
print(f"Saved: {out}")
