"""
Quick check: does the boundary-bistability window exist at R2=1.2?
We compute the left edge (BP1: HIV invades TB boundary) at R2=1.2, m=0.05.
Right edge is always Q=R1^2=1. If BP1 < 1, window exists.
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(spec)
sys.modules["common"] = common
spec.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

P = common.P
M = 0.05


def central_jacobian(x, beta1, beta2, m, eps=1e-6):
    n = len(x)
    J = np.zeros((n, n))
    f0 = common.rhs_full(x, beta1, beta2, m)
    for i in range(n):
        xp = x.copy()
        xp[i] += eps
        J[:, i] = (common.rhs_full(xp, beta1, beta2, m) - f0) / eps
    return J


def transverse_growth(Q, RH):
    """Largest real eigenvalue of HIV block at TB-only E1."""
    beta1 = common.beta1_from_RTH(float(Q), RH, P)
    beta2 = common.beta2_from_RH(RH, P)
    roots = common.find_tb_endemic_equilibria(beta1, M, P, n_grid=800)
    if not roots:
        return None
    tb = max(roots, key=lambda y: y[2] / np.sum(y))
    x = np.zeros(8, dtype=float)
    x[:4] = tb
    J = central_jacobian(x, beta1, beta2, M)
    return float(np.max(np.real(eigvals(J[4:7, 4:7])))), x, tb


def find_bp1(RH, Q_lo=0.3, Q_hi=1.5):
    """Find Q where transverse growth crosses zero (BP1)."""
    f_lo = transverse_growth(Q_lo, RH)
    f_hi = transverse_growth(Q_hi, RH)
    if f_lo is None or f_hi is None:
        return None
    lam_lo = f_lo[0]
    lam_hi = f_hi[0]
    print(f"  Q={Q_lo:.3f}: lambda={lam_lo:.6e}")
    print(f"  Q={Q_hi:.3f}: lambda={lam_hi:.6e}")
    if lam_lo * lam_hi > 0:
        print(f"  No sign change in [{Q_lo},{Q_hi}]")
        return None
    q_star = brentq(lambda q: transverse_growth(q, RH)[0], Q_lo, Q_hi, xtol=1e-8)
    return q_star


def main():
    print("=== Window check at R2=1.2 ===", flush=True)
    RH = 1.2
    beta2 = common.beta2_from_RH(RH, P)
    print(f"beta2 = {beta2:.6f}", flush=True)

    # Find BP1
    bp1 = find_bp1(RH)
    if bp1 is not None:
        lam, x, tb = transverse_growth(bp1, RH)
        N = np.sum(x)
        B = (x[2] + x[6]) / N
        print(f"\nBP1 at R2={RH}: Q={bp1:.6f}, B={B:.6f}, lambda={lam:.2e}", flush=True)
        print(f"  TB state: S={x[0]:.2f}, L={x[1]:.2f}, I={x[2]:.2f}, T={x[3]:.2f}", flush=True)
        window_exists = bp1 < 1.0
        print(f"\nRight edge Q=1.0 (R1^2=1)", flush=True)
        print(f"Left edge  Q={bp1:.6f}", flush=True)
        print(f"Window exists: {window_exists}", flush=True)
        if window_exists:
            print(f"Window width: {1.0 - bp1:.6f}", flush=True)
        # Also check at Q=0.8 (inside window if exists)
        lam08, x08, tb08 = transverse_growth(0.8, RH)
        N08 = np.sum(x08)
        B08 = (x08[2] + x08[6]) / N08
        print(f"\nAt Q=0.8: lambda={lam08:.6e}, B={B08:.6f} (TB boundary {'unstable' if lam08>0 else 'stable'})", flush=True)
    else:
        print("Could not find BP1", flush=True)

    # Compare with R2=1.8
    print(f"\n=== Comparison with R2=1.8 ===", flush=True)
    print(f"R2=1.8: BP1=0.664, window width=0.336", flush=True)

    results = {
        "R2": RH, "m": M,
        "BP1_Q": bp1,
        "right_edge_Q": 1.0,
        "window_exists": bp1 < 1.0 if bp1 else None,
        "window_width": 1.0 - bp1 if bp1 else None,
        # Distinguishes "scan completed but no BP1 in the searched Q range"
        # from a run that never reached the comparison stage.
        "status": "bp1_found" if bp1 is not None else "no_bp1_in_scanned_range",
    }
    outpath = HERE.parent / "output" / "window_check_R2_1.2.json"
    with open(outpath, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved: {outpath}", flush=True)


if __name__ == "__main__":
    main()
