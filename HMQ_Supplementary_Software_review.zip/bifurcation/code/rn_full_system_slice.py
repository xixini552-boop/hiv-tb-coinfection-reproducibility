"""
R=N (proportionate mixing) full-system bifurcation slice.

Compares the bistability window edges with the withdrawal-assumption baseline.
Under R=N the HIV-mixing denominator is the total population N instead of
R = N - I - J3 - A.

Outputs:
  ../output/rn_full_system_slice.json
  ../figures/fig_RN_full_backward.pdf
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq, least_squares

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(spec)
sys.modules["common"] = common
spec.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

P = common.P
RH, M = 1.8, 0.05
BETA2 = common.beta2_from_RH(RH, P)
OUT = HERE.parent / "output"
FIG = HERE.parent / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# R=N model functions
# ---------------------------------------------------------------------------

def rhs_full_RN(x, beta1, beta2, m, p=P):
    """Full 8D RHS with proportionate mixing R=N."""
    S, L, I, T, J1, J2, J3, A = x
    N = S + L + I + T + J1 + J2 + J3 + A
    R = N  # proportionate mixing
    Jstar = J1 + J2 + J3
    if N <= 1e-12:
        return np.ones(8) * 1e12
    B = (I + J3) / N
    a, omega = common.response_from_burden(B, m, p)
    denom_L = 1.0 + omega * L
    denom_I = 1.0 + omega * I
    denom_J2 = 1.0 + omega * J2
    if denom_L <= 0 or denom_I <= 0 or denom_J2 <= 0:
        return np.ones(8) * 1e12
    treat_L = a * L / denom_L
    treat_I = a * I / denom_I
    treat_J2 = a * J2 / denom_J2
    tb_force = beta1 * (I + J3) / N
    hiv_force = beta2 * Jstar / R
    dS = p.Lambda - tb_force * S - hiv_force * S - p.mu * S
    dL = beta1 * (S + T) * (I + J3) / N - p.sigma_rel * beta2 * L * Jstar / R - (p.mu + p.k) * L - treat_L
    dI = p.k * L - (p.mu + p.d) * I - treat_I
    dT = treat_L + treat_I - beta1 * T * (I + J3) / N - beta2 * T * Jstar / R - p.mu * T
    dJ1 = beta2 * (S + T) * Jstar / R - p.theta * beta1 * J1 * (I + J3) / N - (p.alpha1 + p.mu) * J1 + treat_J2
    dJ2 = p.sigma_rel * beta2 * L * Jstar / R + p.theta * beta1 * J1 * (I + J3) / N - (p.alpha2 + p.mu + p.k_star) * J2 - treat_J2
    dJ3 = p.k_star * J2 - (p.alpha3 + p.mu + p.d_star) * J3
    dA = p.alpha1 * J1 + p.alpha2 * J2 + p.alpha3 * J3 - (p.mu + p.f) * A
    return np.array([dS, dL, dI, dT, dJ1, dJ2, dJ3, dA], dtype=float)


def full_tb_free_equilibrium_RN(RH, p=P):
    """TB-free HIV-endemic equilibrium under proportionate mixing R=N."""
    if RH <= 1.0 + 1e-12:
        return np.array([p.Lambda / p.mu, 0, 0, 0, 0, 0, 0, 0], dtype=float)
    c = (p.mu + p.f + p.alpha1) / (p.mu + p.f)
    denom = (p.alpha1 + p.mu) * (1.0 - 1.0 / RH) / c + p.mu / RH
    N = p.Lambda / denom
    S = N / RH
    J1 = N * (1.0 - 1.0 / RH) / c
    A = p.alpha1 * J1 / (p.mu + p.f)
    return np.array([S, 0.0, 0.0, 0.0, J1, 0.0, 0.0, A], dtype=float)


def RTH_for_beta1_RN(beta1, RH, p=P):
    """TB-invasion number R1^2 at E2 under R=N."""
    beta2 = common.beta2_from_RH(RH, p)
    EH = full_tb_free_equilibrium_RN(RH, p)
    S, J1 = EH[0], EH[4]
    N = np.sum(EH)
    if N <= 0:
        return np.nan
    h = p.sigma_rel * beta2 * J1 / N  # R=N denominator
    F = np.zeros((4, 4))
    F[0, 1] = beta1 * S / N
    F[0, 3] = beta1 * S / N
    F[2, 1] = p.theta * beta1 * J1 / N
    F[2, 3] = p.theta * beta1 * J1 / N
    V = np.array([
        [p.mu + p.k + p.a0 + h, 0.0, 0.0, 0.0],
        [-p.k, p.mu + p.d + p.a0, 0.0, 0.0],
        [-h, 0.0, p.alpha2 + p.mu + p.k_star + p.a0, 0.0],
        [0.0, 0.0, -p.k_star, p.alpha3 + p.mu + p.d_star],
    ], dtype=float)
    K = F @ np.linalg.inv(V)
    return float(np.max(np.abs(eigvals(K))))


def critical_RT_RN(RH, p=P):
    rho = RTH_for_beta1_RN(p.beta1_star_TB_only, RH, p)
    return 1.0 / rho if np.isfinite(rho) and rho > 0 else np.nan


def beta1_from_RTH_RN(Q, RH, p=P):
    return Q * critical_RT_RN(RH, p) * p.beta1_star_TB_only


def central_jacobian_RN(x, beta1, beta2, m, eps=1e-6):
    n = len(x)
    J = np.zeros((n, n))
    f0 = rhs_full_RN(x, beta1, beta2, m)
    for i in range(n):
        xp = x.copy()
        xp[i] += eps
        J[:, i] = (rhs_full_RN(xp, beta1, beta2, m) - f0) / eps
    return J


def tb_only_state_RN(Q):
    """Upper TB-only equilibrium embedded in full state (beta1 via R=N scaling)."""
    beta1 = beta1_from_RTH_RN(float(Q), RH, P)
    roots = common.find_tb_endemic_equilibria(beta1, M, P, n_grid=800)
    if not roots:
        return None
    tb = max(roots, key=lambda y: y[2] / np.sum(y))
    x = np.zeros(8, dtype=float)
    x[:4] = tb
    return x


def transverse_growth_RN(Q):
    """Largest HIV-invasion eigenvalue along TB-only boundary under R=N."""
    x = tb_only_state_RN(Q)
    if x is None:
        return np.nan
    beta1 = beta1_from_RTH_RN(float(Q), RH, P)
    J = central_jacobian_RN(x, beta1, BETA2, M)
    return float(np.max(np.real(eigvals(J[4:7, 4:7]))))


def solve_equilibrium_RN(seed, beta1, beta2, m):
    lower = np.zeros(8)
    upper = np.ones(8) * (2.5 * P.N0)
    seed = np.clip(np.asarray(seed, dtype=float), lower + 1e-10, upper)
    try:
        result = least_squares(
            lambda y: rhs_full_RN(y, beta1, beta2, m) / max(P.Lambda, 1.0),
            seed, bounds=(lower, upper),
            xtol=1e-10, ftol=1e-10, gtol=1e-10, max_nfev=2000,
            x_scale=np.maximum(seed, 1.0),
        )
    except Exception:
        return None
    x = np.maximum(result.x, 0.0)
    err = np.linalg.norm(rhs_full_RN(x, beta1, beta2, m) / max(P.Lambda, 1.0))
    return x if err < 1e-6 else None


# ---------------------------------------------------------------------------
# Main computation
# ---------------------------------------------------------------------------

def main():
    print("=== R=N proportionate mixing full-system slice ===", flush=True)
    print(f"RH={RH}, M={M}, beta2={BETA2:.6f}", flush=True)

    # E2 under R=N
    E2_RN = full_tb_free_equilibrium_RN(RH, P)
    E2_WD = common.full_tb_free_equilibrium(RH, P)
    N_RN = np.sum(E2_RN)
    N_WD = np.sum(E2_WD)
    print(f"\nE2 (R=N):  S={E2_RN[0]:.2f}, J1={E2_RN[4]:.2f}, A={E2_RN[7]:.2f}, N={N_RN:.2f}", flush=True)
    print(f"E2 (withdrawal): S={E2_WD[0]:.2f}, J1={E2_WD[4]:.2f}, A={E2_WD[7]:.2f}, N={N_WD:.2f}", flush=True)

    # Critical RT and beta1 conversion
    crit_RN = critical_RT_RN(RH, P)
    crit_WD = common.critical_isolated_RT_for_invasion(RH, P)
    print(f"\ncritical RT factor: R=N={crit_RN:.6f}, withdrawal={crit_WD:.6f}", flush=True)
    print(f"beta1 at Q=1: R=N={beta1_from_RTH_RN(1.0, RH, P):.6f}, withdrawal={common.beta1_from_RTH(1.0, RH, P):.6f}", flush=True)

    # Right edge: R1^2=1 is by definition at Q=1 (beta1 = critical * beta1_star)
    # But we verify by computing RTH at that beta1
    beta1_right_RN = beta1_from_RTH_RN(1.0, RH, P)
    rth_check = RTH_for_beta1_RN(beta1_right_RN, RH, P)
    print(f"\nRight edge Q=1: beta1={beta1_right_RN:.6f}, R1^2 check={rth_check:.8f}", flush=True)

    # Left edge: HIV-invasion branch point on TB boundary
    # Scan transverse growth
    q_grid = np.linspace(0.55, 0.95, 50)
    growth = []
    for q in q_grid:
        g = transverse_growth_RN(q)
        growth.append(g)
        if q in [0.6, 0.65, 0.7, 0.75, 0.8]:
            print(f"  Q={q:.3f}: transverse growth={g:.6e}", flush=True)

    # Find crossing
    bracket = None
    for i in range(len(q_grid) - 1):
        g0, g1 = growth[i], growth[i+1]
        if np.isfinite(g0) and np.isfinite(g1) and g0 * g1 < 0:
            bracket = (q_grid[i], q_grid[i+1])
            break
    if bracket is None:
        print("WARNING: No transverse growth crossing found in [0.55, 0.95]", flush=True)
        # Try wider range
        q_grid2 = np.linspace(0.4, 1.1, 80)
        growth2 = [transverse_growth_RN(q) for q in q_grid2]
        for i in range(len(q_grid2) - 1):
            g0, g1 = growth2[i], growth2[i+1]
            if np.isfinite(g0) and np.isfinite(g1) and g0 * g1 < 0:
                bracket = (q_grid2[i], q_grid2[i+1])
                print(f"  Found bracket in wider range: {bracket}", flush=True)
                break

    if bracket:
        Q_left_RN = float(brentq(transverse_growth_RN, *bracket, xtol=1e-10, rtol=1e-10))
        print(f"\nLeft edge (branch point) Q = {Q_left_RN:.8f} (R=N)", flush=True)
    else:
        Q_left_RN = None
        print("\nNo branch point found!", flush=True)

    # Baseline values for comparison
    Q_left_WD = 0.6642535243
    Q_right = 1.0

    # Window width
    if Q_left_RN is not None:
        width_RN = Q_right - Q_left_RN
        width_WD = Q_right - Q_left_WD
        print(f"\nWindow: R=N [{Q_left_RN:.6f}, {Q_right}], width={width_RN:.6f}", flush=True)
        print(f"Window: withdrawal [{Q_left_WD:.6f}, {Q_right}], width={width_WD:.6f}", flush=True)
        print(f"Left edge shift: {Q_left_RN - Q_left_WD:+.6f} ({(Q_left_RN/Q_left_WD - 1)*100:+.1f}%)", flush=True)
        print(f"Width change: {width_RN - width_WD:+.6f} ({(width_RN/width_WD - 1)*100:+.1f}%)", flush=True)

    # Stability of the TB-only state at Q=0.80 (window interior).  The
    # supplementary text quotes the maximum real eigenvalue and the active-TB
    # burden of this state, so both are persisted together with the full
    # spectrum rather than only printed.
    interior_probe = None
    if Q_left_RN is not None and Q_left_RN < 0.80 < Q_right:
        x_tb = tb_only_state_RN(0.80)
        if x_tb is not None:
            beta1_08 = beta1_from_RTH_RN(0.80, RH, P)
            J = central_jacobian_RN(x_tb, beta1_08, BETA2, M)
            eigvals_J = eigvals(J)
            max_real = float(np.max(np.real(eigvals_J)))
            burden_08 = float((x_tb[2] + x_tb[6]) / np.sum(x_tb))
            interior_probe = {
                "Q": 0.80,
                "beta1": float(beta1_08),
                "active_tb_burden": burden_08,
                "max_real_eigenvalue": max_real,
                "stable": bool(max_real < 0.0),
                "eigenvalues": [[float(v.real), float(v.imag)] for v in eigvals_J],
                "state": [float(v) for v in x_tb],
                "transverse_hiv_growth": float(transverse_growth_RN(0.80)),
            }
            print(f"\nAt Q=0.80 (R=N): TB-only max Re(lambda) = {max_real:.6e}", flush=True)
            print(f"  TB burden = {burden_08:.6f}", flush=True)

    # Save results
    results = {
        "RH": RH, "M": M, "mixing": "R=N (proportionate)",
        "E2_RN": {"S": float(E2_RN[0]), "J1": float(E2_RN[4]), "A": float(E2_RN[7]), "N": float(N_RN)},
        "E2_withdrawal": {"S": float(E2_WD[0]), "J1": float(E2_WD[4]), "A": float(E2_WD[7]), "N": float(N_WD)},
        "critical_RT_RN": float(crit_RN),
        "critical_RT_withdrawal": float(crit_WD),
        "right_edge_Q": Q_right,
        "left_edge_Q_RN": float(Q_left_RN) if Q_left_RN else None,
        "left_edge_Q_withdrawal": Q_left_WD,
        "window_width_RN": float(Q_right - Q_left_RN) if Q_left_RN else None,
        "window_width_withdrawal": float(Q_right - Q_left_WD),
        "interior_probe_Q080": interior_probe,
    }
    outpath = OUT / "rn_full_system_slice.json"
    with open(outpath, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved: {outpath}", flush=True)


if __name__ == "__main__":
    main()
