"""Time-integration verification of the full-system stability partition.

Reviewer Major Issue 1 asks for basin / time-integration evidence. We verify:
 (A) Inside BP1 < R_1^2 < 1 (use 0.80), two DIFFERENT initial conditions
     converge to two DIFFERENT full-system attractors: E1 (HIV-free TB
     boundary) and E2 (TB-free HIV-endemic boundary).
 (B) Below BP1 (use 0.64), the TB-only boundary equilibrium is resident-stable
     but transversely HIV-unstable: a tiny HIV seed grows away from it.
"""
import importlib.util
import sys
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "mod05", str(here / "05_full_backward_bifurcation_v4_verified.py"))
mod = importlib.util.module_from_spec(spec)
sys.modules["mod05"] = mod
spec.loader.exec_module(mod)
P = mod.P
RH, M, BETA2 = mod.RH, mod.M, mod.BETA2


def integrate(Q, x0, t_end=4000.0):
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)

    def rhs(t, x):
        x = np.maximum(x, 0.0)
        return mod.rhs_full(x, beta1, BETA2, M, P)

    sol = solve_ivp(rhs, (0, t_end), x0, method="LSODA", rtol=1e-9, atol=1e-11,
                    dense_output=False)
    return sol.y[:, -1]


def report(name, xf):
    S, L, I, T, J1, J2, J3, A = xf
    N = xf.sum()
    hiv = (J1 + J2 + J3 + A) / N
    tb = (I + J3) / N
    print(f"  {name}: N={N:.4f}, activeTB B=(I+J3)/N={tb:.5f}, "
          f"HIV frac=(J1+J2+J3+A)/N={hiv:.3e}")


print("=== (A) Q=0.80 inside BP1(0.6643)<Q<1: expect TWO full-system attractors ===")
Q = 0.80
E1 = mod.tb_only_state(Q).copy()
E2 = mod.full_tb_free_equilibrium(RH, P).copy()
# IC1: near E1 (HIV-free) with a tiny HIV seed in J1
ic1 = E1.copy(); ic1[4] += 1e-4 * E1.sum()
# IC2: near E2 (TB-free) with a tiny active-TB seed in I
ic2 = E2.copy(); ic2[2] += 1e-4 * E2.sum()
print("  Initial:")
report("IC1 ~ E1 + HIV seed", ic1)
report("IC2 ~ E2 + TB seed ", ic2)
xf1 = integrate(Q, ic1)
xf2 = integrate(Q, ic2)
print("  After t=4000:")
report("from IC1 ->", xf1)
report("from IC2 ->", xf2)

print()
print("=== (B) Q=0.64 below BP1: E1 resident-stable but HIV-transverse-unstable ===")
Q = 0.64
E1b = mod.tb_only_state(Q).copy()
ic = E1b.copy(); ic[4] += 1e-4 * E1b.sum()
report("IC ~ E1 + HIV seed (t=0)", ic)
xfb = integrate(Q, ic, t_end=4000.0)
report("after t=4000 ->", xfb)
S, L, I, T, J1, J2, J3, A = xfb
print(f"  HIV fraction grew from 1e-4 seed to {(J1+J2+J3+A)/xfb.sum():.4f} "
      f"=> transverse instability confirmed" if (J1+J2+J3+A)/xfb.sum() > 1e-3
      else "=> HIV decayed (transversely stable)")
