"""
Basin partitioning analysis for the full HIV-TB model.
At RH=1.8, m=0.05, Q=0.8 (inside the bistability window [0.664, 1)),
integrate trajectories from a grid of initial conditions and classify
the attractor they converge to.
"""
import sys, os
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from importlib import import_module
_common = import_module("00_common")
P = _common.P
beta2_from_RH = _common.beta2_from_RH
beta1_from_RTH = _common.beta1_from_RTH
full_tb_free_equilibrium = _common.full_tb_free_equilibrium
rhs_full = _common.rhs_full
integrate_full_to_attractor = _common.integrate_full_to_attractor
active_tb_burden_full = _common.active_tb_burden_full
hiv_burden_full = _common.hiv_burden_full

# Parameters
RH = 1.8
M = 0.05
Q = 0.8  # inside bistability window [0.664, 1)

beta2 = beta2_from_RH(RH, P)
beta1 = beta1_from_RTH(Q, RH, P)
E2 = full_tb_free_equilibrium(RH, P)

print(f"RH={RH}, M={M}, Q={Q}")
print(f"beta1={beta1:.6f}, beta2={beta2:.6f}")
print(f"E2 (TB-free HIV-endemic): S={E2[0]:.1f}, J1={E2[4]:.1f}, A={E2[7]:.1f}")

# Grid of deterministic seed parameters used to construct the initial state.
N_GRID = 25
tb_seed = np.linspace(0.001, 0.25, N_GRID)
hiv_seed = np.linspace(0.001, 0.25, N_GRID)

# Classification thresholds
TB_BURDEN_TOL = 0.005  # below this -> TB-free
HIV_BURDEN_TOL = 0.005  # below this -> HIV-free

basin = np.zeros((N_GRID, N_GRID), dtype=int)
# 0 = TB-free HIV-endemic, 1 = HIV-free TB-endemic, 2 = co-endemic, 3 = other

# Reference attractors for distance-based classification
# E2 is TB-free HIV-endemic
# HIV-free TB-endemic: need to find it
# Let's integrate from a high-TB low-HIV initial condition
x0_tb = np.array([P.N0*0.5, 100, 300, 50, 0, 0, 0, 0], dtype=float)
x0_tb[0] = P.N0 - np.sum(x0_tb[1:])
E_tb = integrate_full_to_attractor(beta1, beta2, M, x0_tb, t_end=2000)
print(f"\nHIV-free TB-endemic reference:")
print(f"  S={E_tb[0]:.1f}, L={E_tb[1]:.1f}, I={E_tb[2]:.1f}, T={E_tb[3]:.1f}")
print(f"  TB burden={active_tb_burden_full(E_tb):.4f}, HIV burden={hiv_burden_full(E_tb):.4f}")

print(f"\nRunning basin grid ({N_GRID}x{N_GRID}={N_GRID**2} trajectories)...")

for i, b in enumerate(tb_seed):
    for j, h in enumerate(hiv_seed):
        # Construct the full initial state from the two seed parameters.
        N = P.N0
        I = b * N * 0.7
        J3 = b * N * 0.3
        J1 = h * N * 0.6
        J2 = h * N * 0.3
        L = b * N * 0.5
        T = 0.0
        A = h * N * 0.1
        S = N - (L + I + T + J1 + J2 + J3 + A)
        if S < 10:
            S = 10.0
            # rescale others
            total = L + I + T + J1 + J2 + J3 + A
            scale = (N - S) / total if total > 0 else 1.0
            L, I, T, J1, J2, J3, A = [v*scale for v in [L, I, T, J1, J2, J3, A]]
        
        x0 = np.array([S, L, I, T, J1, J2, J3, A], dtype=float)
        x_end = integrate_full_to_attractor(beta1, beta2, M, x0, t_end=1500)
        
        if x_end is None:
            basin[i, j] = 3
            continue
        
        tb_b = active_tb_burden_full(x_end)
        hiv_b = hiv_burden_full(x_end)
        
        if tb_b < TB_BURDEN_TOL and hiv_b > HIV_BURDEN_TOL:
            basin[i, j] = 0  # TB-free HIV-endemic
        elif hiv_b < HIV_BURDEN_TOL and tb_b > TB_BURDEN_TOL:
            basin[i, j] = 1  # HIV-free TB-endemic
        elif tb_b > TB_BURDEN_TOL and hiv_b > HIV_BURDEN_TOL:
            basin[i, j] = 2  # co-endemic
        else:
            basin[i, j] = 3  # other/DFE

# Count
n0 = np.sum(basin == 0)
n1 = np.sum(basin == 1)
n2 = np.sum(basin == 2)
n3 = np.sum(basin == 3)
print(f"\nBasin classification:")
print(f"  TB-free HIV-endemic: {n0}/{N_GRID**2} ({100*n0/N_GRID**2:.0f}%)")
print(f"  HIV-free TB-endemic: {n1}/{N_GRID**2} ({100*n1/N_GRID**2:.0f}%)")
print(f"  Co-endemic: {n2}/{N_GRID**2} ({100*n2/N_GRID**2:.0f}%)")
print(f"  Other: {n3}/{N_GRID**2}")

# Find separatrix: for each HIV fraction, find the TB fraction threshold
print(f"\nSeparatrix (critical initial TB fraction for each HIV fraction):")
for j, h in enumerate(hiv_seed[::5]):
    col = basin[:, j*5]
    # find transition from 0 to 1
    tb_only = np.where(col == 1)[0]
    if len(tb_only) > 0:
        crit_idx = tb_only[0]
        print(f"  HIV seed h={h:.3f}: critical TB seed b ~ {tb_seed[crit_idx]:.4f}")

# Plot
fig, ax = plt.subplots(1, 1, figsize=(7, 5.5))

# Custom colormap: light blue=TB-free HIV, dark blue=HIV-free TB, orange=co-endemic, grey=other
from matplotlib.colors import ListedColormap
cmap = ListedColormap(['#9ECAE1', '#08519C', '#E6550D', '#BDBDBD'])

im = ax.imshow(basin, origin='lower', aspect='auto',
               extent=[hiv_seed[0], hiv_seed[-1], tb_seed[0], tb_seed[-1]],
               cmap=cmap, vmin=0, vmax=3, interpolation='nearest')

ax.set_xlabel('HIV seed parameter $h$', fontsize=12)
ax.set_ylabel('TB seed parameter $b$', fontsize=12)
ax.set_title(f'Finite-time classification at $\\mathcal{{R}}_2=1.8$, $m=0.05$, $\\mathcal{{R}}_1^2={Q}$\n(inside the bistability window; terminal-state rule)', fontsize=11)

# Legend
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#9ECAE1', label='TB-free HIV-endemic ($E_2$)'),
    Patch(facecolor='#08519C', label='HIV-free TB-endemic ($E_1$)'),
    Patch(facecolor='#E6550D', label='Co-endemic'),
    Patch(facecolor='#BDBDBD', label='Other'),
]
ax.legend(handles=legend_elements, loc='upper right', fontsize=9, framealpha=0.9)

plt.tight_layout()
outpath = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'figures', 'fig_basin_partitioning.pdf')
outpath = os.path.normpath(outpath)
plt.savefig(outpath, dpi=300, bbox_inches='tight')
print(f"\nSaved: {outpath}")

# Also save as PNG for quick viewing
outpath_png = outpath.replace('.pdf', '.png')
plt.savefig(outpath_png, dpi=150, bbox_inches='tight')
print(f"Saved: {outpath_png}")
