"""
Common functions for the HIV-TB article figure code.

Model variables:
    Full model: X = (S, L, I, T, J1, J2, J3, A)
    TB-only:    X_T = (S, L, I, T)
    HIV-only:   X_H = (S, J1, A)

Default preset:
    illustrative_backward

This preset is intentionally chosen to demonstrate the TB-only backward
bifurcation predicted by the theory. The audited full-system branch analysis
is implemented separately and explicitly distinguishes TB-only boundary roots
from strictly co-endemic roots. It keeps the literature-style demographic,
progression, and mortality parameters fixed, while calibrating only the new
healthcare-response parameters.
"""

from __future__ import annotations

import os
import warnings
from dataclasses import dataclass, replace
from pathlib import Path
import numpy as np

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from scipy.optimize import brentq, least_squares
from scipy.integrate import solve_ivp
from scipy.linalg import eigvals
from scipy.interpolate import make_interp_spline, PchipInterpolator

warnings.filterwarnings("ignore", category=RuntimeWarning)

# ============================================================
# Global options
# ============================================================

OUTPUT_DIR = str(Path(__file__).resolve().parent.parent / "figures")
FAST_MODE = True
SAVE_TIFF = False

# Main manuscript preset.
# Other option: "literature_standard"
PARAMETER_PRESET = "illustrative_backward"

if FAST_MODE:
    TB_RT_POINTS = 160
    TB_ROOT_GRID = 180
    FULL_Q_POINTS = 56
    FULL_ROOT_MAX_NFEV = 900
    BURDEN_GRID = 42
    T_END = 650.0
else:
    TB_RT_POINTS = 300
    TB_ROOT_GRID = 320
    FULL_Q_POINTS = 100
    FULL_ROOT_MAX_NFEV = 1600
    BURDEN_GRID = 85
    T_END = 1200.0


# ------------------------------
# Extended bifurcation analysis
# ------------------------------
if FAST_MODE:
    EXT_RT_POINTS = 200
    EXT_Q_POINTS = 80
    TWO_D_RT = 50
    TWO_D_M = 30
    LYAP_N_STEPS = 400
    LYAP_TAU = 2.0
    OSC_T_END = 500.0
    OSC_N_POINTS = 1500
    HOPF_SCAN_N = 120
else:
    EXT_RT_POINTS = 400
    EXT_Q_POINTS = 160
    TWO_D_RT = 100
    TWO_D_M = 60
    LYAP_N_STEPS = 1200
    LYAP_TAU = 3.0
    OSC_T_END = 1000.0
    OSC_N_POINTS = 4000
    HOPF_SCAN_N = 250


# ============================================================
# Style
# ============================================================

def set_publication_style():
    mpl.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "mathtext.rm": "serif",

        "font.size": 9.0,
        "axes.labelsize": 10.0,
        "axes.titlesize": 10.5,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "legend.fontsize": 8.0,

        "axes.linewidth": 1.0,
        "axes.unicode_minus": False,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.size": 3.5,
        "ytick.major.size": 3.5,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,

        "axes.spines.top": False,
        "axes.spines.right": False,

        "figure.dpi": 200,
        "savefig.dpi": 600,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })


def white_box(alpha=0.86, pad=0.18):
    return {
        "boxstyle": f"round,pad={pad}",
        "facecolor": "white",
        "edgecolor": "none",
        "alpha": alpha,
    }


def save_fig(fig, name: str):
    Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
    base = Path(OUTPUT_DIR) / name
    fig.savefig(f"{base}.pdf", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(f"{base}.eps", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(f"{base}.svg", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(f"{base}.png", bbox_inches="tight", pad_inches=0.03, dpi=600)
    if SAVE_TIFF:
        try:
            fig.savefig(
                f"{base}.tiff",
                bbox_inches="tight",
                pad_inches=0.03,
                dpi=600,
                pil_kwargs={"compression": "tiff_lzw"},
            )
        except Exception as exc:
            print(f"TIFF save failed for {name}: {exc}")
    plt.close(fig)
    print(f"saved: {base}.pdf / svg / png", flush=True)


# ============================================================
# Parameters
# ============================================================

@dataclass
class Params:
    # Literature-style fixed epidemiological parameters
    N0: float = 10000.0
    mu: float = 0.0143
    k: float = 0.5
    d: float = 0.1

    alpha1: float = 0.1
    alpha2: float = 0.2
    alpha3: float = 0.5
    f: float = 0.5
    k_star: float = 2.5
    d_star: float = 0.2

    # Generalized co-infection multipliers.
    # Literature baseline is theta=sigma_rel=1.
    theta: float = 1.0
    sigma_rel: float = 1.0

    # Healthcare-response parameters (illustrative, chosen to exhibit
    # the backward-bifurcation regime predicted by the analysis).
    a0: float = 0.6
    a_max: float = 1.5
    omega0: float = 3.0e-3
    omega_min: float = 1.0e-5
    response_mode: str = "coupled"

    # Literature constant treatment rates, recorded but not used.
    r1_lit_not_used: float = 3.0
    r2_lit_not_used: float = 1.0
    r_star_lit_not_used: float = 3.0

    @property
    def Lambda(self) -> float:
        return self.mu * self.N0

    @property
    def beta1_star_TB_only(self) -> float:
        return (self.mu + self.k + self.a0) * (self.mu + self.d + self.a0) / self.k

    @property
    def beta2_star_HIV_only(self) -> float:
        return self.alpha1 + self.mu


def get_params(preset: str = PARAMETER_PRESET) -> Params:
    if preset == "illustrative_backward":
        # The healthcare-response parameters are chosen to illustrate the
        # backward-bifurcation regime predicted by the analysis.
        return Params(
            a0=0.6,
            a_max=1.5,
            omega0=3.0e-3,
            omega_min=1.0e-5,
            theta=1.0,
            sigma_rel=1.0,
        )

    if preset == "literature_standard":
        # Conservative response baseline used earlier.
        # It may not show full-model backward bifurcation.
        return Params(
            a0=1.675,
            a_max=3.0,
            omega0=5.0e-4,
            omega_min=1.0e-4,
            theta=1.0,
            sigma_rel=1.0,
        )

    raise ValueError(f"Unknown preset: {preset}")


P = get_params()


def write_parameter_summary(extra_lines=None):
    Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
    path = Path(OUTPUT_DIR) / "parameter_summary.txt"
    lines = []
    lines.append("HIV-TB article parameter summary")
    lines.append("================================")
    lines.append("")
    lines.append(f"PARAMETER_PRESET = {PARAMETER_PRESET}")
    lines.append("")
    lines.append("Selected parameter values")
    lines.append("-------------------------")
    for key, value in P.__dict__.items():
        lines.append(f"{key} = {value}")
    lines.append(f"Lambda = {P.Lambda}")
    lines.append(f"beta1_star_TB_only = {P.beta1_star_TB_only}")
    lines.append(f"beta2_star_HIV_only = {P.beta2_star_HIV_only}")
    lines.append("")
    lines.append("Interpretation")
    lines.append("--------------")
    lines.append("The demographic, progression and mortality parameters are fixed at literature-style values.")
    lines.append("The parameters a0, a_max, omega0 and omega_min are illustrative healthcare-response parameters")
    lines.append("chosen to exhibit the backward-bifurcation regime predicted by the analysis.")
    lines.append("They replace the constant TB treatment rates in the benchmark HIV-TB model.")
    lines.append("The constant rates r1, r2 and r* are recorded but are not inserted into the ODEs.")
    lines.append("The main preset illustrative_backward is used to demonstrate the theoretical full-model backward-bifurcation regime.")
    if extra_lines:
        lines.append("")
        lines.extend(extra_lines)
    path.write_text("\n".join(lines), encoding="utf-8")
    print(f"saved: {path}", flush=True)


# ============================================================
# Shared model utilities
# ============================================================

def beta1_from_RT(RT: float, p: Params = P) -> float:
    return RT * p.beta1_star_TB_only


def beta2_from_RH(RH: float, p: Params = P) -> float:
    return RH * p.beta2_star_HIV_only


def response_from_burden(B: float, m: float, p: Params = P):
    B = max(float(B), 0.0)
    z = (1.0 + m) * B / (1.0 + m * B)
    if p.response_mode == "coupled":
        a = p.a0 + (p.a_max - p.a0) * z
        omega = p.omega0 + (p.omega_min - p.omega0) * z
    elif p.response_mode == "none":
        a = p.a0
        omega = p.omega0
    elif p.response_mode == "treatment_only":
        a = p.a0 + (p.a_max - p.a0) * z
        omega = p.omega0
    elif p.response_mode == "resource_only":
        a = p.a0
        omega = p.omega0 + (p.omega_min - p.omega0) * z
    else:
        raise ValueError(f"Unknown healthcare response mode: {p.response_mode}")
    return a, omega


# ============================================================
# TB-only subsystem
# ============================================================

def rhs_tb(x, beta1, m, p=P):
    S, L, I, T = x
    N = S + L + I + T
    if N <= 0:
        return np.ones(4) * 1e12

    a, omega = response_from_burden(I / N, m, p)
    denom_L = 1.0 + omega * L
    denom_I = 1.0 + omega * I

    if denom_L <= 0 or denom_I <= 0:
        return np.ones(4) * 1e12

    treat_L = a * L / denom_L
    treat_I = a * I / denom_I

    dS = p.Lambda - beta1 * S * I / N - p.mu * S
    dL = beta1 * (S + T) * I / N - (p.mu + p.k) * L - treat_L
    dI = p.k * L - (p.mu + p.d) * I - treat_I
    dT = treat_L + treat_I - beta1 * T * I / N - p.mu * T
    return np.array([dS, dL, dI, dT], dtype=float)


def tb_equilibrium_from_I(I, beta1, m, p=P):
    if I <= 1e-8:
        return None

    N = (p.Lambda - p.d * I) / p.mu
    if N <= 0 or I >= N:
        return None

    a, omega = response_from_burden(I / N, m, p)
    denom_I = 1.0 + omega * I
    if denom_I <= 0:
        return None

    S = p.Lambda / (p.mu + beta1 * I / N)
    L = ((p.mu + p.d) * I + a * I / denom_I) / p.k
    T = N - S - L - I

    if not np.all(np.isfinite([S, L, T])):
        return None
    if S < -1e-7 or L < -1e-7 or T < -1e-7:
        return None

    return np.array([max(S, 0.0), max(L, 0.0), max(I, 0.0), max(T, 0.0)])


def tb_endemic_residual(I, beta1, m, p=P):
    eq = tb_equilibrium_from_I(I, beta1, m, p)
    if eq is None:
        return np.nan
    value = rhs_tb(eq, beta1, m, p)[1]
    return value if np.isfinite(value) else np.nan


def find_tb_endemic_equilibria(beta1, m, p=P, n_grid=TB_ROOT_GRID):
    I_upper = 0.999 * p.Lambda / (p.mu + p.d)
    if I_upper <= 1e-8:
        return []

    grid_log = np.logspace(-8, np.log10(I_upper), n_grid // 2)
    grid_lin = np.linspace(1e-6, I_upper, n_grid // 2)
    grid = np.unique(np.concatenate([grid_log, grid_lin]))
    values = np.array([tb_endemic_residual(I, beta1, m, p) for I in grid])

    roots = []
    for i in range(len(grid) - 1):
        left, right = grid[i], grid[i + 1]
        f_left, f_right = values[i], values[i + 1]

        if not np.isfinite(f_left) or not np.isfinite(f_right):
            continue

        root = None
        if abs(f_left) < 1e-10:
            root = left
        elif f_left * f_right < 0:
            try:
                root = brentq(
                    lambda z: tb_endemic_residual(z, beta1, m, p),
                    left,
                    right,
                    maxiter=200,
                    xtol=1e-10,
                    rtol=1e-10,
                )
            except ValueError:
                root = None

        if root is None or root <= 1e-8:
            continue
        if all(abs(root - old) > 1e-5 * max(1.0, old) for old in roots):
            roots.append(root)

    equilibria = []
    for I in roots:
        eq = tb_equilibrium_from_I(I, beta1, m, p)
        if eq is None:
            continue

        # Exclude numerical copies of the DFE.
        burden = I / np.sum(eq)
        if burden <= 1.0e-10:
            continue

        residual = np.linalg.norm(
            rhs_tb(eq, beta1, m, p) / max(p.Lambda, 1.0)
        )
        if residual < 7.0e-6:
            equilibria.append(eq)

    equilibria.sort(key=lambda z: z[2] / np.sum(z))
    return equilibria


def numerical_jacobian(fun, x, args):
    x = np.asarray(x, dtype=float)
    n = len(x)
    J = np.zeros((n, n))
    for j in range(n):
        h = 1e-6 * max(1.0, abs(x[j]))
        xp = x.copy()
        xm = x.copy()
        xp[j] += h
        xm[j] = max(xm[j] - h, 0.0)
        fp = fun(xp, *args)
        fm = fun(xm, *args)
        denom = xp[j] - xm[j]
        J[:, j] = (fp - fm) / denom
    return J


def central_numerical_jacobian(fun, x, args, relative_step=1e-6):
    """Central-difference Jacobian without projection at zero coordinates.

    This is used for boundary-equilibrium diagnostics.  The older helper
    clips the backward point to zero, which is useful for constrained root
    searches but produces a one-sided derivative on invariant boundaries.
    """
    x = np.asarray(x, dtype=float)
    n = len(x)
    J = np.zeros((n, n))
    for j in range(n):
        h = relative_step * max(1.0, abs(x[j]))
        xp = x.copy(); xm = x.copy()
        xp[j] += h; xm[j] -= h
        fp = fun(xp, *args)
        fm = fun(xm, *args)
        J[:, j] = (fp - fm) / (2.0 * h)
    return J


def tb_stability(eq, beta1, m, p=P):
    J = numerical_jacobian(lambda y, b, mm, pp: rhs_tb(y, b, mm, pp), eq, (beta1, m, p))
    eigs = eigvals(J)
    max_real = float(np.max(np.real(eigs)))
    return max_real < -1e-6, max_real, eigs


# ============================================================
# HIV-only subsystem
# ============================================================

def hiv_endemic_equilibrium(RH, p=P):
    if RH <= 1.0:
        return np.array([p.Lambda / p.mu, 0.0, 0.0])
    S = p.Lambda / (p.mu + (p.alpha1 + p.mu) * (RH - 1.0))
    J1 = (RH - 1.0) * S
    A = p.alpha1 * J1 / (p.mu + p.f)
    return np.array([S, J1, A])


# ============================================================
# Full model
# ============================================================

def full_tb_free_equilibrium(RH, p=P):
    if RH <= 1.0 + 1e-12:
        return np.array([p.Lambda / p.mu, 0, 0, 0, 0, 0, 0, 0], dtype=float)

    S = p.Lambda / (p.mu + (p.alpha1 + p.mu) * (RH - 1.0))
    J1 = (RH - 1.0) * S
    A = p.alpha1 * J1 / (p.mu + p.f)
    return np.array([S, 0.0, 0.0, 0.0, J1, 0.0, 0.0, A], dtype=float)


def rhs_full(x, beta1, beta2, m, p=P):
    S, L, I, T, J1, J2, J3, A = x
    N = S + L + I + T + J1 + J2 + J3 + A
    R = N - I - J3 - A
    Jstar = J1 + J2 + J3

    if N <= 1e-12 or R <= 1e-12:
        return np.ones(8) * 1e12

    B = (I + J3) / N
    a, omega = response_from_burden(B, m, p)

    denom_L = 1.0 + omega * L
    denom_I = 1.0 + omega * I
    denom_J2 = 1.0 + omega * J2
    if denom_L <= 0 or denom_I <= 0 or denom_J2 <= 0:
        return np.ones(8) * 1e12

    treat_L = a * L / denom_L
    treat_I = a * I / denom_I
    treat_J2 = a * J2 / denom_J2

    tb_force = beta1 * (I + J3) / N
    hiv_force = beta2 * Jstar / R

    dS = p.Lambda - tb_force * S - hiv_force * S - p.mu * S

    dL = (
        beta1 * (S + T) * (I + J3) / N
        - p.sigma_rel * beta2 * L * Jstar / R
        - (p.mu + p.k) * L
        - treat_L
    )

    dI = p.k * L - (p.mu + p.d) * I - treat_I

    dT = (
        treat_L + treat_I
        - beta1 * T * (I + J3) / N
        - beta2 * T * Jstar / R
        - p.mu * T
    )

    dJ1 = (
        beta2 * (S + T) * Jstar / R
        - p.theta * beta1 * J1 * (I + J3) / N
        - (p.alpha1 + p.mu) * J1
        + treat_J2
    )

    dJ2 = (
        p.sigma_rel * beta2 * L * Jstar / R
        + p.theta * beta1 * J1 * (I + J3) / N
        - (p.alpha2 + p.mu + p.k_star) * J2
        - treat_J2
    )

    dJ3 = p.k_star * J2 - (p.alpha3 + p.mu + p.d_star) * J3

    dA = p.alpha1 * J1 + p.alpha2 * J2 + p.alpha3 * J3 - (p.mu + p.f) * A

    return np.array([dS, dL, dI, dT, dJ1, dJ2, dJ3, dA], dtype=float)


def active_tb_burden_full(x):
    N = np.sum(x)
    return (x[2] + x[6]) / N if N > 0 else np.nan


def hiv_burden_full(x):
    """Non-AIDS HIV fraction used to distinguish boundary from interior roots."""
    N = np.sum(x)
    return (x[4] + x[5] + x[6]) / N if N > 0 else np.nan


def full_equilibrium_class(x, tb_tol=1.0e-7, hiv_tol=1.0e-5):
    """Classify a full-system equilibrium by disease support.

    The previous branch code used only active-TB burden.  That criterion admits
    the HIV-free invariant boundary as a purported co-endemic equilibrium.  A
    root is called ``co_endemic`` only when both active-TB and non-AIDS HIV
    fractions exceed their documented relative tolerances.
    """
    tb = active_tb_burden_full(x)
    hiv = hiv_burden_full(x)
    tb_present = bool(np.isfinite(tb) and tb > tb_tol)
    hiv_present = bool(np.isfinite(hiv) and hiv > hiv_tol)
    if tb_present and hiv_present:
        return "co_endemic"
    if tb_present:
        return "tb_only"
    if hiv_present:
        return "hiv_only"
    return "disease_free"


def coinfection_burden_full(x):
    N = np.sum(x)
    return (x[5] + x[6]) / N if N > 0 else np.nan


def hiv_prevalence_full(x):
    N = np.sum(x)
    return (x[4] + x[5] + x[6]) / N if N > 0 else np.nan


def RTH_for_beta1(beta1, RH, p=P):
    """Return the TB-invasion number \(\mathcal{R}_1^2\).

    The subscript 1 identifies TB as the invader and the superscript 2
    identifies the HIV-endemic resident equilibrium.
    """
    beta2 = beta2_from_RH(RH, p)
    EH = full_tb_free_equilibrium(RH, p)
    S, J1 = EH[0], EH[4]
    N = np.sum(EH)
    R = S + J1

    if N <= 0 or R <= 0:
        return np.nan

    h = p.sigma_rel * beta2 * J1 / R

    F = np.zeros((4, 4))
    # x_T = (L, I, J2, J3)
    F[0, 1] = beta1 * S / N
    F[0, 3] = beta1 * S / N
    F[2, 1] = p.theta * beta1 * J1 / N
    F[2, 3] = p.theta * beta1 * J1 / N

    V = np.array([
        [p.mu + p.k + p.a0 + h, 0.0, 0.0, 0.0],
        [-p.k, p.mu + p.d + p.a0, 0.0, 0.0],
        [-h, 0.0, p.alpha2 + p.mu + p.k_star + p.a0, 0.0],
        [0.0, 0.0, -p.k_star, p.alpha3 + p.mu + p.d_star],
    ], dtype=float)

    K = F @ np.linalg.inv(V)
    return float(np.max(np.abs(eigvals(K))))


def critical_isolated_RT_for_invasion(RH, p=P):
    rho = RTH_for_beta1(p.beta1_star_TB_only, RH, p)
    if not np.isfinite(rho) or rho <= 0:
        return np.nan
    return 1.0 / rho


def beta1_from_RTH(Q, RH, p=P):
    return Q * critical_isolated_RT_for_invasion(RH, p) * p.beta1_star_TB_only


def full_initial_condition(RH, p=P, kind="moderate"):
    base = full_tb_free_equilibrium(RH, p)
    if kind == "low":
        seed = np.array([0, 2, 1, 0, 0, 0.5, 0.2, 0], dtype=float)
    elif kind == "high":
        seed = np.array([0, 700, 300, 140, 0, 180, 90, 0], dtype=float)
    else:
        seed = np.array([0, 100, 35, 20, 0, 25, 10, 0], dtype=float)

    x = base + seed
    x[0] = max(x[0] - np.sum(seed), 1.0)
    return np.maximum(x, 0.0)


def integrate_full_to_attractor(beta1, beta2, m, x0, p=P, t_end=0.65 * T_END):
    sol = solve_ivp(
        lambda t, y: rhs_full(y, beta1, beta2, m, p),
        (0.0, t_end),
        x0,
        method="LSODA",
        rtol=1e-7,
        atol=1e-9,
        max_step=4.0,
    )
    if not sol.success:
        return None
    return np.maximum(sol.y[:, -1], 0.0)


def full_residual_scaled(x, beta1, beta2, m, p=P):
    return rhs_full(x, beta1, beta2, m, p) / max(p.Lambda, 1.0)


def solve_full_equilibrium_from_seed(seed, beta1, beta2, m, p=P):
    lower = np.zeros(8)
    upper = np.ones(8) * (2.5 * p.N0)
    seed = np.clip(np.asarray(seed, dtype=float), lower + 1e-10, upper)

    try:
        result = least_squares(
            lambda y: full_residual_scaled(y, beta1, beta2, m, p),
            seed,
            bounds=(lower, upper),
            xtol=1e-10,
            ftol=1e-10,
            gtol=1e-10,
            max_nfev=FULL_ROOT_MAX_NFEV,
            x_scale=np.maximum(seed, 1.0),
        )
    except Exception:
        return None

    x = np.maximum(result.x, 0.0)
    err = np.linalg.norm(full_residual_scaled(x, beta1, beta2, m, p))
    if np.isfinite(err) and err < 7e-6:
        return x
    return None


def is_duplicate(x, collection, tol=2e-4):
    for old in collection:
        denom = max(1.0, np.linalg.norm(old))
        if np.linalg.norm(x - old) / denom < tol:
            return True
    return False


def find_full_equilibria(beta1, beta2, RH, m, p=P, previous=None):
    if previous is None:
        previous = []

    seeds = [
        full_tb_free_equilibrium(RH, p),
        full_initial_condition(RH, p, "low"),
        full_initial_condition(RH, p, "moderate"),
        full_initial_condition(RH, p, "high"),
    ]
    seeds.extend(previous)

    for kind in ["low", "high"]:
        xt = integrate_full_to_attractor(beta1, beta2, m, full_initial_condition(RH, p, kind), p)
        if xt is not None:
            seeds.append(xt)

    eqs = []
    for seed in seeds:
        eq = solve_full_equilibrium_from_seed(seed, beta1, beta2, m, p)
        if eq is None:
            continue
        if not is_duplicate(eq, eqs):
            eqs.append(eq)

    eqs.sort(key=active_tb_burden_full)
    return eqs


def full_stability(eq, beta1, beta2, m, p=P):
    J = central_numerical_jacobian(
        lambda y, b1, b2, mm, pp: rhs_full(y, b1, b2, mm, pp),
        eq,
        (beta1, beta2, m, p),
    )
    eigs = eigvals(J)
    max_real = float(np.max(np.real(eigs)))
    return max_real < -1e-6, max_real, eigs


def scan_full_branch_RTH(RH, m, q_min=0.55, q_max=1.55, n=FULL_Q_POINTS, p=P):
    Q_values = np.linspace(q_min, q_max, n)
    beta2 = beta2_from_RH(RH, p)

    records = []
    previous = []

    # Low-to-high sweep
    for Q in Q_values:
        beta1 = beta1_from_RTH(Q, RH, p)
        eqs = find_full_equilibria(beta1, beta2, RH, m, p, previous)
        previous = eqs
        for eq in eqs:
            burden = active_tb_burden_full(eq)
            stable, max_real, eigs = full_stability(eq, beta1, beta2, m, p)
            eq_class = full_equilibrium_class(eq)
            records.append({
                "Q": Q,
                "burden": burden,
                "stable": stable,
                "max_real": max_real,
                "state": eq,
                "eq_class": eq_class,
                "hiv_fraction": hiv_burden_full(eq),
            })

    # High-to-low sweep helps capture the upper branch below threshold.
    previous = [full_initial_condition(RH, p, "high")]
    for Q in np.linspace(q_max, q_min, n):
        beta1 = beta1_from_RTH(Q, RH, p)
        eqs = find_full_equilibria(beta1, beta2, RH, m, p, previous)
        positive = [eq for eq in eqs if active_tb_burden_full(eq) > 1e-7]
        previous = [max(positive, key=active_tb_burden_full)] if positive else eqs

        for eq in eqs:
            duplicate = any(
                abs(Q - r["Q"]) < 1e-10 and
                np.linalg.norm(eq - r["state"]) / max(1.0, np.linalg.norm(eq)) < 2e-4
                for r in records
            )
            if duplicate:
                continue
            burden = active_tb_burden_full(eq)
            stable, max_real, eigs = full_stability(eq, beta1, beta2, m, p)
            eq_class = full_equilibrium_class(eq)
            records.append({
                "Q": Q,
                "burden": burden,
                "stable": stable,
                "max_real": max_real,
                "state": eq,
                "eq_class": eq_class,
                "hiv_fraction": hiv_burden_full(eq),
            })

    return records


# ============================================================
# Pseudo-arclength continuation utilities
# ============================================================

CONTINUATION_MIN_BURDEN = 1e-8
CONTINUATION_BRANCH_LINK_TOL = 0.35
CONTINUATION_ARC_WEIGHT = 10.0
CONTINUATION_MAX_STATE_SCALE = 3.0
CONTINUATION_MAX_BRANCHES_TB = 8
CONTINUATION_MAX_BRANCHES_FULL = 8
CONTINUATION_MAX_STEPS_TB = 280 if FAST_MODE else 560
CONTINUATION_MAX_STEPS_FULL = 140 if FAST_MODE else 280

# ── Continuation tolerance knobs (overridable by caller) ──
PSEUDO_ARCLENGTH_RESIDUAL_TOL = 8e-6   # equilibrium residual
PSEUDO_ARCLENGTH_ARC_TOL = 5e-4        # arclength constraint


def _pack_continuation_z(state, parameter_value, p=P):
    """Pack population state and continuation parameter into scaled coordinates."""
    state = np.asarray(state, dtype=float)
    scale = np.ones_like(state) * max(float(p.N0), 1.0)
    return np.r_[state / scale, float(parameter_value)], scale


def _unpack_continuation_z(z, scale):
    """Unpack scaled continuation coordinates."""
    z = np.asarray(z, dtype=float)
    state = np.maximum(z[:-1] * scale, 0.0)
    parameter_value = float(z[-1])
    return state, parameter_value


def _state_distance_scaled(x, y, p=P):
    """Relative distance used only for linking seed points into branches."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    return float(np.linalg.norm((x - y) / max(float(p.N0), 1.0)))


def _deduplicate_seed_records(records, param_key, state_key="state", p=P,
                              param_tol=1e-10, state_tol=2e-4):
    """Remove duplicate seed equilibria before branch linking."""
    unique = []
    for r in sorted(
        records,
        key=lambda z: (
            z[param_key],
            active_tb_burden_full(z[state_key])
            if len(z[state_key]) == 8
            else z[state_key][2] / max(np.sum(z[state_key]), 1.0),
        ),
    ):
        x = np.asarray(r[state_key], dtype=float)
        duplicate = False
        for old in unique:
            if abs(float(r[param_key]) - float(old[param_key])) > param_tol:
                continue
            denom = max(1.0, np.linalg.norm(old[state_key]))
            if np.linalg.norm(x - old[state_key]) / denom < state_tol:
                duplicate = True
                break
        if not duplicate:
            unique.append(r)
    return unique


def _link_seed_records_into_branches(records, param_key, state_key="state", p=P,
                                     link_tol=CONTINUATION_BRANCH_LINK_TOL):
    """
    Link nearby seed equilibria into provisional branches.

    This is not the final continuation result. It only supplies reliable
    neighbouring seed pairs for pseudo-arclength continuation.
    """
    if not records:
        return []

    records = _deduplicate_seed_records(records, param_key, state_key, p)
    params = sorted({float(r[param_key]) for r in records})
    by_param = {val: [] for val in params}
    for r in records:
        by_param[float(r[param_key])].append(r)

    if len(params) > 1:
        dpar = np.diff(np.asarray(params, dtype=float))
        dpar = dpar[dpar > 1e-12]
        max_param_gap = 2.75 * float(np.median(dpar)) if len(dpar) else np.inf
    else:
        max_param_gap = np.inf

    branches = []
    active = []

    for par in params:
        candidates = by_param[par]

        possible = []
        for bi in active:
            last = branches[bi][-1]
            if par - float(last[param_key]) > max_param_gap + 1e-12:
                continue
            for j, cand in enumerate(candidates):
                dist = _state_distance_scaled(last[state_key], cand[state_key], p)
                possible.append((dist, bi, j))

        possible.sort(key=lambda z: z[0])
        used_branches = set()
        used_candidates = set()
        new_active = []

        for dist, bi, j in possible:
            if bi in used_branches or j in used_candidates:
                continue
            if dist <= link_tol:
                branches[bi].append(candidates[j])
                used_branches.add(bi)
                used_candidates.add(j)
                new_active.append(bi)

        for j, cand in enumerate(candidates):
            if j not in used_candidates:
                branches.append([cand])
                new_active.append(len(branches) - 1)

        active = new_active

    return [b for b in branches if len(b) >= 2]


def _pseudo_arclength_trace(z0, z1, residual_func, scale, parameter_bounds,
                            max_steps=200, ds=None, ds_min=None, ds_max=None,
                            residual_tol=None, arc_tol=None,
                            arc_weight=None):
    """
    One-direction pseudo-arclength continuation.

    Solves F(x, lambda)=0 plus the arclength constraint. The state is scaled
    by N0 so that population variables and reproduction-number parameters
    have comparable numerical magnitudes.
    """
    if residual_tol is None:
        residual_tol = PSEUDO_ARCLENGTH_RESIDUAL_TOL
    if arc_tol is None:
        arc_tol = PSEUDO_ARCLENGTH_ARC_TOL
    if arc_weight is None:
        arc_weight = CONTINUATION_ARC_WEIGHT
    z_prev = np.asarray(z0, dtype=float).copy()
    z_curr = np.asarray(z1, dtype=float).copy()

    dz0 = z_curr - z_prev
    norm0 = float(np.linalg.norm(dz0))
    if not np.isfinite(norm0) or norm0 < 1e-12:
        return [z_prev]

    lam_min, lam_max = map(float, parameter_bounds)
    lam_range = max(lam_max - lam_min, 1e-8)

    if ds is None:
        ds = min(max(norm0, lam_range / 240.0), lam_range / 50.0)
    if ds_min is None:
        ds_min = max(ds / 32.0, lam_range / 20000.0)
    if ds_max is None:
        ds_max = min(2.4 * ds, lam_range / 28.0)

    n_state = len(scale)
    lower = np.r_[np.zeros(n_state), lam_min]
    upper = np.r_[np.ones(n_state) * CONTINUATION_MAX_STATE_SCALE, lam_max]

    out = [z_prev.copy(), z_curr.copy()]
    current_ds = float(ds)

    for _ in range(max_steps):
        tangent = z_curr - z_prev
        tangent_norm = float(np.linalg.norm(tangent))
        if not np.isfinite(tangent_norm) or tangent_norm < 1e-12:
            break
        tangent = tangent / tangent_norm

        accepted = False
        while current_ds >= ds_min:
            z_pred = z_curr + current_ds * tangent
            z_pred = np.minimum(np.maximum(z_pred, lower + 1e-12), upper - 1e-12)

            def augmented_residual(z):
                state, par = _unpack_continuation_z(z, scale)
                dyn = np.asarray(residual_func(state, par), dtype=float)
                arc = np.dot(z - z_curr, tangent) - current_ds
                return np.r_[dyn, arc_weight * arc]

            try:
                sol = least_squares(
                    augmented_residual,
                    z_pred,
                    bounds=(lower, upper),
                    xtol=1e-10,
                    ftol=1e-10,
                    gtol=1e-10,
                    max_nfev=max(500, FULL_ROOT_MAX_NFEV),
                    x_scale=np.maximum(np.abs(z_pred), 1.0),
                )
            except Exception:
                sol = None

            if sol is not None:
                z_next = sol.x
                state_next, par_next = _unpack_continuation_z(z_next, scale)
                dyn_norm = float(np.linalg.norm(residual_func(state_next, par_next)))
                arc_err = abs(float(np.dot(z_next - z_curr, tangent) - current_ds))

                if (
                    sol.success
                    and np.isfinite(dyn_norm)
                    and dyn_norm < residual_tol
                    and arc_err < arc_tol
                ):
                    if np.linalg.norm(z_next - z_curr) < 1e-10:
                        return out

                    out.append(z_next.copy())
                    z_prev, z_curr = z_curr, z_next
                    current_ds = min(current_ds * 1.18, ds_max)
                    accepted = True
                    break

            current_ds *= 0.5

        if not accepted:
            break

        # Stop once the branch has reached a requested plotting boundary.
        if z_curr[-1] <= lam_min + 1e-8 and tangent[-1] < 0:
            break
        if z_curr[-1] >= lam_max - 1e-8 and tangent[-1] > 0:
            break

    return out


def _bidirectional_pseudo_arclength(seed0, seed1, residual_func, scale,
                                    parameter_bounds, max_steps):
    """Trace both directions from a neighbouring seed pair."""
    z0 = np.asarray(seed0, dtype=float)
    z1 = np.asarray(seed1, dtype=float)
    forward = _pseudo_arclength_trace(
        z0, z1, residual_func, scale, parameter_bounds, max_steps=max_steps
    )
    backward = _pseudo_arclength_trace(
        z1, z0, residual_func, scale, parameter_bounds, max_steps=max_steps
    )
    return list(reversed(backward[2:])) + forward


def _records_from_continuation_z(z_values, scale, param_key, branch_id,
                                 source_label="pseudo_arclength"):
    records = []
    for arc_index, z in enumerate(z_values):
        state, par = _unpack_continuation_z(z, scale)
        records.append({
            param_key: par,
            "state": state,
            "branch_id": branch_id,
            "arc_index": arc_index,
            "continuation_source": source_label,
        })
    return records


def continue_tb_branches_from_scan(seed_records, m, p=P, RT_min=0.05, RT_max=5.0,
                                   max_steps=CONTINUATION_MAX_STEPS_TB,
                                   max_branches=CONTINUATION_MAX_BRANCHES_TB):
    """
    Convert TB scan equilibria into pseudo-arclength continuation branches.

    The scan is used only to locate neighbouring seed points. The returned
    branch points are recomputed by solving the augmented continuation system.
    """
    seeds = []
    for r in seed_records:
        if "state" not in r:
            continue
        x = np.asarray(r["state"], dtype=float)
        burden = x[2] / max(np.sum(x), 1.0)
        if burden > CONTINUATION_MIN_BURDEN and RT_min <= float(r["RT"]) <= RT_max:
            seeds.append(r)

    branches = _link_seed_records_into_branches(seeds, "RT", "state", p)
    branches = sorted(branches, key=len, reverse=True)[:max_branches]

    def residual_func(state, RT):
        beta1 = beta1_from_RT(RT, p)
        return rhs_tb(state, beta1, m, p) / max(float(p.Lambda), 1.0)

    out = []
    branch_id = 0
    for b in branches:
        b = sorted(b, key=lambda z: float(z["RT"]))
        if len(b) < 2:
            continue

        seed_pairs = [(b[0], b[1])]
        if len(b) >= 4:
            mid = len(b) // 2
            seed_pairs.append((b[mid - 1], b[mid]))

        for seed_a, seed_b in seed_pairs[:2]:
            z0, scale = _pack_continuation_z(seed_a["state"], seed_a["RT"], p)
            z1, _ = _pack_continuation_z(seed_b["state"], seed_b["RT"], p)
            z_values = _bidirectional_pseudo_arclength(
                z0, z1, residual_func, scale, (RT_min, RT_max), max_steps=max_steps
            )
            if len(z_values) >= 3:
                out.extend(_records_from_continuation_z(z_values, scale, "RT", branch_id))
                branch_id += 1

    return out


def continue_full_branches_from_scan(seed_records, RH, m, p=P, q_min=0.1, q_max=4.0,
                                     max_steps=CONTINUATION_MAX_STEPS_FULL,
                                     max_branches=CONTINUATION_MAX_BRANCHES_FULL):
    r"""
    Convert full-system scan equilibria into pseudo-arclength continuation branches.

    This does not alter the model or stability calculation. It only replaces
    visual branch drawing from raw scan points with augmented-equation branch
    tracing in (state, $\mathcal{R}_1^2$) space: TB is the invader
    (subscript 1) and the HIV-endemic background is the resident
    equilibrium (superscript 2).
    """
    beta2 = beta2_from_RH(RH, p)
    seeds = []
    for r in seed_records:
        if "state" not in r:
            continue
        x = np.asarray(r["state"], dtype=float)
        burden = active_tb_burden_full(x)
        if burden > CONTINUATION_MIN_BURDEN and q_min <= float(r["Q"]) <= q_max:
            seeds.append(r)

    branches = _link_seed_records_into_branches(seeds, "Q", "state", p)
    branches = sorted(branches, key=len, reverse=True)[:max_branches]

    def residual_func(state, Q):
        beta1 = beta1_from_RTH(Q, RH, p)
        return full_residual_scaled(state, beta1, beta2, m, p)

    out = []
    branch_id = 0
    for b in branches:
        b = sorted(b, key=lambda z: float(z["Q"]))
        if len(b) < 2:
            continue

        seed_pairs = [(b[0], b[1])]
        if len(b) >= 4:
            mid = len(b) // 2
            seed_pairs.append((b[mid - 1], b[mid]))

        for seed_a, seed_b in seed_pairs[:2]:
            z0, scale = _pack_continuation_z(seed_a["state"], seed_a["Q"], p)
            z1, _ = _pack_continuation_z(seed_b["state"], seed_b["Q"], p)
            z_values = _bidirectional_pseudo_arclength(
                z0, z1, residual_func, scale, (q_min, q_max), max_steps=max_steps
            )
            if len(z_values) >= 3:
                out.extend(_records_from_continuation_z(z_values, scale, "Q", branch_id))
                branch_id += 1

    return out


def solve_full_trajectory(RT, RH, m, x0=None, p=P, t_end=T_END):
    beta1 = beta1_from_RT(RT, p)
    beta2 = beta2_from_RH(RH, p)
    if x0 is None:
        x0 = full_initial_condition(RH, p, "moderate")

    sol = solve_ivp(
        lambda t, y: rhs_full(y, beta1, beta2, m, p),
        (0.0, t_end),
        x0,
        method="LSODA",
        rtol=1e-7,
        atol=1e-9,
        max_step=4.0,
    )
    if not sol.success:
        raise RuntimeError(sol.message)
    sol.y[sol.y < 0] = 0.0
    return sol


# ============================================================
# Extended stability classification with Hopf detection
# ============================================================


def _find_conjugate_pairs(eigs, tol=1e-6):
    """Group eigenvalues into conjugate pairs, returning list of (idx1, idx2)."""
    n = len(eigs)
    used = np.zeros(n, dtype=bool)
    pairs = []
    for i in range(n):
        if used[i]:
            continue
        if abs(eigs[i].imag) < tol:
            used[i] = True
            continue
        for j in range(i + 1, n):
            if used[j]:
                continue
            if (abs(eigs[i].real - eigs[j].real) < tol and
                    abs(eigs[i].imag + eigs[j].imag) < tol):
                pairs.append((i, j))
                used[i] = True
                used[j] = True
                break
        if not used[i]:
            used[i] = True
    return pairs


def classify_stability(eigs, tol=1e-6):
    """Enriched stability classification.

    Returns
    -------
    dict with keys:
        stable, max_real, n_unstable, saddle,
        hopf_candidate, hopf_frequency, leading_imag
    """
    reals = np.real(eigs)
    imags = np.abs(np.imag(eigs))
    max_real = float(np.max(reals))
    stable = max_real < -tol
    n_unstable = int(np.sum(reals > tol))
    saddle = n_unstable > 0 and n_unstable < len(eigs) and stable == False

    hopf_candidate = False
    hopf_frequency = None
    pairs = _find_conjugate_pairs(eigs, tol)
    for i, j in pairs:
        avg_real = (reals[i] + reals[j]) / 2.0
        avg_imag = (imags[i] + imags[j]) / 2.0
        if abs(avg_real) < tol and avg_imag > 10 * tol:
            hopf_candidate = True
            if hopf_frequency is None or avg_imag > hopf_frequency:
                hopf_frequency = float(avg_imag)

    leading_imag = float(imags[np.argmax(reals)])
    n_unstable = int(n_unstable)  # ensure plain Python int
    return {
        "stable": stable,
        "max_real": max_real,
        "n_unstable": n_unstable,
        "saddle": saddle,
        "hopf_candidate": hopf_candidate,
        "hopf_frequency": hopf_frequency,
        "leading_imag": leading_imag,
    }


def tb_stability_extended(eq, beta1, m, p=P):
    """Extended stability for TB subsystem, returns classify_stability dict."""
    J = central_numerical_jacobian(
        lambda y, b, mm, pp: rhs_tb(y, b, mm, pp), eq, (beta1, m, p)
    )
    eigs = eigvals(J)
    result = classify_stability(eigs)
    result["eigs"] = eigs
    return result


def full_stability_extended(eq, beta1, beta2, m, p=P):
    """Extended stability for full model, returns classify_stability dict."""
    J = central_numerical_jacobian(
        lambda y, b1, b2, mm, pp: rhs_full(y, b1, b2, mm, pp),
        eq, (beta1, beta2, m, p),
    )
    eigs = eigvals(J)
    result = classify_stability(eigs)
    result["eigs"] = eigs
    return result


# ============================================================
# Time integration and oscillation analysis
# ============================================================


def integrate_to_attractor(rhs_func, x0, args, t_transient=200.0,
                           t_record=300.0, n_points=2000, rtol=1e-7, atol=1e-9):
    """Integrate past transient and record asymptotic behaviour.

    Returns (t, y) where y has shape (n_dim, n_points).
    """
    t_total = t_transient + t_record
    t_eval = np.linspace(t_transient, t_total, n_points)

    sol = solve_ivp(
        rhs_func,
        (0.0, t_total),
        np.asarray(x0, dtype=float),
        args=args,
        method="LSODA",
        rtol=rtol,
        atol=atol,
        max_step=4.0,
        t_eval=t_eval,
    )
    if not sol.success:
        return None, None
    sol.y[sol.y < 0] = 0.0
    return sol.t, sol.y


def analyse_timeseries(t, y, component_idx=2, transient_frac=0.2,
                       min_amplitude=1e-5):
    """FFT-based oscillation diagnostics on a scalar time series.

    Parameters
    ----------
    t : ndarray (n_t,)
    y : ndarray (n_vars, n_t) or (n_t,)
    component_idx : int
        Which state variable to analyse (default 2 = I compartment).
    transient_frac : float
        Further fraction of the already-trimmed series to discard.
    min_amplitude : float
        Below this peak-to-peak, classify as non-oscillatory.

    Returns
    -------
    dict with oscillation diagnostics.
    """
    if y.ndim > 1:
        signal = y[component_idx, :].copy()
    else:
        signal = y.copy()

    n = len(signal)
    start = int(n * transient_frac)
    signal = signal[start:]
    t_trim = t[start:] if len(t) > start else t

    signal = signal - np.mean(signal)
    amplitude = float((np.max(signal) - np.min(signal)) / 2.0)

    if amplitude < min_amplitude or len(signal) < 32:
        return {
            "is_oscillatory": False,
            "dominant_frequency": 0.0,
            "dominant_period": np.inf,
            "amplitude": amplitude,
            "power_spectrum": (np.array([]), np.array([])),
            "peak_frequencies": [],
            "n_peaks": 0,
            "broadband": False,
        }

    window = np.hanning(len(signal))
    signal_windowed = signal * window
    dt = float(np.mean(np.diff(t_trim))) if len(t_trim) > 1 else 1.0
    n_fft = 2 ** int(np.ceil(np.log2(len(signal_windowed))))
    fft = np.fft.rfft(signal_windowed, n=n_fft)
    freqs = np.fft.rfftfreq(n_fft, d=dt)
    power = np.abs(fft) ** 2

    if len(power) < 4:
        return {
            "is_oscillatory": False,
            "dominant_frequency": 0.0,
            "dominant_period": np.inf,
            "amplitude": amplitude,
            "power_spectrum": (freqs, power),
            "peak_frequencies": [],
            "n_peaks": 0,
            "broadband": False,
        }

    try:
        from scipy.signal import find_peaks
        peaks, props = find_peaks(power, height=np.max(power) * 0.05, distance=2)
    except ImportError:
        peaks = np.array([], dtype=int)

    peak_freqs = [(freqs[p], power[p]) for p in peaks if p < len(freqs)]
    peak_freqs.sort(key=lambda x: x[1], reverse=True)

    median_power = float(np.median(power[1:])) if len(power) > 2 else 1e-30
    max_power = float(np.max(power))
    is_oscillatory = max_power > 5.0 * median_power if median_power > 0 else False

    dominant_frequency = float(peak_freqs[0][0]) if peak_freqs else 0.0
    dominant_period = 1.0 / dominant_frequency if dominant_frequency > 1e-10 else np.inf

    high_peaks = [(f, p) for f, p in peak_freqs if p > 0.3 * max_power]
    broadband = len(high_peaks) > 5

    return {
        "is_oscillatory": is_oscillatory,
        "dominant_frequency": dominant_frequency,
        "dominant_period": dominant_period,
        "amplitude": amplitude,
        "power_spectrum": (freqs, power),
        "peak_frequencies": peak_freqs,
        "n_peaks": len(peaks),
        "broadband": broadband,
    }


# ============================================================
# Largest Lyapunov exponent (Benettin algorithm)
# ============================================================


def largest_lyapunov_exponent(rhs_func, x0, args,
                              n_steps=LYAP_N_STEPS, tau=LYAP_TAU,
                              eps0=1e-7, transient_frac=0.25,
                              rtol=1e-9, atol=1e-12):
    """Compute largest Lyapunov exponent via Benettin renormalisation.

    Parameters
    ----------
    rhs_func : callable (t, y, *args) -> dy/dt
    x0 : ndarray
        Initial condition near the attractor.
    args : tuple
        Extra arguments for rhs_func.
    n_steps : int
        Renormalisation cycles.
    tau : float
        Integration time per cycle (years).
    eps0 : float
        Initial perturbation norm.
    transient_frac : float
        Fraction of cycles discarded before averaging.

    Returns
    -------
    lle : float
    history : ndarray (n_steps,)
    converged : bool
    """
    n_dim = len(x0)
    x_ref = np.asarray(x0, dtype=float).copy()

    rng = np.random.RandomState(42)
    v0 = rng.randn(n_dim)
    v0 = v0 / np.linalg.norm(v0)
    x_pert = x_ref + eps0 * v0

    log_div = np.zeros(n_steps)
    for i in range(n_steps):
        sol_ref = solve_ivp(
            rhs_func, (0.0, tau), x_ref, args=args,
            method="LSODA", rtol=rtol, atol=atol, max_step=min(1.0, tau / 4.0),
        )
        sol_pert = solve_ivp(
            rhs_func, (0.0, tau), x_pert, args=args,
            method="LSODA", rtol=rtol, atol=atol, max_step=min(1.0, tau / 4.0),
        )

        if not sol_ref.success or not sol_pert.success:
            return np.nan, log_div[:i], False

        x_ref_new = np.maximum(sol_ref.y[:, -1], 0.0)
        x_pert_new = np.maximum(sol_pert.y[:, -1], 0.0)

        d = x_pert_new - x_ref_new
        d_norm = np.linalg.norm(d)
        if d_norm < 1e-14:
            return 0.0, log_div[:i + 1], True

        log_div[i] = np.log(d_norm / eps0)
        x_pert = x_ref_new + eps0 * d / d_norm
        x_ref = x_ref_new

    n_transient = max(1, int(n_steps * transient_frac))
    used = log_div[n_transient:]
    lle = float(np.mean(used) / tau) if len(used) > 0 else 0.0

    if len(used) > 5:
        tail_std = float(np.std(used[-max(5, len(used) // 5):]))
        converged = tail_std < 0.1 * abs(np.mean(used)) if abs(np.mean(used)) > 1e-12 else True
    else:
        converged = False

    return lle, log_div, converged


# ============================================================
# 2-D bifurcation scanner for TB subsystem
# ============================================================


def scan_tb_2d_bifurcation(RT_vals, m_vals, p=P, n_grid=None):
    """Scan a rectangular grid in (RT, m) and classify dynamical regime.

    Returns
    -------
    dict with keys:
        RT_grid, m_grid,
        n_stable, n_total, has_hopf, max_burden, regime
    """
    if n_grid is None:
        n_grid = max(60, TB_ROOT_GRID // 2)

    n_RT = len(RT_vals)
    n_m = len(m_vals)

    n_stable = np.zeros((n_RT, n_m), dtype=int)
    n_total = np.zeros((n_RT, n_m), dtype=int)
    has_hopf = np.zeros((n_RT, n_m), dtype=bool)
    max_burden = np.zeros((n_RT, n_m))
    regime = np.zeros((n_RT, n_m), dtype=int)

    for i, RT in enumerate(RT_vals):
        if i % max(1, n_RT // 10) == 0:
            print(f"  2D scan column {i + 1}/{n_RT} (RT={RT:.3f})", flush=True)
        for j, m in enumerate(m_vals):
            beta1 = beta1_from_RT(RT, p)
            eqs = find_tb_endemic_equilibria(beta1, m, p, n_grid=n_grid)
            n_total[i, j] = len(eqs)
            stable_count = 0
            hopf_flag = False
            burden_max = 0.0
            for eq in eqs:
                result = tb_stability_extended(eq, beta1, m, p)
                if result["stable"]:
                    stable_count += 1
                    burden = eq[2] / np.sum(eq)
                    burden_max = max(burden_max, burden)
                if result["hopf_candidate"]:
                    hopf_flag = True
            n_stable[i, j] = stable_count
            has_hopf[i, j] = hopf_flag
            max_burden[i, j] = burden_max

            # Assign regime code
            # -1 = unresolved, 0 = DFE only, 1 = bistable,
            #  2 = endemic only,  3 = unstable endemic (LP < R1 < Hopf)
            if n_total[i, j] == 0:
                if RT < 1.0:
                    regime[i, j] = 0  # DFE only: DFE stable, no endemic
                else:
                    regime[i, j] = -1  # unresolved: DFE unstable, solver missed
            elif stable_count >= 1:
                if RT < 1.0:
                    regime[i, j] = 1  # bistable: DFE + stable endemic
                else:
                    regime[i, j] = 2  # endemic only: DFE unstable
            elif RT < 1.0:
                # Endemic exists but none stable: LP < R1 < Hopf region
                regime[i, j] = 3  # unstable endemic (real dynamical regime)
            else:
                regime[i, j] = -1  # unresolved

    return {
        "RT_grid": RT_vals,
        "m_grid": m_vals,
        "n_stable": n_stable,
        "n_total": n_total,
        "has_hopf": has_hopf,
        "max_burden": max_burden,
        "regime": regime,
    }


# ============================================================
# Bifurcation curve finders for TB subsystem
# ============================================================


def compute_m_c_TB_analytic(p: Params = P) -> float:
    """Analytic m_c^TB from the Section 3 centre-manifold formula.

    Equation (5.2)--(5.3):  N(m) = 0  ⇒  m_c^TB = k Λ N(0) / denom
    where N(0) is Eq.~(5.2) evaluated at m = 0.
    """
    mu, k, d = p.mu, p.k, p.d
    a0 = p.a0
    a_max = p.a_max
    omega0 = p.omega0
    Lambda = p.Lambda

    # Eq.(5.2): N(0) = term1 - term2 - term3  (the (1+m) factor is 1 at m=0)
    term1 = 2.0 * a0 * omega0 * (
        ((mu + d + a0) / k) ** 2 + (mu + k + a0) / k
    )
    term2 = (
        2.0
        * mu
        * (mu + k + a0)
        * (mu + d + a0)
        * (mu + d + a0 + k)
        / (k * k * Lambda)
    )
    term3_denom = k * Lambda  # factor shared by term3 and m_c denominator
    term3 = 2.0 * mu * (a_max - a0) * (2.0 * mu + k + d + 2.0 * a0) / term3_denom

    N0 = term1 - term2 - term3

    # Eq.(5.3): m_c^TB = k Λ N(0) / [2 μ (a_max-a0) (2μ + k + d + 2 a0)]
    denom_mc = 2.0 * mu * (a_max - a0) * (2.0 * mu + k + d + 2.0 * a0)
    m_c = k * Lambda * N0 / denom_mc
    return m_c


def _tb_dF_dI_5point(I, RT, m, p=P):
    """Five-point stencil approximation of dF/dI for the TB fold condition.

    More accurate and less sensitive to step-size choice than the
    two-point central difference used in _tb_LP_system.  This is the
    derivative that enters the LP continuation in trace_tb_LP_curve_by_I.
    """
    beta1 = beta1_from_RT(RT, p)
    h = max(1.0e-8, 1.0e-4 * I)
    h = min(h, 0.2 * I)

    fm2 = tb_endemic_residual(I - 2.0 * h, beta1, m, p)
    fm1 = tb_endemic_residual(I - h, beta1, m, p)
    fp1 = tb_endemic_residual(I + h, beta1, m, p)
    fp2 = tb_endemic_residual(I + 2.0 * h, beta1, m, p)

    values = np.array([fm2, fm1, fp1, fp2])
    if not np.all(np.isfinite(values)):
        return np.nan

    return (fm2 - 8.0 * fm1 + 8.0 * fp1 - fp2) / (12.0 * h)


def trace_tb_LP_curve_by_I(p=P, m_min=0.02, I_end=2.0, n_I=360):
    """Trace the TB saddle-node curve using I as continuation parameter.

    Unlike trace_tb_LP_curve (which uses m as continuation parameter and
    frequently fails near the cusp), this version uses I as the natural
    continuation parameter.  The curve is traced from a seed LP point at
    m = m_min down to I → 0, where it approaches the analytic codimension‑2
    endpoint (R1, m) = (1, m_c^TB) derived in Section 3.

    Parameters
    ----------
    p : Params
    m_min : float
        m value at which the seed LP is solved.
    I_end : float
        Terminal (small) I value for the trace.
    n_I : int
        Number of I grid points.

    Returns
    -------
    list of dicts
        Sorted by m.  Each dict has keys:
        m, RT, I, valid, fold_eigenvalue, second_real.
        The last entry is the analytic codim‑2 endpoint (m_c^TB, 1, 0).
    """
    m_c = compute_m_c_TB_analytic(p)

    # --- Seed LP point at m = m_min ----------------------------------------
    seed = least_squares(
        lambda z: _tb_LP_system(z, m_min, p),
        x0=np.array([0.05 * p.N0, 0.48]),
        bounds=(
            [1.0e-6, 0.30],
            [0.99 * p.Lambda / (p.mu + p.d), 1.20],
        ),
        xtol=1.0e-13,
        ftol=1.0e-13,
        gtol=1.0e-13,
        max_nfev=2000,
    )

    if not seed.success:
        raise RuntimeError(
            f"Could not initialize the TB LP curve at m={m_min:.4f}.  "
            f"least_squares message: {seed.message}"
        )

    I_seed, RT_seed = seed.x

    # --- I grid: dense both near the fold and near I → 0 -------------------
    n_linear = n_I // 3
    I_mid = max(0.55 * I_seed, 10.0 * I_end)

    I_grid = np.concatenate([
        np.linspace(I_seed, I_mid, n_linear),
        np.geomspace(I_mid, I_end, n_I - n_linear + 1)[1:],
    ])

    points = []
    guess = np.array([RT_seed, m_min])

    for I in I_grid:

        def fixed_I_system(z):
            RT, m = z
            beta1 = beta1_from_RT(RT, p)
            F = tb_endemic_residual(I, beta1, m, p)
            dF = _tb_dF_dI_5point(I, RT, m, p)

            if not np.isfinite(F) or not np.isfinite(dF):
                return np.array([1.0e3, 1.0e3])

            return np.array([F / p.Lambda, dF])

        sol = least_squares(
            fixed_I_system,
            x0=guess,
            bounds=(
                [0.30, 0.0],
                [1.02, 1.05 * m_c],
            ),
            x_scale=[0.2, 10.0],
            xtol=1.0e-12,
            ftol=1.0e-12,
            gtol=1.0e-12,
            max_nfev=1000,
        )

        error = np.max(np.abs(fixed_I_system(sol.x)))
        if not sol.success or error > 1.0e-7:
            raise RuntimeError(
                f"LP continuation failed at I={I:.6g}; "
                f"residual={error:.3e}, message={sol.message}"
            )

        RT, m = sol.x
        beta1 = beta1_from_RT(RT, p)
        eq = tb_equilibrium_from_I(I, beta1, m, p)

        J = numerical_jacobian(
            lambda y, b, mm, pp: rhs_tb(y, b, mm, pp),
            eq,
            (beta1, m, p),
        )
        eigs = eigvals(J)

        # Remove the fold eigenvalue closest to zero.
        zero_index = int(np.argmin(np.abs(eigs)))
        zero_eigenvalue = eigs[zero_index]
        other_eigs = np.delete(eigs, zero_index)

        if abs(zero_eigenvalue) > 5.0e-4:
            raise RuntimeError(
                f"LP eigenvalue check failed at m={m:.6g}, "
                f"|fold_ev| = {abs(zero_eigenvalue):.2e}"
            )

        points.append({
            "m": float(m),
            "RT": float(RT),
            "I": float(I),
            "valid": True,
            "fold_eigenvalue": complex(zero_eigenvalue),
            "second_real": float(np.max(np.real(other_eigs))),
        })

        guess = sol.x

    points.sort(key=lambda q: q["m"])

    # --- Exact codimension-two endpoint from Section 3 ----------------------
    points.append({
        "m": float(m_c),
        "RT": 1.0,
        "I": 0.0,
        "valid": True,
        "fold_eigenvalue": 0.0,
        "second_real": np.nan,
    })

    return points


def _tb_LP_system(vars, m, p):
    """Two-equation system for the fold / saddle-node (LP) condition.

    Unknowns:  vars = (I, RT)  where  I = TB infectious fraction,
    RT = beta1 / beta1_star_TB_only.

    Equations:
      (1)  F(I; RT, m) = 0        equilibrium condition
      (2)  dF/dI(I; RT, m) = 0    fold condition (tangency)
    """
    I, RT = vars
    if I <= 1e-12 or RT <= 0.01:
        return np.array([1e12, 1e12])

    beta1 = beta1_from_RT(RT, p)

    # Equilibrium residual
    F = tb_endemic_residual(I, beta1, m, p)
    if not np.isfinite(F):
        return np.array([1e12, 1e12])

    # dF/dI via central differences
    h = max(1e-7, abs(I) * 1e-6)
    Fp = tb_endemic_residual(I + h, beta1, m, p)
    Fm = tb_endemic_residual(I - h, beta1, m, p)
    if not (np.isfinite(Fp) and np.isfinite(Fm)):
        return np.array([1e12, 1e12])
    dF = (Fp - Fm) / (2.0 * h)

    return np.array([F, dF], dtype=float)


def _tb_LP_validate(I, RT, m, p, tol_res=1e-7, tol_fold=1e-5):
    """Post-solve validation of a candidate LP point."""
    beta1 = beta1_from_RT(RT, p)

    # (a) Equilibrium residual
    F = tb_endemic_residual(I, beta1, m, p)
    if not np.isfinite(F) or abs(F) > tol_res:
        return False, f"F = {F:.2e}"

    # (b) State variables all non-negative
    eq = tb_equilibrium_from_I(I, beta1, m, p)
    if eq is None:
        return False, "tb_equilibrium_from_I returned None"
    if np.any(eq < -1e-10):
        return False, f"negative state: {eq}"

    # (c) Fold condition (dF/dI ≈ 0)
    h = max(1e-7, abs(I) * 1e-6)
    Fp = tb_endemic_residual(I + h, beta1, m, p)
    Fm = tb_endemic_residual(I - h, beta1, m, p)
    dF = (Fp - Fm) / (2.0 * h)
    if not np.isfinite(dF) or abs(dF) > tol_fold:
        return False, f"dF/dI = {dF:.2e}"

    # (d) Full Jacobian has exactly one near-zero eigenvalue
    _, max_real, eigs = tb_stability(eq, beta1, m, p)
    n_near_zero = sum(1 for ev in eigs if abs(np.real(ev)) < 5e-4)
    if n_near_zero != 1:
        return False, f"{n_near_zero} near-zero eigenvalues (want 1), max_Re={max_real:.2e}"

    # (e) Reject near-DFE spurious solutions: the LP should have I/N > 1e-6
    I_over_N = I / np.sum(eq)
    if I_over_N < 1e-8:
        return False, f"I/N = {I_over_N:.2e} (near DFE, not a genuine LP)"

    return True, "OK"


def trace_tb_LP_curve(m_vals, p=P, verbose=True):
    """Trace the TB-only saddle-node (LP) curve in (RT, m) space.

    For each m, solves  F(I; RT, m) = 0,  dF/dI(I; RT, m) = 0
    using the previous solution as initial guess (pseudo-arclength continuation).

    Returns
    -------
    list of dicts: [{"m": m, "RT": RT, "I": I, "valid": bool, "diagnostic": str}, ...]
    """
    from scipy.optimize import least_squares

    # Initial guess for small m: scan I at RT where DFE becomes unstable-ish
    # For very small m in backward regime, the LP RT is near R_c ≈ 0.48
    lp_points = []

    # Scan for the first LP at the smallest m
    m0 = m_vals[0]
    RT_scan = np.linspace(0.40, 1.50, 120)
    candidates = []
    for RT in RT_scan:
        beta1 = beta1_from_RT(RT, p)
        eqs = find_tb_endemic_equilibria(beta1, m0, p, n_grid=80)
        if len(eqs) >= 2:
            # Near a fold: two equilibria found → saddle-node nearby
            # Use the I from the smaller-burden equilibrium (unstable branch)
            burdens = [(eq[2] / np.sum(eq), eq) for eq in eqs]
            burdens.sort()
            I_guess = burdens[0][1][2] / np.sum(burdens[0][1])
            candidates.append((RT, I_guess * np.sum(burdens[0][1])))

    if not candidates:
        if verbose:
            print("  trace_tb_LP_curve: no candidate LP found at smallest m")
        return lp_points

    # Use the candidate with RT closest to the expected range
    best = min(candidates, key=lambda x: abs(x[0] - 0.48))
    I_guess, RT_guess = best[1], best[0]

    for i_m, m_val in enumerate(m_vals):
        if verbose and (i_m % max(1, len(m_vals) // 8) == 0):
            print(f"  LP trace: m={m_val:.3f} ({i_m + 1}/{len(m_vals)})", flush=True)

        # Extrapolate initial guess from previous valid points
        valid_pts_so_far = [p for p in lp_points if p["valid"]]
        if len(valid_pts_so_far) >= 3:
            # Quadratic extrapolation in m for I and RT
            recent = valid_pts_so_far[-3:]
            m_fit = np.array([p["m"] for p in recent])
            I_fit = np.array([p["I"] for p in recent])
            RT_fit = np.array([p["RT"] for p in recent])
            try:
                coef_I = np.polyfit(m_fit, I_fit, 2)
                coef_RT = np.polyfit(m_fit, RT_fit, 2)
                I_extrap = np.polyval(coef_I, m_val)
                RT_extrap = np.polyval(coef_RT, m_val)
                # Sanity: extrapolation should not jump wildly
                dp_prev = valid_pts_so_far[-1]
                if (0.5 * I_fit[-1] < I_extrap < 2.0 * I_fit[-1] and
                    0.8 < RT_extrap < 1.3):
                    I_guess, RT_guess = I_extrap, RT_extrap
            except Exception:
                pass  # Keep previous guess if extrapolation fails

        # Try solving with multiple strategies
        success = False
        attempt_guesses = [
            (I_guess, RT_guess),           # nominal guess
            (I_guess * 0.95, RT_guess),    # perturb I down
            (I_guess * 1.05, RT_guess),    # perturb I up
            (I_guess, RT_guess * 1.02),    # perturb RT up (near cusp)
        ]
        # Relax fold tolerance at high m (near cusp the fold is shallow)
        tol_fold = 1e-5 if m_val < 12.0 else 5e-4

        for attempt, (I0, RT0) in enumerate(attempt_guesses):
            if success:
                break
            x0 = np.array([I0, RT0], dtype=float)

            # Strategy 1: trust-region (trf) — works well away from cusp
            if attempt < 2:
                try:
                    res = least_squares(
                        lambda v: _tb_LP_system(v, m_val, p),
                        x0,
                        bounds=([1e-12, 0.05], [np.inf, 3.0]),
                        ftol=1e-12, xtol=1e-12, gtol=1e-12,
                        max_nfev=300,
                        method="trf",
                    )
                    if res.success:
                        I_sol, RT_sol = res.x
                        valid, diag = _tb_LP_validate(
                            I_sol, RT_sol, m_val, p, tol_fold=tol_fold)
                        if valid:
                            lp_points.append({
                                "m": float(m_val), "RT": float(RT_sol),
                                "I": float(I_sol), "valid": True,
                                "diagnostic": diag,
                            })
                            I_guess, RT_guess = I_sol, RT_sol
                            success = True
                            break
                except Exception:
                    continue

            # Strategy 2: Levenberg-Marquardt — better for ill-conditioned
            # systems near the cusp
            try:
                res = least_squares(
                    lambda v: _tb_LP_system(v, m_val, p),
                    x0,
                    method="lm",
                    ftol=1e-12, xtol=1e-12, gtol=1e-12,
                    max_nfev=400,
                )
                if res.success:
                    I_sol, RT_sol = res.x
                    if I_sol > 1e-12 and 0.05 < RT_sol < 3.0:
                        valid, diag = _tb_LP_validate(
                            I_sol, RT_sol, m_val, p, tol_fold=tol_fold)
                        if valid:
                            lp_points.append({
                                "m": float(m_val), "RT": float(RT_sol),
                                "I": float(I_sol), "valid": True,
                                "diagnostic": diag,
                            })
                            I_guess, RT_guess = I_sol, RT_sol
                            success = True
                            break
            except Exception:
                continue

        if not success:
            # Record failure; extrapolated guess provides continuity
            lp_points.append({
                "m": float(m_val), "RT": float(RT_guess),
                "I": float(I_guess), "valid": False,
                "diagnostic": "solver did not converge near cusp",
            })
            if verbose:
                print(f"    LP solver failed at m={m_val:.4f}", flush=True)

    return lp_points


def _tb_Hopf_system(z, m, p=P):
    """Equilibrium and Hopf conditions for fixed m.

    Unknowns:  z = (I, RT).

    Equations:
      (1)  F(I; RT, m) = 0              equilibrium condition
      (2)  Re(lambda_leading) = 0        Hopf condition

    lambda_leading is the eigenvalue with the largest imaginary part.
    """
    I, RT = z
    beta1 = beta1_from_RT(RT, p)

    F = tb_endemic_residual(I, beta1, m, p)
    eq = tb_equilibrium_from_I(I, beta1, m, p)

    if eq is None or not np.isfinite(F):
        return np.array([1.0e3, 1.0e3])

    J = numerical_jacobian(
        lambda y, b, mm, pp: rhs_tb(y, b, mm, pp),
        eq,
        (beta1, m, p),
    )
    eigs = eigvals(J)

    # Select the complex pair with the largest imaginary part.
    index = int(np.argmax(np.abs(np.imag(eigs))))
    leading_complex = eigs[index]

    return np.array([
        F / p.Lambda,
        np.real(leading_complex),
    ])


def trace_tb_Hopf_curve(m_vals, p=P):
    """Trace the TB Hopf curve by continuation in m.

    Solves  F=0,  Re(leading_eig)=0  at each m using least_squares.
    The initial guess at the smallest m must be provided and has been
    verified for the current parameter set.

    The curve terminates when the solver fails, which occurs near the
    LP–Hopf meeting point where the Hopf eigenvalue loses its purely
    imaginary character.

    Returns
    -------
    list of dicts: [{"m": m, "RT": RT, "I": I, "frequency": freq}, ...]
    """
    points = []

    # Initial value verified for the current parameter set.
    guess = np.array([0.07 * p.N0, 0.505])

    for m in np.asarray(m_vals, dtype=float):
        sol = least_squares(
            lambda z: _tb_Hopf_system(z, m, p),
            x0=guess,
            bounds=(
                [1.0e-4, 0.30],
                [0.99 * p.Lambda / (p.mu + p.d), 1.20],
            ),
            x_scale=[500.0, 0.2],
            xtol=1.0e-12,
            ftol=1.0e-12,
            gtol=1.0e-12,
            max_nfev=1000,
        )

        if not sol.success:
            break

        I, RT = sol.x
        residual = _tb_Hopf_system(sol.x, m, p)

        beta1 = beta1_from_RT(RT, p)
        eq = tb_equilibrium_from_I(I, beta1, m, p)
        J = numerical_jacobian(
            lambda y, b, mm, pp: rhs_tb(y, b, mm, pp),
            eq,
            (beta1, m, p),
        )
        eigs = eigvals(J)
        index = int(np.argmax(np.abs(np.imag(eigs))))
        leading_complex = eigs[index]
        frequency = abs(np.imag(leading_complex))

        if (
            np.max(np.abs(residual)) > 1.0e-7
            or frequency < 1.0e-4
        ):
            break

        points.append({
            "m": float(m),
            "RT": float(RT),
            "I": float(I),
            "frequency": float(frequency),
        })

        guess = sol.x

    return points


def find_saddle_node_tb(m, p=P, RT_min=0.05, RT_max=5.0,
                        n_scan=HOPF_SCAN_N, refine=True):
    """Locate saddle-node (fold) bifurcation RT values for fixed m.

    Uses the proper LP solver (F=0, dF/dI=0) with continuation.
    Falls back to the old grid-scan method if the LP solver fails.
    """
    result = trace_tb_LP_curve([m], p=p, verbose=False)
    if result and result[0]["valid"]:
        return [result[0]["RT"]]
    # Fallback: old grid-scan detector (kept for backward compatibility
    # but marked as approximate)
    RT_scan = np.linspace(RT_min, RT_max, n_scan)
    counts = []
    for RT in RT_scan:
        beta1 = beta1_from_RT(RT, p)
        eqs = find_tb_endemic_equilibria(beta1, m, p, n_grid=max(60, TB_ROOT_GRID // 2))
        counts.append(len(eqs))

    sn_points = []
    for k in range(len(counts) - 1):
        if counts[k] != counts[k + 1]:
            sn_points.append(float((RT_scan[k] + RT_scan[k + 1]) / 2.0))

    return sorted(set(round(s, 6) for s in sn_points))


def find_hopf_bifurcation_tb(m, p=P, RT_min=0.05, RT_max=5.0,
                             n_scan=HOPF_SCAN_N, refine=True):
    """Locate Hopf bifurcation points for the TB subsystem at fixed m.

    Returns list of dicts: [{'RT': ..., 'frequency': ..., 'burden': ...}, ...]
    """
    RT_scan = np.linspace(RT_min, RT_max, n_scan)
    hopf_indicator = np.full(n_scan, np.nan)
    hopf_freqs = np.full(n_scan, np.nan)
    hopf_burdens = np.full(n_scan, np.nan)

    for i, RT in enumerate(RT_scan):
        beta1 = beta1_from_RT(RT, p)
        eqs = find_tb_endemic_equilibria(beta1, m, p, n_grid=max(60, TB_ROOT_GRID // 2))
        for eq in eqs:
            result = tb_stability_extended(eq, beta1, m, p)
            if result["hopf_candidate"]:
                hopf_indicator[i] = result["max_real"]
                hopf_freqs[i] = result["hopf_frequency"]
                hopf_burdens[i] = eq[2] / np.sum(eq)
                break  # take first Hopf candidate at this RT

    hopf_points = []
    for k in range(len(hopf_indicator) - 1):
        va, vb = hopf_indicator[k], hopf_indicator[k + 1]
        if np.isfinite(va) and np.isfinite(vb) and va * vb < 0:
            RT_a, RT_b = RT_scan[k], RT_scan[k + 1]
            if refine:
                try:
                    def indicator_at_RT(RT_val):
                        beta1_val = beta1_from_RT(RT_val, p)
                        eqs_val = find_tb_endemic_equilibria(
                            beta1_val, m, p, n_grid=max(60, TB_ROOT_GRID // 2))
                        for eq_val in eqs_val:
                            r_val = tb_stability_extended(eq_val, beta1_val, m, p)
                            if r_val["hopf_candidate"]:
                                return r_val["max_real"]
                        return 1.0
                    RT_refined = brentq(indicator_at_RT, RT_a, RT_b, maxiter=100, xtol=1e-8)
                    freq = float(np.nanmean([hopf_freqs[k], hopf_freqs[k + 1]]))
                    bur = float(np.nanmean([hopf_burdens[k], hopf_burdens[k + 1]]))
                    hopf_points.append({
                        "RT": float(RT_refined),
                        "frequency": freq,
                        "burden": bur,
                    })
                except (ValueError, RuntimeError):
                    pass
            else:
                freq = float(np.nanmean([hopf_freqs[k], hopf_freqs[k + 1]]))
                bur = float(np.nanmean([hopf_burdens[k], hopf_burdens[k + 1]]))
                hopf_points.append({
                    "RT": float((RT_a + RT_b) / 2.0),
                    "frequency": freq,
                    "burden": bur,
                })

    return hopf_points
def plot_smooth_branch(ax, x, y, color, linestyle='-', linewidth=2.2, label=None, zorder=4):
    """专为后向分岔设计的平滑曲线绘制（保单调Pchip插值 + 高密度插值）"""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(x) < 4 or len(y) < 4:
        # 点太少时直接画
        ax.plot(x, y, color=color, linestyle=linestyle, linewidth=linewidth, label=label, zorder=zorder)
        return
    
    # 排序 + 去重（重复x取y均值）
    order = np.argsort(x)
    x_sorted, y_sorted = x[order], y[order]
    # collapse duplicate x by averaging y
    xu, idx, inv, cnt = np.unique(x_sorted, return_index=True, return_inverse=True, return_counts=True)
    if len(xu) < len(x_sorted):
        yu = np.zeros_like(xu)
        np.add.at(yu, inv, y_sorted)
        yu /= cnt
        x_sorted, y_sorted = xu, yu
    if len(x_sorted) < 4:
        ax.plot(x_sorted, y_sorted, color=color, linestyle=linestyle, linewidth=linewidth, label=label, zorder=zorder)
        return
    x_new = np.linspace(x_sorted.min(), x_sorted.max(), 800)
    spl = PchipInterpolator(x_sorted, y_sorted)
    y_smooth = spl(x_new)
    
    ax.plot(x_new, y_smooth, color=color, linestyle=linestyle, linewidth=linewidth, 
            label=label, zorder=zorder)
