"""
Direct vs indirect m-sensitivity decomposition at the left edge BP1.

At the HIV-invasion branch point of the TB boundary (Q=Q_BP1), the transverse
HIV-invasion eigenvalue is zero. We decompose d(lambda_trans)/dm into:
  - direct term: m changes a(B1) in the treatment flow J2->J1, with E1 fixed
  - indirect term: m moves the resident TB-endemic equilibrium E1 (B1 changes),
    which shifts S1*, I1*, T1* and hence the HIV invasion block.

Output: ../output/bp1_m_sensitivity_decomposition.json
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
from scipy.linalg import eigvals

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(spec)
sys.modules["common"] = common
spec.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

P = common.P
RH = 1.8
BETA2 = common.beta2_from_RH(RH, P)
M0 = 0.05
DELTA = 0.01  # finite difference step
OUT = HERE.parent / "output"


def central_jacobian(x, beta1, beta2, m, eps=1e-6):
    n = len(x)
    J = np.zeros((n, n))
    f0 = common.rhs_full(x, beta1, beta2, m)
    for i in range(n):
        xp = x.copy()
        xp[i] += eps
        J[:, i] = (common.rhs_full(xp, beta1, beta2, m) - f0) / eps
    return J


def transverse_eig(x, beta1, beta2, m):
    """Largest real eigenvalue of the HIV (J1,J2,J3) block at TB-only E1."""
    J = central_jacobian(x, beta1, beta2, m)
    return float(np.max(np.real(eigvals(J[4:7, 4:7]))))


def tb_only_state(Q, m):
    beta1 = common.beta1_from_RTH(float(Q), RH, P)
    roots = common.find_tb_endemic_equilibria(beta1, m, P, n_grid=800)
    if not roots:
        return None
    tb = max(roots, key=lambda y: y[2] / np.sum(y))
    x = np.zeros(8, dtype=float)
    x[:4] = tb
    return x


def main():
    print("=== Direct vs indirect m-sensitivity at BP1 ===", flush=True)

    # Step 1: Find E1 at m=0.05, Q=BP1
    Q_BP1 = 0.6642535241319278
    beta1_0 = common.beta1_from_RTH(Q_BP1, RH, P)
    E1_0 = tb_only_state(Q_BP1, M0)
    N0 = np.sum(E1_0)
    B1_0 = (E1_0[2] + E1_0[6]) / N0
    a1_0, omega1_0 = common.response_from_burden(B1_0, M0, P)
    print(f"m={M0}: Q_BP1={Q_BP1:.6f}, beta1={beta1_0:.6f}", flush=True)
    print(f"  E1: S={E1_0[0]:.2f}, L={E1_0[1]:.2f}, I={E1_0[2]:.2f}, T={E1_0[3]:.2f}", flush=True)
    print(f"  B1={B1_0:.6f}, a(B1)={a1_0:.6f}, omega(B1)={omega1_0:.6e}", flush=True)

    # Step 2: lambda_trans at baseline (should be ~0)
    lambda_0 = transverse_eig(E1_0, beta1_0, BETA2, M0)
    print(f"  lambda_trans(m0, E1_m0) = {lambda_0:.6e} (should be ~0)", flush=True)

    # Step 3: Direct effect - fix E1, change m to m0+delta
    m_plus = M0 + DELTA
    lambda_direct = transverse_eig(E1_0, beta1_0, BETA2, m_plus)
    direct_deriv = (lambda_direct - lambda_0) / DELTA
    print(f"\nDirect (E1 fixed, m={m_plus}):", flush=True)
    print(f"  lambda_trans = {lambda_direct:.6e}", flush=True)
    print(f"  d(lambda)/dm (direct) = {direct_deriv:.6e}", flush=True)

    # Step 4: Total effect - E1 moves with m
    E1_plus = tb_only_state(Q_BP1, m_plus)
    if E1_plus is not None:
        N_plus = np.sum(E1_plus)
        B1_plus = (E1_plus[2] + E1_plus[6]) / N_plus
        a1_plus, _ = common.response_from_burden(B1_plus, m_plus, P)
        lambda_total = transverse_eig(E1_plus, beta1_0, BETA2, m_plus)
        total_deriv = (lambda_total - lambda_0) / DELTA
        indirect_deriv = total_deriv - direct_deriv
        print(f"\nTotal (E1 moves with m={m_plus}):", flush=True)
        print(f"  E1: S={E1_plus[0]:.2f}, L={E1_plus[1]:.2f}, I={E1_plus[2]:.2f}, T={E1_plus[3]:.2f}", flush=True)
        print(f"  B1={B1_plus:.6f} (delta B1={B1_plus-B1_0:+.2e})", flush=True)
        print(f"  a(B1)={a1_plus:.6f} (delta a={a1_plus-a1_0:+.2e})", flush=True)
        print(f"  lambda_trans = {lambda_total:.6e}", flush=True)
        print(f"  d(lambda)/dm (total) = {total_deriv:.6e}", flush=True)
        print(f"  d(lambda)/dm (indirect) = {indirect_deriv:.6e}", flush=True)

        # Relative contributions
        if abs(total_deriv) > 1e-15:
            direct_frac = direct_deriv / total_deriv * 100
            indirect_frac = indirect_deriv / total_deriv * 100
            print(f"\nRelative contributions to d(lambda)/dm:", flush=True)
            print(f"  direct (a(B1) in V): {direct_frac:.1f}%", flush=True)
            print(f"  indirect (E1 moves): {indirect_frac:.1f}%", flush=True)
    else:
        total_deriv = None
        indirect_deriv = None
        print("Could not find E1 at m+delta", flush=True)

    # Also compute at m=2 for comparison
    print(f"\n--- Cross-check at m=2.0 ---", flush=True)
    Q_BP1_m2 = 0.8761255336024463
    E1_m2 = tb_only_state(Q_BP1_m2, 2.0)
    if E1_m2 is not None:
        N_m2 = np.sum(E1_m2)
        B1_m2 = (E1_m2[2] + E1_m2[6]) / N_m2
        a1_m2, _ = common.response_from_burden(B1_m2, 2.0, P)
        beta1_m2 = common.beta1_from_RTH(Q_BP1_m2, RH, P)
        lambda_m2 = transverse_eig(E1_m2, beta1_m2, BETA2, 2.0)
        print(f"  Q_BP1={Q_BP1_m2:.6f}, B1={B1_m2:.6f}, a(B1)={a1_m2:.6f}", flush=True)
        print(f"  lambda_trans = {lambda_m2:.6e} (should be ~0)", flush=True)
        # Direct at m=2
        lambda_m2_direct = transverse_eig(E1_m2, beta1_m2, BETA2, 2.0+DELTA)
        direct_m2 = (lambda_m2_direct - lambda_m2) / DELTA
        # Total at m=2
        E1_m2p = tb_only_state(Q_BP1_m2, 2.0+DELTA)
        if E1_m2p is not None:
            lambda_m2_total = transverse_eig(E1_m2p, beta1_m2, BETA2, 2.0+DELTA)
            total_m2 = (lambda_m2_total - lambda_m2) / DELTA
            indirect_m2 = total_m2 - direct_m2
            print(f"  d(lambda)/dm: direct={direct_m2:.6e}, indirect={indirect_m2:.6e}, total={total_m2:.6e}", flush=True)

    # Save
    results = {
        "m0": M0, "Q_BP1_m0": Q_BP1, "delta": DELTA,
        "lambda_at_BP1": lambda_0,
        "direct_derivative": direct_deriv,
        "total_derivative": total_deriv,
        "indirect_derivative": indirect_deriv,
        "B1_m0": B1_0, "a_B1_m0": a1_0,
        "note": "At BP1, lambda_trans=0. Positive d(lambda)/dm means increasing m makes TB boundary transversely stable (window shrinks). Direct term = m changes a(B1) in J2->J1 treatment flow with E1 fixed. Indirect term = m moves E1 (B1 changes).",
    }
    outpath = OUT / "bp1_m_sensitivity_decomposition.json"
    with open(outpath, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved: {outpath}", flush=True)


if __name__ == "__main__":
    main()
