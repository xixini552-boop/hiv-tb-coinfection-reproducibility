"""
10_extended_bifurcation.py
==========================
TB-only two-parameter bifurcation diagram in the (R1, m) plane
(Figure 5 in the manuscript: Section 4.1, Single-disease bifurcation structure).

The LP (saddle-node) curve is computed by solving the exact fold condition
F(I; R1, m) = 0,  dF/dI(I; R1, m) = 0  using numerical continuation with I
as the continuation parameter.

The Hopf curve is computed by solving F=0,  Re(leading_eig)=0  at each m.
"""

import importlib.util
import json
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location("common", str(Path(__file__).with_name("00_common.py")))
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({name: getattr(common, name) for name in dir(common) if not name.startswith("_")})

import matplotlib.colors as mcolors
import matplotlib.ticker as mticker
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import PchipInterpolator


# ============================================================
# Figure: 2D bifurcation diagram in (RT, m) space
# ============================================================


def figure_tb_2d_bifurcation():
    set_publication_style()

    RT_grid = np.linspace(0.4, 1.4, 300)
    m_grid = np.logspace(np.log10(0.02), np.log10(25.0), 220)

    # ---------------------------------------------------------
    # 1. LP curve
    # ---------------------------------------------------------
    lp_points = trace_tb_LP_curve_by_I(
        P, m_min=0.02, I_end=2.0, n_I=360
    )

    lp_m = np.array([q["m"] for q in lp_points])
    lp_RT = np.array([q["RT"] for q in lp_points])

    # Sort the LP points and remove numerical duplicates.
    order = np.argsort(lp_m)
    lp_m = lp_m[order]
    lp_RT = lp_RT[order]

    keep = np.r_[
        True,
        np.diff(lp_m) > 1.0e-10
    ]
    lp_m = lp_m[keep]
    lp_RT = lp_RT[keep]

    if not np.all(np.diff(lp_m) > 0.0):
        raise RuntimeError(
            "LP continuation parameter m is not strictly increasing."
        )

    m_c_TB = compute_m_c_TB_analytic(P)

    lp_interpolant = PchipInterpolator(
        lp_m, lp_RT, extrapolate=False
    )

    # ---------------------------------------------------------
    # 2. Locate the LP–Hopf meeting point
    # ---------------------------------------------------------
    finite_lp = [
        q for q in lp_points
        if np.isfinite(q["second_real"])
    ]

    second_real = np.array(
        [q["second_real"] for q in finite_lp]
    )
    finite_m = np.array([q["m"] for q in finite_lp])

    changes = np.where(
        second_real[:-1] * second_real[1:] <= 0.0
    )[0]

    if len(changes) == 0:
        raise RuntimeError(
            "Could not locate the LP–Hopf meeting point."
        )

    k = changes[0]
    m_meet = finite_m[k] - second_real[k] * (
        finite_m[k + 1] - finite_m[k]
    ) / (second_real[k + 1] - second_real[k])

    RT_meet = float(lp_interpolant(m_meet))

    # Archive the computed bifurcation markers. These are genuine outputs of
    # the solvers above; recording them gives the manuscript values
    # (m_c^TB ≈ 21.2, LP–Hopf meet ≈ (12.75, 0.91)) a reproducible source.
    # The manuscript constants are kept only as metadata for comparison, never
    # as an enforced gate, so the script stays reproducible under reparametrisation.
    archive_10 = {
        "preset": PARAMETER_PRESET,
        "m_c_TB_analytic": float(m_c_TB),
        "m_c_TB_manuscript_ref": 21.1738858213,
        "lp_hopf_meeting_m": float(m_meet),
        "lp_hopf_meeting_m_manuscript_ref": 12.75204,
        "lp_hopf_meeting_R1": float(RT_meet),
        "lp_hopf_meeting_R1_manuscript_ref": 0.914130,
    }
    _out = Path(__file__).resolve().parent.parent / "output" / "tb_only_2d_bifurcation.json"
    _out.parent.mkdir(parents=True, exist_ok=True)
    _out.write_text(json.dumps(archive_10, indent=2), encoding="utf-8")
    print(f"Archived 2D-bifurcation markers to {_out}")

    # ---------------------------------------------------------
    # 3. Hopf curve
    # ---------------------------------------------------------
    hopf_m_grid = np.linspace(0.02, m_meet - 1.0e-3, 180)
    hopf_points = trace_tb_Hopf_curve(hopf_m_grid, P)

    if len(hopf_points) < 100:
        raise RuntimeError(
            f"Too few valid Hopf points: {len(hopf_points)}"
        )

    hopf_m = np.array([q["m"] for q in hopf_points])
    hopf_RT = np.array([q["RT"] for q in hopf_points])

    # Add the limiting LP–Hopf intersection.
    hopf_m = np.append(hopf_m, m_meet)
    hopf_RT = np.append(hopf_RT, RT_meet)

    hopf_interpolant = PchipInterpolator(
        hopf_m, hopf_RT, extrapolate=False
    )

    print(f"Analytic m_c^TB = {m_c_TB:.6f}")
    print(
        "LP–Hopf meeting point: "
        f"m={m_meet:.6f}, R1={RT_meet:.6f}"
    )

    # ---------------------------------------------------------
    # 4. Equilibrium-configuration map
    #
    # 0: no endemic equilibrium
    # 1: endemic equilibria exist but are unstable
    # 2: stable DFE and stable endemic equilibrium coexist
    # 3: DFE unstable; stable endemic equilibrium
    # ---------------------------------------------------------
    regime = np.zeros(
        (len(RT_grid), len(m_grid)), dtype=int
    )

    for j, m in enumerate(m_grid):
        for i, RT in enumerate(RT_grid):

            if RT >= 1.0:
                regime[i, j] = 3
                continue

            if m >= m_c_TB:
                regime[i, j] = 0
                continue

            RT_LP = float(lp_interpolant(m))

            if RT <= RT_LP:
                regime[i, j] = 0
                continue

            if m < m_meet:
                RT_H = float(hopf_interpolant(m))

                if RT < RT_H:
                    regime[i, j] = 1
                else:
                    regime[i, j] = 2
            else:
                regime[i, j] = 2

    # ---------------------------------------------------------
    # 5. Plot
    # ---------------------------------------------------------
    # Larger canvas; horizontal colour bar at the bottom so the long
    # equilibrium-configuration labels remain legible at journal width.
    fig, ax = plt.subplots(figsize=(7.6, 6.4))

    cmap_colors = [
        "#FFB74D",  # no endemic equilibrium
        "#FFF3E0",  # unstable endemic equilibria
        "#E57373",  # DFE-endemic bistability
        "#D0D0D0",  # DFE unstable
    ]

    cmap = mcolors.ListedColormap(cmap_colors)
    bounds = [-0.5, 0.5, 1.5, 2.5, 3.5]
    norm = mcolors.BoundaryNorm(bounds, cmap.N)

    X, Y = np.meshgrid(
        RT_grid, m_grid, indexing="ij"
    )

    im = ax.pcolormesh(
        X,
        Y,
        regime,
        cmap=cmap,
        norm=norm,
        shading="auto",
        rasterized=True,
    )

    ax.plot(
        lp_RT,
        lp_m,
        color="black",
        linewidth=2.0,
        label="Saddle-node (LP)",
        zorder=6,
    )

    ax.plot(
        hopf_RT,
        hopf_m,
        color="#1565C0",
        linestyle="--",
        linewidth=1.8,
        label="complex-eigenvalue crossing",
        zorder=7,
    )

    ax.axvline(
        1.0,
        color="gray",
        linestyle=":",
        linewidth=1.3,
    )

    ax.text(
        1.006,
        18.0,
        r"$\mathcal{R}_1=1$",
        fontsize=10,
        color="gray",
    )

    ax.axhline(
        m_c_TB,
        color="#6A1B9A",
        linestyle="--",
        linewidth=1.1,
    )

    ax.text(
        1.36,
        m_c_TB * 1.10,
        rf"$m_c^{{\mathrm{{TB}}}}\approx{m_c_TB:.1f}$",
        fontsize=10,
        color="#6A1B9A",
        ha="right",
    )

    ax.set_xlabel(
        r"TB reproduction number, $\mathcal{R}_1$", fontsize=11
    )
    ax.set_ylabel(r"Healthcare responsiveness, $m$", fontsize=11)
    ax.tick_params(axis="both", labelsize=10)
    ax.set_yscale("log")
    ax.set_xlim(0.4, 1.4)
    ax.set_ylim(0.02, 25.0)
    ax.yaxis.set_major_formatter(
        mticker.FormatStrFormatter("%g")
    )

    # Horizontal colour bar at the bottom gives full width to long labels.
    cbar = fig.colorbar(
        im,
        ax=ax,
        ticks=[0, 1, 2, 3],
        orientation="horizontal",
        pad=0.15,
        fraction=0.13,
    )

    cbar.ax.set_xticklabels([
        "No endemic\nequilibrium",
        "Endemic eq.\nunstable",
        "DFE\u2013endemic\nbistability",
        "DFE unstable;\nendemic stable",
    ], fontsize=9)
    cbar.set_label("Equilibrium configuration", fontsize=10.5)
    cbar.ax.tick_params(labelsize=9, length=3)

    ax.legend(
        frameon=False,
        loc="lower left",
        fontsize=9.5,
    )

    fig.tight_layout()
    save_fig(fig, "fig_05_TB_2d_bifurcation")


# ============================================================
# Main
# ============================================================


def main():
    set_publication_style()
    print("=" * 64)
    print("TB-only 2D bifurcation diagram in (R1, m) space")
    print("=" * 64)

    figure_tb_2d_bifurcation()

    print("\n" + "=" * 64)
    print("Figure saved to figures/")
    print("=" * 64)

    m_c_TB = compute_m_c_TB_analytic(P)
    write_parameter_summary([
        "",
        "TB 2D bifurcation scan summary",
        "================================",
        f"RT grid: [0.4, 1.4] with 300 points",
        f"m grid: [0.02, 25.0] with 220 points",
        f"LP curve: I-continuation (trace_tb_LP_curve_by_I, 5-pt stencil)",
        f"Hopf curve: direct F=0, Re(eig)=0 solver (trace_tb_Hopf_curve)",
        f"Analytic m_c^TB = {m_c_TB:.6f} (= {m_c_TB:.1f})",
        "",
        "Regime classification (analytical, from LP & Hopf interpolants):",
        "  0 = no endemic equilibrium (R1 < LP, or m >= m_c^TB)",
        "  1 = endemic equilibria exist but are unstable (LP < R1 < Hopf)",
        "  2 = DFE-endemic bistability (Hopf < R1 < 1, m < m_meet)",
        "  3 = DFE unstable; endemic equilibrium stable (R1 >= 1)",
        "",
        "LP & Hopf meet near m ≈ 12.75, R1 ≈ 0.91.",
        "Non-degeneracy conditions not verified — not labelled as BT.",
        "",
        "m_c^TB formula:  k Λ N(0) / [2 μ (a_max-a0) (2μ+k+d+2 a0)]",
        f"  with N(0) from Eq.(5.2) evaluated at m=0.",
        "",
        "Preset: illustrative_backward",
        "The healthcare-response parameters are chosen to illustrate the",
        "backward-bifurcation regime predicted by the analysis.",
    ])


if __name__ == "__main__":
    main()
