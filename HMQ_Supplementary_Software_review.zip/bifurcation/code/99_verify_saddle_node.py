"""
Third verification: check stability at R1=0.49 and R1=0.51 at m=0.05.
If 0.482 is saddle-node and 0.508 is Hopf:
  - R1=0.49 (between LP and Hopf): 2 equilibria, both unstable
  - R1=0.51 (above Hopf): 2 equilibria, 1 stable + 1 unstable
"""

import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "common",
    str(Path(__file__).with_name("00_common.py"))
)
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({
    name: getattr(common, name)
    for name in dir(common)
    if not name.startswith("_")
})

import numpy as np


def main():
    m = 0.05
    print("=" * 70)
    print(f"Verification at m={m}")
    print("=" * 70)

    test_points = [0.47, 0.48, 0.482, 0.49, 0.50, 0.507, 0.51, 0.52, 0.55]

    print(f"\n{'R1':>8} {'n_eq':>6} {'n_stable':>10} {'burdens':>30} {'max_real_eigs':>30}")
    print("-" * 90)

    for RT in test_points:
        beta1 = beta1_from_RT(RT, P)
        eqs = find_tb_endemic_equilibria(beta1, m, P, n_grid=1200)
        n_stable = 0
        burdens = []
        max_reals = []
        for eq in eqs:
            stable, max_real, eigs = tb_stability(eq, beta1, m, P)
            if stable:
                n_stable += 1
            burdens.append(eq[2] / np.sum(eq))
            max_reals.append(max_real)

        burden_str = ", ".join(f"{b:.4f}" for b in sorted(burdens))
        eig_str = ", ".join(f"{e:.4f}" for e in sorted(max_reals))
        print(f"{RT:8.3f} {len(eqs):6d} {n_stable:10d} {burden_str:>30} {eig_str:>30}")

    print("\n" + "=" * 70)
    print("INTERPRETATION:")
    print("  - If n_eq changes 0->2: that's the SADDLE-NODE (LP)")
    print("  - If n_stable changes 0->1: that's the HOPF bifurcation")
    print("  - Bistable region = Hopf < R1 < 1 (DFE stable + endemic stable)")
    print("=" * 70)


if __name__ == "__main__":
    main()
