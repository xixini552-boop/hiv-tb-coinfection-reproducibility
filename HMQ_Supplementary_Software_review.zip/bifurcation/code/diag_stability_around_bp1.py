"""Diagnostic v2: complete stability partition around BP1 (reviewer Major Issue 1)."""
import importlib.util
import sys
from pathlib import Path
import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "mod05", str(here / "05_full_backward_bifurcation_v4_verified.py"))
mod = importlib.util.module_from_spec(spec)
sys.modules["mod05"] = mod
spec.loader.exec_module(mod)
P = mod.P
RH, M, BETA2 = mod.RH, mod.M, mod.BETA2


def resident_eig(Q):
    x = mod.tb_only_state(Q)
    if x is None:
        return np.nan
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    J = mod.central_numerical_jacobian(
        lambda y: mod.rhs_full(y, beta1, BETA2, M, P), x, ())
    # TB-only invariant subsystem S,L,I,T = [0,1,2,3] (matches rhs_tb).
    idx = [0, 1, 2, 3]
    return float(np.max(np.real(eigvals(J[np.ix_(idx, idx)]))))


# E2 (TB-free HIV-endemic) is fixed for fixed RH; its TB-invasion eigenvalue
# changes with beta1 (hence Q). full_stability uses the full 8D Jacobian.
def e2_full(Q):
    x = mod.full_tb_free_equilibrium(RH, P)
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    stable, max_real, eigs = mod.full_stability(x, beta1, BETA2, M, P)
    return stable, float(max_real)


bp1 = mod.locate_tb_hiv_branch_point()
# TB-only resident fold (where resident eigenvalue crosses 0), bracket 0.58..0.64
try:
    qfold = brentq(lambda q: resident_eig(q), 0.60, 0.64, xtol=1e-10)
except Exception as e:
    qfold = np.nan
print(f"TB-only resident saddle-node at R_1^2 ~ {qfold:.6f}")
print(f"BP1 (transverse HIV crossing) at R_1^2 = {bp1['Q']:.6f}")
print()
print(f"{'Q':>7} | {'resident':>9} | {'transvers':>9} | {'E1full':>7} | {'E2maxReal':>10} | {'E2stab':>6} | full bistable?")
print("-" * 88)
for Q in [0.58, 0.60, 0.62, 0.64, 0.6643, 0.70, 0.80, 0.90, 0.95, 1.0, 1.055]:
    rec = mod.tb_boundary_record(Q)
    res = resident_eig(Q)
    trans = mod.tb_boundary_transverse_growth(Q)
    e2s, e2mr = e2_full(Q)
    e1 = rec["stable"] if rec else None
    bista = "BISTABLE" if (e1 and e2s) else "-"
    print(f"{Q:7.4f} | {res:9.4f} | {trans:9.4f} | {str(e1):>7} | {e2mr:10.4f} | {str(e2s):>6} | {bista}")
