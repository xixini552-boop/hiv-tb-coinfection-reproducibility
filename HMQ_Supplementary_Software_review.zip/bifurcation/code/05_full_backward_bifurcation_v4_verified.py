"""Audited principal-branch diagram for the full HIV--TB system.

The full-system calculation distinguishes invariant-boundary equilibria from
strictly co-endemic equilibria.  In particular, the point previously called
LP1 is tested as the HIV-invasion branch point on the TB-only boundary; it is
not accepted as a generic saddle-node merely because the Jacobian has a zero
eigenvalue.
"""

import importlib.util
import json
import os
import sys
from pathlib import Path

import numpy as np
from matplotlib.lines import Line2D
from scipy.linalg import eig
from scipy.optimize import least_squares

_spec = importlib.util.spec_from_file_location(
    "common", str(Path(__file__).with_name("00_common.py"))
)
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

# Keep publication figures in the shared bifurcation/figures directory,
# independent of the launch directory.  An environment override is useful
# for temporary local renders without changing the manuscript-facing output.
common.OUTPUT_DIR = os.environ.get(
    "FULL_BIF_OUTPUT_DIR",
    str(Path(__file__).resolve().parent.parent / "figures"),
)
OUTPUT_DIR = common.OUTPUT_DIR


RH, M = 1.8, 0.05
Q_MIN, Q_MAX = 0.55, 1.55
REP_Q = 0.80
ROOT_TOL = 1.0e-7
POSITIVE_BURDEN = 1.0e-7
HIV_INTERIOR_TOL = 1.0e-5
FOLD_ZERO_TOL = 1.0e-7
EPS_FOLD = 5.0e-4
EPS_TC = 1.0e-3
# Defaults preserve the validated publication setting.  Environment overrides
# are provided only for fast local figure regeneration after cosmetic edits.
N_BRANCH = int(os.environ.get("FULL_BIF_N_BRANCH", "360"))
SEED_STEPS = int(os.environ.get("FULL_BIF_SEED_STEPS", "800"))
AUDIT_POINTS = int(os.environ.get("FULL_BIF_AUDIT_POINTS", "80"))

STABLE_COLOR = "#0B3C5D"              # stable TB-only boundary
INTERIOR_STABLE_COLOR = "#238B45"     # stable strict co-endemic branch
UNSTABLE_COLOR = "#B2182B"
TB_FREE_COLOR = "#4D4D4D"
FOLD_COLOR = "#D4A017"

BETA2 = beta2_from_RH(RH, P)
E2 = full_tb_free_equilibrium(RH, P)


def scaled_distance(x, y):
    """Distance used only to continue a known branch in 8-D state space."""
    return float(np.linalg.norm((np.asarray(x) - np.asarray(y)) / P.N0))


def equilibrium_records(Q, previous=()):
    """Return every residual-validated equilibrium found at Q.

    ``eq_class`` is retained in every record so that TB-only boundary roots
    cannot be plotted as co-endemic roots.
    """
    beta1 = beta1_from_RTH(Q, RH, P)
    roots = find_full_equilibria(beta1, BETA2, RH, M, P, previous=list(previous))
    records = []
    for x in roots:
        residual = float(np.linalg.norm(full_residual_scaled(x, beta1, BETA2, M, P)))
        # The generic multistart finder is deliberately permissive.  Refine a
        # borderline root before deciding whether it may enter a plotted branch.
        if residual > ROOT_TOL:
            fit = least_squares(
                lambda y: full_residual_scaled(y, beta1, BETA2, M, P), x,
                bounds=(np.zeros(8), np.full(8, 2.5 * P.N0)),
                x_scale=np.maximum(x, 1.0), xtol=1.0e-13, ftol=1.0e-13,
                gtol=1.0e-13, max_nfev=5000,
            )
            x = np.maximum(fit.x, 0.0)
            residual = float(np.linalg.norm(full_residual_scaled(x, beta1, BETA2, M, P)))
        burden = float(active_tb_burden_full(x))
        if residual > ROOT_TOL or burden <= POSITIVE_BURDEN:
            continue
        eq_class = full_equilibrium_class(x, tb_tol=POSITIVE_BURDEN,
                                          hiv_tol=HIV_INTERIOR_TOL)
        stable, max_real, eigs = full_stability(x, beta1, BETA2, M, P)
        records.append(
            {
                "Q": float(Q), "state": np.asarray(x, dtype=float),
                "burden": burden, "stable": bool(stable),
                "eq_class": eq_class,
                "hiv_fraction": float(hiv_burden_full(x)),
                "max_real": float(max_real), "eigs": np.asarray(eigs),
                "residual": residual,
            }
        )
    return records


def nearest_record(records, reference_state, stable=None, eq_class=None):
    """Select one root by full-state continuity and optional disease support."""
    candidates = [r for r in records
                  if (stable is None or r["stable"] == stable)
                  and (eq_class is None or r.get("eq_class") == eq_class)]
    if not candidates:
        return None
    return min(candidates, key=lambda r: scaled_distance(r["state"], reference_state))


def _rep_scaled_distance(x, y):
    return float(np.linalg.norm((np.asarray(x) - np.asarray(y)) / P.N0))


def _rep_append_seed(seeds, seed, tol=1.0e-8):
    x = np.asarray(seed, dtype=float)
    if x.shape != (8,) or not np.all(np.isfinite(x)):
        return
    x = np.maximum(x, 0.0)
    if any(_rep_scaled_distance(x, old) < tol for old in seeds):
        return
    seeds.append(x)


def _rep_basin_seed(b, h):
    """Deterministic mixed TB/HIV seed; no random generator is involved."""
    x = np.zeros(8, dtype=float)
    x[2] = 0.7 * b * P.N0
    x[6] = 0.3 * b * P.N0
    x[1] = 0.5 * b * P.N0
    x[4] = 0.6 * h * P.N0
    x[5] = 0.3 * h * P.N0
    x[7] = 0.1 * h * P.N0
    x[0] = P.N0 - float(np.sum(x[1:]))
    if x[0] < 10.0:
        positive = float(np.sum(x[1:]))
        if positive > 0.0:
            x[1:] *= (P.N0 - 10.0) / positive
        x[0] = 10.0
    return x


def _rep_seeds(Q, beta1):
    """Fixed multistart family for the representative slice."""
    seeds = []
    _rep_append_seed(seeds, full_tb_free_equilibrium(RH, P))
    for kind in ("low", "moderate", "high"):
        _rep_append_seed(seeds, full_initial_condition(RH, P, kind))
    e2 = full_tb_free_equilibrium(RH, P)
    for tb in find_tb_endemic_equilibria(beta1, M, P, n_grid=max(800, TB_ROOT_GRID)):
        boundary = np.zeros(8, dtype=float)
        boundary[:4] = tb
        _rep_append_seed(seeds, boundary)
        for weight in np.linspace(0.05, 0.95, 19):
            _rep_append_seed(seeds, (1.0 - weight) * e2 + weight * boundary)
    for b in (0.001, 0.01, 0.03, 0.10, 0.25):
        for h in (0.001, 0.03, 0.10, 0.25):
            _rep_append_seed(seeds, _rep_basin_seed(b, h))
    return seeds


def _rep_tight_root(seed, beta1):
    """Refine one seed at the tightest solver setting used in this script."""
    lower = np.zeros(8, dtype=float)
    upper = np.full(8, 2.5 * P.N0, dtype=float)
    start = np.clip(np.asarray(seed, dtype=float), lower + 1.0e-10, upper)
    best_x, best_residual = None, np.inf
    for x_scale in ("jac", 1.0):
        try:
            fit = least_squares(
                lambda y: full_residual_scaled(y, beta1, BETA2, M, P),
                start, bounds=(lower, upper), xtol=1.0e-13, ftol=1.0e-13,
                gtol=1.0e-13, max_nfev=6000, x_scale=x_scale,
            )
        except Exception:  # pragma: no cover - diagnostic path
            continue
        x = np.maximum(fit.x, 0.0)
        residual = float(np.linalg.norm(
            full_residual_scaled(x, beta1, BETA2, M, P)
        ))
        if residual < best_residual:
            best_x, best_residual = x, residual
    return best_x, best_residual


def representative_diagnostics(Q=REP_Q, bp1=None, lp2=None):
    """Archive the equilibrium diagnostics quoted at Q = 0.80 in the supplement.

    The two interior points come from the solvers used for the audited
    principal branches and are accepted under the same strict rules: scaled
    residual below ``ROOT_TOL``, and a root counts as strictly co-endemic only
    when both the active-TB and the non-AIDS HIV fractions clear their
    tolerances.
    """
    beta1 = beta1_from_RTH(Q, RH, P)
    roots = []
    for seed in _rep_seeds(Q, beta1):
        x, residual = _rep_tight_root(seed, beta1)
        if x is None or residual > ROOT_TOL:
            continue
        if any(_rep_scaled_distance(x, old["state"]) < 2.0e-4 for old in roots):
            continue
        stable, max_real, eigs = full_stability(x, beta1, BETA2, M, P)
        eigs = np.asarray(eigs, dtype=complex)
        roots.append({
            "state": [float(v) for v in x],
            "eq_class": full_equilibrium_class(
                x, tb_tol=POSITIVE_BURDEN, hiv_tol=HIV_INTERIOR_TOL
            ),
            "burden": float(active_tb_burden_full(x)),
            "hiv_fraction": float(hiv_burden_full(x)),
            "residual": float(residual),
            "stable": bool(stable),
            "max_real": float(max_real),
            "unstable_eigenvalue_count": int(np.sum(np.real(eigs) > 1.0e-6)),
            "eigenvalues": [[float(z.real), float(z.imag)] for z in eigs],
        })

    # TB-only row: the upper branch returned by the scalar boundary solver,
    # embedded in the full state space (J1 = J2 = J3 = A = 0).
    tb_record = tb_boundary_record(Q)
    tb_point = None
    if tb_record is not None:
        tb_point = {
            "state": [float(v) for v in tb_record["state"]],
            "eq_class": tb_record["eq_class"],
            "burden": float(tb_record["burden"]),
            "hiv_fraction": float(tb_record["hiv_fraction"]),
            "residual": float(tb_record["residual"]),
            "stable": bool(tb_record["stable"]),
            "max_real": float(tb_record["max_real"]),
            "unstable_eigenvalue_count": int(
                np.sum(np.real(np.asarray(tb_record["eigs"], dtype=complex)) > 1.0e-6)
            ),
            "eigenvalues": [
                [float(z.real), float(z.imag)]
                for z in np.asarray(tb_record["eigs"], dtype=complex)
            ],
        }

    co_candidates = [r for r in roots
                     if r["eq_class"] == "co_endemic"
                     and r["unstable_eigenvalue_count"] == 1]
    co_point = min(co_candidates, key=lambda r: r["residual"]) if co_candidates else None

    bp1_entry = None
    if bp1 is not None:
        bp1_beta1 = beta1_from_RTH(float(bp1["Q"]), RH, P)
        bp1_entry = {
            "Q": float(bp1["Q"]),
            "burden": float(bp1["burden"]),
            "eq_class": bp1.get("eq_class"),
            "transverse_growth": float(bp1["transverse_growth"]),
            "residual": float(np.linalg.norm(
                full_residual_scaled(bp1["state"], bp1_beta1, BETA2, M, P)
            )),
            "state": [float(v) for v in np.asarray(bp1["state"], dtype=float)],
        }

    lp2_entry = None
    if lp2 is not None:
        lp2_entry = {
            "Q": float(lp2["Q"]),
            "burden": float(lp2["burden"]),
            "eq_class": lp2.get("eq_class"),
            "F_norm": float(lp2["F_norm"]),
            "lambda0": float(lp2["lambda0"]),
            "max_other_real": float(lp2["max_other_real"]),
            "wTfQ": float(lp2["wTfQ"]),
            "wTD2vv": float(lp2["wTD2vv"]),
            "state": [float(v) for v in np.asarray(lp2["state"], dtype=float)],
        }

    payload = {
        "description": (
            "Representative equilibrium diagnostics at Q = R1^2 = 0.80 for the "
            "supplementary window-diagnostics table; produced by "
            "05_full_backward_bifurcation_v4_verified.py."
        ),
        "Q": float(Q),
        "beta1": float(beta1),
        "beta2": float(BETA2),
        "RH": float(RH),
        "m": float(M),
        "residual_convention": (
            "||F|| is the scaled residual ||f(x*)|| / Lambda used throughout "
            "the branch audit."
        ),
        "root_tolerance": float(ROOT_TOL),
        "tb_only_tolerance": float(POSITIVE_BURDEN),
        "hiv_interior_tolerance": float(HIV_INTERIOR_TOL),
        "solver": {
            "method": "scipy.optimize.least_squares",
            "xtol": 1.0e-13, "ftol": 1.0e-13, "gtol": 1.0e-13,
            "max_nfev": 6000, "x_scale": ["jac", 1.0],
        },
        "seed_family": (
            "TB-free equilibrium, the three standard full-system initial "
            "conditions, the TB-only boundary roots embedded in the full "
            "state space, their convex combinations with the TB-free "
            "equilibrium, and a fixed mixed TB/HIV grid; no random generator "
            "is used."
        ),
        "table_points": {
            "tb_only_high_burden": tb_point,
            "strict_co_endemic": co_point,
            "bp1": bp1_entry,
            "lp2": lp2_entry,
        },
        "all_roots": roots,
    }
    outdir = Path(__file__).resolve().parent.parent / "output"
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "representative_diagnostics.json"
    path.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    print(f"representative diagnostics written to {path}")
    if tb_point is not None:
        print(f"  Q={Q:.2f} TB-only: B={tb_point['burden']:.8f}, "
              f"||F||={tb_point['residual']:.3e}, maxRe={tb_point['max_real']:.6e}")
    if co_point is not None:
        print(f"  Q={Q:.2f} co-endemic: B={co_point['burden']:.8f}, "
              f"||F||={co_point['residual']:.3e}, maxRe={co_point['max_real']:.6e}")
    if bp1_entry is not None:
        print(f"  BP1: Q={bp1_entry['Q']:.10f}, B={bp1_entry['burden']:.8f}, "
              f"transverse={bp1_entry['transverse_growth']:.3e}, "
              f"||F||={bp1_entry['residual']:.3e}")
    if lp2_entry is not None:
        print(f"  LP2: Q={lp2_entry['Q']:.10f}, B={lp2_entry['burden']:.8f}, "
              f"||F||={lp2_entry['F_norm']:.3e}, lambda0={lp2_entry['lambda0']:.3e}")
    return payload


def nearest_real_eigenvalue(J):
    values = eig(J, left=False, right=False)
    real_values = [z.real for z in values if abs(z.imag) < 1.0e-7]
    if not real_values:
        raise RuntimeError("No real Jacobian eigenvalue available for fold solve")
    return float(min(real_values, key=abs))


def fold_residual(z):
    """Nine equations: eight equilibrium equations plus lambda_0(J)=0."""
    x = P.N0 * z[:8]
    Q = float(z[8])
    beta1 = beta1_from_RTH(Q, RH, P)
    F = full_residual_scaled(x, beta1, BETA2, M, P)
    J = central_numerical_jacobian(lambda y: rhs_full(y, beta1, BETA2, M, P), x, ())
    return np.r_[F, nearest_real_eigenvalue(J) / 0.1]


def tb_only_state(Q):
    """Return the upper TB-only equilibrium embedded in the full state."""
    beta1 = beta1_from_RTH(float(Q), RH, P)
    roots = find_tb_endemic_equilibria(
        beta1, M, P, n_grid=max(800, TB_ROOT_GRID)
    )
    if not roots:
        return None
    tb = max(roots, key=lambda y: y[2] / np.sum(y))
    x = np.zeros(8, dtype=float)
    x[:4] = tb
    return x


def tb_boundary_record(Q):
    """Return a validated record for the HIV-free TB-only boundary."""
    x = tb_only_state(Q)
    if x is None:
        return None
    beta1 = beta1_from_RTH(float(Q), RH, P)
    stable, max_real, eigs = full_stability(x, beta1, BETA2, M, P)
    return {
        "Q": float(Q), "state": x, "burden": float(active_tb_burden_full(x)),
        "stable": bool(stable), "eq_class": "tb_only", "hiv_fraction": 0.0,
        "max_real": float(max_real), "eigs": np.asarray(eigs),
        "residual": float(np.linalg.norm(
            full_residual_scaled(x, beta1, BETA2, M, P)
        )),
    }


def tb_boundary_transverse_growth(Q):
    """Largest HIV invasion eigenvalue along the TB-only boundary."""
    rec = tb_boundary_record(Q)
    if rec is None:
        return np.nan
    beta1 = beta1_from_RTH(float(Q), RH, P)
    J = central_numerical_jacobian(
        lambda y: rhs_full(y, beta1, BETA2, M, P), rec["state"], ()
    )
    # The invariant HIV-free boundary makes the J1,J2,J3 block the transverse
    # linearisation.  A zero crossing here is a branch point, not a fold.
    return float(np.max(np.real(eigvals(J[4:7, 4:7]))))


def locate_tb_hiv_branch_point(q_lower=0.62, q_upper=0.72):
    """Locate the TB-only/HIV branch point by transverse eigenvalue crossing."""
    from scipy.optimize import brentq

    grid = np.linspace(q_lower, q_upper, 41)
    growth = [tb_boundary_transverse_growth(q) for q in grid]
    bracket = None
    for q0, q1, g0, g1 in zip(grid[:-1], grid[1:], growth[:-1], growth[1:]):
        if np.isfinite(g0) and np.isfinite(g1) and (g0 == 0 or g0 * g1 < 0):
            bracket = (q0, q1)
            break
    if bracket is None:
        raise RuntimeError("Could not bracket the TB-only/HIV branch point")
    Q = float(brentq(tb_boundary_transverse_growth, *bracket,
                     xtol=1e-12, rtol=1e-12))
    rec = tb_boundary_record(Q)
    rec["kind"] = "boundary_branch_point"
    rec["transverse_growth"] = tb_boundary_transverse_growth(Q)
    return rec


def solve_fold(seed_state, seed_Q, lower_Q, upper_Q, name):
    """Solve and validate one simple, non-degenerate saddle-node."""
    lower = np.r_[np.zeros(8), lower_Q]
    upper = np.r_[np.full(8, 2.5), upper_Q]
    z0 = np.r_[np.asarray(seed_state) / P.N0, seed_Q]
    fit = least_squares(
        fold_residual, z0, bounds=(lower, upper), x_scale="jac",
        xtol=1.0e-13, ftol=1.0e-13, gtol=1.0e-13, max_nfev=6000,
    )
    x = P.N0 * fit.x[:8]
    Q = float(fit.x[8])
    beta1 = beta1_from_RTH(Q, RH, P)
    F = full_residual_scaled(x, beta1, BETA2, M, P)
    J = central_numerical_jacobian(lambda y: rhs_full(y, beta1, BETA2, M, P), x, ())
    values, right = eig(J)
    values_left, left = eig(J.T)
    i_right = int(np.argmin(np.abs(values)))
    i_left = int(np.argmin(np.abs(values_left)))
    v = right[:, i_right].real
    w = left[:, i_left].real
    v /= np.linalg.norm(v)
    w /= float(np.dot(w, v))

    # Non-degeneracy diagnostics: w^T f_Q and w^T D_x^2 f[v,v].
    dQ, h = 1.0e-5, 0.2
    bp = beta1_from_RTH(Q + dQ, RH, P)
    bm = beta1_from_RTH(Q - dQ, RH, P)
    fQ = (rhs_full(x, bp, BETA2, M, P) - rhs_full(x, bm, BETA2, M, P)) / (2.0 * dQ)
    d2 = (
        rhs_full(x + h * v, beta1, BETA2, M, P)
        - 2.0 * rhs_full(x, beta1, BETA2, M, P)
        + rhs_full(x - h * v, beta1, BETA2, M, P)
    ) / h**2

    eq_class = full_equilibrium_class(
        x, tb_tol=POSITIVE_BURDEN, hiv_tol=HIV_INTERIOR_TOL
    )
    diag = {
        "name": name, "Q": Q, "state": x, "burden": active_tb_burden_full(x),
        "eq_class": eq_class, "hiv_fraction": hiv_burden_full(x),
        "F_norm": float(np.linalg.norm(F)), "lambda0": float(values[i_right].real),
        "max_other_real": float(max(np.real(np.delete(values, i_right)))),
        "wTfQ": float(np.dot(w, fQ)), "wTD2vv": float(np.dot(w, d2)),
        "fit_norm": float(np.linalg.norm(fold_residual(fit.x))), "success": bool(fit.success),
    }
    if eq_class != "co_endemic":
        raise RuntimeError(
            f"{name} is a {eq_class} boundary root, not an interior fold: "
            f"Q={Q:.10f}, HIV fraction={hiv_burden_full(x):.3e}"
        )
    if (
        not fit.success or diag["F_norm"] > ROOT_TOL
        or abs(diag["lambda0"]) > FOLD_ZERO_TOL
        or abs(diag["wTfQ"]) < 1.0e-8 or abs(diag["wTD2vv"]) < 1.0e-8
    ):
        raise RuntimeError(f"{name} did not pass fold validation: {diag}")
    return diag


def follow_branch(Q_values, initial_record, stable, eq_class=None):
    """Natural continuation away from folds; one known branch at a time."""
    branch = [initial_record]
    previous = initial_record["state"]
    for Q in Q_values[1:]:
        records = equilibrium_records(Q, previous=[previous])
        candidate = nearest_record(
            records, previous, stable=stable, eq_class=eq_class
        )
        if candidate is None:
            raise RuntimeError(f"Lost {'stable' if stable else 'unstable'} branch at Q={Q:.8f}")
        branch.append(candidate)
        previous = candidate["state"]
    return branch


def continue_high_stable_to(Q_target):
    """Obtain the upper stable branch at Q_target from a reliable high-Q seed."""
    previous = []
    record = None
    for Q in np.linspace(Q_MAX, Q_target, SEED_STEPS):
        records = equilibrium_records(Q, previous=previous)
        stable_records = [r for r in records if r["stable"]]
        if not stable_records:
            raise RuntimeError(f"Upper stable branch was lost before Q={Q:.8f}")
        record = max(stable_records, key=lambda r: r["burden"])
        previous = [record["state"]]
    return record


def audit_extra_unstable(Q_values, principal_states):
    """Keep unassigned unstable roots for a supplementary diagnostic scatter."""
    extras = []
    previous = []
    for Q in Q_values:
        records = equilibrium_records(Q, previous=previous)
        previous = [r["state"] for r in records]
        for r in records:
            if r["stable"]:
                continue
            closest = min((scaled_distance(r["state"], x) for x in principal_states), default=np.inf)
            if closest > 1.0e-3:
                extras.append(r)
    return extras


def _root_census_key(record):
    """Stable key for de-duplicating the same root found at nearby audit points."""
    state = np.asarray(record["state"], dtype=float)
    return tuple(np.round(state / P.N0, 7).tolist())


def serialize_extra_unstable_census(extras, q_values):
    """Write a structured census of the non-principal unstable audit roots.

    The plotting diagnostic intentionally keeps every grid detection.  The
    census additionally reports a state-deduplicated view, so the manuscript
    can distinguish the 88 archived detections from repeated hits of the same
    equilibrium on neighbouring Q slices.
    """
    records = []
    seen = set()
    for idx, r in enumerate(extras):
        eigs = np.asarray(r.get("eigs", []), dtype=complex)
        unstable_count = int(np.sum(np.real(eigs) > 1.0e-6))
        rec = {
            "detection_id": int(idx),
            "Q": float(r["Q"]),
            "eq_class": str(r.get("eq_class", "unknown")),
            "burden": float(r["burden"]),
            "hiv_fraction": float(r.get("hiv_fraction", np.nan)),
            "max_real": float(r.get("max_real", np.nan)),
            "unstable_eigenvalue_count": unstable_count,
            "residual": float(r.get("residual", np.nan)),
            "state": [float(v) for v in np.asarray(r["state"], dtype=float)],
        }
        rec["dedup_key"] = list(_root_census_key(r))
        if tuple(rec["dedup_key"]) not in seen:
            seen.add(tuple(rec["dedup_key"]))
            rec["unique_root_id"] = len(seen) - 1
        else:
            rec["unique_root_id"] = None
        records.append(rec)
    unique = [r for r in records if r["unique_root_id"] is not None]
    by_class = {}
    for r in records:
        by_class[r["eq_class"]] = by_class.get(r["eq_class"], 0) + 1
    by_unique_class = {}
    for r in unique:
        by_unique_class[r["eq_class"]] = by_unique_class.get(r["eq_class"], 0) + 1
    payload = {
        "description": "Structured census of additional non-principal unstable full-system equilibria",
        "RH": float(RH), "m": float(M),
        "Q_interval": [float(np.min(q_values)), float(np.max(q_values))],
        "audit_points": int(len(q_values)),
        "principal_distance_cutoff": 1.0e-3,
        "residual_cutoff": ROOT_TOL,
        "positive_tb_burden_cutoff": POSITIVE_BURDEN,
        "strict_hiv_fraction_cutoff": HIV_INTERIOR_TOL,
        "definition": "unstable record (max_real >= -1e-6) with scaled distance > 1e-3 from all principal states",
        "detection_count": int(len(records)),
        "unique_state_count": int(len(unique)),
        "detection_count_by_class": by_class,
        "unique_state_count_by_class": by_unique_class,
        "Q_range_detected": ([float(min(r["Q"] for r in records)), float(max(r["Q"] for r in records))]
                              if records else None),
        "burden_range_detected": ([float(min(r["burden"] for r in records)), float(max(r["burden"] for r in records))]
                                  if records else None),
        "max_real_range": ([float(min(r["max_real"] for r in records)), float(max(r["max_real"] for r in records))]
                            if records else None),
        "unstable_eigenvalue_count_range": ([int(min(r["unstable_eigenvalue_count"] for r in records)),
                                              int(max(r["unstable_eigenvalue_count"] for r in records))]
                                             if records else None),
        "detections": records,
    }
    outdir = Path(__file__).resolve().parent.parent / "output"
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "full_backward_nonprincipal_unstable_census.json"
    path.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    csv_path = outdir / "full_backward_nonprincipal_unstable_census.csv"
    import csv
    fields = ["detection_id", "unique_root_id", "Q", "eq_class", "burden",
              "hiv_fraction", "max_real", "unstable_eigenvalue_count", "residual"]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in records:
            writer.writerow({k: r[k] for k in fields})
    return payload


def print_fold(fold):
    print(
        f"{fold['name']}: Q={fold['Q']:.8f}, B={fold['burden']:.8f}, "
        f"||F||={fold['F_norm']:.2e}, lambda0={fold['lambda0']:.2e}, "
        f"wTfQ={fold['wTfQ']:.2e}, wTD2={fold['wTD2vv']:.2e}"
    )


def main():
    set_publication_style()

    # The former LP1 is reclassified from a putative fold to the branch point at which
    # HIV invades the TB-only boundary.  It is deliberately not passed to the
    # generic fold solver.
    bp1 = locate_tb_hiv_branch_point()
    print(
        f"BP1 (TB-only/HIV branch point): Q={bp1['Q']:.10f}, "
        f"B={bp1['burden']:.8f}, max transverse growth="
        f"{bp1['transverse_growth']:.2e}"
    )

    # LP2 is retained only after the strict interior-support check.
    roots_2 = equilibrium_records(1.0525)
    low_candidates = [
        r for r in roots_2
        if r["stable"] and r.get("eq_class") == "co_endemic"
    ]
    if not low_candidates:
        raise RuntimeError("Could not obtain a strict interior seed near LP2")
    low_seed = min(low_candidates, key=lambda r: r["burden"])

    lp2 = solve_fold(low_seed["state"], 1.0525, 1.00, 1.12, "LP2")
    print_fold(lp2)

    # Continue the stable interior branch from LP2 toward the TB-free branch.
    q2_in = lp2["Q"] - EPS_FOLD
    roots_q2 = equilibrium_records(q2_in, previous=[low_seed["state"]])
    low0 = nearest_record(
        roots_q2, lp2["state"], stable=True, eq_class="co_endemic"
    )
    if low0 is None:
        raise RuntimeError("Unable to initialise the strict interior branch near LP2")
    low = follow_branch(
        np.linspace(q2_in, 1.0 + EPS_TC, N_BRANCH), low0,
        stable=True, eq_class="co_endemic"
    )

    # Locate the part of the unstable interior branch that is numerically
    # separated from the HIV-free boundary by the strict support tolerance.
    middle0 = None
    q_middle_start = None
    for q in np.linspace(bp1["Q"] + 2.0e-3, 0.80, 32):
        roots = equilibrium_records(float(q), previous=[bp1["state"]])
        candidate = nearest_record(
            roots, bp1["state"], stable=False, eq_class="co_endemic"
        )
        if candidate is not None:
            middle0 = candidate
            q_middle_start = float(q)
            break
    middle = []
    if middle0 is not None:
        middle = follow_branch(
            np.linspace(q_middle_start, q2_in, N_BRANCH), middle0,
            stable=False, eq_class="co_endemic"
        )

    # Trace the neighbouring TB-only boundary explicitly.  This is the branch
    # that was previously plotted as the high-burden branch.
    tb_boundary = [
        rec for rec in (
            tb_boundary_record(q)
            for q in np.linspace(bp1["Q"], Q_MAX, N_BRANCH)
        ) if rec is not None
    ]

    # Add exact special points and the known E2 transcritical endpoint for plotting.
    bp1_record = {"Q": bp1["Q"], "state": bp1["state"],
                  "burden": bp1["burden"], "stable": None}
    lp2_record = {"Q": lp2["Q"], "state": lp2["state"], "burden": lp2["burden"], "stable": None}
    middle_plot = ([bp1_record] if not middle or middle[0]["Q"] > bp1["Q"] else []) + middle + [lp2_record]
    low_plot = [{"Q": 1.0, "state": E2, "burden": 0.0, "stable": None}] + list(reversed(low)) + [lp2_record]

    # Audit additional unstable roots without pretending they belong to the principal S-branch.
    principal_states = [r["state"] for r in tb_boundary + middle + low] + [bp1["state"], lp2["state"]]
    extras = audit_extra_unstable(
        np.linspace(Q_MIN, bp1["Q"] - 1.0e-3, AUDIT_POINTS), principal_states
    )
    print(f"Additional non-principal unstable roots below BP1: {len(extras)}")
    extra_census = serialize_extra_unstable_census(
        extras, np.linspace(Q_MIN, bp1["Q"] - 1.0e-3, AUDIT_POINTS)
    )
    print(
        f"  census unique states={extra_census['unique_state_count']}; "
        f"classes={extra_census['detection_count_by_class']}", flush=True
    )

    # Main figure: bistability window first; every other element is downgraded.
    fig, ax = plt.subplots(figsize=(6.5, 4.3))

    # Colour family: only three families -- TB boundary, HIV boundary, interior.
    C_TB = "#0B3C5D"        # HIV-free TB boundary
    C_HIV = "#4D4D4D"       # TB-free HIV boundary (original grey)
    C_INT_U = "#B2182B"     # unstable interior (original red)
    C_INT_S = "#238B45"     # stable interior (original green)
    C_TB_U = "#7B5EA7"      # TB boundary, resident-stable only (original purple)
    C_LP2 = "#D4A017"       # interior-fold marker (original gold)
    C_WIN = "#F2EFB3"       # bistability-window tint (original pale yellow)

    # Extend the TB boundary to the left of BP1 (resident-stable, transversely
    # unstable).  Points below the resident fold return None and are dropped.
    tb_left_raw = [
        rec for rec in (
            tb_boundary_record(q)
            for q in np.linspace(0.58, bp1["Q"], max(80, N_BRANCH // 3))
        ) if rec is not None
    ]
    tb_left = [r for r in tb_left_raw if r["Q"] < bp1["Q"] - 1e-9]
    tb_right = tb_boundary  # BP1 .. Q_MAX, stable in the full system

    # P0 -- bistability window [BP1, 1).
    ax.axvspan(bp1["Q"], 1.0, color=C_WIN, alpha=0.55, zorder=0)

    # P0 -- TB-free HIV boundary on y=0 (solid below 1, dashed above 1).
    ax.plot(np.linspace(0.55, 1.0, 200), np.zeros(200),
            color=C_HIV, linewidth=2.2, zorder=3)
    ax.plot(np.linspace(1.0, 1.25, 100), np.zeros(100),
            color=C_HIV, linestyle="--", linewidth=1.4, zorder=3)
    ax.text(0.555, 0.009, "TB-free HIV endemic", fontsize=8,
            color=C_HIV, va="bottom", zorder=4)

    # P2 (left, thin dashed): TB boundary, resident-stable / transversely unstable.
    if tb_left:
        ax.plot([r["Q"] for r in tb_left], [r["burden"] for r in tb_left],
                color=C_TB_U, linestyle=(0, (6, 2, 1.5, 2)), linewidth=2.0, zorder=3)
    # P0 (right, thick solid): TB boundary, stable in full system.
    ax.plot([r["Q"] for r in tb_right], [r["burden"] for r in tb_right],
            color=C_TB, linewidth=2.2, zorder=4)
    # Label the stable TB segment inside the window.
    _tb_q = np.array([r["Q"] for r in tb_right])
    _tb_b = np.array([r["burden"] for r in tb_right])
    _idx = int(np.argmin(np.abs(_tb_q - 0.80)))
    ax.text(0.80, _tb_b[_idx] + 0.008, "HIV-free TB endemic", fontsize=8,
            color=C_TB, ha="center", va="bottom", zorder=5)

    # P2 -- interior branches, light grey (never the focal information).
    ax.plot([r["Q"] for r in middle_plot], [r["burden"] for r in middle_plot],
            color=C_INT_U, linestyle="--", linewidth=1.4, zorder=2)
    # Stable interior branch kept only for geometric continuity of LP2.
    ax.plot([r["Q"] for r in low_plot], [r["burden"] for r in low_plot],
            color=C_INT_S, linewidth=1.2, zorder=2)

    # P1 -- vertical edges of the window, with plain-language labels.
    ax.axvline(bp1["Q"], color="#555555", linestyle="--", linewidth=1.0, zorder=1)
    ax.axvline(1.0, color="#555555", linestyle="-", linewidth=1.0, zorder=1)
    ax.text(bp1["Q"] - 0.012, 0.305, "branch point",
            fontsize=7.5, color="#444444", ha="right", va="top", zorder=5)

    # P2 -- LP2 as a small hollow triangle, not a second focal marker.
    ax.plot(lp2["Q"], lp2["burden"], marker="^", markersize=7,
            markerfacecolor="none", markeredgecolor=C_LP2,
            markeredgewidth=1.2, zorder=6)

    # Axes.
    ax.set_xlim(0.55, 1.25)
    ax.set_ylim(0, 0.35)
    ax.set_xlabel("TB invasion number of the HIV-endemic state", fontsize=9)
    ax.set_ylabel(r"Active-TB burden  $(I^*+J_3^*)/N^*$", fontsize=9)
    ax.grid(True, color="#E8E8E8", linewidth=0.45, alpha=0.7)

    # Legend: boundary and strict co-endemic branch meanings are explicit;
    # BP1 / LP2 / resident fold markers stay out.
    ax.legend(handles=[
        Line2D([0], [0], color=C_TB, linewidth=2.2,
               label="HIV-free TB (stable in full system)"),
        Line2D([0], [0], color=C_TB_U, linestyle=(0, (6, 2, 1.5, 2)), linewidth=2.0,
               label="HIV-free TB (unstable to HIV)"),
        Line2D([0], [0], color=C_HIV, linewidth=2.2,
               label="TB-free HIV endemic"),
        Line2D([0], [0], color=C_INT_U, linestyle="--", linewidth=1.4,
               label="strict co-endemic (unstable)"),
        Line2D([0], [0], color=C_INT_S, linewidth=1.2,
               label="strict co-endemic (stable)"),
    ], frameon=False, loc="upper right", fontsize=8, handlelength=2.5)

    fig.tight_layout()
    save_fig(fig, "fig_05_full_backward_bifurcation_verified")
    plt.close(fig)

    # Supplementary diagnostic: never join these points into a branch without another continuation check.
    if extras:
        fig, ax = plt.subplots(figsize=(5.9, 3.8))
        ax.scatter([r["Q"] for r in extras], [r["burden"] for r in extras],
                   s=14, color=UNSTABLE_COLOR, alpha=0.75)
        ax.axvline(bp1["Q"], color="#6A3D9A", linestyle="--", linewidth=1.0)
        ax.set_xlabel(r"$\mathcal{R}_1^2$")
        ax.set_ylabel(r"$(I^*+J_3^*)/N^*$")
        ax.grid(True, color="#E8E8E8", linewidth=0.45)
        fig.tight_layout()
        save_fig(fig, "fig_S_full_additional_unstable_diagnostic")
        plt.close(fig)

    # Representative diagnostics for the supplementary window table (Q = 0.80).
    rep = representative_diagnostics(bp1=bp1, lp2=lp2)

    write_parameter_summary([
        "Audited full-system principal branches",
        f"BP1: Q={bp1['Q']:.8f}, burden={bp1['burden']:.8f}, "
        f"max_transverse_growth={bp1['transverse_growth']:.2e}",
        f"LP2: Q={lp2['Q']:.8f}, burden={lp2['burden']:.8f}, F={lp2['F_norm']:.2e}",
        f"Q=0.80 representative diagnostics: archived as output/representative_diagnostics.json",
        f"Q=0.80 TB-only: burden={rep['table_points']['tb_only_high_burden']['burden']:.8f}, "
        f"||F||={rep['table_points']['tb_only_high_burden']['residual']:.2e}, "
        f"maxRe={rep['table_points']['tb_only_high_burden']['max_real']:.6e}",
        f"Q=0.80 strict co-endemic: burden="
        f"{rep['table_points']['strict_co_endemic']['burden']:.8f}, "
        f"||F||={rep['table_points']['strict_co_endemic']['residual']:.2e}, "
        f"maxRe={rep['table_points']['strict_co_endemic']['max_real']:.6e}",
        f"TB-only / middle / low points: {len(tb_boundary)} / {len(middle)} / {len(low)}",
        f"strict interior HIV prevalence threshold={HIV_INTERIOR_TOL:.1e}",
        f"additional unstable diagnostic points below BP1: {len(extras)}",
        f"non-principal census unique states: {extra_census['unique_state_count']}",
        f"non-principal census classes: {extra_census['detection_count_by_class']}",
    ])


if __name__ == "__main__":
    main()
