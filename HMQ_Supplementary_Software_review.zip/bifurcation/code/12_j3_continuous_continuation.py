"""Continuous two-parameter continuation in the J3-treatment rate.

Reviewer concern (Major 2): the baseline model gives no direct TB treatment to
the HIV-active-TB compartment J3, and the existing ESM control compares only
rho = 0 (no treatment) with rho = 1 (full saturated treatment). A reviewer
asked to VARY THE J3 TREATMENT RATE CONTINUOUSLY and show how the boundary
branch point BP1 and the strict-interior saddle-node LP2 move, and where (if
anywhere) the interior fold disappears.

Here rho in [0, 1] scales the saturated J3 -> J1 treatment flow,

    treat_J3 = rho * a(B) J3 / (1 + omega(B) J3),

and, at the TB-free state B = 0 where this flow linearises, adds rho*a0 to the
J3 diagonal of the invasion removal matrix. For each rho we locate

  * BP1 : the TB-only/HIV boundary branch point (HIV-invasion transcritical),
  * LP2 : the strict-interior saddle-node, retained only when solve_fold
          converges to a co_endemic root that passes all fold checks;
          recorded as absent otherwise.

Outputs: j3_continuous_continuation.json and a two-parameter figure
fig_j3_continuous_continuation, plus a text summary.
"""

import importlib.util
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent

os.environ.setdefault("FULL_BIF_N_BRANCH", "240")
os.environ.setdefault("FULL_BIF_SEED_STEPS", "400")

# --- shared model -----------------------------------------------------------
_spec_c = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(_spec_c)
sys.modules["common"] = common
_spec_c.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

# --- verified full-system solver --------------------------------------------
_spec_v = importlib.util.spec_from_file_location(
    "verifier", str(HERE / "05_full_backward_bifurcation_v4_verified.py")
)
verifier = importlib.util.module_from_spec(_spec_v)
sys.modules["verifier"] = verifier
_spec_v.loader.exec_module(verifier)

common.OUTPUT_DIR = os.environ.get("ESM_OUTPUT_DIR", str(HERE / ".." / "figures"))
OUTPUT_DIR = common.OUTPUT_DIR
RESULT_DIR = HERE / ".." / "output"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

# ===========================================================================
# Continuous J3-treatment coefficient
# ===========================================================================

J3_RHO = 0.0  # module-level continuous coefficient in [0, 1]


def rhs_full(x, beta1, beta2, m, p=P):
    """Full RHS with a J3->J1 saturated treatment flow scaled by J3_RHO."""
    S, L, I, T, J1, J2, J3, A = x
    N = S + L + I + T + J1 + J2 + J3 + A
    R = N - I - J3 - A
    Jstar = J1 + J2 + J3

    if N <= 1e-12 or R <= 1e-12:
        return np.ones(8) * 1e12

    B = (I + J3) / N
    a, omega = response_from_burden(B, m, p)

    denom_L = 1.0 + omega * L
    denom_I = 1.0 + omega * I
    denom_J2 = 1.0 + omega * J2
    denom_J3 = 1.0 + omega * J3
    if min(denom_L, denom_I, denom_J2, denom_J3) <= 0:
        return np.ones(8) * 1e12

    treat_L = a * L / denom_L
    treat_I = a * I / denom_I
    treat_J2 = a * J2 / denom_J2
    treat_J3 = J3_RHO * a * J3 / denom_J3   # continuous, 0 at rho=0

    tb_force = beta1 * (I + J3) / N
    hiv_force = beta2 * Jstar / R

    dS = p.Lambda - tb_force * S - hiv_force * S - p.mu * S
    dL = (
        beta1 * (S + T) * (I + J3) / N
        - p.sigma_rel * beta2 * L * Jstar / R
        - (p.mu + p.k) * L
        - treat_L
    )
    dI = p.k * L - (p.mu + p.d) * I - treat_I
    dT = (
        treat_L + treat_I
        - beta1 * T * (I + J3) / N
        - beta2 * T * Jstar / R
        - p.mu * T
    )
    dJ1 = (
        beta2 * (S + T) * Jstar / R
        - p.theta * beta1 * J1 * (I + J3) / N
        - (p.alpha1 + p.mu) * J1
        + treat_J2 + treat_J3
    )
    dJ2 = (
        p.sigma_rel * beta2 * L * Jstar / R
        + p.theta * beta1 * J1 * (I + J3) / N
        - (p.alpha2 + p.mu + p.k_star) * J2
        - treat_J2
    )
    dJ3 = p.k_star * J2 - (p.alpha3 + p.mu + p.d_star) * J3 - treat_J3
    dA = p.alpha1 * J1 + p.alpha2 * J2 + p.alpha3 * J3 - (p.mu + p.f) * A
    return np.array([dS, dL, dI, dT, dJ1, dJ2, dJ3, dA], dtype=float)


def RTH_for_beta1(beta1, RH, p=P):
    """TB-invasion number with rho*a0 added to the J3 removal diagonal."""
    beta2 = beta2_from_RH(RH, p)
    EH = full_tb_free_equilibrium(RH, p)
    S, J1 = EH[0], EH[4]
    N = np.sum(EH)
    R = S + J1
    if N <= 0 or R <= 0:
        return np.nan

    h = p.sigma_rel * beta2 * J1 / R
    F = np.zeros((4, 4))
    F[0, 1] = beta1 * S / N
    F[0, 3] = beta1 * S / N
    F[2, 1] = p.theta * beta1 * J1 / N
    F[2, 3] = p.theta * beta1 * J1 / N

    j3_removal = p.alpha3 + p.mu + p.d_star + J3_RHO * p.a0
    V = np.array([
        [p.mu + p.k + p.a0 + h, 0.0, 0.0, 0.0],
        [-p.k, p.mu + p.d + p.a0, 0.0, 0.0],
        [-h, 0.0, p.alpha2 + p.mu + p.k_star + p.a0, 0.0],
        [0.0, 0.0, -p.k_star, j3_removal],
    ], dtype=float)
    K = F @ np.linalg.inv(V)
    return float(np.max(np.abs(eigvals(K))))


# Route every model call through the continuous-rho variant.
#
# IMPORTANT: importing the verifier re-instantiates its OWN copy of 00_common
# via spec_from_file_location (distinct from `common` loaded above). The
# equilibrium solvers find_full_equilibria / full_residual_scaled /
# full_stability resolve the name rhs_full from THAT inner namespace, so it
# must be patched as well. Patching only `common` and verifier globals would
# leave the root-finder on the unpatched model while fold_residual's Jacobian
# used the rho-aware variant -- an inconsistent hybrid that yields a spurious
# fold.
_INNER_COMMON = verifier.find_full_equilibria.__globals__


def _patch_all():
    for ns in (common.__dict__, verifier.__dict__, _INNER_COMMON):
        ns["rhs_full"] = rhs_full
        ns["RTH_for_beta1"] = RTH_for_beta1


_patch_all()


def set_rho(rho):
    global J3_RHO
    J3_RHO = float(rho)


def locate_bp1_wide():
    """BP1 over a wide bracket that covers the rho-induced shift."""
    try:
        return verifier.locate_tb_hiv_branch_point(q_lower=0.55, q_upper=1.10)
    except RuntimeError:
        return None


def locate_interior_fold():
    """Return a validated strict-interior LP2, or None if it is absent.

    Sweep a Q window for a stable co-endemic seed (the stable segment lies
    just below the fold), choose the seed with the largest burden (closest
    to the turning point), then solve the augmented fold residual and accept
    only a co_endemic root that passes the verifier's non-degeneracy checks.
    The verifier itself rejects a boundary transcritical because w^T f_Q
    vanishes there.
    """
    seed = None
    seed_q = None
    for q in np.linspace(1.12, 0.995, 26):
        try:
            records = verifier.equilibrium_records(float(q))
        except Exception:
            continue
        cands = [r for r in records
                 if r["stable"] and r.get("eq_class") == "co_endemic"
                 and r["burden"] > verifier.POSITIVE_BURDEN]
        if cands:
            cand = max(cands, key=lambda r: r["burden"])
            if seed is None or cand["burden"] > seed["burden"]:
                seed, seed_q = cand, float(q)
    if seed is None:
        return None, "no stable co-endemic seed in [0.995,1.12]"
    try:
        fold = verifier.solve_fold(seed["state"], seed_q, 0.95, 1.20, "LP2")
        return fold, "validated"
    except Exception as exc:
        return None, f"fold solve failed: {type(exc).__name__}: {str(exc)[:120]}"


def run_continuation(rho_grid):
    rows = []
    for rho in rho_grid:
        set_rho(rho)
        bp1 = locate_bp1_wide()
        lp2, lp2_note = locate_interior_fold()
        row = {
            "rho": float(rho),
            "bp1_Q": (float(bp1["Q"]) if bp1 is not None else None),
            "bp1_burden": (float(bp1["burden"]) if bp1 is not None else None),
            "lp2_Q": (float(lp2["Q"]) if lp2 is not None else None),
            "lp2_burden": (float(lp2["burden"]) if lp2 is not None else None),
            "lp2_max_other_real": (float(lp2["max_other_real"]) if lp2 is not None else None),
            "interior_fold_present": lp2 is not None,
            "note": lp2_note,
        }
        rows.append(row)
        print(
            f"rho={rho:.3f}  BP1={row['bp1_Q'] if row['bp1_Q'] is None else round(row['bp1_Q'],6)}"
            f"  LP2={row['lp2_Q'] if row['lp2_Q'] is None else round(row['lp2_Q'],6)}"
            f"  interior_fold={row['interior_fold_present']}", flush=True,
        )
    return rows


def make_figure(rows):
    import matplotlib.pyplot as plt
    set_publication_style()

    rho = np.array([r["rho"] for r in rows])
    bp1 = np.array([np.nan if r["bp1_Q"] is None else r["bp1_Q"] for r in rows])
    lp2 = np.array([np.nan if r["lp2_Q"] is None else r["lp2_Q"] for r in rows])

    present = ~np.isnan(lp2)
    last_present = rho[present].max() if present.any() else None

    fig, ax = plt.subplots(figsize=(7.4, 5.0))

    # Shade the treatment-strength range over which no strict-interior fold
    # is detected.
    if last_present is not None and last_present < rho.max() + 1e-9:
        ax.axvspan(last_present, rho.max(), color="#B2182B", alpha=0.07, zorder=0)
        ax.text(0.5 * (last_present + rho.max()), 0.700,
                "no validated\nstrict-interior fold",
                fontsize=9.5, color="#B2182B", ha="center", va="center")

    ax.axhline(1.0, color="#6E6E6E", linestyle="--", linewidth=1.3,
               label=r"TB-invasion threshold $\mathcal{R}_1^2=1$")
    ax.plot(rho, bp1, "-o", color="#0B3C5D", linewidth=2.1, markersize=5.0,
            label="Boundary branch point BP1")
    ax.plot(rho[present], lp2[present], "-D", color="#D4A017",
            linewidth=2.1, markersize=5.5, label="Strict-interior fold LP2")

    if last_present is not None:
        ax.axvline(last_present, color="#B2182B", linestyle=":", linewidth=1.3)
        ax.annotate(f"LP2 reaches the threshold\nnear $\\rho\\approx{last_present:.2f}$",
                    xy=(last_present, 1.0), xytext=(last_present - 0.30, 1.045),
                    fontsize=9.5, color="#B2182B",
                    arrowprops=dict(arrowstyle="->", color="#B2182B", linewidth=0.9))

    ax.set_xlabel(r"J$_3$ treatment-strength coefficient $\rho$", fontsize=11)
    ax.set_ylabel(r"Location in $\mathcal{R}_1^2$", fontsize=11)
    ax.tick_params(axis="both", labelsize=10)
    ax.set_xlim(-0.02, 1.02)
    ax.set_ylim(0.60, 1.10)
    ax.grid(True, color="#E8E8E8", linewidth=0.5, alpha=0.8)
    ax.legend(frameon=False, fontsize=9.5, loc="lower left")
    fig.tight_layout()
    save_fig(fig, "fig_j3_continuous_continuation")
    plt.close(fig)
    return last_present


def main():
    # Dense grid, refined in the critical interval where the fold reaches Q=1.
    rho_grid = np.sort(np.unique(np.r_[
        np.linspace(0.0, 0.40, 5),
        np.linspace(0.45, 0.80, 8),
        np.linspace(0.85, 1.0, 4),
    ]))
    print("Continuous J3-treatment continuation; rho grid:",
          np.round(rho_grid, 3), flush=True)

    rows = run_continuation(rho_grid)

    # Persist the numerical continuation BEFORE plotting so a cosmetic plotting
    # error can never discard the computed results.
    present_rho = [r["rho"] for r in rows if r["interior_fold_present"]]
    last_present = max(present_rho) if present_rho else None
    payload = {
        "description": "Continuous J3-treatment-rate two-parameter continuation",
        "treatment": "treat_J3 = rho*a(B)J3/(1+omega(B)J3), J3->J1",
        "RH": verifier.RH, "m": verifier.M,
        "rho_grid": [float(x) for x in rho_grid],
        "rows": rows,
        "interior_fold_last_present_rho": (float(last_present) if last_present is not None else None),
    }
    out_json = RESULT_DIR / "j3_continuous_continuation.json"
    out_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"saved: {out_json}", flush=True)

    crit = make_figure(rows)

    lines = ["Continuous J3-treatment continuation", "=" * 60]
    for r in rows:
        lines.append(
            f"rho={r['rho']:.3f}  BP1={r['bp1_Q']}  LP2={r['lp2_Q']}  "
            f"fold_present={r['interior_fold_present']}  ({r['note']})"
        )
    lines.append(f"Last rho with a validated interior fold: {crit}")
    summary = "\n".join(lines)
    (Path(OUTPUT_DIR) / "j3_continuous_continuation_summary.txt").write_text(
        summary + "\n", encoding="utf-8")
    print("\n" + summary)


if __name__ == "__main__":
    main()
