"""
Save key TB-only bifurcation numbers to a JSON result file.

This script:
1. Computes m_c^TB analytically
2. Computes the LP (saddle-node) curve and interpolates at m=0.05
3. Compares with the values in the manuscript
4. Saves everything to output/tb_only_key_numbers.json
"""

import importlib.util
import sys
import json
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "common",
    str(Path(__file__).with_name("00_common.py"))
)
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({
    name: getattr(common, name)
    for name in dir(common)
    if not name.startswith("_")
})

import numpy as np
from scipy.interpolate import PchipInterpolator


def main():
    print("=" * 64)
    print("Saving key TB-only bifurcation numbers")
    print("=" * 64)

    # 1. Compute m_c^TB analytically
    m_c_TB = compute_m_c_TB_analytic(P)
    print(f"\n1. Analytic m_c^TB = {m_c_TB:.10f}")
    print(f"   Manuscript value: 21.2")
    print(f"   Match: {abs(m_c_TB - 21.2) < 0.05}")

    # 2. Compute LP curve and interpolate at m=0.05
    print(f"\n2. Computing LP (saddle-node) curve...")
    lp_points = trace_tb_LP_curve_by_I(
        P, m_min=0.02, I_end=2.0, n_I=360
    )

    lp_m = np.array([q["m"] for q in lp_points])
    lp_RT = np.array([q["RT"] for q in lp_points])

    # Sort and remove duplicates
    order = np.argsort(lp_m)
    lp_m = lp_m[order]
    lp_RT = lp_RT[order]
    keep = np.r_[True, np.diff(lp_m) > 1.0e-10]
    lp_m = lp_m[keep]
    lp_RT = lp_RT[keep]

    # Interpolate at m=0.05
    lp_interpolant = PchipInterpolator(lp_m, lp_RT, extrapolate=False)
    m_target = 0.05
    saddle_node_R1 = float(lp_interpolant(m_target))
    print(f"   Saddle-node R1 at m={m_target} = {saddle_node_R1:.6f}")
    print(f"   Manuscript value: 0.482")
    print(f"   Match: {abs(saddle_node_R1 - 0.482) < 0.005}")

    # 3. Save to JSON
    output_path = Path(OUTPUT_DIR) / "tb_only_key_numbers.json"
    result = {
        "preset": PARAMETER_PRESET,
        "m_c_TB_analytic": m_c_TB,
        "m_c_TB_rounded": round(m_c_TB, 1),
        "manuscript_m_c_TB": 21.2,
        "m_c_TB_match": bool(abs(m_c_TB - 21.2) < 0.05),
        "saddle_node": {
            "m_value": m_target,
            "R1": saddle_node_R1,
            "R1_rounded": round(saddle_node_R1, 3),
            "manuscript_R1": 0.482,
            "match": bool(abs(saddle_node_R1 - 0.482) < 0.005),
        },
        "lp_curve_info": {
            "n_points": len(lp_points),
            "m_range": [float(lp_m.min()), float(lp_m.max())],
            "R1_range": [float(lp_RT.min()), float(lp_RT.max())],
            "method": "trace_tb_LP_curve_by_I (I-continuation, 5-pt stencil)",
        },
        "parameter_values": {
            "a0": P.a0,
            "a_max": P.a_max,
            "omega0": P.omega0,
            "omega_min": P.omega_min,
            "mu": P.mu,
            "k": P.k,
            "d": P.d,
            "Lambda": P.Lambda,
        },
    }

    output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"\n3. Saved to: {output_path}")

    # 4. Summary
    print("\n" + "=" * 64)
    print("SUMMARY")
    print("=" * 64)
    print(f"  m_c^TB:       computed={m_c_TB:.4f}, manuscript=21.2, match={'YES' if abs(m_c_TB - 21.2) < 0.05 else 'NO'}")
    print(f"  saddle-node:  computed={saddle_node_R1:.4f}, manuscript=0.482, match={'YES' if abs(saddle_node_R1 - 0.482) < 0.005 else 'NO'}")
    print("=" * 64)


if __name__ == "__main__":
    main()
