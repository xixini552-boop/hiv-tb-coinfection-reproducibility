"""
Standard augmented fold system validation for LP2.

Solves the full 17-equation augmented saddle-node system
    f(x,q) = 0          (8 equilibrium equations)
    J(x,q) v = 0        (8 Jacobian-nullvector equations)
    c^T v = 1           (1 normalization, c selects largest |v| component)
and compares the result with the 9-equation nearest-eigenvalue solver
used for branch discovery.

Output: bifurcation/output/lp2_augmented_validation.json
"""
import os, json
import numpy as np
from scipy.optimize import root
from scipy.linalg import eig

# Same directory imports
import importlib.util
_HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "bif_v4", os.path.join(_HERE, "05_full_backward_bifurcation_v4_verified.py")
)
mod = importlib.util.module_from_spec(spec)
mod.__name__ = "bif_v4"
try:
    spec.loader.exec_module(mod)
except SystemExit:
    pass

P = mod.P
RH = mod.RH
BETA2 = mod.BETA2
M = mod.M


def augmented_fold_residual(z):
    """17 equations: 8 equilibrium + 8 Jv=0 + 1 c^T v=1."""
    x = z[:8]
    v = z[8:16]
    Q = float(z[16])
    beta1 = mod.beta1_from_RTH(Q, RH, P)
    F = mod.full_residual_scaled(x, beta1, BETA2, M, P)
    J = mod.central_numerical_jacobian(
        lambda y: mod.rhs_full(y, beta1, BETA2, M, P), x, ()
    )
    Jv = J @ v
    c = np.zeros(8)
    c[np.argmax(np.abs(v))] = 1.0
    norm = np.dot(c, v) - 1.0
    return np.concatenate([F, Jv, [norm]])


def main():
    print("=" * 60)
    print("Standard Augmented Fold Validation for LP2")
    print("=" * 60)

    # Known LP2 state from the validated 9-equation solve
    lp2_state = np.array([
        1174.435901, 66.435699, 49.989363, 514.082280,
        725.620541, 10.776977, 37.718664, 181.949798
    ])
    Q_lp2 = 1.05496491

    # 9-equation solve (refine)
    lp2_9eq = mod.solve_fold(lp2_state, Q_lp2, 0.6, 1.1, "LP2_9eq")
    print(f"\n9-equation LP2: Q={lp2_9eq['Q']:.10f}")
    print(f"  burden={lp2_9eq['burden']:.8f}, hiv={lp2_9eq['hiv_fraction']:.8f}")
    print(f"  w^T f_Q={lp2_9eq['wTfQ']:.4f}, w^T D2f[v,v]={lp2_9eq['wTD2vv']:.6e}")

    # Initial guess for augmented system
    x0 = lp2_9eq["state"]
    Q0 = lp2_9eq["Q"]
    beta1_0 = mod.beta1_from_RTH(Q0, RH, P)
    J0 = mod.central_numerical_jacobian(
        lambda y: mod.rhs_full(y, beta1_0, BETA2, M, P), x0, ()
    )
    values, right = eig(J0)
    i0 = int(np.argmin(np.abs(values)))
    v0 = right[:, i0].real
    v0 /= v0[np.argmax(np.abs(v0))]
    z0 = np.concatenate([x0, v0, [Q0]])

    # Solve 17-equation augmented system
    sol = root(augmented_fold_residual, z0, method="hybr",
               options={"xtol": 1e-12, "maxfev": 10000})

    x_aug, v_aug, Q_aug = sol.x[:8], sol.x[8:16], float(sol.x[16])
    beta1_aug = mod.beta1_from_RTH(Q_aug, RH, P)
    F_aug = mod.full_residual_scaled(x_aug, beta1_aug, BETA2, M, P)
    J_aug = mod.central_numerical_jacobian(
        lambda y: mod.rhs_full(y, beta1_aug, BETA2, M, P), x_aug, ()
    )
    eigvals_aug, _ = eig(J_aug)
    burden_aug = float(mod.active_tb_burden_full(x_aug))
    hiv_aug = float(mod.hiv_burden_full(x_aug))

    # Nondegeneracy for augmented solution
    values_l, left = eig(J_aug.T)
    w_aug = left[:, int(np.argmin(np.abs(values_l)))].real
    w_aug /= float(np.dot(w_aug, v_aug))
    dQ = 1e-5
    bp = mod.beta1_from_RTH(Q_aug + dQ, RH, P)
    bm = mod.beta1_from_RTH(Q_aug - dQ, RH, P)
    fQ = (mod.rhs_full(x_aug, bp, BETA2, M, P)
          - mod.rhs_full(x_aug, bm, BETA2, M, P)) / (2 * dQ)
    h = 0.2
    d2 = (mod.rhs_full(x_aug + h * v_aug, beta1_aug, BETA2, M, P)
          - 2 * mod.rhs_full(x_aug, beta1_aug, BETA2, M, P)
          + mod.rhs_full(x_aug - h * v_aug, beta1_aug, BETA2, M, P)) / h**2

    results = {
        "9eq_Q": lp2_9eq["Q"], "9eq_burden": lp2_9eq["burden"],
        "9eq_hiv_fraction": lp2_9eq["hiv_fraction"],
        "9eq_wTfQ": lp2_9eq["wTfQ"], "9eq_wTD2vv": lp2_9eq["wTD2vv"],
        "aug_Q": Q_aug, "aug_burden": burden_aug, "aug_hiv_fraction": hiv_aug,
        "aug_residual_norm": float(np.linalg.norm(F_aug)),
        "aug_Jv_norm": float(np.linalg.norm(J_aug @ v_aug)),
        "aug_min_eigenvalue": float(np.min(np.abs(eigvals_aug))),
        "aug_wTfQ": float(np.dot(w_aug, fQ)),
        "aug_wTD2vv": float(np.dot(w_aug, d2)),
        "solver_success": bool(sol.success),
        "Q_diff": float(abs(lp2_9eq["Q"] - Q_aug)),
    }

    print(f"\n17-equation augmented LP2: Q={Q_aug:.10f}")
    print(f"  residual={results['aug_residual_norm']:.2e}, "
          f"||Jv||={results['aug_Jv_norm']:.2e}, "
          f"min|eig|={results['aug_min_eigenvalue']:.2e}")
    print(f"  Q diff vs 9eq: {results['Q_diff']:.2e}")
    print(f"  w^T f_Q={results['aug_wTfQ']:.4f}, "
          f"w^T D2f[v,v]={results['aug_wTD2vv']:.6e}")

    outdir = os.path.join(_HERE, "..", "output")
    os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, "lp2_augmented_validation.json"), "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to output/lp2_augmented_validation.json")
    print("=" * 60)


if __name__ == "__main__":
    main()
