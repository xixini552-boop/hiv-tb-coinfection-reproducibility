"""Mechanism controls for the burden-dependent healthcare response."""

import csv
import importlib.util
import json
import sys
from dataclasses import replace
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import brentq
from scipy.interpolate import PchipInterpolator


SPEC = importlib.util.spec_from_file_location(
    "common", str(Path(__file__).with_name("00_common.py"))
)
COMMON = importlib.util.module_from_spec(SPEC)
sys.modules["common"] = COMMON
SPEC.loader.exec_module(COMMON)

OUTPUT_DIR = Path(__file__).parents[1] / "output" / "mechanism_controls"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

MODES = {
    "coupled": "coupled feedback",
    "none": "no burden feedback",
    "treatment_only": "treatment response only",
    "resource_only": "resource response only",
}
M_VALUES = (0.05, 6.0)
RT_VALUES = np.linspace(0.40, 1.35, 220)


def collect_records():
    records = []
    for mode in MODES:
        parameters = replace(COMMON.P, response_mode=mode)
        for response_sensitivity in M_VALUES:
            for tb_reproduction in RT_VALUES:
                beta1 = COMMON.beta1_from_RT(tb_reproduction, parameters)
                equilibria = COMMON.find_tb_endemic_equilibria(
                    beta1,
                    response_sensitivity,
                    parameters,
                    n_grid=220,
                )
                for branch_index, equilibrium in enumerate(equilibria):
                    stable, max_real, _ = COMMON.tb_stability(
                        equilibrium,
                        beta1,
                        response_sensitivity,
                        parameters,
                    )
                    records.append({
                        "mode": mode,
                        "response_sensitivity": response_sensitivity,
                        "tb_reproduction": tb_reproduction,
                        "branch_index": branch_index,
                        "infectious_level": float(equilibrium[2]),
                        "active_burden": equilibrium[2] / np.sum(equilibrium),
                        "stable": int(stable),
                        "max_real": max_real,
                    })
    return records


def write_records(records):
    csv_path = OUTPUT_DIR / "mechanism_controls.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def has_stable_subthreshold_equilibrium(mode, response_sensitivity, tb_reproduction):
    """Predicate for the leftmost stable subthreshold TB-only equilibrium."""
    parameters = replace(COMMON.P, response_mode=mode)
    beta1 = COMMON.beta1_from_RT(tb_reproduction, parameters)
    equilibria = COMMON.find_tb_endemic_equilibria(
        beta1,
        response_sensitivity,
        parameters,
        n_grid=400,
    )
    for equilibrium in equilibria:
        stable, _, _ = COMMON.tb_stability(
            equilibrium,
            beta1,
            response_sensitivity,
            parameters,
        )
        if stable:
            return True
    return False


def refine_stability_crossing(mode, response_sensitivity):
    """Grid-independent leftmost subthreshold stability crossing.

    The 220-point ``RT_VALUES`` scan locates the crossing only to the grid
    spacing (~4e-3), which is coarse enough to move the reported value at the
    third decimal.  The bracket found on the grid is therefore refined by
    bisection on the exact predicate "a stable subthreshold equilibrium exists
    at this R1".
    """
    previous = None
    for tb_reproduction in RT_VALUES:
        if tb_reproduction >= 1.0:
            break
        if has_stable_subthreshold_equilibrium(mode, response_sensitivity, tb_reproduction):
            if previous is None:
                return float(tb_reproduction)
            low, high = previous, float(tb_reproduction)
            while high - low > 1.0e-10:
                mid = 0.5 * (low + high)
                if has_stable_subthreshold_equilibrium(mode, response_sensitivity, mid):
                    high = mid
                else:
                    low = mid
            return float(high)
        previous = float(tb_reproduction)
    return None


def summarize(records):
    summary = {}
    for mode in MODES:
        summary[mode] = {}
        for response_sensitivity in M_VALUES:
            subset = [
                row for row in records
                if row["mode"] == mode
                and row["response_sensitivity"] == response_sensitivity
                and row["stable"] == 1
                and row["tb_reproduction"] < 1.0
            ]
            summary[mode][str(response_sensitivity)] = {
                "subthreshold_stable_points": len(subset),
                "lowest_tb_reproduction": refine_stability_crossing(
                    mode,
                    response_sensitivity,
                ),
                "lowest_tb_reproduction_grid": (
                    min(row["tb_reproduction"] for row in subset)
                    if subset else None
                ),
                "highest_subthreshold_burden": (
                    max(row["active_burden"] for row in subset)
                    if subset else None
                ),
            }
    (OUTPUT_DIR / "mechanism_controls_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    return summary


def locate_fold_points():
    fold_points = {}
    for mode in MODES:
        parameters = replace(COMMON.P, response_mode=mode)
        fold_points[mode] = {}
        for response_sensitivity in M_VALUES:
            candidates = COMMON.trace_tb_LP_curve(
                [response_sensitivity],
                parameters,
                verbose=False,
            )
            valid = [point for point in candidates if point["valid"]]
            if not valid:
                continue
            point = valid[0]
            beta1 = COMMON.beta1_from_RT(point["RT"], parameters)
            equilibrium = COMMON.tb_equilibrium_from_I(
                point["I"],
                beta1,
                response_sensitivity,
                parameters,
            )
            if equilibrium is None:
                raise RuntimeError(
                    f"Fold reconstruction failed for {mode}, "
                    f"m={response_sensitivity}"
                )
            residual = np.linalg.norm(
                COMMON.rhs_tb(equilibrium, beta1, response_sensitivity, parameters)
                / max(parameters.Lambda, 1.0)
            )
            if residual > 1.0e-6:
                raise RuntimeError(
                    f"Fold residual too large for {mode}, "
                    f"m={response_sensitivity}: {residual:.3e}"
                )
            fold_points[mode][response_sensitivity] = {
                "I": point["I"],
                "tb_reproduction": point["RT"],
                "active_burden": point["I"] / np.sum(equilibrium),
            }
    return fold_points


def build_equilibrium_curve(mode, response_sensitivity, fold_points, records):
    parameters = replace(COMMON.P, response_mode=mode)
    i_upper = 0.999 * parameters.Lambda / (parameters.mu + parameters.d)
    sampled_i = [
        row["infectious_level"]
        for row in records
        if row["mode"] == mode
        and row["response_sensitivity"] == response_sensitivity
    ]
    i_values = np.unique(np.concatenate([
        np.geomspace(1.0e-6, i_upper, 350),
        np.asarray(sampled_i, dtype=float),
    ]))
    rt_scan = np.linspace(0.35, 1.4, 160)
    fold = fold_points.get(mode, {}).get(response_sensitivity)
    if fold is not None:
        i_values = np.unique(np.append(i_values, fold["I"]))

    curve = []
    for infectious_level in i_values:
        def residual_at_rt(tb_reproduction):
            beta1 = COMMON.beta1_from_RT(tb_reproduction, parameters)
            return COMMON.tb_endemic_residual(
                infectious_level,
                beta1,
                response_sensitivity,
                parameters,
            )

        residuals = np.array([residual_at_rt(rt) for rt in rt_scan])
        bracket = None
        for left_index in range(len(rt_scan) - 1):
            left_value = residuals[left_index]
            right_value = residuals[left_index + 1]
            if not (np.isfinite(left_value) and np.isfinite(right_value)):
                continue
            if left_value == 0:
                bracket = (rt_scan[left_index], rt_scan[left_index])
                break
            if left_value * right_value < 0:
                bracket = (rt_scan[left_index], rt_scan[left_index + 1])
                break
        if bracket is None:
            continue
        if bracket[0] == bracket[1]:
            tb_reproduction = bracket[0]
        else:
            tb_reproduction = brentq(
                residual_at_rt,
                bracket[0],
                bracket[1],
                xtol=1.0e-10,
                rtol=1.0e-10,
            )
        beta1 = COMMON.beta1_from_RT(tb_reproduction, parameters)
        equilibrium = COMMON.tb_equilibrium_from_I(
            infectious_level,
            beta1,
            response_sensitivity,
            parameters,
        )
        if equilibrium is None:
            continue
        equilibrium_residual = np.linalg.norm(
            COMMON.rhs_tb(
                equilibrium,
                beta1,
                response_sensitivity,
                parameters,
            )
            / max(parameters.Lambda, 1.0)
        )
        if equilibrium_residual > 1.0e-6:
            raise RuntimeError(
                f"Equilibrium residual too large for {mode}, "
                f"m={response_sensitivity}, I={infectious_level}: "
                f"{equilibrium_residual:.3e}"
            )
        stable, max_real, _ = COMMON.tb_stability(
            equilibrium,
            beta1,
            response_sensitivity,
            parameters,
        )
        curve.append({
            "I": infectious_level,
            "tb_reproduction": tb_reproduction,
            "active_burden": infectious_level / np.sum(equilibrium),
            "stable": int(stable),
            "max_real": max_real,
        })
    return curve


def plot_folded_unstable_branch(axis, points, color, linewidth=1.7):
    array = np.asarray(points, dtype=float)
    array = array[np.isfinite(array).all(axis=1)]
    if len(array) < 4:
        axis.plot(
            array[:, 0],
            array[:, 1],
            color=color,
            linestyle="--",
            linewidth=linewidth,
        )
        return

    order = np.argsort(array[:, 1])
    x = array[order, 0]
    y = array[order, 1]
    y_unique, inverse, counts = np.unique(
        y,
        return_inverse=True,
        return_counts=True,
    )
    x_unique = np.zeros_like(y_unique)
    np.add.at(x_unique, inverse, x)
    x_unique /= counts
    y_smooth = np.linspace(y_unique.min(), y_unique.max(), 1200)
    x_smooth = PchipInterpolator(y_unique, x_unique)(y_smooth)
    axis.plot(
        x_smooth,
        y_smooth,
        color=color,
        linestyle="--",
        linewidth=linewidth,
    )


def find_stability_transitions(curve):
    ordered = sorted(curve, key=lambda row: row["I"])
    transitions = []
    for left, right in zip(ordered[:-1], ordered[1:]):
        if left["stable"] == right["stable"]:
            continue
        left_real = left["max_real"]
        right_real = right["max_real"]
        if np.isfinite(left_real) and np.isfinite(right_real) and right_real != left_real:
            fraction = np.clip(
                (-1.0e-6 - left_real) / (right_real - left_real),
                0.0,
                1.0,
            )
        else:
            fraction = 0.5
        transitions.append({
            "I": left["I"] + fraction * (right["I"] - left["I"]),
            "tb_reproduction": (
                left["tb_reproduction"]
                + fraction * (right["tb_reproduction"] - left["tb_reproduction"])
            ),
            "active_burden": (
                left["active_burden"]
                + fraction * (right["active_burden"] - left["active_burden"])
            ),
        })
    return transitions


def plot_continuous_stability_curve(axis, curve, fold, color, linewidth=1.7):
    ordered = sorted(curve, key=lambda row: row["I"])
    nodes = [dict(row) for row in ordered]
    nodes.extend(find_stability_transitions(ordered))
    if fold is not None:
        nodes.append({
            "I": fold["I"],
            "tb_reproduction": fold["tb_reproduction"],
            "active_burden": fold["active_burden"],
        })
    nodes.sort(key=lambda row: row["I"])

    unique_nodes = []
    for node in nodes:
        if unique_nodes and np.isclose(node["I"], unique_nodes[-1]["I"], atol=1.0e-8, rtol=0.0):
            continue
        unique_nodes.append(node)
    if len(unique_nodes) < 4:
        return

    i_nodes = np.asarray([node["I"] for node in unique_nodes], dtype=float)
    x_nodes = np.asarray(
        [node["tb_reproduction"] for node in unique_nodes],
        dtype=float,
    )
    y_nodes = np.asarray(
        [node["active_burden"] for node in unique_nodes],
        dtype=float,
    )
    x_curve = PchipInterpolator(i_nodes, x_nodes)
    y_curve = PchipInterpolator(i_nodes, y_nodes)
    ordered_i = np.asarray([row["I"] for row in ordered], dtype=float)

    def stability_at(infectious_level):
        right_index = np.searchsorted(ordered_i, infectious_level, side="right")
        if right_index == 0:
            return bool(ordered[0]["stable"])
        if right_index >= len(ordered):
            return bool(ordered[-1]["stable"])
        left = ordered[right_index - 1]
        right = ordered[right_index]
        if left["stable"] == right["stable"]:
            return bool(left["stable"])
        fraction = (infectious_level - left["I"]) / (right["I"] - left["I"])
        max_real = left["max_real"] + fraction * (right["max_real"] - left["max_real"])
        return bool(max_real < -1.0e-6)

    interval_styles = [
        stability_at(0.5 * (left["I"] + right["I"]))
        for left, right in zip(unique_nodes[:-1], unique_nodes[1:])
    ]

    def draw_path(i_start, i_end, stable):
        i_dense = np.linspace(i_start, i_end, 240)
        x_dense = np.asarray(x_curve(i_dense), dtype=float)
        y_dense = np.asarray(y_curve(i_dense), dtype=float)
        if stable:
            axis.plot(
                x_dense,
                y_dense,
                color=color,
                linestyle="-",
                linewidth=linewidth,
            )
            return

        display_points = axis.transData.transform(
            np.column_stack([x_dense, y_dense])
        )
        segment_lengths = np.linalg.norm(
            np.diff(display_points, axis=0),
            axis=1,
        )
        arc = np.concatenate(([0.0], np.cumsum(segment_lengths)))
        arc *= 72.0 / axis.figure.dpi
        total_length = arc[-1]
        if total_length <= 0.0:
            return

        dash_on = 7.0
        dash_off = 4.0
        dash_cycle = dash_on + dash_off
        phase = (0.5 * dash_on - total_length) % dash_cycle

        def point_at(distance):
            index = np.searchsorted(arc, distance, side="right")
            if index == 0:
                return x_dense[0], y_dense[0]
            if index >= len(arc):
                return x_dense[-1], y_dense[-1]
            fraction = (distance - arc[index - 1]) / (arc[index] - arc[index - 1])
            x_value = x_dense[index - 1] + fraction * (x_dense[index] - x_dense[index - 1])
            y_value = y_dense[index - 1] + fraction * (y_dense[index] - y_dense[index - 1])
            return x_value, y_value

        distance = 0.0
        while distance < total_length - 1.0e-9:
            position = (phase + distance) % dash_cycle
            on_segment = position < dash_on
            remaining = (dash_on - position) if on_segment else (dash_cycle - position)
            end_distance = min(distance + remaining, total_length)
            if on_segment:
                interior = arc[(arc > distance) & (arc < end_distance)]
                distances = np.concatenate(([distance], interior, [end_distance]))
                segment_points = np.asarray([point_at(value) for value in distances])
                axis.plot(
                    segment_points[:, 0],
                    segment_points[:, 1],
                    color=color,
                    linestyle="-",
                    linewidth=linewidth,
                )
            distance = end_distance

    run_start = 0
    for interval_index in range(1, len(interval_styles) + 1):
        at_end = interval_index == len(interval_styles)
        style_changed = (
            not at_end
            and interval_styles[interval_index] != interval_styles[run_start]
        )
        if not at_end and not style_changed:
            continue
        start_i = unique_nodes[run_start]["I"]
        end_i = unique_nodes[interval_index]["I"]
        draw_path(start_i, end_i, interval_styles[run_start])
        run_start = interval_index


def plot_panel(curves, fold_points, mode, filename, show_legend=False):
    figure, axis = plt.subplots(figsize=(4.3, 3.4))
    colours = {0.05: "#0B3C5D", 6.0: "#D55E00"}
    axis.set_xlim(0.35, 1.4)
    axis.set_ylim(-0.03, 0.58)

    for response_sensitivity in M_VALUES:
        curve = curves[mode][response_sensitivity]
        fold = fold_points.get(mode, {}).get(response_sensitivity)
        plot_continuous_stability_curve(
            axis,
            curve,
            fold,
            color=colours[response_sensitivity],
            linewidth=1.7,
        )
    axis.axvline(1.0, color="#777777", linestyle=":", linewidth=0.8)
    axis.set_xlabel(r"TB reproduction number, $\mathcal{R}_1$")
    axis.set_ylabel(r"Active-TB burden, $I^*/N^*$")
    axis.grid(True, alpha=0.25, linewidth=0.5)
    if show_legend:
        axis.plot([], [], color="#0B3C5D", label=r"$m=0.05$")
        axis.plot([], [], color="#D55E00", label=r"$m=6$")
        axis.plot([], [], color="#333333", linestyle="-", label="stable")
        axis.plot([], [], color="#333333", linestyle="--", label="unstable")
        axis.legend(frameon=False, fontsize=8, ncol=2)
    for line in axis.lines:
        line.set_antialiased(True)
        line.set_solid_capstyle("round")
        line.set_solid_joinstyle("round")
        line.set_dash_capstyle("round")
        line.set_dash_joinstyle("round")
        if line.get_linestyle() == "--" and len(line.get_xdata()) > 1:
            display_points = axis.transData.transform(
                np.column_stack([line.get_xdata(), line.get_ydata()])
            )
            segment_lengths = np.linalg.norm(
                np.diff(display_points, axis=0),
                axis=1,
            )
            path_length_points = (
                np.sum(segment_lengths) * 72.0 / axis.figure.dpi
            )
            dash_on = 7.0
            dash_off = 4.0
            dash_cycle = dash_on + dash_off
            dash_offset = (path_length_points - 0.5 * dash_on) % dash_cycle
            line.set_linestyle((dash_offset, (dash_on, dash_off)))
    figure.tight_layout()
    figure.savefig(OUTPUT_DIR / f"{filename}.pdf", bbox_inches="tight")
    figure.savefig(OUTPUT_DIR / f"{filename}.png", dpi=300, bbox_inches="tight")
    plt.close(figure)


def plot_records(records):
    filenames = {
        "coupled": "fig_mechanism_controls_coupled",
        "none": "fig_mechanism_controls_no_feedback",
        "treatment_only": "fig_mechanism_controls_treatment_only",
        "resource_only": "fig_mechanism_controls_resource_only",
    }
    fold_points = locate_fold_points()
    curves = {
        mode: {
            response_sensitivity: build_equilibrium_curve(
                mode,
                response_sensitivity,
                fold_points,
                records,
            )
            for response_sensitivity in M_VALUES
        }
        for mode in MODES
    }
    for index, mode in enumerate(MODES):
        plot_panel(
            curves,
            fold_points,
            mode,
            filenames[mode],
            show_legend=True,
        )


def main():
    records = collect_records()
    write_records(records)
    summary = summarize(records)
    plot_records(records)
    print(json.dumps(summary, indent=2))
    print(f"saved outputs to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
