# HIV--TB article code

This directory contains the Python scripts used to regenerate the manuscript
figures and the supplementary J3-treatment control. Run the scripts from
this directory so that the shared module 00_common.py is imported correctly.

## Reproduction order

The current article workflow is:

    01_response_curves.py
    02_tb_only_bifurcation.py
    03_hiv_only_bifurcation.py
    04_full_threshold_shift.py
    05_full_backward_bifurcation_v4_verified.py
    m1_epidemiological_range_scan.py
    10_extended_bifurcation.py
    14_mechanism_controls.py
    esm_j3_treatment_control.py
    12_j3_continuous_continuation.py
    11_augmented_fold_validation.py
    bp1_m_sensitivity.py
    bp1_vs_m_extension.py
    b1_fold_R1sq_vs_m.py
    rn_full_system_slice.py
    window_check_r2.py
    prcc_response_sensitivity.py
    basin_partitioning.py
    fig_basin_trajectories.py
    audit_full_bistability_window.py
    99_save_key_numbers_v2.py

`run_all.py` runs exactly this manuscript-cited list in order and stops at the first failure:

    python run_all.py

Pass `--figures-only` to stop after the eight manuscript-figure scripts:

    python run_all.py --figures-only

The interactive probes (`_probe_j3.py`), the standalone diagnostics
(`99_diagnose_saddle_node.py`, `99_verify_saddle_node.py`,
`verify_resident_fold_4d.py`, `verify_stability_partition_independent.py`,
`diag_basin_time_integration.py`, `diag_stability_around_bp1.py`), the helper
module `fig05_enhanced_stability.py`, and the superseded first-generation
key-number script `99_save_key_numbers.py` are intentionally not part of the
reproduction order.

The generated figures are written to ../figures. Mechanism-control summaries
are written to ../output/mechanism_controls. The regime plot reconstructs the
validated TB-only saddle-node curve directly; `figures/lp_lower_full_curve.txt`
is retained only as a legacy diagnostic and is not used for the reported
full-system branch figure.

`14_mechanism_controls.py` reports the leftmost stability crossing both on the
220-point `RT_VALUES` grid (`lowest_tb_reproduction_grid`) and refined by
bisection on the exact predicate "a stable subthreshold equilibrium exists at
this R1" (`lowest_tb_reproduction`). The bisected value is the grid-independent
one and is the number quoted in the supplementary response-mode table.

`prcc_response_sensitivity.py` produces `../output/prcc_response_sensitivity.json`
and `.csv`: the partial rank correlation coefficients of the equilibrium
active-TB burden at fixed `R1 = 0.8` with respect to all model parameters, over
2000 Latin-hypercube samples (seed 20261016).

`b1_fold_R1sq_vs_m.py` produces `../output/b1_fold_R1sq_vs_m.json`: the
TB-only boundary fold traced in `m` and evaluated as the TB-invasion number of
the resident HIV-endemic state at `R2 = 1.8`. It is the source of the
supplementary statement that the fold reaches `R1^2 = 0.956` at `m ~ 6.897`
(`m = 6.897` gives `R1 = 0.7801`, `R1^2 = 0.95600`), and it also records the
interpolated crossing `m_at_R1sq_target = 6.896934`.

The M1 scan is run from this directory with:

    python m1_epidemiological_range_scan.py

It writes `../output/m1_epidemiological_range_scan.csv` and `.json`, together
with `../figures/fig_M1_epidemiological_range_scan.pdf` (and SVG/PNG) and a
plain-text summary. The scan uses 256 Latin-hypercube samples (seed
20260912), fixes `N0=10000`, samples saturation in the dimensionless
coordinates `omega_tilde=N0*omega`, and performs direct TB-only checks on 64
prespecified samples. It is a robustness check over prespecified parameter
ranges, not a probability distribution or a country calibration.

The continuous J3-treatment continuation is run with:

    python 12_j3_continuous_continuation.py

It imports the validated full-system solver from
`05_full_backward_bifurcation_v4_verified.py` and tracks the boundary branch
point BP1 and the interior fold LP2 on a 17-point grid in the treatment
rewiring fraction `rho` (five points over 0--0.40, eight over 0.45--0.80 and
four over 0.85--1.00, refined where the fold approaches the threshold). Results
are persisted to `../output/j3_continuous_continuation.json` before plotting, so
a plotting error cannot discard the computed continuation. That JSON is the
source of the manuscript statement that BP1 moves by less than 3% across
`rho` in [0, 0.5] and that the interior fold is no longer detected for
`rho >= 0.55` (`interior_fold_last_present_rho = 0.5`), and of the
corresponding supplementary table. Its companion figure
`../figures/fig_j3_continuous_continuation.pdf` is a diagnostic and is not
cited by the manuscript; the `rho = 1` entry quoted there comes from
`esm_j3_treatment_control.py`, not from this continuous family.

The verified full-system script also writes
`../output/full_backward_nonprincipal_unstable_census.json` and `.csv`. These
files contain the 88 additional non-principal unstable detections below BP1,
their support class, state, burden, HIV fraction, residual, largest real
eigenvalue, and unstable-eigenvalue count. The finite census is an audit
diagnostic and does not assert global branch completeness.

The same script additionally writes `../output/representative_diagnostics.json`,
which archives the numbers in the supplementary window-diagnostics table: the
two Q = 0.80 representative equilibria (TB-only high-burden and the detected
strict co-endemic interior root) with their scaled residuals, stability
classification and full eight-dimensional spectra, the branch point BP1, the
interior fold LP2, and the complete list of roots detected at Q = 0.80. The
Table caption numbers are read from this file, so the table can be re-derived
without re-reading the printed log.

## Parameter preset

The default preset in 00_common.py is:

    PARAMETER_PRESET = "illustrative_backward"

It keeps the demographic, progression, and mortality rates at the
literature-based values used in the manuscript and uses the illustrative
healthcare-response values:

    a0 = 0.6
    a_max = 1.5
    omega0 = 3.0e-3
    omega_min = 1.0e-5
    m = 0.05

These values are synthetic presets for mechanism and inverse-problem
experiments; they are not country-calibrated estimates.

The code gives:

    m_c^TB = 21.1738858213

No separate full-system critical response-sensitivity value is used or
reported: the full-system branch results are finite-range numerical findings
at the stated parameter slice, whereas m_c^TB is the analytical threshold for the
TB-only subsystem.

At R2=1.8 and m=0.05, the audited full-system calculation gives
R1^2_BP1=0.6642535243 for the TB-only/HIV boundary branch point and
R1^2_LP2=1.05496491 for the validated strict-interior saddle-node. The
J3-to-J1 control shifts the boundary branch point (BP1) to approximately
R1^2=0.6830 and yields no validated subthreshold interior fold in
0.60 <= R1^2 <= 1.08; this is a finite-range structural-sensitivity result
rather than a global absence claim.

## Numerical scope

The full-system results concern the detected principal branch in the reported
finite search range. Grid searches, state-space branch matching, and validated
fold solves are used together; the workflow does not claim global branch
completeness. The TB-only values at m=0.05 are
R1_LP approximately 0.4817 and R1_H approximately 0.5068.

## Dependencies

The scripts use Python, NumPy, SciPy, Matplotlib, and (for the inverse/PINN
workflow) PyTorch. The versioned computational details are documented in
HMQ_ESM.tex and the reproducibility manifest.
