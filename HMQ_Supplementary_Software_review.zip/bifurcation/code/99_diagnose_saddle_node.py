"""
Diagnose the saddle-node R1 discrepancy at m=0.05.

Method 1: LP curve from trace_tb_LP_curve_by_I
Method 2: Direct scan with find_tb_endemic_equilibria
Method 3: Check the seed point of the LP curve
"""

import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "common",
    str(Path(__file__).with_name("00_common.py"))
)
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({
    name: getattr(common, name)
    for name in dir(common)
    if not name.startswith("_")
})

import numpy as np


def main():
    m = 0.05
    print("=" * 70)
    print(f"Diagnosing saddle-node R1 at m={m}")
    print("=" * 70)

    # Method 1: LP curve details near m=0.05
    print("\n--- Method 1: LP curve from trace_tb_LP_curve_by_I ---")
    lp_points = trace_tb_LP_curve_by_I(P, m_min=0.02, I_end=2.0, n_I=360)

    # Sort by m
    lp_points.sort(key=lambda q: q["m"])

    print(f"Total LP points: {len(lp_points)}")
    print(f"m range: [{lp_points[0]['m']:.6f}, {lp_points[-1]['m']:.6f}]")
    print(f"R1 range: [{lp_points[0]['RT']:.6f}, {lp_points[-1]['RT']:.6f}]")

    # Find points near m=0.05
    print("\nLP points near m=0.05:")
    print(f"{'m':>12} {'R1':>12} {'I':>12} {'fold_ev':>14} {'second_real':>12}")
    for p in lp_points:
        if 0.03 < p["m"] < 0.08:
            print(f"{p['m']:12.6f} {p['RT']:12.6f} {p['I']:12.4f} "
                  f"{abs(p['fold_eigenvalue']):14.2e} {p['second_real']:12.6f}")

    # Linear interpolation at m=0.05
    lp_m = np.array([p["m"] for p in lp_points])
    lp_RT = np.array([p["RT"] for p in lp_points])
    idx = np.searchsorted(lp_m, 0.05)
    if 0 < idx < len(lp_m):
        m0, m1 = lp_m[idx-1], lp_m[idx]
        r0, r1 = lp_RT[idx-1], lp_RT[idx]
        interp = r0 + (0.05 - m0) * (r1 - r0) / (m1 - m0)
        print(f"\nLinear interpolation at m=0.05: R1 = {interp:.6f}")
        print(f"  using m={m0:.6f}->R1={r0:.6f} and m={m1:.6f}->R1={r1:.6f}")

    # Method 2: Direct scan with find_tb_endemic_equilibria
    print("\n--- Method 2: Direct scan with find_tb_endemic_equilibria ---")
    print("Scanning R1 from 0.45 to 0.55 (200 points)...")

    RT_values = np.linspace(0.45, 0.55, 200)
    n_stable_list = []
    n_total_list = []

    for RT in RT_values:
        beta1 = beta1_from_RT(RT, P)
        eqs = find_tb_endemic_equilibria(beta1, m, P, n_grid=900)
        n_stable = sum(1 for eq in eqs if tb_stability(eq, beta1, m, P)[0])
        n_stable_list.append(n_stable)
        n_total_list.append(len(eqs))

    # Find where number of equilibria changes (saddle-node)
    print("\nR1 values where number of equilibria changes:")
    for i in range(1, len(RT_values)):
        if n_total_list[i] != n_total_list[i-1] or n_stable_list[i] != n_stable_list[i-1]:
            print(f"  R1={RT_values[i]:.4f}: total={n_total_list[i]}, stable={n_stable_list[i]} "
                  f"(prev: total={n_total_list[i-1]}, stable={n_stable_list[i-1]})")

    # Find the saddle-node more precisely
    print("\nFine scan around 0.47-0.52 (500 points)...")
    RT_fine = np.linspace(0.47, 0.52, 500)
    prev_total = None
    for RT in RT_fine:
        beta1 = beta1_from_RT(RT, P)
        eqs = find_tb_endemic_equilibria(beta1, m, P, n_grid=1200)
        n_total = len(eqs)
        if prev_total is not None and n_total != prev_total:
            print(f"  Change at R1≈{RT:.4f}: total {prev_total} -> {n_total}")
        prev_total = n_total

    # Method 3: Check the seed point
    print("\n--- Method 3: LP curve seed point ---")
    print(f"Seed is at m_min=0.02, solved by least_squares")
    seed = least_squares(
        lambda z: _tb_LP_system(z, 0.02, P),
        x0=np.array([0.05 * P.N0, 0.48]),
        bounds=([1.0e-6, 0.30], [0.99 * P.Lambda / (P.mu + P.d), 1.20]),
        xtol=1.0e-13, ftol=1.0e-13, gtol=1.0e-13, max_nfev=2000,
    )
    I_seed, RT_seed = seed.x
    print(f"  Seed: I={I_seed:.4f}, R1={RT_seed:.6f}")
    print(f"  Seed residual: {np.max(np.abs(_tb_LP_system(seed.x, 0.02, P))):.2e}")

    print("\n" + "=" * 70)


if __name__ == "__main__":
    main()
