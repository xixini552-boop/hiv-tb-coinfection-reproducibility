import json, os
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "output"))
d = json.load(open("j3_continuous_continuation.json", encoding="utf-8"))
print("top keys:", list(d.keys()))
def show(o, ind=0, depth=3):
    if depth < 0: return
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, (dict, list)):
                print("  " * ind + str(k) + ":"); show(v, ind + 1, depth - 1)
            else:
                print("  " * ind + "%s = %s" % (k, str(v)[:90]))
    elif isinstance(o, list):
        print("  " * ind + "[n=%d]" % len(o))
        for row in o:
            print("  " * ind + "  " + str(row)[:150])
show(d)
