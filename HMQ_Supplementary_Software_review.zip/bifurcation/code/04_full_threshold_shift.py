import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location("common", str(Path(__file__).with_name("00_common.py")))
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({name: getattr(common, name) for name in dir(common) if not name.startswith("_")})

def main():
    set_publication_style()

    # R_2 = 1 is included as the limiting point of E_2.
    RH_values = np.linspace(1.0, 3.0, 240)
    RTcrit = np.array([
        critical_isolated_RT_for_invasion(RH, P)
        for RH in RH_values
    ])

    fig, ax = plt.subplots(figsize=(5.75, 3.50))

    ax.plot(
        RH_values,
        RTcrit,
        color="#0F4C81",
        linewidth=2.25,
    )

    ax.axhline(
        1.0,
        color="black",
        linestyle="--",
        linewidth=1.0,
    )

    ax.fill_between(
        RH_values,
        RTcrit,
        1.0,
        where=np.isfinite(RTcrit) & (RTcrit < 1.0),
        color="#FFE066",
        alpha=0.28,
        linewidth=0.0,
        label=r"TB invasion possible with $\mathcal{R}_1<1$",
    )

    ax.set_xlabel(
        r"HIV reproduction number, $\mathcal{R}_2$"
    )
    ax.set_ylabel(
        r"Critical basic reproduction number, "
        r"$\mathcal{R}_1^*$"
    )

    ax.set_xlim(1.0, 3.0)

    ymin = max(0.0, np.nanmin(RTcrit) - 0.03)
    ax.set_ylim(ymin, 1.025)

    ax.grid(
        True,
        color="#E4E4E4",
        linewidth=0.45,
        alpha=0.75,
    )

    ax.legend(
        frameon=False,
        loc="upper right",
    )

    fig.tight_layout()
    save_fig(fig, "fig_04_full_threshold_shift")

if __name__ == "__main__":
    main()
