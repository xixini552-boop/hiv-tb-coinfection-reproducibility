"""
Save key TB-only bifurcation numbers to the correct output directory.
"""

import importlib.util
import sys
import json
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "common",
    str(Path(__file__).with_name("00_common.py"))
)
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({
    name: getattr(common, name)
    for name in dir(common)
    if not name.startswith("_")
})

import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq


def main():
    print("=" * 64)
    print("Saving key TB-only bifurcation numbers")
    print("=" * 64)

    # 1. Compute m_c^TB analytically
    m_c_TB = compute_m_c_TB_analytic(P)
    print(f"\n1. Analytic m_c^TB = {m_c_TB:.10f}")

    # 2. Compute LP curve and interpolate at m=0.05
    print(f"\n2. Computing LP (saddle-node) curve...")
    lp_points = trace_tb_LP_curve_by_I(P, m_min=0.02, I_end=2.0, n_I=360)

    lp_m = np.array([q["m"] for q in lp_points])
    lp_RT = np.array([q["RT"] for q in lp_points])
    order = np.argsort(lp_m)
    lp_m = lp_m[order]
    lp_RT = lp_RT[order]
    keep = np.r_[True, np.diff(lp_m) > 1.0e-10]
    lp_m = lp_m[keep]
    lp_RT = lp_RT[keep]

    lp_interpolant = PchipInterpolator(lp_m, lp_RT, extrapolate=False)
    m_target = 0.05
    saddle_node_R1 = float(lp_interpolant(m_target))
    print(f"   Saddle-node R1 at m={m_target} = {saddle_node_R1:.6f}")

    # 3. Compute Hopf crossing at m=0.05 from a direct stability scan.
    #    No manuscript fallback: the value must come from the model.
    print(f"\n3. Computing Hopf crossing at m={m_target}...")
    RT_fine = np.linspace(0.46, 0.55, 200)
    hopf_R1 = None
    prev_RT = None
    prev_stable = None
    for RT in RT_fine:
        beta1 = beta1_from_RT(RT, P)
        eqs = find_tb_endemic_equilibria(beta1, m_target, P, n_grid=1200)
        n_stable = sum(1 for eq in eqs if tb_stability(eq, beta1, m_target, P)[0])
        if prev_stable is not None and n_stable > prev_stable:
            hopf_R1 = RT
            print(f"   Hopf crossing at R1 = {hopf_R1:.6f}")
            break
        prev_RT, prev_stable = RT, n_stable

    if hopf_R1 is None:
        raise RuntimeError(
            "Hopf crossing not found in [0.46, 0.55]; "
            "the key-number archive must not fall back to the manuscript value."
        )

    # Refine to the grid-independent crossing: the grid point above is only
    # the first point classified stable, so bisect the leading-eigenvalue
    # real part of the upper endemic branch between the last unstable and
    # the first stable grid point.
    def upper_branch_max_real(rt):
        beta1 = beta1_from_RT(rt, P)
        eqs = find_tb_endemic_equilibria(beta1, m_target, P, n_grid=1200)
        if not eqs:
            return float("nan")
        upper = max(eqs, key=lambda eq: eq[2])
        return tb_stability(upper, beta1, m_target, P)[1]

    f_lo = upper_branch_max_real(prev_RT)
    f_hi = upper_branch_max_real(hopf_R1)
    if f_lo > 0.0 > f_hi:
        hopf_R1 = float(brentq(upper_branch_max_real, prev_RT, hopf_R1, xtol=1e-12))
        print(f"   Refined Hopf crossing at R1 = {hopf_R1:.8f}")

    # 4. Save to JSON in output directory
    output_dir = Path(__file__).resolve().parent.parent / "output"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path = output_dir / "tb_only_key_numbers.json"

    result = {
        "preset": PARAMETER_PRESET,
        "m_value": m_target,
        "m_c_TB_analytic": m_c_TB,
        "m_c_TB_rounded": round(m_c_TB, 1),
        "saddle_node_LP": {
            "R1": saddle_node_R1,
            "R1_rounded": round(saddle_node_R1, 3),
            "meaning": "Two endemic equilibria appear/disappear here",
        },
        "hopf_crossing": {
            "R1": hopf_R1,
            "R1_rounded": round(hopf_R1, 3),
            "meaning": "Upper endemic branch becomes stable here",
        },
        "bistable_region": {
            "left_edge": hopf_R1,
            "right_edge": 1.0,
            "meaning": "DFE stable + stable endemic equilibrium coexist",
        },
        "lp_curve_info": {
            "n_points": len(lp_points),
            "m_range": [float(lp_m.min()), float(lp_m.max())],
            "R1_range": [float(lp_RT.min()), float(lp_RT.max())],
            "method": "trace_tb_LP_curve_by_I (I-continuation, 5-pt stencil)",
        },
        "parameter_values": {
            "a0": P.a0,
            "a_max": P.a_max,
            "omega0": P.omega0,
            "omega_min": P.omega_min,
            "mu": P.mu,
            "k": P.k,
            "d": P.d,
            "Lambda": P.Lambda,
        },
    }

    output_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"\n4. Saved to: {output_path}")

    # 5. Summary
    print("\n" + "=" * 64)
    print("SUMMARY")
    print("=" * 64)
    print(f"  m_c^TB:          {m_c_TB:.4f} (rounded: {round(m_c_TB, 1)})")
    print(f"  Saddle-node LP:  {saddle_node_R1:.4f} (rounded: {round(saddle_node_R1, 3)})")
    print(f"  Hopf crossing:   {hopf_R1:.4f} (rounded: {round(hopf_R1, 3)})")
    print(f"  Bistable region: ({round(hopf_R1, 3)}, 1.0)")
    print("=" * 64)


if __name__ == "__main__":
    main()
