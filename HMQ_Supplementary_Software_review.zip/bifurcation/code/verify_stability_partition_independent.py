"""Independent verification of the stability partition (Major Issue 1).

Does NOT trust diag_stability_around_bp1.py's resident index [0,1,3,4,5,7].
Re-derives every block from the 8D Jacobian:
  - TB-only invariant subsystem = S,L,I,T = indices [0,1,2,3]  (matches rhs_tb)
  - HIV transverse core = J1,J2,J3 = indices [4,5,6] = J[4:7,4:7]
  - HIV block incl. downstream AIDS sink = J[4:8,4:8] (check A does not move crossing)
  - full 8D stability
"""
import importlib.util
import sys
from pathlib import Path
import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "mod05", str(here / "05_full_backward_bifurcation_v4_verified.py"))
mod = importlib.util.module_from_spec(spec)
sys.modules["mod05v"] = mod
spec.loader.exec_module(mod)
P = mod.P
RH, M, BETA2 = mod.RH, mod.M, mod.BETA2

TB_IDX = [0, 1, 2, 3]          # correct TB-only invariant subsystem S,L,I,T
DIAG_IDX = [0, 1, 3, 4, 5, 7]  # what the old diagnostic used
HIV_CORE = [4, 5, 6]           # J1,J2,J3 (infectious HIV)
HIV_FULL = [4, 5, 6, 7]        # + A (downstream sink)


def full_J(Q):
    x = mod.tb_only_state(Q)
    if x is None:
        return None, None
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    J = mod.central_numerical_jacobian(
        lambda y: mod.rhs_full(y, beta1, BETA2, M, P), x, ())
    return x, J


def block_max(J, idx):
    return float(np.max(np.real(eigvals(J[np.ix_(idx, idx)]))))


def tb_resident_correct(Q):
    x, J = full_J(Q)
    return np.nan if J is None else block_max(J, TB_IDX)


def tb_resident_diagold(Q):
    x, J = full_J(Q)
    return np.nan if J is None else block_max(J, DIAG_IDX)


def transverse_core(Q):
    x, J = full_J(Q)
    return np.nan if J is None else block_max(J, HIV_CORE)


def transverse_withA(Q):
    x, J = full_J(Q)
    return np.nan if J is None else block_max(J, HIV_FULL)


# --- locate crossings by brentq on fine brackets ---
def locate(fn, lo, hi, label):
    xs = np.linspace(lo, hi, 2001)
    vals = np.array([fn(q) for q in xs])
    cross = None
    for i in range(len(xs) - 1):
        if np.isfinite(vals[i]) and np.isfinite(vals[i+1]) and vals[i]*vals[i+1] < 0:
            cross = brentq(fn, xs[i], xs[i+1], xtol=1e-11)
            break
    print(f"[{label}] zero crossing Q = {cross:.8f}" if cross else f"[{label}] NO crossing in [{lo},{hi}]")
    return cross


print("="*92)
print("Independent stability-partition verification  (R2=%.2f, m=%.2f)" % (RH, M))
print("="*92)

qfold_correct = locate(tb_resident_correct, 0.55, 0.70, "TB resident fold, CORRECT idx [0,1,2,3]")
qfold_diagold = locate(tb_resident_diagold, 0.55, 0.70, "TB resident fold, OLD diag idx [0,1,3,4,5,7]")
bp1_core = locate(transverse_core, 0.60, 0.75, "HIV transverse crossing, core [4:7,4:7]")
bp1_withA = locate(transverse_withA, 0.60, 0.75, "HIV transverse crossing, incl A [4:8,4:8]")
bp1_func = mod.locate_tb_hiv_branch_point()["Q"]
print(f"locate_tb_hiv_branch_point() (used in paper)        Q = {bp1_func:.8f}")
print()

hdr = f"{'Q':>7} | {'TB4(correct)':>12} | {'diag6(old)':>10} | {'HIV3 core':>10} | {'HIV4+A':>10} | {'full8 maxRe':>11} | full8 stable?"
print(hdr); print("-"*len(hdr))
for Q in [0.58, 0.60, 0.6142, 0.64, 0.6643, 0.70, 0.80, 0.90, 0.95, 0.99, 1.0, 1.055]:
    x, J = full_J(Q)
    if J is None:
        print(f"{Q:7.4f} | no TB-only upper root"); continue
    tb4 = block_max(J, TB_IDX); d6 = block_max(J, DIAG_IDX)
    h3 = block_max(J, HIV_CORE); h4 = block_max(J, HIV_FULL)
    f8 = float(np.max(np.real(eigvals(J))))
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    stab, mr, _ = mod.full_stability(x, beta1, BETA2, M, P)
    print(f"{Q:7.4f} | {tb4:12.5f} | {d6:10.5f} | {h3:10.5f} | {h4:10.5f} | {f8:11.5f} | {stab}")

# --- E2 (TB-free HIV-endemic) TB-invasion stability vs Q ---
print()
print("E2 TB-free HIV-endemic full stability (loses TB-stability at R_1^2=1?):")
for Q in [0.8, 0.95, 0.99, 1.0, 1.01, 1.055]:
    x = mod.full_tb_free_equilibrium(RH, P)
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    stab, mr, _ = mod.full_stability(x, beta1, BETA2, M, P)
    print(f"  Q={Q:6.4f}  E2 full maxRe={mr:+.5f}  stable={stab}")
