import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "common",
    str(Path(__file__).with_name("00_common.py"))
)
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({
    name: getattr(common, name)
    for name in dir(common)
    if not name.startswith("_")
})

from matplotlib.lines import Line2D
from scipy.interpolate import PchipInterpolator


def plot_folded_unstable_branch(
    ax,
    pts,
    color,
    linestyle=(0, (5.8, 3.2)),
    linewidth=2.3,
    label=None,
    zorder=4,
):
    """
    Plot the folded unstable branch using burden as the continuation variable.

    For a backward bifurcation, the unstable branch near the fold is not always
    well represented as burden = f(R_T). Using burden as the ordering variable
    avoids an artificial sharp corner near the turning region.
    """
    arr = np.asarray(pts, dtype=float)

    if len(arr) < 4:
        ax.plot(
            arr[:, 0],
            arr[:, 1],
            color=color,
            linestyle=linestyle,
            linewidth=linewidth,
            label=label,
            zorder=zorder,
            antialiased=True,
            dash_capstyle="round",
            dash_joinstyle="round",
        )
        return

    mask = np.isfinite(arr[:, 0]) & np.isfinite(arr[:, 1])
    arr = arr[mask]

    if len(arr) < 4:
        ax.plot(
            arr[:, 0],
            arr[:, 1],
            color=color,
            linestyle=linestyle,
            linewidth=linewidth,
            label=label,
            zorder=zorder,
            antialiased=True,
            dash_capstyle="round",
            dash_joinstyle="round",
        )
        return

    # Order the folded branch by burden instead of by R_T.
    order = np.argsort(arr[:, 1])
    x = arr[order, 0]
    y = arr[order, 1]

    # Remove duplicated burden values by averaging their R_T values.
    y_unique, inverse, counts = np.unique(
        y,
        return_inverse=True,
        return_counts=True,
    )

    x_unique = np.zeros_like(y_unique)
    np.add.at(x_unique, inverse, x)
    x_unique /= counts

    if len(y_unique) < 4:
        ax.plot(
            x_unique,
            y_unique,
            color=color,
            linestyle=linestyle,
            linewidth=linewidth,
            label=label,
            zorder=zorder,
            antialiased=True,
            dash_capstyle="round",
            dash_joinstyle="round",
        )
        return

    # Shape-preserving interpolation. This is smoother than connecting raw
    # points but avoids spline overshoot near the fold.
    y_smooth = np.linspace(y_unique.min(), y_unique.max(), 1400)
    x_smooth = PchipInterpolator(y_unique, x_unique)(y_smooth)

    ax.plot(
        x_smooth,
        y_smooth,
        color=color,
        linestyle=linestyle,
        linewidth=linewidth,
        label=label,
        zorder=zorder,
        antialiased=True,
        dash_capstyle="round",
        dash_joinstyle="round",
    )


def main():
    set_publication_style()

    m = 0.05

    RT_values = np.unique(
        np.concatenate(
            [
                np.linspace(0.40, 1.35, max(TB_RT_POINTS, 520)),
                np.linspace(0.475, 0.520, 1800),
            ]
        )
    )

    records = []
    ymax = 0.01

    print("Scanning TB-only bifurcation...")

    for RT in RT_values:
        beta1 = beta1_from_RT(RT, P)
        eqs = find_tb_endemic_equilibria(
            beta1,
            m,
            P,
            n_grid=max(TB_ROOT_GRID, 900),
        )

        for eq in eqs:
            burden = eq[2] / np.sum(eq)
            stable, max_real, eigs = tb_stability(eq, beta1, m, P)
            records.append((RT, burden, stable))
            ymax = max(ymax, burden * 1.12)

    fig, ax = plt.subplots(figsize=(5.85, 3.9))

    # Disease-free equilibrium branch
    x_left = np.linspace(RT_values.min(), 1.0, 600)
    x_right = np.linspace(1.0, RT_values.max(), 600)

    ax.plot(
        x_left,
        np.zeros_like(x_left),
        color="#1565C0",
        linewidth=2.3,
        zorder=2,
        solid_capstyle="round",
        solid_joinstyle="round",
        antialiased=True,
    )

    ax.plot(
        x_right,
        np.zeros_like(x_right),
        color="#B71C1C",
        linestyle=(0, (5.8, 3.2)),
        linewidth=2.25,
        zorder=2,
        dash_capstyle="round",
        dash_joinstyle="round",
        antialiased=True,
    )

    ax.axvline(
        1.0,
        color="black",
        linestyle="--",
        linewidth=1.0,
        zorder=1,
    )

    # Endemic branches
    stable_pts = [(r, y) for r, y, st in records if st and y > 1e-8]
    unstable_pts = [(r, y) for r, y, st in records if (not st) and y > 1e-8]

    if stable_pts:
        xs = np.array([p[0] for p in stable_pts], dtype=float)
        ys = np.array([p[1] for p in stable_pts], dtype=float)

        plot_smooth_branch(
            ax,
            xs,
            ys,
            color="#2E7D32",
            linestyle="-",
            linewidth=2.6,
            label="stable endemic equilibrium",
            zorder=4,
        )

        ax.scatter(
            xs,
            ys,
            color="#2E7D32",
            s=3,
            alpha=0.05,
            edgecolors="none",
            zorder=5,
        )

    if unstable_pts:
        plot_folded_unstable_branch(
            ax,
            unstable_pts,
            color="#E65100",
            linestyle=(0, (5.8, 3.2)),
            linewidth=2.3,
            label="unstable endemic equilibrium",
            zorder=4,
        )

    # Make all lines visually rounder
    for line in ax.lines:
        line.set_antialiased(True)
        line.set_solid_capstyle("round")
        line.set_solid_joinstyle("round")
        line.set_dash_capstyle("round")
        line.set_dash_joinstyle("round")

    legend_handles = [
        Line2D(
            [0],
            [0],
            color="#1565C0",
            linewidth=2.3,
            label=r"stable DFE ($\mathcal{R}_1<1$)",
        ),
        Line2D(
            [0],
            [0],
            color="#B71C1C",
            linestyle=(0, (5.8, 3.2)),
            linewidth=2.25,
            label=r"unstable DFE ($\mathcal{R}_1>1$)",
        ),
    ]

    if stable_pts:
        legend_handles.append(
            Line2D(
                [0],
                [0],
                color="#2E7D32",
                linewidth=2.6,
                label="stable endemic equilibrium",
            )
        )

    if unstable_pts:
        legend_handles.append(
            Line2D(
                [0],
                [0],
                color="#E65100",
                linestyle=(0, (5.8, 3.2)),
                linewidth=2.3,
                label="unstable endemic equilibria",
            )
        )

    ax.set_xlabel(r"TB reproduction number, $\mathcal{R}_1$")
    ax.set_ylabel(r"TB-only active burden, $I^*/N^*$")

    # Annotate m value
    ax.text(0.97, 0.92, r"$m = 0.05$", transform=ax.transAxes,
            fontsize=10, ha="right", va="top", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white",
                      edgecolor="#CCCCCC", alpha=0.85))

    ax.set_xlim(RT_values.min(), RT_values.max())
    ax.set_ylim(-0.025 * ymax, ymax)

    ax.grid(
        True,
        color="#E4E4E4",
        linewidth=0.45,
        alpha=0.75,
    )

    ax.legend(
        handles=legend_handles,
        frameon=False,
        loc="best",
    )

    fig.tight_layout()
    save_fig(fig, "fig_02_TB_only_backward")


if __name__ == "__main__":
    main()
