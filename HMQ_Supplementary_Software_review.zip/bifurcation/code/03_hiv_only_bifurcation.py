import importlib.util
import sys
from pathlib import Path

_spec = importlib.util.spec_from_file_location("common", str(Path(__file__).with_name("00_common.py")))
common = importlib.util.module_from_spec(_spec)
sys.modules["common"] = common
_spec.loader.exec_module(common)
globals().update({name: getattr(common, name) for name in dir(common) if not name.startswith("_")})

def main():
    set_publication_style()

    RH_values = np.linspace(0.3, 2.8, 350)
    J_prev = []
    A_prev = []

    for RH in RH_values:
        S, J1, A = hiv_endemic_equilibrium(RH, P)
        N = S + J1 + A
        J_prev.append(J1 / N)
        A_prev.append(A / N)

    fig, ax = plt.subplots(figsize=(5.6, 3.75))
    ax.plot(RH_values, J_prev, color="#0F4C81", linewidth=2.2, label=r"HIV-only infected, $J_1^*/N_2^*$")
    ax.plot(RH_values, A_prev, color="#C41E3A", linestyle="--", linewidth=2.0, label=r"AIDS stage, $A_2^*/N_2^*$")
    ax.axvline(1.0, color="black", linestyle="--", linewidth=1.0)
    ax.text(1.0, 0.04, r"$\mathcal{R}_2=1$" "\n" "(forward threshold)", fontsize=7.8,
            ha="right", va="bottom",
            bbox=dict(facecolor="white", edgecolor="#CCCCCC", alpha=0.85, pad=3))

    ax.set_xlabel(r"HIV reproduction number, $\mathcal{R}_2$")
    ax.set_ylabel("Equilibrium prevalence")
    ax.set_xlim(RH_values.min(), RH_values.max())
    ax.set_ylim(bottom=0)
    ax.grid(True, color="#E4E4E4", linewidth=0.45, alpha=0.75)
    ax.legend(frameon=False, loc="lower right")

    fig.tight_layout()
    save_fig(fig, "fig_03_HIV_only_forward")

if __name__ == "__main__":
    main()
