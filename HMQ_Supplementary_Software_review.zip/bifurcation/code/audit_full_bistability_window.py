"""Deterministic multistart audit inside the reported full-system window.

The audit is deliberately separate from the principal-branch reconstruction.
It searches the window Q in (Q_BP1, 1) from a fixed collection of boundary,
continuation, mixed-disease, and deterministic random initial states.  Every
accepted root is checked with the full eight-dimensional Jacobian spectrum.

This is an auditable finite search, not a proof of global uniqueness.
"""

from __future__ import annotations

import csv
import importlib.util
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.optimize import least_squares


ROOT = Path(__file__).resolve().parents[2]
COMMON_PATH = ROOT / "bifurcation" / "code" / "00_common.py"
FULL_PATH = ROOT / "bifurcation" / "code" / "05_full_backward_bifurcation_v4_verified.py"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# The full-branch module imports and registers the shared ``common`` module.
full = load_module("full_bifurcation_audit", FULL_PATH)
common = sys.modules["common"]

RH = float(full.RH)
M = float(full.M)
ROOT_TOL = 1.0e-7
POSITIVE_BURDEN = 1.0e-7
HIV_INTERIOR_TOL = 1.0e-5
SEED_DEDUP_TOL = 1.0e-8
ROOT_DEDUP_TOL = 2.0e-4


def state_distance(x: np.ndarray, y: np.ndarray) -> float:
    return float(np.linalg.norm((np.asarray(x) - np.asarray(y)) / common.P.N0))


def append_seed(seeds: list[np.ndarray], seed: np.ndarray) -> None:
    """Add a finite nonnegative seed unless it duplicates an earlier seed."""
    x = np.asarray(seed, dtype=float)
    if x.shape != (8,) or not np.all(np.isfinite(x)):
        return
    x = np.maximum(x, 0.0)
    if any(state_distance(x, old) < SEED_DEDUP_TOL for old in seeds):
        return
    seeds.append(x)


def basin_seed(b: float, h: float) -> np.ndarray:
    """Construct the deterministic TB/HIV mixed seed used for basin plots."""
    n0 = common.P.N0
    x = np.zeros(8, dtype=float)
    x[2] = 0.7 * b * n0
    x[6] = 0.3 * b * n0
    x[1] = 0.5 * b * n0
    x[4] = 0.6 * h * n0
    x[5] = 0.3 * h * n0
    x[7] = 0.1 * h * n0
    x[0] = n0 - np.sum(x[1:])
    if x[0] < 10.0:
        positive = np.sum(x[1:])
        if positive > 0.0:
            x[1:] *= (n0 - 10.0) / positive
        x[0] = 10.0
    return x


def window_seeds(
    q: float,
    previous_roots: List[np.ndarray],
    rng: np.random.Generator,
) -> List[np.ndarray]:
    """Build the fixed, auditable multistart set for one Q slice."""
    beta1 = common.beta1_from_RTH(q, RH, common.P)
    beta2 = common.beta2_from_RH(RH, common.P)
    seeds: List[np.ndarray] = []

    # Disease-free/HIV boundary and the three standard full-system seeds.
    append_seed(seeds, common.full_tb_free_equilibrium(RH, common.P))
    for kind in ("low", "moderate", "high"):
        append_seed(seeds, common.full_initial_condition(RH, common.P, kind))

    # Every TB-only equilibrium found by the scalar boundary solver.
    tb_roots = common.find_tb_endemic_equilibria(
        beta1, M, common.P, n_grid=max(800, common.TB_ROOT_GRID)
    )
    for tb in tb_roots:
        x = np.zeros(8, dtype=float)
        x[:4] = tb
        append_seed(seeds, x)

    # Continuation seeds from the previous Q slice.
    for root in previous_roots:
        append_seed(seeds, root)

    # Mixed-disease states spanning low, intermediate, and high burdens.
    for b in (0.001, 0.01, 0.03, 0.10, 0.25):
        for h in (0.001, 0.03, 0.10, 0.25):
            append_seed(seeds, basin_seed(b, h))

    # Convex combinations of the two detected boundary states.
    e2 = common.full_tb_free_equilibrium(RH, common.P)
    for tb in tb_roots:
        tb_full = np.zeros(8, dtype=float)
        tb_full[:4] = tb
        for weight in (0.1, 0.3, 0.5, 0.7, 0.9):
            append_seed(seeds, (1.0 - weight) * e2 + weight * tb_full)

    # Fixed pseudo-random compositions provide a reproducible spread that is
    # not tied to the hand-designed basin grid.
    for _ in range(12):
        composition = rng.dirichlet(np.full(8, 0.7))
        x = composition * common.P.N0
        if common.P.N0 - x[2] - x[6] - x[7] <= 1.0:
            continue
        append_seed(seeds, x)

    return seeds


def strict_root(
    seed: np.ndarray, beta1: float, beta2: float
) -> Tuple[Optional[np.ndarray], Dict]:
    """Solve one equilibrium and apply the manuscript's strict audit rule."""
    lower = np.zeros(8, dtype=float)
    upper = np.full(8, 2.5 * common.P.N0, dtype=float)
    seed = np.clip(np.asarray(seed, dtype=float), lower + 1.0e-10, upper)
    meta = {
        "optimizer_success": False,
        "optimizer_status": None,
        "optimizer_nfev": None,
        "residual": np.inf,
        "failure_reason": None,
        "solver_x_scale": None,
    }
    best_fit = None
    best_x = None
    best_residual = np.inf
    best_scale = None
    last_exception = None
    for x_scale in ("jac", 1.0):
        try:
            fit = least_squares(
                lambda y: common.full_residual_scaled(
                    y, beta1, beta2, M, common.P
                ),
                seed,
                bounds=(lower, upper),
                xtol=1.0e-12,
                ftol=1.0e-12,
                gtol=1.0e-12,
                max_nfev=max(1800, common.FULL_ROOT_MAX_NFEV),
                x_scale=x_scale,
            )
        except Exception as exc:  # pragma: no cover - diagnostic path
            last_exception = exc
            continue
        candidate_x = np.maximum(np.asarray(fit.x, dtype=float), 0.0)
        candidate_residual = float(np.linalg.norm(
            common.full_residual_scaled(
                candidate_x, beta1, beta2, M, common.P
            )
        ))
        if candidate_residual < best_residual:
            best_fit = fit
            best_x = candidate_x
            best_residual = candidate_residual
            best_scale = x_scale
        if candidate_residual < ROOT_TOL:
            break

    if best_fit is None or best_x is None:
        meta["failure_reason"] = (
            f"exception:{type(last_exception).__name__}"
            if last_exception is not None else "solver_failure"
        )
        return None, meta

    x = best_x
    residual = best_residual
    meta.update({
        "optimizer_success": bool(best_fit.success),
        "optimizer_status": int(best_fit.status),
        "optimizer_nfev": int(best_fit.nfev),
        "residual": residual,
        "solver_x_scale": (
            best_scale if isinstance(best_scale, str) else "one"
        ),
    })
    if not np.all(np.isfinite(x)) or not np.isfinite(residual):
        meta["failure_reason"] = "nonfinite"
        return None, meta
    if residual >= ROOT_TOL:
        meta["failure_reason"] = "residual"
        return None, meta
    meta["failure_reason"] = "accepted"
    return x, meta


def root_record(q: float, x: np.ndarray, residual: float, beta1: float, beta2: float) -> dict:
    stable, max_real, eigs = common.full_stability(x, beta1, beta2, M, common.P)
    eigs = np.asarray(eigs, dtype=complex)
    return {
        "Q": float(q),
        "eq_class": str(common.full_equilibrium_class(
            x, tb_tol=POSITIVE_BURDEN, hiv_tol=HIV_INTERIOR_TOL
        )),
        "burden": float(common.active_tb_burden_full(x)),
        "hiv_fraction": float(common.hiv_burden_full(x)),
        "residual": float(residual),
        "stable": bool(stable),
        "max_real": float(max_real),
        "unstable_eigenvalue_count": int(np.sum(np.real(eigs) > 1.0e-6)),
        "near_zero_eigenvalue_count": int(np.sum(np.abs(np.real(eigs)) <= 1.0e-6)),
        "eigenvalues": [[float(z.real), float(z.imag)] for z in eigs],
        "state": [float(v) for v in np.asarray(x, dtype=float)],
    }


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--n-q", type=int, default=80)
    parser.add_argument("--seed", type=int, default=20260930)
    parser.add_argument("--q-eps", type=float, default=1.0e-4)
    parser.add_argument("--q-upper", type=float, default=0.999)
    args = parser.parse_args()

    bp = full.locate_tb_hiv_branch_point()
    q_lower = float(bp["Q"] + args.q_eps)
    q_values = np.linspace(q_lower, args.q_upper, args.n_q)
    rng = np.random.default_rng(args.seed)
    beta2 = common.beta2_from_RH(RH, common.P)

    attempts: List[dict] = []
    roots: List[dict] = []
    summaries: List[dict] = []
    previous_roots: List[np.ndarray] = []

    for q_index, q in enumerate(q_values):
        beta1 = common.beta1_from_RTH(float(q), RH, common.P)
        seeds = window_seeds(float(q), previous_roots, rng)
        accepted_states: List[np.ndarray] = []
        q_attempts = 0
        q_failures = 0
        q_duplicate_hits = 0
        q_accepted = 0

        for seed_index, seed in enumerate(seeds):
            q_attempts += 1
            x, meta = strict_root(seed, beta1, beta2)
            attempt = {
                "q_index": int(q_index),
                "Q": float(q),
                "seed_index": int(seed_index),
                "seed_total": int(len(seeds)),
                "optimizer_success": bool(meta["optimizer_success"]),
                "optimizer_status": meta["optimizer_status"],
                "optimizer_nfev": meta["optimizer_nfev"],
                "solver_x_scale": meta["solver_x_scale"],
                "residual": float(meta["residual"]),
                "accepted": False,
                "duplicate": False,
                "failure_reason": meta["failure_reason"],
                "eq_class": "",
                "burden": np.nan,
                "hiv_fraction": np.nan,
                "max_real": np.nan,
                "unstable_eigenvalue_count": np.nan,
            }
            if x is None:
                q_failures += 1
                attempts.append(attempt)
                continue

            record = root_record(float(q), x, meta["residual"], beta1, beta2)
            duplicate = any(
                state_distance(x, old) < ROOT_DEDUP_TOL
                for old in accepted_states
            )
            attempt.update({
                "eq_class": record["eq_class"],
                "burden": record["burden"],
                "hiv_fraction": record["hiv_fraction"],
                "max_real": record["max_real"],
                "unstable_eigenvalue_count": record["unstable_eigenvalue_count"],
                "duplicate": bool(duplicate),
                "accepted": True,
                "failure_reason": "duplicate" if duplicate else "accepted",
            })
            attempts.append(attempt)
            if duplicate:
                q_duplicate_hits += 1
                continue
            accepted_states.append(x)
            record["q_index"] = int(q_index)
            record["root_index"] = int(len(accepted_states) - 1)
            roots.append(record)
            q_accepted += 1

        previous_roots = accepted_states
        q_records = [r for r in roots if r["q_index"] == q_index]
        class_counts: dict[str, int] = {}
        stable_class_counts: dict[str, int] = {}
        for record in q_records:
            cls = record["eq_class"]
            class_counts[cls] = class_counts.get(cls, 0) + 1
            if record["stable"]:
                stable_class_counts[cls] = stable_class_counts.get(cls, 0) + 1
        summaries.append({
            "q_index": int(q_index),
            "Q": float(q),
            "n_seeds": int(len(seeds)),
            "n_attempts": int(q_attempts),
            "n_failures": int(q_failures),
            "n_duplicate_hits": int(q_duplicate_hits),
            "n_unique_roots": int(q_accepted),
            "class_counts": class_counts,
            "stable_class_counts": stable_class_counts,
            "stable_co_endemic_count": int(
                sum(
                    1 for r in q_records
                    if r["stable"] and r["eq_class"] == "co_endemic"
                )
            ),
        })
        print(
            f"[{q_index + 1:03d}/{len(q_values):03d}] Q={q:.8f} "
            f"seeds={len(seeds)} roots={q_accepted} failures={q_failures}",
            flush=True,
        )

    outdir = ROOT / "bifurcation" / "output"
    outdir.mkdir(parents=True, exist_ok=True)
    metadata = {
        "description": (
            "Deterministic multistart audit of the reported full-system "
            "boundary-bistability window"
        ),
        "RH": RH,
        "m": M,
        "Q_BP1": float(bp["Q"]),
        "Q_interval": [q_lower, float(args.q_upper)],
        "n_q": int(args.n_q),
        "seed": int(args.seed),
        "root_residual_cutoff": ROOT_TOL,
        "root_duplicate_cutoff_scaled": ROOT_DEDUP_TOL,
        "positive_tb_burden_cutoff": POSITIVE_BURDEN,
        "strict_hiv_fraction_cutoff": HIV_INTERIOR_TOL,
        "seed_families": [
            "TB-free HIV-endemic equilibrium",
            "standard low/moderate/high full-system states",
            "all scalar TB-only boundary roots",
            "roots accepted at the preceding Q slice",
            "5 x 4 deterministic mixed-disease basin seeds",
            "5 convex combinations of HIV and TB boundary states per TB root",
            "12 fixed-seed Dirichlet compositions",
        ],
        "interpretation": (
            "Finite deterministic search; absence of an additional root is "
            "not a global uniqueness proof."
        ),
        "n_attempts": len(attempts),
        "n_accepted_records": len(roots),
        "n_summaries": len(summaries),
    }
    payload = {
        "metadata": metadata,
        "summaries": summaries,
        "roots": roots,
    }
    (outdir / "full_backward_window_audit.json").write_text(
        json.dumps(payload, indent=2, allow_nan=False),
        encoding="utf-8",
    )

    root_fields = [
        "q_index", "root_index", "Q", "eq_class", "burden",
        "hiv_fraction", "residual", "stable", "max_real",
        "unstable_eigenvalue_count", "near_zero_eigenvalue_count",
    ]
    with (outdir / "full_backward_window_audit_roots.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=root_fields)
        writer.writeheader()
        for record in roots:
            writer.writerow({key: record[key] for key in root_fields})

    attempt_fields = [
        "q_index", "Q", "seed_index", "seed_total", "optimizer_success",
        "optimizer_status", "optimizer_nfev", "solver_x_scale", "residual", "accepted",
        "duplicate", "failure_reason", "eq_class", "burden",
        "hiv_fraction", "max_real", "unstable_eigenvalue_count",
    ]
    with (outdir / "full_backward_window_audit_attempts.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=attempt_fields)
        writer.writeheader()
        for record in attempts:
            writer.writerow({key: record[key] for key in attempt_fields})

    summary_fields = [
        "q_index", "Q", "n_seeds", "n_attempts", "n_failures",
        "n_duplicate_hits", "n_unique_roots", "stable_co_endemic_count",
        "class_counts", "stable_class_counts",
    ]
    with (outdir / "full_backward_window_audit_summary.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=summary_fields)
        writer.writeheader()
        for record in summaries:
            row = dict(record)
            row["class_counts"] = json.dumps(row["class_counts"], sort_keys=True)
            row["stable_class_counts"] = json.dumps(
                row["stable_class_counts"], sort_keys=True
            )
            writer.writerow({key: row[key] for key in summary_fields})

    stable_co = [
        r for r in roots
        if r["stable"] and r["eq_class"] == "co_endemic"
    ]
    print(
        f"Audit complete: Q=[{q_lower:.8f}, {args.q_upper:.8f}], "
        f"attempts={len(attempts)}, unique roots={len(roots)}, "
        f"stable co-endemic roots={len(stable_co)}",
        flush=True,
    )


if __name__ == "__main__":
    main()
