"""
Left-edge BP1 (HIV-invasion branch point of TB boundary) vs m extension table.

Computes the boundary bistability window left edge for multiple m values
under the baseline withdrawal-assumption mixing. For each m, locates Q_BP1
where the transverse HIV-invasion eigenvalue crosses zero along the
TB-only boundary. Also records the TB burden at BP1.

Output: ../output/bp1_vs_m_extension.json
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(spec)
sys.modules["common"] = common
spec.loader.exec_module(common)
for _name in dir(common):
    if not _name.startswith("_"):
        globals()[_name] = getattr(common, _name)

P = common.P
RH = 1.8
BETA2 = common.beta2_from_RH(RH, P)
M_VALUES = [0.05, 0.1, 0.2, 0.5, 1.0, 2.0, 3.0, 5.0]
OUT = HERE.parent / "output"
OUT.mkdir(parents=True, exist_ok=True)


def central_jacobian(x, beta1, beta2, m, eps=1e-6):
    n = len(x)
    J = np.zeros((n, n))
    f0 = common.rhs_full(x, beta1, beta2, m)
    for i in range(n):
        xp = x.copy()
        xp[i] += eps
        J[:, i] = (common.rhs_full(xp, beta1, beta2, m) - f0) / eps
    return J


def tb_only_state_m(Q, m):
    """Upper TB-only equilibrium at given Q and m."""
    beta1 = common.beta1_from_RTH(float(Q), RH, P)
    roots = common.find_tb_endemic_equilibria(beta1, m, P, n_grid=800)
    if not roots:
        return None
    tb = max(roots, key=lambda y: y[2] / np.sum(y))
    x = np.zeros(8, dtype=float)
    x[:4] = tb
    return x


def transverse_growth_m(Q, m):
    """Largest HIV-invasion eigenvalue along TB-only boundary."""
    x = tb_only_state_m(Q, m)
    if x is None:
        return np.nan
    beta1 = common.beta1_from_RTH(float(Q), RH, P)
    J = central_jacobian(x, beta1, BETA2, m)
    return float(np.max(np.real(eigvals(J[4:7, 4:7]))))


def find_bp1(m, q_lo=0.55, q_hi=1.05):
    """Locate BP1 for given m by transverse eigenvalue crossing."""
    grid = np.linspace(q_lo, q_hi, 60)
    growth = [transverse_growth_m(q, m) for q in grid]
    bracket = None
    for i in range(len(grid) - 1):
        g0, g1 = growth[i], growth[i+1]
        if np.isfinite(g0) and np.isfinite(g1) and g0 * g1 < 0:
            bracket = (grid[i], grid[i+1])
            break
    if bracket is None:
        # Try wider range
        grid2 = np.linspace(0.4, 1.15, 80)
        growth2 = [transverse_growth_m(q, m) for q in grid2]
        for i in range(len(grid2) - 1):
            g0, g1 = growth2[i], growth2[i+1]
            if np.isfinite(g0) and np.isfinite(g1) and g0 * g1 < 0:
                bracket = (grid2[i], grid2[i+1])
                break
    if bracket is None:
        return None, None
    Q_bp = float(brentq(lambda q: transverse_growth_m(q, m), *bracket,
                        xtol=1e-10, rtol=1e-10))
    x_bp = tb_only_state_m(Q_bp, m)
    burden = None
    if x_bp is not None:
        N = np.sum(x_bp)
        burden = float((x_bp[2] + x_bp[6]) / N) if N > 0 else None
    return Q_bp, burden


def main():
    print("=== BP1 (left edge) vs m extension ===", flush=True)
    print(f"RH={RH}, beta2={BETA2:.6f}", flush=True)
    results = []
    for m in M_VALUES:
        Q_bp, burden = find_bp1(m)
        width = 1.0 - Q_bp if Q_bp is not None else None
        rec = {
            "m": m,
            "Q_BP1": Q_bp,
            "TB_burden_at_BP1": burden,
            "window_width": width,
            "right_edge": 1.0,
            # Explicit flag: a negative window_width means BP1 has moved past the
            # right edge, i.e. the boundary-bistability window is closed at this m.
            "window_closed": bool(Q_bp is not None and Q_bp > 1.0),
        }
        results.append(rec)
        print(f"  m={m:5.2f}: BP1 Q={Q_bp if Q_bp else 'NOT FOUND':>10}, "
              f"burden={burden if burden else 'N/A':>8}, "
              f"width={width if width else 'N/A':>8}", flush=True)

    # Compare with known values
    print(f"\nReference: m=0.05 BP1=0.664254, m=2.0 BP1=0.876 (from main text)",
          flush=True)

    # Relative shift from m=0.05
    base = results[0]["Q_BP1"]
    if base:
        print(f"\nRelative to m=0.05 (Q={base:.6f}):", flush=True)
        for r in results:
            if r["Q_BP1"]:
                shift = (r["Q_BP1"] / base - 1) * 100
                print(f"  m={r['m']:5.2f}: {shift:+6.1f}%", flush=True)

    outpath = OUT / "bp1_vs_m_extension.json"
    with open(outpath, "w") as f:
        json.dump({"RH": RH, "mixing": "withdrawal (baseline)",
                   "m_values": results}, f, indent=2)
    print(f"\nSaved: {outpath}", flush=True)


if __name__ == "__main__":
    main()
