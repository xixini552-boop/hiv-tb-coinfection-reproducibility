"""Cross-check resident fold directly with the 4D TB-only subsystem rhs_tb.

The HIV-free boundary is an invariant manifold; its resident (longitudinal)
stability must equal the stability of the 4D TB-only model (S,L,I,T).  We
therefore find the TB-only saddle-node independently via rhs_tb, map its
beta1 to Q=R_1^2 at fixed R2, and compare to 0.62111701.
"""
import importlib.util
import sys
from pathlib import Path
import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "mod05b", str(here / "05_full_backward_bifurcation_v4_verified.py"))
mod = importlib.util.module_from_spec(spec)
sys.modules["mod05b"] = mod
spec.loader.exec_module(mod)
P = mod.P
RH, M, BETA2 = mod.RH, mod.M, mod.BETA2
cm = mod


def tb4_maxreal_from_Q(Q):
    """Upper TB-only equilibrium, stability from the standalone 4D rhs_tb."""
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    roots = mod.find_tb_endemic_equilibria(beta1, M, P, n_grid=4000)
    if not roots:
        return np.nan
    upper = max(roots, key=lambda y: y[2] / np.sum(y))
    J4 = mod.numerical_jacobian(
        lambda y, b, mm, pp: mod.rhs_tb(y, b, mm, pp), upper, (beta1, M, P))
    return float(np.max(np.real(eigvals(J4))))


# locate the 4D-TB-only saddle-node on the UPPER branch
qs = np.linspace(0.55, 0.70, 3001)
vals = np.array([tb4_maxreal_from_Q(q) for q in qs])
cross = None
for i in range(len(qs) - 1):
    if np.isfinite(vals[i]) and np.isfinite(vals[i+1]) and vals[i]*vals[i+1] < 0:
        cross = brentq(tb4_maxreal_from_Q, qs[i], qs[i+1], xtol=1e-12)
        break
print(f"4D rhs_tb upper-branch saddle-node at Q = {cross:.8f}")

# Also count TB-only equilibria either side to confirm fold (2 roots -> 1)
for Q in [cross-0.01, cross, cross+0.01]:
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    roots = mod.find_tb_endemic_equilibria(beta1, M, P, n_grid=4000)
    burdens = sorted(y[2]/np.sum(y) for y in roots)
    print(f"  Q={Q:.5f}: {len(roots)} TB-only equilibria, I/N burdens={np.round(burdens,5)}")
