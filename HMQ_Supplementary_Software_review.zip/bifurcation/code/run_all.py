"""Regenerate every manuscript-cited figure, table, and diagnostic.

Run from this directory so that the shared module 00_common.py is imported
correctly.  Scripts run in dependency order and the run stops at the first
failure.  The list covers every script that writes an archived output cited by
the manuscript or the supplementary material; interactive probes
(_probe_j3.py) and the superseded first-generation key-number script
(99_save_key_numbers.py) are excluded on purpose.
"""

import subprocess
import sys
from pathlib import Path

# Manuscript figures and the analytic / one-parameter bifurcation analysis.
FIGURE_SCRIPTS = [
    "01_response_curves.py",
    "02_tb_only_bifurcation.py",
    "03_hiv_only_bifurcation.py",
    "04_full_threshold_shift.py",
    "05_full_backward_bifurcation_v4_verified.py",
    "m1_epidemiological_range_scan.py",
    "10_extended_bifurcation.py",
    "14_mechanism_controls.py",
]

# Supplementary controls, validations, and audits that write archived output.
SUPPLEMENT_SCRIPTS = [
    "esm_j3_treatment_control.py",
    "12_j3_continuous_continuation.py",
    "11_augmented_fold_validation.py",
    "bp1_m_sensitivity.py",
    "bp1_vs_m_extension.py",
    "b1_fold_R1sq_vs_m.py",
    "rn_full_system_slice.py",
    "window_check_r2.py",
    "prcc_response_sensitivity.py",
    "basin_partitioning.py",
    "fig_basin_trajectories.py",
    "audit_full_bistability_window.py",
    "99_save_key_numbers_v2.py",
]

root = Path(__file__).resolve().parent


def run(scripts):
    for script in scripts:
        print("=" * 72)
        print(f"Running {script}")
        print("=" * 72)
        result = subprocess.run([sys.executable, str(root / script)], cwd=str(root))
        if result.returncode != 0:
            raise SystemExit(f"{script} failed with exit code {result.returncode}")


if __name__ == "__main__":
    figures_only = "--figures-only" in sys.argv[1:]
    run(FIGURE_SCRIPTS)
    if figures_only:
        print("All article figures finished (supplementary scripts skipped).")
    else:
        run(SUPPLEMENT_SCRIPTS)
        print("All article figures, supplementary controls, and audits finished.")
