"""Map the TB-only boundary fold onto the resident-HIV TB-invasion number.

Traces the validated TB-only saddle-node curve with ``trace_tb_LP_curve_by_I``
and evaluates the TB-invasion number ``RTH_for_beta1`` at the resident
HIV-endemic state (R2 = 1.8), giving the m <-> R1^2 correspondence quoted in
the supplementary section on the mechanism controls.

Output: bifurcation/output/b1_fold_R1sq_vs_m.json
"""

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

SPEC = importlib.util.spec_from_file_location(
    "common", str(Path(__file__).with_name("00_common.py"))
)
COMMON = importlib.util.module_from_spec(SPEC)
sys.modules["common"] = COMMON
SPEC.loader.exec_module(COMMON)

OUT_PATH = Path(__file__).parents[1] / "output" / "b1_fold_R1sq_vs_m.json"

# Resident HIV reproduction number of the E2 state used throughout the article.
RH = 1.8
# Target TB-invasion number of the TB-only boundary fold.
R1SQ_TARGET = 0.956
# Rounded fold position quoted in the supplementary text.
M_REPORTED = 6.897


def main():
    P = COMMON.P
    m_c = COMMON.compute_m_c_TB_analytic(P)

    points = COMMON.trace_tb_LP_curve_by_I(p=P, m_min=6.0, I_end=2.0, n_I=140)
    points = sorted((q for q in points if q.get("valid")), key=lambda q: q["m"])

    curve = []
    for q in points:
        beta1 = COMMON.beta1_from_RT(q["RT"], P)
        curve.append(
            {
                "m": float(q["m"]),
                "R1_standalone": float(q["RT"]),
                "R1sq": float(COMMON.RTH_for_beta1(beta1, RH, P)),
            }
        )

    m_grid = np.array([row["m"] for row in curve])
    r1_grid = np.array([row["R1sq"] for row in curve])
    rt_grid = np.array([row["R1_standalone"] for row in curve])

    m_at_target = float(np.interp(R1SQ_TARGET, r1_grid, m_grid))
    rt_at_target = float(np.interp(R1SQ_TARGET, r1_grid, rt_grid))

    # Direct fold solve at the reported m, so the archived numbers are not
    # interpolated from the tracing grid.
    seed = np.array(
        [points[int(np.argmin(np.abs(m_grid - M_REPORTED)))]["I"],
         points[int(np.argmin(np.abs(m_grid - M_REPORTED)))]["RT"]]
    )
    solution = least_squares(
        lambda v: COMMON._tb_LP_system(v, M_REPORTED, P),
        seed,
        bounds=([1e-12, 0.05], [np.inf, 3.0]),
        xtol=1e-13,
        ftol=1e-13,
        gtol=1e-13,
        max_nfev=2000,
    )
    I_fold, RT_fold = solution.x
    fold_valid, _ = COMMON._tb_LP_validate(
        I_fold, RT_fold, M_REPORTED, P, tol_fold=1e-6
    )
    r1sq_at_reported = float(
        COMMON.RTH_for_beta1(COMMON.beta1_from_RT(RT_fold, P), RH, P)
    )

    payload = {
        "description": (
            "TB-only boundary fold as a function of the response sensitivity m, "
            "evaluated as the TB-invasion number of the resident HIV-endemic "
            "state at R2=1.8 (supplementary mechanism-control text)."
        ),
        "method": {
            "fold_tracer": "trace_tb_LP_curve_by_I (bifurcation/code/00_common.py)",
            "invasion_number": "RTH_for_beta1 (bifurcation/code/00_common.py)",
            "resident_HIV_R2": RH,
            "params_source": "00_common.Params (P)",
            "trace_range": {"m_min": 6.0, "I_end": 2.0, "n_I": 140},
        },
        "analytic_codim2_m_cTB": float(m_c),
        "R1sq_target": R1SQ_TARGET,
        "m_at_R1sq_target": m_at_target,
        "R1_standalone_at_target": rt_at_target,
        "reported_m": {
            "m": M_REPORTED,
            "R1_standalone": float(RT_fold),
            "R1sq": r1sq_at_reported,
            "fold_valid": bool(fold_valid),
            "fold_residual_norm": float(np.linalg.norm(solution.fun)),
        },
        "match": {
            "m_within_0.001": bool(abs(m_at_target - M_REPORTED) < 1.0e-3),
            "R1_within_0.01": bool(abs(RT_fold - 0.78) < 1.0e-2),
            "R1sq_within_0.001": bool(abs(r1sq_at_reported - R1SQ_TARGET) < 1.0e-3),
        },
        "fold_curve": curve,
    }

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    print(f"wrote {OUT_PATH}")
    print(f"  m_c^TB = {m_c:.6f}")
    print(f"  m at R1^2 = {R1SQ_TARGET} = {m_at_target:.6f} (R1 = {rt_at_target:.6f})")
    print(
        f"  at m = {M_REPORTED}: R1 = {RT_fold:.6f}, "
        f"R1^2 = {r1sq_at_reported:.9f}, valid = {fold_valid}"
    )
    print(f"  match = {payload['match']}")
    print(f"  curve points = {len(curve)}")


if __name__ == "__main__":
    main()
