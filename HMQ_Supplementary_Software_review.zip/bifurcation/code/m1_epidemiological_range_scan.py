"""M1: bounded epidemiological-scale parameter-range scan.

This scan is deliberately a robustness check over prespecified parameter
ranges, not a probability distribution and not a country calibration.  It keeps the population
normalisation fixed (N0=10,000) and samples the dimensional rates used by the
TB-only reduction together with the healthcare-response endpoints.  The
saturation coefficients are sampled in the dimensionless coordinates

    omega_tilde = N0 * omega,

then converted back to the individual-based units used by the ODE.  This
prevents a change in the arbitrary population normalisation from changing the
meaning of a saturation parameter.

The primary screen is analytic: compute m_c^TB for every sampled parameter
set and ask whether the default m=0.05 lies in the backward-bifurcation
region.  A deterministic subset is then checked directly with the scalar
TB-only equilibrium solver on R1 in [0.40, 0.999].  The direct check is a
finite grid diagnostic; it is not a global branch-completeness claim.

Outputs (relative to this file):
  ../output/m1_epidemiological_range_scan.csv
  ../output/m1_epidemiological_range_scan.json
  ../figures/fig_M1_epidemiological_range_scan.{pdf,svg,png}
  ../figures/m1_epidemiological_range_scan_summary.txt
"""

from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import replace
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "output"
FIG = HERE.parent / "figures"
OUT.mkdir(parents=True, exist_ok=True)
FIG.mkdir(parents=True, exist_ok=True)

# Load the shared model module without relying on the launch directory.
spec = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
common = importlib.util.module_from_spec(spec)
sys.modules["common"] = common
spec.loader.exec_module(common)


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------

SEED = 20260912
N_SAMPLES = 256
N_DIRECT_CHECK = 64
M_REFERENCE = 0.05
M_SECONDARY = 1.0
RT_MIN = 0.40
RT_MAX = 0.999
RT_POINTS = 31
ROOT_GRID = 96

# The tested ranges are intentionally transparent.  The first nine rates bracket
# the Roeger-style values and the alternative values documented in the
# repository's parameter-verification report; theta and sigma_rel are modest
# susceptibility multipliers.  Response parameters are broad enough to
# include the current synthetic preset and the Tanvi-style order of magnitude
# while excluding negative, non-ordered, or singular response curves.
BOUNDS = {
    "mu": (0.010, 0.020),
    "k": (0.20, 0.60),
    "d": (0.05, 0.20),
    "k_star": (1.00, 3.00),
    "d_star": (0.10, 0.40),
    "alpha1": (0.05, 0.15),
    "alpha2": (0.10, 0.30),
    "alpha3": (0.25, 0.75),
    "f": (0.25, 0.75),
    "theta": (0.90, 1.10),
    "sigma_rel": (0.90, 1.10),
    "a0": (0.30, 0.90),
    "a_max": (0.80, 2.00),
    # Sample omega in dimensionless coordinates; raw omega is derived below.
    # Throughput-constrained ranges: with a_max <= 2 yr^-1 this implies a
    # high-load limit a_max/omega_min_tilde <= 0.10 population fractions/yr.
    # The illustrative baseline (omega_min_tilde=0.1) is retained as a
    # separately reported reference row because it lies outside this
    # deliberately epidemiological-scale range.
    "omega0_tilde": (20.0, 1000.0),
    "omega_min_tilde": (20.0, 400.0),
}


def _lhs_uniform(rng: np.random.Generator, n: int, lo: float, hi: float) -> np.ndarray:
    """One-dimensional Latin-hypercube draw with deterministic seed."""
    u = (np.arange(n, dtype=float) + rng.random(n)) / n
    rng.shuffle(u)
    return lo + (hi - lo) * u


def _lhs_log_uniform(rng: np.random.Generator, n: int, lo: float, hi: float) -> np.ndarray:
    return np.exp(_lhs_uniform(rng, n, np.log(lo), np.log(hi)))


def make_samples() -> list[dict[str, float]]:
    """Generate an ordered LHS, rejecting invalid endpoint orderings."""
    rng = np.random.default_rng(SEED)
    keys = list(BOUNDS)
    samples: list[dict[str, float]] = []
    # Rejection is only for physically ordered response endpoints.  Draw in
    # batches so the resulting sample count is exactly reproducible.
    while len(samples) < N_SAMPLES:
        n = max(2 * (N_SAMPLES - len(samples)), 64)
        block: dict[str, np.ndarray] = {}
        for key in keys:
            lo, hi = BOUNDS[key]
            if key.startswith("omega"):
                block[key] = _lhs_log_uniform(rng, n, lo, hi)
            else:
                block[key] = _lhs_uniform(rng, n, lo, hi)
        for i in range(n):
            row = {key: float(block[key][i]) for key in keys}
            if row["a_max"] <= row["a0"] + 0.05:
                continue
            if row["omega_min_tilde"] >= 0.95 * row["omega0_tilde"]:
                continue
            samples.append(row)
            if len(samples) == N_SAMPLES:
                break
    return samples


def params_from_row(row: dict[str, float]):
    p0 = common.get_params("illustrative_backward")
    return replace(
        p0,
        mu=row["mu"],
        k=row["k"],
        d=row["d"],
        k_star=row["k_star"],
        d_star=row["d_star"],
        alpha1=row["alpha1"],
        alpha2=row["alpha2"],
        alpha3=row["alpha3"],
        f=row["f"],
        theta=row["theta"],
        sigma_rel=row["sigma_rel"],
        a0=row["a0"],
        a_max=row["a_max"],
        omega0=row["omega0_tilde"] / p0.N0,
        omega_min=row["omega_min_tilde"] / p0.N0,
    )


def _n_of_m(m: float, p) -> float:
    """Centre-manifold numerator N(m), matching compute_m_c_TB_analytic."""
    mu, k, d = p.mu, p.k, p.d
    a0, amax, omega0, lam = p.a0, p.a_max, p.omega0, p.Lambda
    term1 = 2.0 * a0 * omega0 * (((mu + d + a0) / k) ** 2 + (mu + k + a0) / k)
    term2 = 2.0 * mu * (mu + k + a0) * (mu + d + a0) * (mu + d + a0 + k) / (k * k * lam)
    term3 = 2.0 * mu * (amax - a0) * (2.0 * mu + k + d + 2.0 * a0) * (1.0 + m) / (k * lam)
    return float(term1 - term2 - term3)


def _asymptotic_throughput_per_population(p, high: bool = True) -> float:
    """High-load limit divided by N0, in fractions of population per year."""
    if high:
        return float(p.a_max / (p.N0 * p.omega_min))
    return float(p.a0 / (p.N0 * p.omega0))


def direct_tb_check(p, m: float) -> dict[str, float | bool | None]:
    """Finite-grid check for stable endemic TB roots below R1=1."""
    hits = 0
    stable_hits = 0
    min_rt = None
    max_burden = 0.0
    for rt in np.linspace(RT_MIN, RT_MAX, RT_POINTS):
        beta1 = common.beta1_from_RT(float(rt), p)
        eqs = common.find_tb_endemic_equilibria(beta1, m, p, n_grid=ROOT_GRID)
        sub = [eq for eq in eqs if rt < 1.0 - 1e-12]
        if sub:
            hits += 1
            min_rt = float(rt) if min_rt is None else min(min_rt, float(rt))
            max_burden = max(max_burden, max(float(eq[2] / np.sum(eq)) for eq in sub))
        for eq in sub:
            stable, _, _ = common.tb_stability(eq, beta1, m, p)
            if stable:
                stable_hits += 1
    return {
        "grid_subthreshold_hits": int(hits),
        "grid_stable_subthreshold_hits": int(stable_hits),
        "stable_subthreshold_detected": bool(stable_hits > 0),
        "grid_min_subthreshold_RT": min_rt,
        "grid_max_subthreshold_burden": float(max_burden),
    }


def build_rows(samples: list[dict[str, float]]) -> tuple[list[dict], list[int]]:
    rows: list[dict] = []
    # Spread the direct checks over the LHS order, while always checking the
    # exact baseline row added below if it is not selected naturally.
    direct_indices = np.unique(np.linspace(0, N_SAMPLES - 1, N_DIRECT_CHECK, dtype=int)).tolist()
    direct_set = set(direct_indices)
    for i, row in enumerate(samples):
        p = params_from_row(row)
        mc = float(common.compute_m_c_TB_analytic(p))
        out = dict(row)
        out.update({
            "sample_id": int(i),
            "N0": float(p.N0),
            "Lambda": float(p.Lambda),
            "omega0": float(p.omega0),
            "omega_min": float(p.omega_min),
            "m_c_TB": mc,
            "N_at_m_reference": _n_of_m(M_REFERENCE, p),
            "N_at_m_secondary": _n_of_m(M_SECONDARY, p),
            "backward_at_m_reference": bool(_n_of_m(M_REFERENCE, p) > 0.0),
            "backward_at_m_secondary": bool(_n_of_m(M_SECONDARY, p) > 0.0),
            "low_burden_throughput_fraction_per_year": _asymptotic_throughput_per_population(p, high=False),
            "high_burden_throughput_fraction_per_year": _asymptotic_throughput_per_population(p, high=True),
            "direct_check_performed": bool(i in direct_set),
        })
        if i in direct_set:
            out.update({f"m05_{k}": v for k, v in direct_tb_check(p, M_REFERENCE).items()})
            out.update({f"m1_{k}": v for k, v in direct_tb_check(p, M_SECONDARY).items()})
        else:
            for prefix in ("m05", "m1"):
                for key in ("grid_subthreshold_hits", "grid_stable_subthreshold_hits",
                            "stable_subthreshold_detected", "grid_min_subthreshold_RT",
                            "grid_max_subthreshold_burden"):
                    out[f"{prefix}_{key}"] = None
        rows.append(out)
    return rows, direct_indices


def baseline_row() -> dict:
    p = common.get_params("illustrative_backward")
    mc = float(common.compute_m_c_TB_analytic(p))
    return {
        "sample_id": "baseline",
        "mu": p.mu, "k": p.k, "d": p.d, "k_star": p.k_star,
        "d_star": p.d_star, "alpha1": p.alpha1, "alpha2": p.alpha2,
        "alpha3": p.alpha3, "f": p.f, "theta": p.theta,
        "sigma_rel": p.sigma_rel, "a0": p.a0, "a_max": p.a_max,
        "omega0_tilde": p.N0 * p.omega0,
        "omega_min_tilde": p.N0 * p.omega_min,
        "N0": p.N0, "Lambda": p.Lambda, "omega0": p.omega0,
        "omega_min": p.omega_min, "m_c_TB": mc,
        "N_at_m_reference": _n_of_m(M_REFERENCE, p),
        "N_at_m_secondary": _n_of_m(M_SECONDARY, p),
        "backward_at_m_reference": bool(_n_of_m(M_REFERENCE, p) > 0.0),
        "backward_at_m_secondary": bool(_n_of_m(M_SECONDARY, p) > 0.0),
        "low_burden_throughput_fraction_per_year": _asymptotic_throughput_per_population(p, high=False),
        "high_burden_throughput_fraction_per_year": _asymptotic_throughput_per_population(p, high=True),
        "direct_check_performed": True,
        **{f"m05_{k}": v for k, v in direct_tb_check(p, M_REFERENCE).items()},
        **{f"m1_{k}": v for k, v in direct_tb_check(p, M_SECONDARY).items()},
    }


def write_outputs(rows: list[dict], direct_indices: list[int]) -> dict:
    csv_path = OUT / "m1_epidemiological_range_scan.csv"
    fieldnames = list(rows[0])
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    sampled = [r for r in rows if r["sample_id"] != "baseline"]
    mcs = np.array([float(r["m_c_TB"]) for r in sampled])
    positive_mc = np.isfinite(mcs) & (mcs > 0)
    m05 = np.array([bool(r["backward_at_m_reference"]) for r in sampled])
    m1 = np.array([bool(r["backward_at_m_secondary"]) for r in sampled])
    checked = [r for r in sampled if r["direct_check_performed"]]
    check_m05 = [r for r in checked if r["m05_stable_subthreshold_detected"]]
    check_m1 = [r for r in checked if r["m1_stable_subthreshold_detected"]]

    summary = {
        "protocol": {
            "seed": SEED,
            "n_samples": N_SAMPLES,
            "n_direct_checks": N_DIRECT_CHECK,
            "m_reference": M_REFERENCE,
            "m_secondary": M_SECONDARY,
            "RT_grid": [RT_MIN, RT_MAX, RT_POINTS],
            "root_grid": ROOT_GRID,
            "N0_fixed": common.get_params().N0,
            "omega_coordinate": "omega_tilde=N0*omega",
            "bounds": BOUNDS,
            "scope": "robustness check over prespecified parameter ranges; not a probability distribution or country calibration",
        },
        "baseline": rows[-1],
        "summary": {
            "positive_finite_m_c_fraction": float(np.mean(positive_mc)),
            "m_c_median": float(np.nanmedian(mcs)),
            "m_c_p10": float(np.nanpercentile(mcs, 10)),
            "m_c_p90": float(np.nanpercentile(mcs, 90)),
            "m_c_range_positive": [float(np.nanmin(mcs[positive_mc])), float(np.nanmax(mcs[positive_mc]))],
            "backward_at_m_0.05_fraction": float(np.mean(m05)),
            "backward_at_m_1_fraction": float(np.mean(m1)),
            "direct_check_m_0.05_stable_fraction": float(len(check_m05) / max(1, len(checked))),
            "direct_check_m_1_stable_fraction": float(len(check_m1) / max(1, len(checked))),
            "direct_check_count": len(checked),
            "direct_check_ids": direct_indices,
            "high_burden_throughput_fraction_per_year_range": [
                float(min(r["high_burden_throughput_fraction_per_year"] for r in sampled)),
                float(max(r["high_burden_throughput_fraction_per_year"] for r in sampled)),
            ],
        },
        # Retain the complete row-level record in JSON as well as CSV.  This
        # makes the archive self-contained when only the machine-readable
        # summary file is deposited.
        "rows": rows,
    }
    json_path = OUT / "m1_epidemiological_range_scan.json"
    json_path.write_text(json.dumps(summary, indent=2, allow_nan=False), encoding="utf-8")
    return summary


def make_figure(rows: list[dict], summary: dict) -> None:
    import matplotlib as mpl
    mpl.use("Agg")
    import matplotlib.pyplot as plt

    mpl.rcParams.update({
        "font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "mathtext.fontset": "stix", "axes.labelsize": 10, "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5, "axes.spines.top": False, "axes.spines.right": False,
        "figure.dpi": 180, "savefig.dpi": 600, "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    sampled = [r for r in rows if r["sample_id"] != "baseline"]
    x = np.array([r["high_burden_throughput_fraction_per_year"] for r in sampled])
    y = np.array([r["m_c_TB"] for r in sampled])
    c = np.array([r["omega0_tilde"] for r in sampled])
    flag = np.array([r["backward_at_m_reference"] for r in sampled])
    base = rows[-1]

    fig, (ax0, ax1) = plt.subplots(1, 2, figsize=(7.6, 3.35))
    sc = ax0.scatter(x[flag], y[flag], c=c[flag], cmap="viridis", s=18, alpha=0.78,
                     edgecolors="none", label=r"$\mathcal{N}(0.05)>0$")
    if np.any(~flag):
        ax0.scatter(x[~flag], y[~flag], c=c[~flag], cmap="viridis", s=18, alpha=0.35,
                    marker="x", label=r"$\mathcal{N}(0.05)\leq0$")
    ax0.scatter([base["high_burden_throughput_fraction_per_year"]], [base["m_c_TB"]],
                marker="*", s=95, color="#B2182B", edgecolor="white", linewidth=0.7,
                zorder=5, label="baseline")
    ax0.set_xscale("log"); ax0.set_yscale("log")
    ax0.set_xlabel(r"High-load throughput limit / $N_0$ (yr$^{-1}$)")
    ax0.set_ylabel(r"Analytic $m_c^{\mathrm{TB}}$")
    ax0.grid(True, color="#E8E8E8", linewidth=0.45)
    ax0.legend(frameon=False, fontsize=7.4, loc="best")
    cb = fig.colorbar(sc, ax=ax0, pad=0.02)
    cb.set_label(r"$\widetilde\omega_0=N_0\omega_0$", fontsize=8.5)

    labels = [r"$m=0.05$", r"$m=1$", r"direct root check, $m=0.05$", r"direct root check, $m=1$"]
    vals = [
        summary["summary"]["backward_at_m_0.05_fraction"],
        summary["summary"]["backward_at_m_1_fraction"],
        summary["summary"]["direct_check_m_0.05_stable_fraction"],
        summary["summary"]["direct_check_m_1_stable_fraction"],
    ]
    colors = ["#238B45", "#66A61E", "#0B3C5D", "#756BB1"]
    yy = np.arange(len(labels))
    ax1.barh(yy, vals, color=colors, alpha=0.88)
    ax1.set_yticks(yy, labels)
    ax1.set_xlim(0, 1.05)
    ax1.set_xlabel("Fraction of sampled sets")
    ax1.grid(True, axis="x", color="#E8E8E8", linewidth=0.45)
    ax1.invert_yaxis()
    for yi, value in zip(yy, vals):
        ax1.text(min(value + 0.02, 0.98), yi, f"{value:.2f}", va="center", fontsize=8)
    fig.tight_layout()
    for ext, kwargs in (("pdf", {}), ("svg", {}), ("png", {"dpi": 600})):
        fig.savefig(FIG / f"fig_M1_epidemiological_range_scan.{ext}", bbox_inches="tight", pad_inches=0.03, **kwargs)
    plt.close(fig)


def main() -> None:
    print(f"M1 scan: seed={SEED}, samples={N_SAMPLES}, direct checks={N_DIRECT_CHECK}", flush=True)
    samples = make_samples()
    rows, direct_indices = build_rows(samples)
    # Put the baseline last so the JSON and plot can reference it without a
    # special search, while the CSV still retains all generated values.
    rows.append(baseline_row())
    summary = write_outputs(rows, direct_indices)
    make_figure(rows, summary)
    s = summary["summary"]
    lines = [
        "M1 epidemiological-scale range scan",
        "=" * 50,
        f"seed={SEED}; sampled parameter sets={N_SAMPLES}; direct TB-only checks={N_DIRECT_CHECK}",
        f"omega coordinate: omega_tilde=N0*omega; N0 fixed at {common.get_params().N0:g}",
        f"positive finite m_c fraction={s['positive_finite_m_c_fraction']:.3f}",
        f"m_c median={s['m_c_median']:.6g}; 10th--90th percentile={s['m_c_p10']:.6g}--{s['m_c_p90']:.6g}; positive range={s['m_c_range_positive'][0]:.6g}--{s['m_c_range_positive'][1]:.6g}",
        f"backward condition at m=0.05: {s['backward_at_m_0.05_fraction']:.3f}",
        f"backward condition at m=1: {s['backward_at_m_1_fraction']:.3f}",
        f"direct stable subthreshold roots at m=0.05: {s['direct_check_m_0.05_stable_fraction']:.3f}",
        f"direct stable subthreshold roots at m=1: {s['direct_check_m_1_stable_fraction']:.3f}",
        f"high-load throughput/N0 range={s['high_burden_throughput_fraction_per_year_range'][0]:.4g}--{s['high_burden_throughput_fraction_per_year_range'][1]:.4g} yr^-1",
        "Interpretation: robustness check over prespecified parameter ranges, not a probability distribution, country calibration, or global branch-completeness test.",
    ]
    (FIG / "m1_epidemiological_range_scan_summary.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
