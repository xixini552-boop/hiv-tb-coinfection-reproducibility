"""Partial rank correlation coefficients (PRCC) for the active-TB burden.

The supplementary text reports PRCCs of the equilibrium active-TB burden with
respect to all model parameters and states that the response-shape parameter
``m`` and the treatment endpoints ``a0``/``a_max`` are among the most
influential inputs.  This script produces that ranking from a Latin-hypercube
sample of the TB-only reduction.

Protocol
--------
* 2000 Latin-hypercube samples (seed 20261016) over the epidemiological rates,
  the two susceptibility multipliers, the response endpoints, the two
  dimensionless saturation coefficients, and the response-shape parameter
  ``m`` in the tested range ``[0.001, 10]``.
* For each sample the TB-only equilibrium active-TB burden ``I*/N*`` is
  evaluated at a fixed subthreshold ``R1 = 0.8``.  Samples without a stable
  endemic equilibrium return zero burden, which is the model-consistent
  response when the subthreshold branch is absent.
* PRCC is the correlation of the rank residuals after linear regression on the
  ranks of the remaining parameters; the reported p-value uses the usual
  t approximation with ``n - p - 2`` degrees of freedom.

Outputs
-------
  ../output/prcc_response_sensitivity.json
  ../output/prcc_response_sensitivity.csv
"""

from __future__ import annotations

import csv
import importlib.util
import json
import sys
from dataclasses import replace
from pathlib import Path

import numpy as np
from scipy.stats import rankdata, t as student_t


HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "output"
OUT.mkdir(parents=True, exist_ok=True)

_spec = importlib.util.spec_from_file_location("common", str(HERE / "00_common.py"))
COMMON = importlib.util.module_from_spec(_spec)
sys.modules["common"] = COMMON
_spec.loader.exec_module(COMMON)


SEED = 20261016
N_SAMPLES = 2000
TB_REPRODUCTION = 0.8
M_BOUNDS = (0.001, 10.0)

# Same ranges as the M1 epidemiological-scale scan, plus the response-shape
# parameter m.  omega0/omega_min are sampled in the dimensionless coordinates
# omega_tilde = N0 * omega.
BOUNDS = {
    "mu": (0.010, 0.020),
    "k": (0.20, 0.60),
    "d": (0.05, 0.20),
    "k_star": (1.00, 3.00),
    "d_star": (0.10, 0.40),
    "alpha1": (0.05, 0.15),
    "alpha2": (0.10, 0.30),
    "alpha3": (0.25, 0.75),
    "f": (0.25, 0.75),
    "theta": (0.90, 1.10),
    "sigma_rel": (0.90, 1.10),
    "a0": (0.30, 0.90),
    "a_max": (0.80, 2.00),
    "omega0_tilde": (20.0, 1000.0),
    "omega_min_tilde": (20.0, 400.0),
    "m": M_BOUNDS,
}

LOG_SCALE = ("omega0_tilde", "omega_min_tilde")


def _lhs_uniform(rng, n, lo, hi):
    u = (np.arange(n, dtype=float) + rng.random(n)) / n
    rng.shuffle(u)
    return lo + (hi - lo) * u


def _lhs_log_uniform(rng, n, lo, hi):
    return np.exp(_lhs_uniform(rng, n, np.log(lo), np.log(hi)))


def make_samples() -> list[dict[str, float]]:
    rng = np.random.default_rng(SEED)
    keys = list(BOUNDS)
    samples: list[dict[str, float]] = []
    while len(samples) < N_SAMPLES:
        n = max(2 * (N_SAMPLES - len(samples)), 64)
        block = {}
        for key in keys:
            lo, hi = BOUNDS[key]
            if key in LOG_SCALE:
                block[key] = _lhs_log_uniform(rng, n, lo, hi)
            else:
                block[key] = _lhs_uniform(rng, n, lo, hi)
        for i in range(n):
            row = {key: float(block[key][i]) for key in keys}
            if row["a_max"] <= row["a0"] + 0.05:
                continue
            if row["omega_min_tilde"] >= 0.95 * row["omega0_tilde"]:
                continue
            samples.append(row)
    # Batched draws can overshoot the target; keep exactly N_SAMPLES so the
    # realized sample size matches the value reported in the manuscript.
    return samples[:N_SAMPLES]


def parameters_from(row: dict[str, float]):
    return replace(
        COMMON.P,
        mu=row["mu"],
        k=row["k"],
        d=row["d"],
        k_star=row["k_star"],
        d_star=row["d_star"],
        alpha1=row["alpha1"],
        alpha2=row["alpha2"],
        alpha3=row["alpha3"],
        f=row["f"],
        theta=row["theta"],
        sigma_rel=row["sigma_rel"],
        a0=row["a0"],
        a_max=row["a_max"],
        omega0=row["omega0_tilde"] / COMMON.P.N0,
        omega_min=row["omega_min_tilde"] / COMMON.P.N0,
    )


def active_burden(parameters, response_sensitivity, tb_reproduction):
    """Stable TB-only equilibrium active-TB burden at fixed R1 (0 if none)."""
    beta1 = COMMON.beta1_from_RT(tb_reproduction, parameters)
    equilibria = COMMON.find_tb_endemic_equilibria(
        beta1,
        response_sensitivity,
        parameters,
        n_grid=400,
    )
    burden = 0.0
    for equilibrium in equilibria:
        stable, _, _ = COMMON.tb_stability(
            equilibrium,
            beta1,
            response_sensitivity,
            parameters,
        )
        if stable:
            burden = max(burden, float(equilibrium[2] / np.sum(equilibrium)))
    return burden


def prcc_table(matrix, response):
    """PRCC of each column of ``matrix`` with ``response``."""
    n, p = matrix.shape
    ranks = rankdata(matrix, axis=0)
    response_rank = rankdata(response)
    dof = n - p - 2
    values = {}
    for j in range(p):
        others = np.delete(ranks, j, axis=1)
        design = np.column_stack([np.ones(n), others])
        residual_x = ranks[:, j] - design @ np.linalg.lstsq(
            design, ranks[:, j], rcond=None
        )[0]
        residual_y = response_rank - design @ np.linalg.lstsq(
            design, response_rank, rcond=None
        )[0]
        rho = float(np.corrcoef(residual_x, residual_y)[0, 1])
        denom = max(1.0e-300, 1.0 - rho * rho)
        statistic = rho * np.sqrt(dof / denom)
        p_value = float(2.0 * student_t.sf(abs(statistic), dof))
        values[j] = {"prcc": rho, "p_value": p_value}
    return values


def main():
    print("=" * 64)
    print("PRCC of equilibrium active-TB burden")
    print("=" * 64)

    samples = make_samples()
    keys = list(BOUNDS)
    burdens = np.zeros(len(samples))
    for index, row in enumerate(samples):
        burdens[index] = active_burden(
            parameters_from(row),
            row["m"],
            TB_REPRODUCTION,
        )

    matrix = np.array([[row[key] for key in keys] for row in samples], dtype=float)
    table = prcc_table(matrix, burdens)

    ordered = sorted(
        (
            {"parameter": keys[j], **table[j]}
            for j in range(len(keys))
        ),
        key=lambda item: -abs(item["prcc"]),
    )
    for item in ordered:
        print(
            f"  {item['parameter']:>16s}  PRCC={item['prcc']:+.4f}  "
            f"p={item['p_value']:.3e}"
        )

    payload = {
        "definition": (
            "Partial rank correlation coefficient of the stable TB-only "
            "equilibrium active-TB burden I*/N* at fixed R1 with respect to "
            "each model parameter."
        ),
        "tb_reproduction": TB_REPRODUCTION,
        "n_samples": int(len(samples)),
        "seed": SEED,
        "sampling": "Latin hypercube; omega0/omega_min in dimensionless "
                    "coordinates omega_tilde = N0 * omega; m in [0.001, 10]",
        "bounds": {key: list(value) for key, value in BOUNDS.items()},
        "non_positive_burden_fraction": float(np.mean(burdens <= 0.0)),
        "ranking": ordered,
    }

    (OUT / "prcc_response_sensitivity.json").write_text(
        json.dumps(payload, indent=2),
        encoding="utf-8",
    )
    with (OUT / "prcc_response_sensitivity.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.writer(handle)
        writer.writerow(["parameter", "prcc", "p_value"])
        for item in ordered:
            writer.writerow(
                [item["parameter"], item["prcc"], item["p_value"]]
            )
    print(f"\nSaved: {OUT / 'prcc_response_sensitivity.json'}")
    print("=" * 64)


if __name__ == "__main__":
    main()
