"""Enhanced Fig 7 (reviewer Major Issues 1 & 2).

Same branch computation as 05_full_backward_bifurcation_v4_verified.py, but the
HIV-free TB-only boundary is now split at BP1 into:
  * full-system stable segment (resident AND transverse stable), solid;
  * resident-stable but HIV-transverse-unstable segment (resident fold -> BP1),
    dash-dot, to make the four-way stability distinction explicit.
The full-system bistability window BP1 <= R_1^2 < 1 is shaded.
"""
import importlib.util
import sys
from pathlib import Path
import numpy as np
from scipy.linalg import eigvals
from scipy.optimize import brentq
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "mod05", str(here / "05_full_backward_bifurcation_v4_verified.py"))
mod = importlib.util.module_from_spec(spec)
sys.modules["mod05"] = mod
spec.loader.exec_module(mod)

# bring names to local scope
for _n in dir(mod):
    if not _n.startswith("_"):
        globals()[_n] = getattr(mod, _n)

P = mod.P
RH, M, BETA2 = mod.RH, mod.M, mod.BETA2
STABLE_COLOR = "#0B3C5D"
TRANSVERSE_UNSTABLE_COLOR = "#7B5EA7"   # purple: resident-stable only
INTERIOR_STABLE_COLOR = "#238B45"
UNSTABLE_COLOR = "#B2182B"
TB_FREE_COLOR = "#4D4D4D"
FOLD_COLOR = "#D4A017"
BISTAB_COLOR = "#F2EFB3"


def resident_eig(Q):
    """Max real eigenvalue of the TB-only (HIV-free) reduced Jacobian."""
    x = mod.tb_only_state(Q)
    if x is None:
        return np.nan
    beta1 = mod.beta1_from_RTH(float(Q), RH, P)
    J = mod.central_numerical_jacobian(
        lambda y: mod.rhs_full(y, beta1, BETA2, M, P), x, ())
    # TB-only invariant subsystem is S,L,I,T = indices [0,1,2,3] (matches rhs_tb).
    # The 8D Jacobian is block-lower-triangular on the HIV-free boundary, so its
    # TB block eigenvalues are exactly the resident (longitudinal) eigenvalues.
    idx = [0, 1, 2, 3]
    return float(np.max(np.real(eigvals(J[np.ix_(idx, idx)]))))


def main():
    mod.set_publication_style()
    bp1 = mod.locate_tb_hiv_branch_point()
    # LP2 + interior branches (identical to 05)
    roots_2 = mod.equilibrium_records(1.0525)
    low_seed = min((r for r in roots_2 if r["stable"]
                    and r.get("eq_class") == "co_endemic"),
                   key=lambda r: r["burden"])
    lp2 = mod.solve_fold(low_seed["state"], 1.0525, 1.00, 1.12, "LP2")
    q2_in = lp2["Q"] - mod.EPS_FOLD
    roots_q2 = mod.equilibrium_records(q2_in, previous=[low_seed["state"]])
    low0 = mod.nearest_record(roots_q2, lp2["state"], stable=True,
                              eq_class="co_endemic")
    low = mod.follow_branch(np.linspace(q2_in, 1.0 + mod.EPS_TC, mod.N_BRANCH),
                            low0, stable=True, eq_class="co_endemic")
    middle0, q_middle_start = None, None
    for q in np.linspace(bp1["Q"] + 2e-3, 0.80, 32):
        roots = mod.equilibrium_records(float(q), previous=[bp1["state"]])
        cand = mod.nearest_record(roots, bp1["state"], stable=False,
                                  eq_class="co_endemic")
        if cand is not None:
            middle0, q_middle_start = cand, float(q)
            break
    middle = mod.follow_branch(np.linspace(q_middle_start, q2_in, mod.N_BRANCH),
                               middle0, stable=False, eq_class="co_endemic") \
        if middle0 is not None else []

    # TB-only boundary: full-system stable segment starts at BP1 (as in 05)
    tb_stable = [r for r in (mod.tb_boundary_record(q)
                             for q in np.linspace(bp1["Q"], mod.Q_MAX, mod.N_BRANCH))
                 if r is not None]
    # Resident fold on the TB-only boundary
    qgrid = np.linspace(0.59, bp1["Q"] - 1e-3, 200)
    prev = None
    q_res_fold = None
    for q in qgrid:
        v = resident_eig(q)
        if prev is not None and np.isfinite(v) and np.isfinite(prev[1]) and prev[1] * v < 0:
            q_res_fold = brentq(resident_eig, prev[0], q, xtol=1e-11)
            break
        prev = (q, v)
    # Transverse-unstable segment: resident fold -> BP1
    tb_trans_unstable = []
    if q_res_fold is not None:
        for q in np.linspace(q_res_fold, bp1["Q"], mod.N_BRANCH):
            r = mod.tb_boundary_record(q)
            if r is not None:
                tb_trans_unstable.append(r)

    bp1_rec = {"Q": bp1["Q"], "state": bp1["state"], "burden": bp1["burden"], "stable": None}
    lp2_rec = {"Q": lp2["Q"], "state": lp2["state"], "burden": lp2["burden"], "stable": None}
    middle_plot = ([bp1_rec] if not middle or middle[0]["Q"] > bp1["Q"] else []) + middle + [lp2_rec]
    low_plot = [{"Q": 1.0, "state": mod.E2, "burden": 0.0, "stable": None}] + list(reversed(low)) + [lp2_rec]

    fig, ax = plt.subplots(figsize=(6.7, 4.4))
    ymax = 1.14 * max(r["burden"] for r in tb_stable)
    # bistability window BP1 <= Q < 1
    ax.axvspan(bp1["Q"], 1.0, color=BISTAB_COLOR, alpha=0.55, zorder=0)
    ax.text(0.5 * (bp1["Q"] + 1.0), 0.97 * ymax, "full-system\nbistability",
            ha="center", va="top", fontsize=7.6, style="italic", zorder=1)
    # TB-free branch
    ax.plot(np.linspace(mod.Q_MIN, 1.0, 250), np.zeros(250), color=TB_FREE_COLOR, linewidth=1.65, zorder=3)
    ax.plot(np.linspace(1.0, mod.Q_MAX, 250), np.zeros(250), color=TB_FREE_COLOR,
            linestyle=(0, (4.2, 2.2)), linewidth=1.55, zorder=3)
    # transverse-unstable boundary segment (resident stable, HIV-transverse unstable)
    if tb_trans_unstable:
        ax.plot([r["Q"] for r in tb_trans_unstable], [r["burden"] for r in tb_trans_unstable],
                color=TRANSVERSE_UNSTABLE_COLOR, linestyle=(0, (6, 2, 1.5, 2)), linewidth=2.0, zorder=4)
    # full-system stable boundary segment
    ax.plot([r["Q"] for r in tb_stable], [r["burden"] for r in tb_stable],
            color=STABLE_COLOR, linewidth=2.25, zorder=5)
    ax.plot([r["Q"] for r in middle_plot], [r["burden"] for r in middle_plot],
            color=UNSTABLE_COLOR, linestyle=(0, (4.2, 2.2)), linewidth=2.05, zorder=4)
    ax.plot([r["Q"] for r in low_plot], [r["burden"] for r in low_plot],
            color=INTERIOR_STABLE_COLOR, linewidth=2.25, zorder=5)
    # special points
    if q_res_fold is not None:
        rf = mod.tb_boundary_record(q_res_fold)
        ax.plot(q_res_fold, rf["burden"], marker="o", markersize=6,
                markerfacecolor=TRANSVERSE_UNSTABLE_COLOR, markeredgecolor="#3B1F5A",
                markeredgewidth=1.0, zorder=10)
        ax.annotate(rf"resident fold $\approx${q_res_fold:.3f}", xy=(q_res_fold, rf["burden"]),
                    xytext=(q_res_fold + 0.02, rf["burden"] + 0.075), fontsize=7.4,
                    arrowprops=dict(arrowstyle="->", color="#3B1F5A", linewidth=0.8))
    ax.plot(bp1["Q"], bp1["burden"], marker="^", markersize=7.5,
            markerfacecolor="#6A3D9A", markeredgecolor="#3B1F5A", markeredgewidth=1.2, zorder=10)
    ax.annotate(rf"BP1: $\mathcal{{R}}_1^2\approx${bp1['Q']:.4f}" + "\n" + r"($\mathcal{R}_2^1=1$)",
                xy=(bp1["Q"], bp1["burden"]),
                xytext=(bp1["Q"] + 0.06, bp1["burden"] - 0.085), fontsize=7.4,
                arrowprops=dict(arrowstyle="->", color="#6A3D9A", linewidth=0.9),
                bbox=mod.white_box(alpha=0.85))
    ax.plot(lp2["Q"], lp2["burden"], marker="D", markersize=7.5,
            markerfacecolor=FOLD_COLOR, markeredgecolor="#5C4A00", markeredgewidth=1.2, zorder=10)
    ax.annotate(rf"LP2: $\mathcal{{R}}_1^2\approx${lp2['Q']:.4f}", xy=(lp2["Q"], lp2["burden"]),
                xytext=(lp2["Q"] + 0.04, lp2["burden"] + 0.05), fontsize=7.4,
                arrowprops=dict(arrowstyle="->", color=FOLD_COLOR, linewidth=0.9),
                bbox=mod.white_box(alpha=0.85))
    RTcrit = mod.critical_isolated_RT_for_invasion(RH, P)
    ax.text(mod.Q_MIN + 0.02, 0.82 * ymax,
            rf"$\mathcal{{R}}_2={RH:g}$" + "\n" + rf"$m={M:g}$" + "\n"
            + rf"$\mathcal{{R}}_1^2=1$ at $\mathcal{{R}}_1\approx{RTcrit:.3f}$",
            fontsize=7.8, bbox=mod.white_box(alpha=0.85))
    ax.axvline(1.0, color="#6E6E6E", linestyle="--", linewidth=0.9, zorder=2)
    ax.set_xlim(mod.Q_MIN, mod.Q_MAX)
    ax.set_ylim(-0.025 * ymax, ymax)
    ax.set_xlabel(r"TB invasion reproduction number, $\mathcal{R}_1^2$ "
                  r"(monotone in $\beta_1$ at fixed $\mathcal{R}_2$)")
    ax.set_ylabel(r"Full active TB burden, $(I^*+J_3^*)/N^*$")
    ax.grid(True, color="#E8E8E8", linewidth=0.45, alpha=0.72)
    handles = [
        Line2D([], [], color=STABLE_COLOR, linewidth=2.25,
               label="HIV-free TB boundary, full-system stable"),
        Line2D([], [], color=TRANSVERSE_UNSTABLE_COLOR, linestyle=(0, (6, 2, 1.5, 2)), linewidth=2.0,
               label="TB boundary: resident-stable, HIV-transverse-unstable"),
        Line2D([], [], color=UNSTABLE_COLOR, linestyle=(0, (4.2, 2.2)), linewidth=2.05,
               label="unstable strict co-endemic equilibria"),
        Line2D([], [], color=INTERIOR_STABLE_COLOR, linewidth=2.25,
               label="stable strict co-endemic equilibria"),
        Line2D([], [], color=TB_FREE_COLOR, linewidth=1.65, label="TB-free HIV-endemic branch"),
        Line2D([], [], marker="D", color=FOLD_COLOR, markeredgecolor="#5C4A00", linewidth=0,
               markersize=7, label="interior saddle-node LP2"),
        Line2D([], [], marker="^", color="#6A3D9A", markeredgecolor="#3B1F5A", linewidth=0,
               markersize=7, label="boundary branch point BP1 ($\\mathcal{R}_2^1=1$)"),
    ]
    ax.legend(handles=handles, frameon=False, loc="upper right", fontsize=6.8, handlelength=2.6)
    fig.tight_layout()
    mod.save_fig(fig, "fig_05_enhanced_resident_fold")
    plt.close(fig)
    print(f"resident fold Q={q_res_fold:.6f}; BP1 Q={bp1['Q']:.6f}; LP2 Q={lp2['Q']:.6f}")
    print("Enhanced figure saved.")


if __name__ == "__main__":
    main()
